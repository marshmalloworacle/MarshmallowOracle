# v6.8 — Adaptive Winning Strategy Engine

New page **Adaptive Engine** (dashboard tab). OFF by default; the setting persists (DB) and the running robot applies it within ~3 s, no restart.

## What it does
- Learns from your own **closed** trades (paper + live/testnet journals, pooled and tagged; `learnFrom` = all | live | paper). Open positions, duplicate ids and unknown strategies are never counted.
- Per strategy: net PnL, win rate, profit factor, expectancy, avg win/loss, payoff, max drawdown, win/loss streaks, consistency, long vs short, by symbol, by market regime.
- Edge score 0-100 = decayed recent + long-term expectancy (weights 0.6 / 0.4), profit factor, drawdown, consistency; shrunk toward 50 until `minTrades` (30) is reached. Regime evidence (>= 15 trades in the regime) takes 60% of the score; long/short evidence 15%.
- Favourite uses hysteresis (challenger must lead by 6 points; 0 when the favourite is deteriorating or no longer profitable). Deterioration / recovery are detected from the last 15 trades. Rankings, snapshots and favourite changes are stored.
- Modes: **OFF** original order (shadow notes what ON would have picked) · **ON** up to +8 ranking points for proven strategies, negative for proven weak ones · **STRONG** up to +15 (x1.25 for the favourite); a strategy/regime with >= 50 trades, negative expectancy and PF < 1 is skipped.
- Repetition guard: -5 after 2 recent losses on the same symbol+strategy+direction, -2 after one very recent loss; -2 per extra pick of the same strategy in one scan (max -6).

## Safety
Only re-orders the qualified/fill queue in `robot.js`. Never changes `sig.score`, size, leverage, margin, stops or limits; never adds a signal; every setup still passes `gate.check` and the risk engine; no qualified setup = NO TRADE. Any engine error falls back to the original order.

## Files
New: src/intelligence/adaptive.js, dashboard/adaptiveRoutes.js, dashboard/public/adaptive.js, tests/adaptive_engine.test.js.
Changed: src/robot.js (4 small hooks), src/decisions/log.js (1 map entry), dashboard/server.js, dashboard/liveRoutes.js (asset list), dashboard/public/index.html (tab), .env.example, package.json.
New DB tables (created on first use; trade tables untouched): adaptive_decisions, adaptive_events, adaptive_snapshots.
