'use strict';
/**
 * v5.2.4 routes: decision log, banners, module cards, position advisor, trade controls.
 * Reads come straight from the shared DB. Writes either set a DB switch (leverage, drawdown mode) or are forwarded to the
 * ROBOT process as commands (take trades ON/OFF, close losing/winning). This server never places or cancels an order.
 */
const config = require('../src/config');
const journal = require('../src/journal/store');
const flags = require('../src/features/flags');
const runtime = require('../src/control/runtime');
const dl = require('../src/decisions/log');
const modules = require('../src/intelligence/modules');
const integrity = require('../src/intelligence/integrity');
const presets = require('../src/intelligence/presets');
const outcomes = require('../src/intelligence/outcomes');

function create({ sendJson, parseBody, dispatchCommand }) {
  const guard = (req, res) => {
    if (req.headers['x-alpha'] !== '1') { sendJson(res, 403, { ok: false, error: 'Missing X-Alpha header (request must come from the dashboard).' }); return false; }
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) { sendJson(res, 403, { ok: false, error: 'Cross-site request refused.' }); return false; } } catch (_) { sendJson(res, 403, { ok: false, error: 'Bad origin.' }); return false; } }
    return true;
  };
  const live = () => config.runMode !== 'SIM';
  const controls = () => ({ ok: true, isLive: config.isLive, runMode: config.runMode, mode: config.mode, exchange: config.exchange,
    sizing: runtime.sizing(), presets: { margin: runtime.MARGINS, leverage: runtime.LEVERAGES }, marginStep: config.manualMarginStep, marginMin: config.manualMarginMin, customMargin: config.manualCustomMargin, customLeverage: config.manualCustomLeverage,
    takeLiveTrades: config.isLive ? !journal.getState('live_paused') : !((journal.getState('robot_heartbeat') || {}).paused), takeLiveOnStart: config.takeLiveOnStart, leverage: runtime.leverageChoice() || 'auto', leverageEnv: config.leverageFixed || 'auto',
    drawdownMode: runtime.drawdownMode(), drawdownModeEffective: runtime.effectiveDrawdownMode(), manualProtect: config.protectManualTrades, manualExits: config.manualTradeExits,
    emergency: journal.getState('emergency_stop') === true, liveStatus: (() => { const l = journal.getState('live_status') || {}; return { error: l.error || null, authorised: !!l.authorised, blocked: l.blocked || null, ts: l.ts || null }; })() });

  async function handle(req, res, pathname, method) {
    if (!pathname.startsWith('/api/v6/')) return false;
    const url = new URL(req.url, 'http://x');
    if (method === 'GET') {
      switch (pathname) {
        case '/api/v6/controls': sendJson(res, 200, controls()); return true;
        case '/api/v6/banners': sendJson(res, 200, { ok: true, banners: dl.banners(), ts: Date.now() }); return true;
        case '/api/v6/decisions': { const q = url.searchParams; sendJson(res, 200, { ok: true, events: dl.list({ limit: q.get('limit'), type: q.get('type') || null, severity: q.get('severity') || null, symbol: q.get('symbol') || null, q: q.get('q') || null }) }); return true; }
        case '/api/v6/feed': { const since = Number(url.searchParams.get('since')) || 0; sendJson(res, 200, { ok: true, now: Date.now(), events: dl.list({ limit: 40, sinceTs: since + 1 }).filter(e => e.lastTs > since) }); return true; }
        case '/api/v6/slots': sendJson(res, 200, { ok: true, slots: runtime.slotConfig() }); return true;
        case '/api/v6/presets': sendJson(res, 200, { ok: true, ...presets.list() }); return true;
        case '/api/v6/performance': sendJson(res, 200, outcomes.performance()); return true;
        case '/api/v6/whatif': sendJson(res, 200, outcomes.whatIf(url.searchParams.get('module') || '')); return true;
        case '/api/v6/modules': sendJson(res, 200, { ok: true, ...modules.build() }); return true;
        case '/api/v6/advisor': {
          const snap = journal.getState(live() ? 'advisor_live' : 'advisor_paper') || { ts: null, rows: [] };
          const fl = flags.all();
          const rows = (snap.rows || []).map(r => ({ ...r, recommendations: integrity.recommend(r, fl, snap.rows) }));
          sendJson(res, 200, { ok: true, mode: live() ? 'live' : 'paper', flags: fl, manualExits: !!config.manualTradeExits, ts: snap.ts, ageSec: snap.ts ? Math.round((Date.now() - snap.ts) / 1000) : null, rows,
            note: 'Integrity is a quality checklist score, NOT the probability of winning. "Data coverage" shows how much could be measured.' }); return true;
        }
        default: return false;
      }
    }
    if (method !== 'POST') return false;
    if (!guard(req, res)) return true;
    const body = await parseBody(req);
    try {
      if (pathname === '/api/v6/leverage') { const v = body.value === 'auto' ? 0 : Number(body.value); runtime.setLeverageChoice(v);
        dl.record({ type: 'SYSTEM', severity: 'INFO', module: 'tradeSizing', reason: v ? `Leverage set to ${v}x by you (applies to NEW trades; open trades keep theirs)` : 'Leverage back to automatic scaling', key: 'lev_' + Date.now(), cooldownMs: 0 });
        const z = runtime.sizing(); sendJson(res, 200, { ok: true, leverage: v || 'auto', sizing: z, message: z.enabled ? `Next trades: ${z.margin} USDT x ${z.leverage}x = ${z.notional} USDT position` : (v ? `Leverage set to ${v}x for new trades` : 'Leverage set to automatic') }); return true; }
      if (pathname === '/api/v6/presets/apply') { if (body.confirm !== true) { sendJson(res, 400, { ok: false, error: 'confirm=true required (show the preview first)' }); return true; } sendJson(res, 200, { ok: true, applied: presets.applyPreset(String(body.name)), message: `Preset ${body.name} applied. You can undo it.` }); return true; }
      if (pathname === '/api/v6/presets/preview') { sendJson(res, 200, { ok: true, preview: presets.preview(String(body.name)) }); return true; }
      if (pathname === '/api/v6/presets/revert') { sendJson(res, 200, { ...presets.revert(), message: 'Previous configuration restored' }); return true; }
      if (pathname === '/api/v6/slots') { const out = runtime.setSlotConfig(body); dl.record({ type: 'SYSTEM', severity: 'INFO', module: 'slots', reason: `Position slots set by you: ramp ${out.ramp ? 'ON (start ' + out.start + ', +1 per ' + out.every + ' trades at PF ' + out.minPF + ')' : 'OFF'}, max ${out.max || 'unlimited'}`, key: 'slots_' + Date.now(), cooldownMs: 0 }); sendJson(res, 200, { ok: true, slots: out, message: 'Slot settings saved. Applies from the next scan, no restart needed.' }); return true; }
      if (pathname === '/api/v6/margin') { const m = body.delta !== undefined ? runtime.adjustMargin(body.delta) : runtime.setMarginChoice(body.value);
        dl.record({ type: 'SYSTEM', severity: 'INFO', module: 'tradeSizing', reason: `Margin per trade set to ${m} USDT by you (applies to NEW trades; open trades keep theirs)`, key: 'mar_' + Date.now(), cooldownMs: 0 });
        const z = runtime.sizing(); sendJson(res, 200, { ok: true, sizing: z, message: z.enabled ? `Next trades: ${z.margin} USDT x ${z.leverage}x = ${z.notional} USDT position` : `Margin saved (${m} USDT); manual sizing is disabled in .env` }); return true; }
      if (pathname === '/api/v6/drawdown-mode') { const m = runtime.setDrawdownMode(String(body.mode));
        dl.record({ type: 'SYSTEM', severity: m === 'enforce' ? 'WARNING' : 'INFO', module: 'drawdownGuard', reason: `Drawdown guard set to ${m.toUpperCase()} by you`, key: 'ddm_' + Date.now(), cooldownMs: 0 });
        sendJson(res, 200, { ok: true, mode: m, message: `Drawdown guard: ${m}` }); return true; }
      if (pathname === '/api/v6/take') {
        const r = await dispatchCommand(body.on === true ? 'RESUME' : 'PAUSE', {}, { timeoutMs: 15000 });
        if (r.status === 'OFFLINE') sendJson(res, 409, { ok: false, error: r.error }); else if (r.status === 'FAILED') sendJson(res, 422, { ok: false, error: r.error });
        else { const ls = journal.getState('live_status') || {}; const warn = body.on === true && config.isLive && !ls.authorised ? ' BUT live trading is not authorised yet - set LIVE_AUTHORIZE=true in .env and restart, or no order will be sent.' : '';
          sendJson(res, 200, { ok: true, takeLiveTrades: body.on === true, message: (body.on === true ? 'Take Live Trades is ON: the robot may open new trades.' : 'Take Live Trades is OFF: no new trades. Open trades keep their stops.') + warn }); }
        return true; }
      if (pathname === '/api/v6/close-by-pnl') {
        const which = body.which === 'winning' ? 'winning' : body.which === 'losing' ? 'losing' : null;
        if (!which) { sendJson(res, 400, { ok: false, error: 'which must be "losing" or "winning"' }); return true; }
        if (body.confirm !== true) { sendJson(res, 400, { ok: false, error: 'confirm=true required' }); return true; }
        const r = await dispatchCommand('CLOSE_BY_PNL', { which }, { timeoutMs: 45000 });
        if (r.status === 'OFFLINE') sendJson(res, 409, { ok: false, error: r.error }); else if (r.status === 'FAILED') sendJson(res, 422, { ok: false, error: r.error });
        else if (r.status === 'QUEUED') sendJson(res, 202, { ok: true, queued: true, message: 'Command sent; the robot has not confirmed yet. Check the positions list.' });
        else sendJson(res, 200, { ok: true, ...(r.result || {}) });
        return true; }
    } catch (e) { sendJson(res, 400, { ok: false, error: e.message }); return true; }
    return false;
  }
  return { handle };
}
module.exports = { create };
