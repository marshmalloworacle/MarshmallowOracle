'use strict';
/**
 * Live Trading Control Center routes.
 *  - GET  /api/live/{account,positions,risk,health,journal,gates,status}  -> READ-ONLY exchange/journal views
 *  - POST /api/live/preview                                              -> pure computation, sends nothing
 *  - POST /api/live/{close,flatten,kill,pause,resume}                    -> forwarded to the ROBOT process as commands.
 *    The dashboard server itself has no code path that places or cancels an order.
 * Every write is re-validated here (LIVE mode + explicit confirmation word) and again inside the robot.
 */
const fs = require('fs');
const path = require('path');
const config = require('../src/config');
const journal = require('../src/journal/store');
const LiveReadModel = require('../src/live/readModel');

const ASSETS = { '/live.js': 'application/javascript; charset=utf-8', '/v67.js': 'application/javascript; charset=utf-8', '/adaptive.js': 'application/javascript; charset=utf-8', '/adi.js': 'application/javascript; charset=utf-8', '/v7.js': 'application/javascript; charset=utf-8', '/paperlab.js': 'application/javascript; charset=utf-8', '/v7.css': 'text/css; charset=utf-8', '/live.css': 'text/css; charset=utf-8', '/theme.css': 'text/css; charset=utf-8', '/v46.js': 'application/javascript; charset=utf-8', '/v46.css': 'text/css; charset=utf-8', '/v5cards.js': 'application/javascript; charset=utf-8', '/obsidian.css': 'text/css; charset=utf-8', '/obsidian.js': 'application/javascript; charset=utf-8', '/obsidian-pages.js': 'application/javascript; charset=utf-8', '/v6.js': 'application/javascript; charset=utf-8', '/v6.css': 'text/css; charset=utf-8', '/theme6.css': 'text/css; charset=utf-8' };   // whitelist: no path traversal possible

function create({ sendJson, parseBody, dispatchCommand, model }) {
  const rm = model || new LiveReadModel();

  async function handle(req, res, pathname, method) {
    if (method === 'GET' && ASSETS[pathname]) {
      const f = path.join(__dirname, 'public', pathname.slice(1));
      if (!fs.existsSync(f)) { res.writeHead(404); res.end(); return true; }
      res.writeHead(200, { 'Content-Type': ASSETS[pathname], 'Cache-Control': 'no-store' }); fs.createReadStream(f).pipe(res); return true;
    }
    if (!pathname.startsWith('/api/live/')) return false;

    if (method === 'GET') {
      const url = new URL(req.url, 'http://x');
      switch (pathname) {
        case '/api/live/account': sendJson(res, 200, await rm.account()); return true;
        case '/api/live/positions': sendJson(res, 200, await rm.positions()); return true;
        case '/api/live/risk': sendJson(res, 200, await rm.risk()); return true;
        case '/api/live/health': sendJson(res, 200, await rm.health()); return true;
        case '/api/live/journal': sendJson(res, 200, rm.journalView(Math.min(500, Number(url.searchParams.get('limit')) || 200))); return true;
        case '/api/live/gates': await probe(); sendJson(res, 200, { ok: true, ...rm.flags(), exchange: config.exchange, mode: config.mode }); return true;
        case '/api/live/feed': sendJson(res, 200, { ok: true, alerts: (journal.getState('live_alerts') || []).slice(-60) }); return true;
        default: return false;       // /api/live/status handled by the main server
      }
    }

    if (method !== 'POST') return false;
    const body = await parseBody(req);
    if (pathname === '/api/live/preview') { sendJson(res, 200, await rm.preview(body || {})); return true; }

    const writes = { '/api/live/close': 'CLOSE_LIVE_POSITION', '/api/live/flatten': 'FLATTEN_LIVE', '/api/live/kill': 'KILL_LIVE', '/api/live/pause': 'PAUSE', '/api/live/resume': 'RESUME' };
    const type = writes[pathname];
    if (!type) return false;
    if (!config.isLive) { sendJson(res, 400, { ok: false, error: 'Not in LIVE mode (TRADING_MODE=LIVE and LIVE_TRADING_ENABLED=true).' }); return true; }
    const need = { '/api/live/flatten': 'FLATTEN', '/api/live/kill': 'KILL' }[pathname];
    if (need && String(body.confirm || '') !== need) { sendJson(res, 400, { ok: false, error: `Confirmation required: send confirm="${need}".` }); return true; }
    if (pathname === '/api/live/close' && (!body.symbol || body.confirm !== true)) { sendJson(res, 400, { ok: false, error: 'symbol and confirm=true are required.' }); return true; }
    const payload = pathname === '/api/live/close' ? { symbol: String(body.symbol).toUpperCase(), reason: 'manual close from dashboard' } : {};
    const r = await dispatchCommand(type, payload, { timeoutMs: 20000 });
    const safe = 'Your open positions keep their exchange stop-loss. If you must act now, use the exchange app.';
    if (r.status === 'OFFLINE') sendJson(res, 409, { ok: false, error: `${r.error} ${safe}` });
    else if (r.status === 'FAILED') sendJson(res, 422, { ok: false, error: r.error });
    else if (r.status === 'QUEUED' || r.status === 'PENDING' || r.status === 'TIMEOUT') sendJson(res, 202, { ok: true, queued: true, message: `Command sent but the robot has not confirmed yet. Check Positions & Orders. ${safe}` });
    else sendJson(res, 200, { ok: true, ...(r.result || {}) });
    return true;
  }
  return { handle, model: rm };
}

let lastProbe = 0;
async function probe() {   // cheap public ping (max every 20s) so the dashboard can show a region block even before any account call
  if (config.exchange !== 'bybit' || Date.now() - lastProbe < 20000) return;
  lastProbe = Date.now();
  try { await require('../src/exchanges/bybit').ping(); } catch (_) { /* state is recorded inside the client */ }
}

module.exports = { create };
