'use strict';
/**
 * Exchange tab + GO LIVE routes (v5.2). No login (by design): protection is
 *  - same-origin + custom-header check on every write (blocks drive-by cross-site requests),
 *  - secrets are write-only (never returned; masked status only),
 *  - GO LIVE / back-to-paper need a typed confirmation word,
 *  - switching exchange or leaving LIVE is refused while live positions are open (use Emergency Stop / Flatten first),
 *  - every change is applied by a SAFE RESTART of the robot, never hot-swapped.
 * Live execution gates, stop-loss placement and risk controls are untouched.
 */
const path = require('path');
const { spawn } = require('child_process');
const config = require('../src/config');
const journal = require('../src/journal/store');
const logger = require('../src/utils/logger');
const envStore = require('../src/control/envStore');

const ROOT = path.resolve(__dirname, '..');
const NEEDS = {
  bybit: ['BYBIT_API_KEY', 'BYBIT_API_SECRET'], mexc: ['MEXC_API_KEY', 'MEXC_API_SECRET'],
  bitget: ['BITGET_API_KEY', 'BITGET_API_SECRET', 'BITGET_PASSPHRASE'], sim: [],
};
const LABELS = { bybit: 'Bybit USDT perpetuals', bitget: 'Bitget USDT-M futures (Classic v2 + Unified v3)', mexc: 'MEXC USDT-M futures', sim: 'Offline simulator (no exchange)' };

function create({ sendJson, parseBody }) {
  const guard = (req, res) => {
    if (req.headers['x-alpha'] !== '1') { sendJson(res, 403, { ok: false, error: 'Missing X-Alpha header (request must come from the dashboard).' }); return false; }
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) { sendJson(res, 403, { ok: false, error: 'Cross-site request refused.' }); return false; } } catch (_) { sendJson(res, 403, { ok: false, error: 'Bad origin.' }); return false; } }
    return true;
  };
  const openLive = () => { try { return journal.getOpenLiveTrades().length; } catch (_) { return 0; } };
  const savedExchange = () => (envStore.readAll().EXCHANGE || config.exchange || 'bybit').toLowerCase();
  const hasKeys = (ex, all = envStore.readAll()) => NEEDS[ex].every(k => !!all[k]);
  const supervised = () => process.env.ALR_SUPERVISED === '1';

  function runVerify(ex) {
    return new Promise((resolve) => {
      const env = { ...process.env }; for (const k of envStore.ALLOWED) delete env[k];      // child re-reads the SAVED .env, not our stale copy
      delete env.ROBOT_SKIP_DOTENV;
      const child = spawn(process.execPath, ['src/scripts/exchange-verify.js', ex], { cwd: ROOT, env });
      let out = ''; const cap = (d) => { out += d.toString(); if (out.length > 20000) out = out.slice(-20000); };
      child.stdout.on('data', cap); child.stderr.on('data', cap);
      const timer = setTimeout(() => { try { child.kill('SIGKILL'); } catch (_) { /* gone */ } }, 45000);
      child.on('close', (code) => {
        clearTimeout(timer);
        const secrets = Object.entries(envStore.readAll()).filter(([k, v]) => envStore.SECRET_KEYS.includes(k) && v && v.length > 5).map(([, v]) => v);
        for (const s of secrets) out = out.split(s).join('••••');
        resolve({ ok: code === 0, code, output: out.trim().slice(-4000) });
      });
      child.on('error', (e) => { clearTimeout(timer); resolve({ ok: false, code: -1, output: `could not start verify: ${e.message}` }); });
    });
  }
  function restart(res, extra = {}) {
    if (supervised()) {
      sendJson(res, 200, { ok: true, restart: 'automatic', message: 'Restarting the robot and dashboard now. This page reconnects in about 10 seconds.', ...extra });
      logger.warn('Safe restart requested from the dashboard (exit 75 -> supervisor restarts both processes)');
      setTimeout(() => process.exit(75), 700);
    } else {
      sendJson(res, 200, { ok: true, restart: 'manual', message: 'Saved. Stop the robot and dashboard (Ctrl+C) and start them again (npm run all) to apply.', ...extra });
    }
  }

  async function handleInner(req, res, pathname, method) {
    if (!(pathname.startsWith('/api/exchange/') || pathname === '/api/system/restart')) return false;

    if (method === 'GET' && pathname === '/api/exchange/state') {
      const saved = envStore.readAll(); const ks = envStore.keyStatus();
      const sel = savedExchange();
      const pendingRestart = (saved.EXCHANGE && saved.EXCHANGE.toLowerCase() !== config.exchange) || (saved.TRADING_MODE && saved.TRADING_MODE.toUpperCase() !== (config.mode === 'LIVE' ? 'LIVE' : 'SIM') && config.runMode !== 'SIM') || false;
      sendJson(res, 200, {
        ok: true, running: { exchange: config.exchange, runMode: config.runMode, liveEnabled: config.liveEnabled, isLive: config.isLive, bitgetAccountType: config.bitget.accountType || 'auto' },
        saved: { exchange: sel, bitgetAccountType: saved.BITGET_ACCOUNT_TYPE || 'auto', mode: (saved.TRADING_MODE || 'SIM').toUpperCase(), liveEnabled: saved.LIVE_TRADING_ENABLED === 'true' },
        exchanges: Object.keys(LABELS).map(id => ({ id, label: LABELS[id], needs: NEEDS[id], keysSaved: id === 'sim' ? true : hasKeys(id, saved) })),
        keys: ks, lockedByEnv: (config.envFromShell || []).filter(k => envStore.ALLOWED.has(k)), pendingRestart, supervised: supervised(), openLivePositions: openLive(),
        note: 'Keys are stored in the local .env (never committed, never shown again after saving).' });
      return true;
    }
    if (method !== 'POST') return false;
    if (!guard(req, res)) return true;
    const body = await parseBody(req);

    if (pathname === '/api/exchange/save') {
      const ex = String(body.exchange || '').toLowerCase();
      if (!NEEDS[ex]) { sendJson(res, 400, { ok: false, error: 'Unknown exchange.' }); return true; }
      if (ex !== config.exchange && config.isLive && openLive() > 0) { sendJson(res, 409, { ok: false, error: `Refused: ${openLive()} live position(s) are open on ${config.exchange.toUpperCase()}. Close them (Flatten / Emergency Stop) before switching exchange.` }); return true; }
      const updates = { EXCHANGE: ex };
      for (const [k, v] of Object.entries(body.keys || {})) { if (!envStore.CREDENTIAL_KEYS.has(k)) { sendJson(res, 400, { ok: false, error: `${k} cannot be changed here (credentials only; the trading mode changes only through GO LIVE / Back to paper).` }); return true; } updates[k] = v; }
      if (body.bitgetAccountType) updates.BITGET_ACCOUNT_TYPE = String(body.bitgetAccountType);
      try { const wrote = envStore.set(updates); logger.info(`Exchange settings saved from dashboard: ${wrote.join(', ')} (values not logged)`); }
      catch (e) { sendJson(res, 400, { ok: false, error: e.message }); return true; }
      sendJson(res, 200, { ok: true, restartRequired: true, message: `Saved. Active exchange will be ${ex.toUpperCase()} after a safe restart.` });
      return true;
    }
    if (pathname === '/api/exchange/test') {
      const ex = String(body.exchange || savedExchange()).toLowerCase();
      if (!['bybit', 'bitget', 'mexc'].includes(ex)) { sendJson(res, 400, { ok: false, error: 'Pick bybit, bitget or mexc.' }); return true; }
      if (!hasKeys(ex)) { sendJson(res, 200, { ok: false, code: 0, output: `Public market-data checks only: ${ex.toUpperCase()} keys are not saved yet. Save them first to test your account.` }); }
      sendJson(res, 200, { ok: true, ...(await runVerify(ex)), exchange: ex, readOnly: true });
      return true;
    }
    if (pathname === '/api/system/restart') { restart(res); return true; }

    return false;
  }
  /** Any unexpected error becomes a JSON 500 with the real message (and a log line) instead of crashing the dashboard. */
  async function handle(req, res, pathname, method) {
    try { return await handleInner(req, res, pathname, method); }
    catch (e) {
      logger.warn(`Exchange route ${method} ${pathname} failed: ${e && e.stack ? e.stack.split('\n').slice(0, 3).join(' | ') : e}`);
      try { sendJson(res, 500, { ok: false, error: `Server error: ${e && e.message ? e.message : e}` }); } catch (_) { /* response already sent */ }
      return true;
    }
  }
  return { handle, runVerify };
}
module.exports = { create, NEEDS };
