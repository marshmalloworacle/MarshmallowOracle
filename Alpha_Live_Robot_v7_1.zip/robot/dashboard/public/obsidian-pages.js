/* v5.1 per-page enhancements: Scanner (quick filters, score bars, direction accents), Positions (live position cards), Analytics (strategy panel).
   Read-only: uses existing endpoints; never writes. Values shown exactly as the API returns them; missing data shows an em dash. */
(function () {
  'use strict';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const getj = async (u) => { const r = await fetch(u); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); };
  const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
  const px = (v) => { v = num(v); if (v == null) return '—'; const a = Math.abs(v); return '$' + v.toFixed(a >= 1000 ? 2 : a >= 1 ? 4 : a >= 0.01 ? 5 : 7); };
  const usd = (v) => { v = num(v); return v == null ? '—' : (v >= 0 ? '+$' : '-$') + Math.abs(v).toFixed(2); };
  const active = (id) => { const e = document.getElementById(id); return e && e.classList.contains('active') && !document.hidden; };

  // ───────────── Scanner ─────────────
  const scan = $('#tab-scanner');
  if (scan) {
    const bar = document.createElement('div'); bar.className = 'ob-chips'; bar.setAttribute('role', 'group'); bar.setAttribute('aria-label', 'Scanner quick filters');
    const CH = [['ALL', 'All', 'scanStatTotal'], ['QUALIFIED', 'Qualified', 'scanStatQualified'], ['WATCH', 'Watch', 'scanStatWatch'], ['REJECTED', 'Rejected', 'scanStatRejected'], ['DQ', 'Data-blocked', 'scanStatDQ']];
    const first = $('.table-container', scan) ; const radar = $('#scanSearch') ? $('#scanSearch').closest('.table-container') : null;
    if (radar) radar.parentNode.insertBefore(bar, radar);
    const sel = () => $('#scanFilterStatus');
    function chips() { const cur = sel() ? sel().value : 'ALL'; bar.innerHTML = CH.map(([v, l, id]) => '<button type="button" class="ob-chip' + (cur === v ? ' on' : '') + '" data-v="' + v + '" aria-pressed="' + (cur === v) + '">' + l + ' <b>' + esc(($('#' + id) || {}).textContent || '0') + '</b></button>').join(''); }
    bar.addEventListener('click', (e) => { const b = e.target.closest('.ob-chip'); if (!b || !sel()) return; sel().value = b.dataset.v; if (typeof window.filterScannerTable === 'function') window.filterScannerTable(); chips(); });
    function decorate() {
      $$('table tbody tr', scan).forEach((tr) => {
        const td = tr.children; if (td.length < 4) return;
        const sc = parseFloat(td[1].textContent); if (Number.isFinite(sc)) { td[1].style.setProperty('--s', Math.max(0, Math.min(100, sc)) + '%'); td[1].classList.add('ob-score'); }
        const d = (td[2].textContent || '').trim().toUpperCase(); tr.dataset.dir = d.indexOf('LONG') >= 0 ? 'long' : d.indexOf('SHORT') >= 0 ? 'short' : '';
      });
    }
    const t = $('#tab-scanner table:last-of-type tbody') || $('#tab-scanner tbody');
    chips(); decorate();
    if (t) new MutationObserver(() => { decorate(); }).observe(t, { childList: true });
    setInterval(() => { if (active('tab-scanner')) { chips(); decorate(); } }, 3000);
  }

  // ───────────── Positions: live cards ─────────────
  const pos = $('#tab-positions');
  if (pos) {
    const host = document.createElement('div'); host.id = 'obPosCards'; pos.insertBefore(host, pos.firstChild);
    const lvl = (p) => { const sl = num(p.stopLoss), tp = num(p.takeProfit), c = num(p.currentPrice), e = num(p.entry); if ([sl, tp, c, e].some(x => x == null) || tp === sl) return null; const f = (x) => Math.max(0, Math.min(100, ((x - sl) / (tp - sl)) * 100)); return { cur: f(c), ent: f(e) }; };
    const age = (ts) => { if (!ts) return '—'; const m = Math.max(0, Math.round((Date.now() - ts) / 60000)); return m < 60 ? m + 'm' : Math.floor(m / 60) + 'h ' + (m % 60) + 'm'; };
    async function cards() {
      let d; try { d = await getj('/api/dashboard/positions'); } catch (e) { host.innerHTML = '<div class="ob-panel"><div class="ob-sub">Positions unavailable: ' + esc(e.message) + '</div></div>'; return; }
      const P = d.positions || [];
      if (!P.length) { host.innerHTML = '<div class="ob-panel ob-empty"><h4>Live positions <span class="ob-tag">0 OPEN</span></h4><div class="ob-sub">No open paper positions. New entries appear here when a qualified signal passes every gate.</div></div>'; return; }
      const tot = P.reduce((s, p) => s + (num(p.unrealizedPnl) || 0), 0), wins = P.filter(p => (num(p.unrealizedPnl) || 0) > 0).length;
      host.innerHTML = '<div class="ob-poshead"><span><b>' + P.length + '</b> open</span><span>Unrealized <b class="' + (tot >= 0 ? 'up' : 'dn') + '">' + usd(tot) + '</b></span><span>' + wins + ' in profit / ' + (P.length - wins) + ' under water</span><span class="ob-tag">' + esc(P[0].mode || 'PAPER') + ' · simulated</span></div><div class="ob-poscards">' +
        P.map((p) => { const u = num(p.unrealizedPnl), L = lvl(p), r = num(p.currentR);
          return '<article class="ob-pc ' + (String(p.direction).toUpperCase() === 'LONG' ? 'long' : 'short') + '"><header><b>' + esc(p.symbol) + '</b><span class="ob-tag ' + (String(p.direction).toUpperCase() === 'LONG' ? 'on' : 'lock') + '">' + esc(p.direction) + '</span><em class="' + (u == null ? '' : u >= 0 ? 'up' : 'dn') + '">' + usd(u) + '</em></header>' +
            (L ? '<div class="ob-rail" role="img" aria-label="Price position between stop-loss and take-profit"><i class="e" style="left:' + L.ent + '%"></i><i class="c" style="left:' + L.cur + '%"></i></div><div class="ob-rl"><span class="dn">SL ' + px(p.stopLoss) + '</span><span class="up">TP ' + px(p.takeProfit) + '</span></div>' : '<div class="ob-sub">Levels unavailable</div>') +
            '<dl><div><dt>Entry</dt><dd>' + px(p.entry) + '</dd></div><div><dt>Mark</dt><dd>' + px(p.currentPrice) + '</dd></div><div><dt>R now</dt><dd>' + (r == null ? '—' : (r >= 0 ? '+' : '') + r.toFixed(2) + 'R') + '</dd></div><div><dt>Margin</dt><dd>' + (num(p.margin) == null ? '—' : '$' + p.margin.toFixed(2)) + ' · ' + esc(p.leverage || '—') + 'x</dd></div><div><dt>Liq. dist</dt><dd>' + (num(p.distToLiqPct) == null ? '—' : p.distToLiqPct.toFixed(1) + '%') + '</dd></div><div><dt>Open</dt><dd>' + age(p.openTime) + '</dd></div></dl>' +
            '<footer><span>' + esc(p.strategyName || '—') + '</span>' + (p.trailingActive ? '<span class="ob-tag on">TRAILING</span>' : '') + '</footer></article>'; }).join('') + '</div>';
    }
    cards(); setInterval(() => { if (active('tab-positions')) cards(); }, 5000);
    document.addEventListener('click', (e) => { if (e.target.closest && e.target.closest('.tab-btn')) setTimeout(() => { if (active('tab-positions')) cards(); }, 300); });
  }

  // ───────────── Analytics: strategy panel ─────────────
  const an = $('#tab-analytics');
  if (an) {
    const host = document.createElement('div'); host.id = 'obStrat'; an.insertBefore(host, an.firstChild);
    const f = (v, d, s) => (num(v) == null ? '—' : v.toFixed(d) + (s || ''));
    async function strat() {
      let d; try { d = await getj('/api/dashboard/strategy-stats'); } catch (e) { host.innerHTML = '<div class="ob-panel"><div class="ob-sub">Strategy statistics unavailable: ' + esc(e.message) + '</div></div>'; return; }
      const o = d.overall || {}, S = d.byStrategy || [];
      host.innerHTML = '<div class="ob-panel"><h4>Strategy performance <span class="ob-tag">' + esc(o.sample || 'NONE') + ' SAMPLE · ' + (o.trades || 0) + ' CLOSED</span></h4>' +
        (S.length ? '<div class="ob-tablewrap"><table><thead><tr><th>Strategy</th><th class="n">Trades</th><th class="n">Win rate</th><th class="n">Profit factor</th><th class="n">Expectancy</th><th class="n">Net R</th><th class="n">Net P&amp;L</th></tr></thead><tbody>' +
          S.map(s => '<tr><td>' + esc(s.name || s.id) + '</td><td class="n">' + (s.trades || 0) + '</td><td class="n">' + f(s.winRate, 1, '%') + '</td><td class="n">' + (s.profitFactor == null ? '∞' : f(s.profitFactor, 2)) + '</td><td class="n ' + ((s.expectancyR || 0) >= 0 ? 'up' : 'dn') + '">' + f(s.expectancyR, 2, 'R') + '</td><td class="n ' + ((s.netR || 0) >= 0 ? 'up' : 'dn') + '">' + f(s.netR, 2, 'R') + '</td><td class="n ' + ((s.netPnl || 0) >= 0 ? 'up' : 'dn') + '">' + usd(s.netPnl) + '</td></tr>').join('') + '</tbody></table></div>' :
          '<div class="ob-sub">No closed paper trades with recorded risk yet. Per-strategy win rate, profit factor and expectancy appear after the first closed trades — nothing is estimated in the meantime.</div>') + '</div>';
    }
    strat(); setInterval(() => { if (active('tab-analytics')) strat(); }, 15000);
    document.addEventListener('click', (e) => { if (e.target.closest && e.target.closest('.tab-btn')) setTimeout(() => { if (active('tab-analytics')) strat(); }, 300); });
  }

  // ───────────── Sentiment meter: legend + verdict (colours come from CSS; thresholds mirror src/market/intel.js bias rules) ─────────────
  function sentiment() {
    $$('.bat').forEach((b) => {
      const m = /-?\d+(\.\d+)?/.exec((b.querySelector('span') || {}).textContent || ''); if (!m) return;
      const sc = parseFloat(m[0]), z = sc <= 40 ? 'bear' : sc >= 60 ? 'bull' : 'neu', word = z === 'bear' ? 'BEARISH' : z === 'bull' ? 'BULLISH' : 'NEUTRAL';
      if (b.dataset.z === z && b.nextElementSibling && b.nextElementSibling.classList.contains('ob-sentleg')) return;
      b.dataset.z = z;
      let leg = b.nextElementSibling; if (!(leg && leg.classList.contains('ob-sentleg'))) { leg = document.createElement('div'); leg.className = 'ob-sentleg'; leg.innerHTML = '<span>Bearish</span><span>Neutral</span><span>Bullish</span>'; b.insertAdjacentElement('afterend', leg); }
      let v = b.previousElementSibling; if (!(v && v.classList.contains('ob-sentverdict'))) { v = document.createElement('span'); v.className = 'ob-sentverdict'; b.insertAdjacentElement('beforebegin', v); }
      v.className = 'ob-sentverdict ' + z; v.textContent = word + ' · ' + sc;
    });
  }
  sentiment(); setInterval(sentiment, 1500);

  // ───────────── Exchange tab (choose exchange, save keys write-only, read-only test, GO LIVE / back to paper) ─────────────
  (function exchangeTab() {
    const sec = $('#tab-exchange'); if (!sec) return;
    const H = { 'Content-Type': 'application/json', 'X-Alpha': '1' };
    const postj = async (u, b) => { const r = await fetch(u, { method: 'POST', headers: H, body: JSON.stringify(b || {}) }); const d = await r.json().catch(() => ({})); return { ok: r.ok && d.ok !== false, status: r.status, body: d }; };
    const FIELDS = { bybit: [['BYBIT_API_KEY', 'API key'], ['BYBIT_API_SECRET', 'API secret']], bitget: [['BITGET_API_KEY', 'API key'], ['BITGET_API_SECRET', 'API secret'], ['BITGET_PASSPHRASE', 'API passphrase']], mexc: [['MEXC_API_KEY', 'API key'], ['MEXC_API_SECRET', 'API secret']], sim: [] };
    const NAMES = { bybit: 'Bybit', bitget: 'Bitget', mexc: 'MEXC', sim: 'Simulator' };
    let S = null, pick = null, out = '', busy = false;
    const toast = (m, err) => { if (window.__v6toast) { window.__v6toast(m, !err); return; } let t = $('#obToast'); if (!t) { t = document.createElement('div'); t.id = 'obToast'; t.setAttribute('role', 'status'); document.body.appendChild(t); } t.textContent = m; t.className = 'show' + (err ? ' err' : ''); clearTimeout(t._h); t._h = setTimeout(() => { t.className = ''; }, 3200); };
    async function load() {
      try {
        const r = await fetch('/api/exchange/state', { cache: 'no-store' }); const txt = await r.text();
        try { S = JSON.parse(txt); } catch (_) { throw new Error('the server answered HTTP ' + r.status + ' with ' + (txt ? '"' + txt.slice(0, 160).replace(/\s+/g, ' ') + '"' : 'an empty reply') + '. Usually this means an OLD dashboard process is still running (stop it with: pkill -f dashboard/server.js; pkill -f src/robot.js) and then start again with: npm run paper'); }
        if (S.ok === false) throw new Error(S.error || 'server error');
      } catch (e) { S = null; sec.innerHTML = '<div class="ob-panel"><h4>Could not load exchange settings</h4><div class="ob-sub">' + esc(e.message) + '</div><button class="btn" id="obXRetry" style="margin-top:10px">Try again</button></div>'; const b = $('#obXRetry'); if (b) b.onclick = () => load(); return; }
      if (!pick) pick = S.saved.exchange; draw();
    }
    function draw() {
      if (!S) return; const run = S.running, sv = S.saved, ks = S.keys[pick] || {};
      const live = run.isLive, status = live ? 'LIVE · ' + run.exchange.toUpperCase() : run.runMode === 'LIVE' ? 'LIVE LOCKED · ' + run.exchange.toUpperCase() : 'PAPER · ' + run.exchange.toUpperCase();
      const fields = (FIELDS[pick] || []).map(([k, l]) => '<label class="ob-set"><span>' + l + (ks[k] && ks[k].saved ? ' <span class="ob-tag on">SAVED ' + esc(ks[k].masked || '') + '</span>' : ' <span class="ob-tag">NOT SAVED</span>') + '</span><input type="password" autocomplete="off" data-key="' + k + '" placeholder="' + (ks[k] && ks[k].saved ? 'leave blank to keep' : 'paste here') + '" style="width:260px"></label>').join('');
      const locked = (S.lockedByEnv || []);
      const lockBanner = locked.length ? '<div class="ob-panel" style="margin-bottom:14px;border-color:#6b5a2a"><h4>Set outside the dashboard <span class="ob-tag lock">ENVIRONMENT</span></h4><div class="ob-sub">These come from the terminal / Codespaces secrets and <b>override what you save here</b>: <code>' + locked.map(esc).join(', ') + '</code>. ' + (S.supervised ? 'A dashboard restart clears them so your saved values apply.' : 'Remove them from Codespaces secrets (or unset them) for the dashboard to control these settings.') + '</div></div>' : '';
      sec.innerHTML = lockBanner + '<p class="ob-lead">One exchange is active at a time. Saving writes your choice and keys to the local <code>.env</code> (never shown again, never committed) and a safe restart applies it. Keys should have trading permission only. Never enable withdrawals.</p>' +
        (S.pendingRestart ? '<div class="ob-panel" style="margin-bottom:14px;border-color:#6b5a2a"><h4>Restart needed <span class="ob-tag lock">PENDING</span></h4><div class="ob-sub">Saved settings differ from what is running.</div><button class="btn btn-primary" data-act="restart" style="margin-top:8px">Restart now</button></div>' : '') +
        '<div class="ob-mgrid"><div class="ob-panel"><h4>Active exchange <span class="ob-tag ' + (live ? 'lock' : 'on') + '">' + esc(status) + '</span></h4>' +
        '<div class="seg" role="group" aria-label="Exchange" style="margin:8px 0 12px">' + S.exchanges.map(e => '<button type="button" class="seg-btn ' + (e.id === pick ? 'active' : '') + '" data-ex="' + e.id + '">' + NAMES[e.id] + (e.keysSaved && e.id !== 'sim' ? ' ✓' : '') + '</button>').join('') + '</div>' +
        '<div class="ob-sub">' + esc((S.exchanges.find(e => e.id === pick) || {}).label || '') + '</div>' + fields +
        (pick === 'bitget' ? '<label class="ob-set"><span>Account type</span><select data-bgtype><option value="auto"' + (sv.bitgetAccountType === 'auto' ? ' selected' : '') + '>Auto-detect</option><option value="classic"' + (sv.bitgetAccountType === 'classic' ? ' selected' : '') + '>Classic (v2)</option><option value="uta"' + (sv.bitgetAccountType === 'uta' ? ' selected' : '') + '>Unified (UTA, v3)</option></select></label>' : '') +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn btn-primary" data-act="save"' + (busy ? ' disabled' : '') + '>Save</button><button class="btn" data-act="test"' + (busy || pick === 'sim' ? ' disabled' : '') + '>Test connection (read-only)</button></div>' +
        '<div class="ob-note">Test connection reads market data and your balance. It never places an order.</div></div>' +
        '<div class="ob-panel"><h4>Trading mode <span class="ob-tag ' + (live ? 'lock' : 'on') + '">' + (live ? 'LIVE' : 'PAPER') + '</span></h4>' +
        '<div class="ob-sub">' + (live ? 'Real money on ' + esc(run.exchange.toUpperCase()) + '. <b>Stop live</b> (Live Accounts) pauses new trades and keeps open ones; <b>Emergency Stop</b> closes them.' : 'Paper trading: simulated trades only, nothing is sent to an exchange.') + '</div>' +
        '<div class="ob-note">Live authorisation comes only from <code>.env</code>: <code>TRADING_MODE=LIVE</code>, <code>LIVE_TRADING_ENABLED=true</code>, <code>LIVE_AUTHORIZE=true</code>, then restart. There is no dashboard switch for it. Open live positions: <b>' + S.openLivePositions + '</b>.</div>' +
        (S.supervised ? '' : '<div class="ob-note" style="color:var(--amber)">Started without the supervisor: changes are saved, but you must restart manually (stop, then <code>npm run all</code>).</div>') + '</div></div>' +
        '<div class="ob-panel" style="margin-top:14px"><h4>Connection test output</h4><pre id="obXOut" style="white-space:pre-wrap;font:12px var(--font-num);margin:0;color:var(--text-muted)">' + esc(out || 'Nothing run yet.') + '</pre></div>';
    }
    function modal(title, body, word, danger, go) {
      const m = document.createElement('div'); m.className = 'lv-modal'; m.style.cssText = 'position:fixed;inset:0;display:grid;place-items:center;background:rgba(0,0,0,.6);z-index:120';
      m.innerHTML = '<div class="ob-panel" style="max-width:460px;width:92%"><h4>' + esc(title) + '</h4><div class="ob-sub">' + body + '</div><div class="ob-sub" style="margin-top:10px">Type <b>' + esc(word) + '</b> to confirm:</div><input id="obCW" autocomplete="off" style="width:100%;margin-top:6px"><div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px"><button class="btn" id="obCN">Cancel</button><button class="btn ' + (danger ? 'btn-danger' : 'btn-primary') + '" id="obCY" disabled>Confirm</button></div></div>';
      document.body.appendChild(m); const i = $('#obCW', m), y = $('#obCY', m); i.focus();
      i.addEventListener('input', () => { y.disabled = i.value.trim() !== word; }); $('#obCN', m).onclick = () => m.remove(); m.addEventListener('click', (e) => { if (e.target === m) m.remove(); });
      y.onclick = async () => { y.disabled = true; y.textContent = 'Working...'; await go(i.value.trim()); m.remove(); };
    }
    async function waitBack(msg) { if (window.__alphaWaitRestart) window.__alphaWaitRestart(msg); else setTimeout(() => location.reload(), 15000); }
    sec.addEventListener('click', async (e) => {
      const ex = e.target.closest('[data-ex]'); if (ex) { pick = ex.dataset.ex; draw(); return; }
      const b = e.target.closest('[data-act]'); if (!b || busy) return; const a = b.dataset.act;
      if (a === 'save' || a === 'test') {
        busy = true; draw();
        try {
          if (a === 'save') {
            const keys = {}; $$('[data-key]', sec).forEach(i => { if (i.value.trim()) keys[i.dataset.key] = i.value.trim(); });
            const t = $('[data-bgtype]', sec);
            const r = await postj('/api/exchange/save', { exchange: pick, keys, bitgetAccountType: t ? t.value : undefined });
            toast(r.ok ? r.body.message : (r.body.error || 'Save failed'), !r.ok); if (r.ok) out = 'Saved. Use Test connection to verify, then Restart now to apply.';
          } else {
            out = 'Testing ' + NAMES[pick] + ' (read-only)...'; draw(); const r = await postj('/api/exchange/test', { exchange: pick });
            out = (r.body.ok === false && !r.body.output ? (r.body.error || 'Test failed') : r.body.output || '') + (r.body.ok ? '' : ''); toast(r.body.ok ? 'Connection test passed' : 'Connection test reported problems', !r.body.ok);
          }
        } catch (er) { toast(er.message, true); }
        busy = false; await load(); return;
      }
      if (a === 'restart') { const r = await postj('/api/system/restart'); if (r.ok && r.body.restart === 'automatic') waitBack('Restarting the robot safely...'); else toast(r.body.message || 'Restart manually', !r.ok); return; }
    });
    window.__obExchange = { load };
  })();
})();
