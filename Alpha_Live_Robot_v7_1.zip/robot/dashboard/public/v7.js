/* ALPHA LIVE ROBOT v7.0 — smooth scrolling (top scrollbars, sticky headers, jump buttons), per-position charts (SL / TP / trailing),
   iPhone-style notification gestures. Presentation only: chart numbers come from /api/v7/position-chart (the robot's real position state). */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fx = (v) => (v == null || !isFinite(v)) ? '–' : (Math.abs(v) >= 100 ? Number(v).toFixed(2) : Math.abs(v) >= 1 ? Number(v).toFixed(4) : Number(v).toPrecision(5));
  const ls = { get: (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (_) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) { /* private mode */ } } };

  /* ───────────────────────── 1. scrolling ───────────────────────── */
  function scrollBox(tb) {
    let el = tb.parentElement;
    for (let i = 0; el && i < 4 && el !== document.body; i++, el = el.parentElement) {
      const cs = getComputedStyle(el);
      if (/(auto|scroll)/.test(cs.overflowX) || el.classList.contains('table-container') || el.classList.contains('ob-tablewrap')) return el;
    }
    return null;
  }
  function enhanceTables() {
    for (const tb of $$('table')) {
      if (!tb.offsetParent) continue;
      const box = scrollBox(tb); if (!box) continue;
      if (!box.dataset.v7) {
        box.dataset.v7 = '1'; box.classList.add('v7-scroll');
        const bar = document.createElement('div'); bar.className = 'v7-topbar'; bar.innerHTML = '<div></div>'; bar.style.display = 'none';
        box.parentNode.insertBefore(bar, box); box._v7bar = bar;
        let lock = false;
        bar.addEventListener('scroll', () => { if (lock) return; lock = true; box.scrollLeft = bar.scrollLeft; lock = false; });
        box.addEventListener('scroll', () => { if (lock) return; lock = true; bar.scrollLeft = box.scrollLeft; lock = false; });
      }
      const rows = tb.tBodies[0] ? tb.tBodies[0].rows.length : 0;
      box.classList.toggle('v7-tall', rows > 9);        // long tables scroll inside the page so their header stays visible
    }
    for (const box of $$('[data-v7]')) {
      const bar = box._v7bar; if (!bar || !bar.isConnected) continue;
      const need = box.scrollWidth > box.clientWidth + 4;
      bar.style.display = need ? '' : 'none';
      if (need) bar.firstChild.style.width = box.scrollWidth + 'px';
    }
  }
  const jump = document.createElement('div'); jump.id = 'v7Jump';
  jump.innerHTML = '<button id="v7Up" title="Back to top" aria-label="Back to top">↑</button><button id="v7Dn" title="Jump to bottom" aria-label="Jump to bottom">↓</button>';
  document.body.appendChild(jump);
  $('#v7Up').onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
  $('#v7Dn').onclick = () => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
  function jumpState() {
    const y = window.scrollY, max = document.documentElement.scrollHeight - window.innerHeight;
    $('#v7Up').classList.toggle('on', y > 360); $('#v7Dn').classList.toggle('on', max > 700 && y < max - 360);
  }
  window.addEventListener('scroll', jumpState, { passive: true }); window.addEventListener('resize', () => { enhanceTables(); jumpState(); });

  /* ───────────────────────── 2. position charts ───────────────────────── */
  const open = new Set(ls.get('v7_open_charts', [])), panels = new Map();   // key = mode|symbol|id
  const TFS = ['5m', '15m', '1h'];
  let curTf = TFS.includes(ls.get('v7_chart_tf', '15m')) ? ls.get('v7_chart_tf', '15m') : '15m';

  function draw(cv, D) {
    const dpr = window.devicePixelRatio || 1, W = Math.max(320, cv.clientWidth), H = 300;
    cv.width = W * dpr; cv.height = H * dpr; const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
    const cs = D.candles || [], L = D.levels || {};
    if (!cs.length) { g.fillStyle = '#A0ADB8'; g.font = '13px sans-serif'; g.fillText('No candle data', 20, 30); return; }
    const padL = 8, padR = 98, padT = 12, padB = 22, pw = W - padL - padR, ph = H - padT - padB;
    let lo = Math.min(...cs.map(c => c.l)), hi = Math.max(...cs.map(c => c.h));
    for (const v of [L.entry, L.stop, L.initialStop, L.tp, L.mark]) if (v != null) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
    const pad = (hi - lo) * 0.07 || hi * 0.01; lo -= pad; hi += pad;
    const y = (v) => padT + (hi - v) / (hi - lo) * ph, n = cs.length, step = pw / n, bw = Math.max(1, step * 0.62), xi = (i) => padL + i * step + step / 2;
    const idxAt = (t) => { for (let i = 0; i < n; i++) if (cs[i].t >= t) return i; return n - 1; };
    // zones
    const zone = (a, b, col) => { if (a == null || b == null) return; g.fillStyle = col; g.fillRect(padL, Math.min(y(a), y(b)), pw, Math.abs(y(a) - y(b))); };
    zone(L.entry, L.tp, 'rgba(69,212,154,.07)'); zone(L.entry, L.stop, 'rgba(228,124,130,.07)');
    // grid
    g.strokeStyle = 'rgba(255,255,255,.05)'; g.lineWidth = 1; g.fillStyle = 'rgba(160,173,184,.7)'; g.font = '10.5px "DM Mono",monospace'; g.textAlign = 'left';
    for (let k = 0; k <= 4; k++) { const v = lo + (hi - lo) * k / 4, yy = y(v); g.beginPath(); g.moveTo(padL, yy); g.lineTo(padL + pw, yy); g.stroke(); }
    for (let k = 0; k < 4; k++) { const i = Math.floor(n * (k + 0.5) / 4), d = new Date(cs[i].t); g.fillText(String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), xi(i) - 14, H - 6); }
    // candles
    cs.forEach((c, i) => {
      const up = c.c >= c.o, col = up ? '#45D49A' : '#E47C82', x = xi(i);
      g.strokeStyle = col; g.beginPath(); g.moveTo(x, y(c.h)); g.lineTo(x, y(c.l)); g.stroke();
      g.fillStyle = col; const t = Math.min(y(c.o), y(c.c)), h = Math.max(1, Math.abs(y(c.o) - y(c.c))); g.fillRect(x - bw / 2, t, bw, h);
    });
    // entry time marker
    if (D.openTime && D.openTime >= cs[0].t) { const x = xi(idxAt(D.openTime)); g.setLineDash([2, 4]); g.strokeStyle = 'rgba(207,216,220,.35)'; g.beginPath(); g.moveTo(x, padT); g.lineTo(x, padT + ph); g.stroke(); g.setLineDash([]); }
    // stop path (initial stop -> each move -> current)
    const moves = (D.stopMoves || []).filter(m => m.t && m.to != null).sort((a, b) => a.t - b.t);
    if (moves.length && L.initialStop != null) {
      g.strokeStyle = '#E9B86A'; g.lineWidth = 1.6; g.beginPath(); let px = D.openTime && D.openTime >= cs[0].t ? xi(idxAt(D.openTime)) : padL, py = y(L.initialStop); g.moveTo(px, py);
      for (const m of moves) { const x = Math.max(px, xi(idxAt(m.t))); g.lineTo(x, py); py = y(m.to); g.lineTo(x, py); px = x; }
      g.lineTo(padL + pw, py); g.stroke(); g.lineWidth = 1;
    }
    // horizontal levels + labels
    const lines = [];
    const add = (v, col, dash, label, w) => { if (v != null && v > lo && v < hi) lines.push({ v, col, dash, label, w: w || 1.4 }); };
    add(L.tp, '#45D49A', [], 'TP'); add(L.entry, '#cfd8dc', [5, 4], 'Entry');
    if (L.trailing != null) { add(L.initialStop, 'rgba(228,124,130,.6)', [2, 4], 'SL0', 1); add(L.trailing, '#E9B86A', [], (L.trailingLabel || 'Trail').replace('Trailing / moved stop', 'Trail SL')); } else add(L.stop, '#E47C82', [], 'SL');
    add(L.mark, '#42CDBE', [1, 3], 'Now', 1.2); if (L.liq != null) add(L.liq, '#b58cff', [6, 4], 'Liq');
    for (const ln of lines) { g.setLineDash(ln.dash); g.strokeStyle = ln.col; g.lineWidth = ln.w; g.beginPath(); g.moveTo(padL, y(ln.v)); g.lineTo(padL + pw, y(ln.v)); g.stroke(); }
    g.setLineDash([]); g.lineWidth = 1;
    // labels (pushed apart so they never overlap)
    const lab = lines.map(l => ({ ...l, ly: y(l.v) })).sort((a, b) => a.ly - b.ly);
    for (let i = 1; i < lab.length; i++) if (lab[i].ly - lab[i - 1].ly < 15) lab[i].ly = lab[i - 1].ly + 15;
    g.font = '700 10.5px "DM Mono",monospace'; g.textAlign = 'left';
    for (const l of lab) { const t = l.label + ' ' + fx(l.v), w = g.measureText(t).width + 10; g.fillStyle = l.col.startsWith('rgba') ? '#7a3b40' : l.col; g.beginPath(); g.roundRect ? g.roundRect(padL + pw + 4, l.ly - 8, w, 16, 6) : g.rect(padL + pw + 4, l.ly - 8, w, 16); g.fill(); g.fillStyle = '#071012'; g.fillText(t, padL + pw + 9, l.ly + 3.5); }
  }
  function panelFor(key, info) {
    if (panels.has(key)) return panels.get(key);
    const el = document.createElement('div'); el.className = 'v7-chart';
    el.innerHTML = '<div class="hd"><b>' + esc(info.symbol) + '</b><span class="side"></span><span class="tf">' + TFS.map(t => '<button data-tf="' + t + '">' + t + '</button>').join('') + '</span><span class="st"></span></div><canvas></canvas>' +
      '<div class="lg"><span><i style="background:#45D49A"></i>Take-profit</span><span><i style="background:#E47C82"></i>Stop-loss</span><span><i style="background:#E9B86A"></i>Trailing / moved stop</span><span><i style="background:#cfd8dc"></i>Entry</span><span><i style="background:#42CDBE"></i>Price now</span></div>';
    const p = { el, key, info, data: null, busy: false }; panels.set(key, p);
    el.querySelectorAll('[data-tf]').forEach(b => b.onclick = () => { curTf = b.dataset.tf; ls.set('v7_chart_tf', curTf); panels.forEach(x => refresh(x)); });
    new ResizeObserver(() => { if (p.data && el.isConnected) draw(el.querySelector('canvas'), p.data); }).observe(el);
    return p;
  }
  async function refresh(p) {
    if (p.busy || !p.el.isConnected) return; p.busy = true;
    try {
      const r = await fetch('/api/v7/position-chart?symbol=' + encodeURIComponent(p.info.symbol) + '&tf=' + curTf + '&mode=' + p.info.mode + (p.info.id ? '&id=' + encodeURIComponent(p.info.id) : ''), { cache: 'no-store' });
      const d = await r.json(); if (!r.ok || d.ok === false) throw new Error(d.error || ('HTTP ' + r.status));
      p.data = d; p.el.querySelector('canvas').style.display = ''; const er = p.el.querySelector('.er'); if (er) er.remove();
      p.el.querySelector('.side').innerHTML = '<span style="color:' + (d.side === 'LONG' ? '#45D49A' : '#E47C82') + ';font-weight:800">' + d.side + '</span>';
      const L = d.levels; p.el.querySelector('.st').innerHTML = 'Entry <b>' + fx(L.entry) + '</b> · SL <b style="color:#E47C82">' + fx(L.stop) + '</b>' + (L.trailing != null ? ' <span style="color:#E9B86A">(' + esc(L.trailingLabel) + ')</span>' : '') + ' · TP <b style="color:#45D49A">' + fx(L.tp) + '</b> · Now <b>' + fx(L.mark) + '</b>' + (d.upnl != null ? ' · uPnL <b style="color:' + (d.upnl >= 0 ? '#45D49A' : '#E47C82') + '">' + (d.upnl >= 0 ? '+' : '') + Number(d.upnl).toFixed(2) + '</b>' : '');
      p.el.querySelectorAll('[data-tf]').forEach(b => b.classList.toggle('on', b.dataset.tf === curTf));
      draw(p.el.querySelector('canvas'), d);
    } catch (e) {
      p.el.querySelector('canvas').style.display = 'none'; let er = p.el.querySelector('.er'); if (!er) { er = document.createElement('div'); er.className = 'er'; p.el.insertBefore(er, p.el.querySelector('.lg')); } er.textContent = e.message;
    }
    p.busy = false;
  }
  function keyFor(mode, symbol, id) { return mode + '|' + symbol + '|' + (id || ''); }
  function enhancePositions() {
    const targets = [];
    for (const b of $$('button[onclick*="closePosition("]')) { const m = /closePosition\('([^']+)'\)/.exec(b.getAttribute('onclick') || ''); if (m) targets.push({ b, mode: 'paper', id: m[1], symbol: m[1].split('_')[0].toUpperCase() }); }
    for (const b of $$('button[data-a="close"][data-s]')) targets.push({ b, mode: 'live', id: null, symbol: b.dataset.s });
    for (const t of targets) {
      const tr = t.b.closest('tr'); if (!tr) continue; const key = keyFor(t.mode, t.symbol, t.id);
      let cb = tr.querySelector('.v7-chartbtn');
      if (!cb) { cb = document.createElement('button'); cb.type = 'button'; cb.className = 'v7-chartbtn'; cb.textContent = '📈 Chart'; cb.title = 'Show TP / SL / trailing-stop chart'; cb.onclick = (e) => { e.stopPropagation(); if (open.has(key)) open.delete(key); else open.add(key); ls.set('v7_open_charts', [...open]); enhancePositions(); }; t.b.parentNode.insertBefore(cb, t.b); }
      const isOpen = open.has(key); cb.classList.toggle('on', isOpen); cb.textContent = isOpen ? '📉 Hide chart' : '📈 Chart';
      const next = tr.nextElementSibling, has = next && next.classList.contains('v7-chartrow') && next.dataset.key === key;
      if (isOpen && !has) {
        if (next && next.classList.contains('v7-chartrow')) next.remove();
        const row = document.createElement('tr'); row.className = 'v7-chartrow'; row.dataset.key = key; const td = document.createElement('td'); td.colSpan = Math.max(tr.cells.length, 1); row.appendChild(td);
        const p = panelFor(key, { symbol: t.symbol, mode: t.mode, id: t.id }); td.appendChild(p.el); tr.after(row); refresh(p);
      } else if (!isOpen && has) next.remove();
    }
  }
  setInterval(() => { panels.forEach(p => { if (p.el.isConnected) refresh(p); }); }, 5000);

  /* ───────────────────────── 3. notification gestures (swipe / tap to dismiss) ───────────────────────── */
  (function () {
    let cur = null, sx = 0, dx = 0, t0 = 0, moved = false;
    const gone = (el) => { el.classList.add('v7-gone'); setTimeout(() => el.remove(), 320); };
    document.addEventListener('pointerdown', (e) => { const el = e.target.closest && e.target.closest('.v6-toast'); if (!el) return; cur = el; sx = e.clientX; dx = 0; t0 = Date.now(); moved = false; el.classList.remove('v7-back'); }, true);
    document.addEventListener('pointermove', (e) => { if (!cur) return; dx = e.clientX - sx; if (Math.abs(dx) > 4) { moved = true; cur.classList.add('v7-drag'); cur.style.transform = 'translateX(' + (dx > 0 ? dx : dx * 0.35) + 'px)'; cur.style.opacity = String(Math.max(0.25, 1 - Math.abs(dx) / 320)); } }, true);
    const end = () => {
      if (!cur) return; const el = cur; cur = null; const v = Math.abs(dx) / Math.max(1, Date.now() - t0);
      el.classList.remove('v7-drag');
      if (!moved || dx > 80 || v > 0.7) { el.style.transform = ''; el.style.opacity = ''; gone(el); }
      else { el.classList.add('v7-back'); el.style.transform = ''; el.style.opacity = ''; setTimeout(() => el.classList.remove('v7-back'), 380); }
    };
    document.addEventListener('pointerup', end, true); document.addEventListener('pointercancel', end, true);
  })();

  /* ───────────────────────── 4. back arrow + Home (every page) ───────────────────────── */
  (function () {
    let hist = []; try { hist = JSON.parse(sessionStorage.getItem('v7_nav_hist') || '[]'); } catch (_) { /* fresh */ }
    const view = () => { const lr = document.getElementById('liveRoot'); return lr && lr.style.display === 'block' ? 'live' : 'paper'; };
    const loc = () => {
      if (view() === 'live') { const b = document.querySelector('#lvTabs button.on'); return 'live:' + (b ? b.dataset.t : 'account'); }
      const a = document.querySelector('.tab-content.active'); return 'paper:' + (a ? a.id : 'tab-overview');
    };
    let last = loc(), quiet = 0;
    // v7.1: a normal page toolbar row at the top of the content area (static, not floating), so it never covers the sidebar.
    const nav = document.createElement('div'); nav.id = 'v7Nav'; nav.setAttribute('role', 'toolbar'); nav.setAttribute('aria-label', 'Page navigation');
    nav.innerHTML = '<button id="v7Back" type="button" title="Back to the previous section (Alt+←)" aria-label="Back">← Back</button><button id="v7Home" type="button" title="Home (Command Center)" aria-label="Home">⌂ Home</button><span class="sp"></span><button id="v7Clear" type="button" class="sub" title="Remove leftover test/ghost rows and finish old scan sessions">Clear stale rows</button>';
    const hdr = document.querySelector('header.header');      // directly under the page header, above the control bar (same margins as #v6Bar)
    if (hdr) hdr.after(nav); else { const host = document.querySelector('main.container') || document.body; host.insertBefore(nav, host.firstChild); }
    document.getElementById('v7Clear').onclick = async () => {
      if (!window.confirm('Remove leftover test/ghost open rows and finish old scanner sessions?\nReal exchange positions and your closed-trade history are NOT touched.')) return;
      try {
        const r = await fetch('/api/v7/clear-stale', { method: 'POST', headers: { 'X-Alpha': '1', 'Content-Type': 'application/json' }, body: '{}' }).then(x => x.json());
        if (!r.ok) throw new Error(r.error || 'failed');
        const msg = 'Cleared ' + (r.removedTestRows + r.removedOrphans) + ' stale row(s) and ' + r.stoppedScanSessions + ' old scan session(s).';
        if (window.__v6toast) window.__v6toast(msg, true); else window.alert(msg);
        setTimeout(() => location.reload(), 900);
      } catch (e) { window.alert('Clear failed: ' + e.message); }
    };
    const go = (target) => {
      const [v, id] = target.split(':'); quiet = Date.now() + 700;
      const sw = document.querySelector('#modeSwitch button[data-v="' + (v === 'live' ? 'live' : 'paper') + '"]');
      if (view() !== v && sw) sw.click();
      setTimeout(() => {
        if (v === 'live') { const b = document.querySelector('#lvTabs button[data-t="' + id + '"]'); if (b) b.click(); }
        else { const b = Array.from(document.querySelectorAll('.tab-btn')).find(x => (x.getAttribute('onclick') || '').indexOf("'" + id + "'") >= 0); if (typeof window.switchTab === 'function' && document.getElementById(id)) window.switchTab(id, b || null); }
        last = loc(); window.scrollTo({ top: 0, behavior: 'smooth' }); paint();
      }, v !== view() ? 80 : 0);
    };
    const paint = () => { const b = document.getElementById('v7Back'); if (b) { b.disabled = !hist.length; b.classList.toggle('dim', !hist.length); } try { sessionStorage.setItem('v7_nav_hist', JSON.stringify(hist.slice(-40))); } catch (_) { /* ignore */ } };
    const back = () => { const prev = hist.pop(); if (!prev) return; go(prev); };
    document.getElementById('v7Back').onclick = back;
    document.getElementById('v7Home').onclick = () => { const h = 'paper:tab-overview'; if (loc() !== h) { hist.push(loc()); } go(h); };
    document.addEventListener('keydown', (e) => { if (e.altKey && e.key === 'ArrowLeft' && !/INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || '')) { e.preventDefault(); back(); } });
    setInterval(() => {
      const cur = loc(); if (cur !== last) { if (Date.now() > quiet && last) { if (hist[hist.length - 1] !== last) hist.push(last); } last = cur; paint(); }
    }, 250);
    paint();
  })();

  /* ───────────────────────── boot ───────────────────────── */
  let pend = null;
  const kick = () => { if (pend) return; pend = setTimeout(() => { pend = null; try { enhanceTables(); enhancePositions(); } catch (_) { /* never break the dashboard */ } }, 160); };
  new MutationObserver(kick).observe(document.body, { childList: true, subtree: true });
  setInterval(kick, 2500); kick(); jumpState();
})();
