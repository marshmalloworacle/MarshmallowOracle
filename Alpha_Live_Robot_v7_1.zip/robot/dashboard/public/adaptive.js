/* ALPHA LIVE ROBOT v6.8 — ADAPTIVE WINNING STRATEGY ENGINE page. Presentation only: every number comes from /api/adaptive/status
   (the shared DB the robot writes). A setting is shown as ACTIVE only after the running robot reports the same mode. */
(function () {
  'use strict';
  const root = document.getElementById('adpRoot'); if (!root) return;
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const f = (v, d) => (v == null || !isFinite(v)) ? '–' : Number(v).toFixed(d == null ? 2 : d);
  const pct = (v) => v == null ? '–' : (v * 100).toFixed(0) + '%';
  const ago = (ts) => { if (!ts) return 'never'; const s = Math.max(0, Math.round((Date.now() - ts) / 1000)); return s < 90 ? s + 's ago' : s < 5400 ? Math.round(s / 60) + 'm ago' : Math.round(s / 3600) + 'h ago'; };
  const H = { 'Content-Type': 'application/json', 'X-Alpha': '1' };
  const CSS = '#adpRoot .a-card{background:var(--card-bg,#10151B);border:1px solid var(--border,#29333D);border-radius:12px;padding:14px 16px;margin-bottom:14px}' +
    '#adpRoot h3{margin:0 0 10px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-muted,#A0ADB8)}' +
    '#adpRoot .a-row{display:flex;gap:14px;flex-wrap:wrap;align-items:center}#adpRoot .a-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px}' +
    '#adpRoot .a-k{font-size:11px;color:var(--text-dim,#71808B);text-transform:uppercase;letter-spacing:.06em}#adpRoot .a-v{font-size:15px;font-weight:700;color:var(--text,#F1F5F7)}' +
    '#adpRoot .a-seg button{padding:7px 16px;border:1px solid var(--border,#29333D);background:transparent;color:var(--text-muted,#A0ADB8);cursor:pointer;font-weight:700}' +
    '#adpRoot .a-seg button:first-child{border-radius:8px 0 0 8px}#adpRoot .a-seg button:last-child{border-radius:0 8px 8px 0}' +
    '#adpRoot .a-seg button.on{background:var(--accent,#42CDBE);color:#07110f;border-color:var(--accent,#42CDBE)}' +
    '#adpRoot .a-sw{width:52px;height:28px;border-radius:14px;border:1px solid var(--border,#29333D);background:#2a3138;position:relative;cursor:pointer}' +
    '#adpRoot .a-sw i{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#9aa7b1;transition:.15s}' +
    '#adpRoot .a-sw.on{background:var(--accent,#42CDBE)}#adpRoot .a-sw.on i{left:27px;background:#07110f}' +
    '#adpRoot table{width:100%;border-collapse:collapse;font-size:12.5px}#adpRoot th,#adpRoot td{padding:7px 8px;text-align:right;border-bottom:1px solid var(--border,#29333D)}' +
    '#adpRoot th:nth-child(-n+2),#adpRoot td:nth-child(-n+2){text-align:left}#adpRoot th{color:var(--text-dim,#71808B);font-weight:600;font-size:11px;text-transform:uppercase}' +
    '#adpRoot .pill{display:inline-block;padding:2px 8px;border-radius:99px;font-size:11px;font-weight:700;border:1px solid var(--border,#29333D)}' +
    '#adpRoot .FAVOURITE{color:#45D49A;border-color:#45D49A}#adpRoot .DETERIORATING,#adpRoot .WEAK{color:#E47C82;border-color:#E47C82}#adpRoot .RECOVERING{color:#E9B86A;border-color:#E9B86A}#adpRoot .LEARNING{color:#71808B}' +
    '#adpRoot .pos{color:#45D49A}#adpRoot .neg{color:#E47C82}#adpRoot .bar{height:6px;background:#222b33;border-radius:3px;overflow:hidden;min-width:60px}#adpRoot .bar b{display:block;height:100%;background:var(--accent,#42CDBE)}' +
    '#adpRoot .a-msg{padding:9px 12px;border-radius:8px;font-size:13px;margin-top:10px}#adpRoot .a-msg.warn{background:rgba(233,184,106,.12);color:#E9B86A}#adpRoot .a-msg.ok{background:rgba(69,212,154,.12);color:#45D49A}#adpRoot .a-msg.bad{background:rgba(228,124,130,.12);color:#E47C82}' +
    '#adpRoot .a-log{font-size:12.5px;line-height:1.5}#adpRoot .a-log div{padding:5px 0;border-bottom:1px solid var(--border,#29333D)}#adpRoot input{background:#0A0C10;border:1px solid var(--border,#29333D);color:var(--text,#F1F5F7);border-radius:6px;padding:5px 8px;width:70px}';
  const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
  let S = null, pending = null, msg = null, busy = false, editing = false;

  async function load() {
    try { const r = await fetch('/api/adaptive/status', { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); S = await r.json(); S._err = null; }
    catch (e) { if (S) S._err = 'Backend not reachable (' + e.message + ') — the values below may be stale and no setting can be confirmed.'; else S = { _err: 'Backend not reachable (' + e.message + ').' }; }
    if (pending && S.cfg && S.applied && S.applied.confirmed && S.cfg.mode === pending) { pending = null; msg = { k: 'ok', t: 'Confirmed by the running robot.' }; }
    if (!editing) render();
  }
  async function save(patch) {
    if (busy) return; busy = true; msg = { k: 'warn', t: 'Saving…' }; render();
    try {
      const r = await fetch('/api/adaptive/config', { method: 'POST', headers: H, body: JSON.stringify(patch) }); let j = {}; try { j = await r.json(); } catch (_) { /* non-json */ }
      if (!r.ok || j.ok === false) msg = { k: 'bad', t: 'NOT saved: ' + (j.error || ('HTTP ' + r.status)) };
      else { if (patch.mode !== undefined || patch.enabled !== undefined) pending = j.cfg.mode; msg = { k: j.applied && j.applied.confirmed ? 'ok' : 'warn', t: j.message }; }
    } catch (e) { msg = { k: 'bad', t: 'NOT saved — backend not reachable: ' + e.message }; }
    busy = false; await load();
  }
  window.__adpSave = save;
  window.__adpToggle = () => save({ enabled: !(S && S.enabled) });
  window.__adpMode = (m) => save({ mode: m });
  window.__adpAdv = () => {
    const g = (id) => document.getElementById(id).value, p = {};
    for (const [id, k] of [['adpMin', 'minTrades'], ['adpMinR', 'minRegimeTrades'], ['adpRw', 'recentWeight'], ['adpLw', 'longTermWeight'], ['adpBo', 'bonusOn'], ['adpBs', 'bonusStrong'], ['adpSk', 'skipMinTrades']]) if (g(id) !== '') p[k] = Number(g(id));
    p.learnFrom = g('adpLearn'); editing = false; save(p);
  };

  function render() {
    if (!S || !S.cfg) { root.innerHTML = '<div class="a-card"><b>Adaptive engine</b><div class="a-msg bad">' + esc(S && S._err || 'Loading…') + '</div></div>'; return; }
    const c = S.cfg, a = S.applied || {}, I = S.intel || {}, on = S.enabled;
    const status = !on ? '<span class="pill LEARNING">OFF — original GPS selection (history still collected)</span>' : a.confirmed ? '<span class="pill FAVOURITE">ACTIVE — ' + esc(c.mode) + ' (confirmed by robot)</span>' : '<span class="pill RECOVERING">SAVED (' + esc(c.mode) + ') — NOT YET CONFIRMED BY THE ROBOT</span>';
    const nm = (x) => x ? esc(x.name) + ' <span class="a-k">(' + f(x.score, 0) + ')</span>' : '–';
    let h = '';
    if (S._err) h += '<div class="a-msg bad">' + esc(S._err) + '</div>';
    h += '<div class="a-card"><h3>ADAPTIVE WINNING STRATEGY ENGINE</h3><div class="a-row">' +
      '<div><div class="a-k">Adaptive engine</div><div class="a-sw ' + (on ? 'on' : '') + '" role="switch" aria-checked="' + on + '" onclick="__adpToggle()"><i></i></div></div>' +
      '<div><div class="a-k">Mode</div><div class="a-seg">' + ['OFF', 'ON', 'STRONG'].map(m => '<button class="' + (c.mode === m ? 'on' : '') + '" onclick="__adpMode(\'' + m + '\')">' + m + '</button>').join('') + '</div></div>' +
      '<div><div class="a-k">Status</div><div>' + status + '</div></div>' +
      '<div><div class="a-k">Current favourite</div><div class="a-v">' + (I.favourite ? esc(I.favourite.name) : '— none yet') + '</div></div>' +
      '<div><div class="a-k">Last ranking update</div><div class="a-v">' + ago(S.lastRankingUpdate) + '</div></div>' +
      '<div><div class="a-k">Closed trades learned from</div><div class="a-v">' + S.closedTrades + '</div><div class="a-k">' + (S.sources ? 'live ' + S.sources.live + ' · paper ' + S.sources.paper + ' · lab ' + S.sources.lab : '') + '</div></div></div>' +
      (msg ? '<div class="a-msg ' + msg.k + '">' + esc(msg.t) + '</div>' : '') +
      (!a.robotSeen ? '<div class="a-msg warn">The robot is not reporting right now. A saved setting applies the moment the robot is running; nothing is active until then.</div>' : '') +
      '<div class="a-k" style="margin-top:10px">OFF = original order · ON = proven strategies get up to +' + c.bonusOn + ' ranking points · STRONG = up to +' + c.bonusStrong + ' and proven losers (≥' + c.skipMinTrades + ' trades) can be skipped. It never changes size, leverage, stops or any risk limit, and never opens a setup that did not qualify.</div></div>';
    h += '<div class="a-card"><h3>Intelligence</h3><div class="a-grid">' +
      [['Overall winning strategy', nm(I.overall)], ['Best for current regime', nm(I.regimeBest)], ['Second best', nm(I.second)], ['Third best', nm(I.third)], ['Most improved', nm(I.mostImproved)], ['Deteriorating', nm(I.deteriorating)],
        ['Strategies evaluated', I.totalEvaluated], ['Current market regime', esc(I.regime || '–')], ['Current preferred strategy', nm(I.preferred)]].map(x => '<div><div class="a-k">' + x[0] + '</div><div class="a-v">' + x[1] + '</div></div>').join('') + '</div>' +
      '<div class="a-msg ' + (I.preferred ? 'ok' : 'warn') + '" style="margin-top:12px"><b>Why:</b> ' + esc(I.why || '') + '</div></div>';
    h += '<div class="a-card"><h3>Strategy performance ranking (realized, closed trades only)</h3><div style="overflow-x:auto"><table><thead><tr><th>#</th><th>Strategy</th><th>Win rate</th><th>Trades</th><th>Net PnL</th><th>PF</th><th>Expectancy</th><th>Max DD</th><th>Confidence</th><th>Status</th></tr></thead><tbody>' +
      (S.ranking || []).map(e => '<tr><td>' + e.rank + '</td><td><b>' + esc(e.name) + '</b></td><td>' + pct(e.winRate) + '</td><td>' + e.n + '</td><td class="' + (e.netPnl > 0 ? 'pos' : e.netPnl < 0 ? 'neg' : '') + '">' + f(e.netPnl) + '</td><td>' + f(e.profitFactor) + '</td><td>' + f(e.expectancy) + '</td><td>' + f(e.maxDrawdown) + '</td>' +
        '<td><div class="bar" title="' + e.n + ' / ' + c.minTrades + ' trades"><b style="width:' + Math.round((e.confidence || 0) * 100) + '%"></b></div></td><td><span class="pill ' + e.status + '">' + e.status + '</span></td></tr>').join('') +
      '</tbody></table></div><div class="a-k" style="margin-top:8px">Needs ' + c.minTrades + ' completed trades before a strategy can be favoured; below that selection stays balanced. Recent weight ' + pct(c.recentWeight) + ' · long-term ' + pct(c.longTermWeight) + '. Learning from: ' + esc(c.learnFrom) + '.</div></div>';
    h += '<div class="a-card"><h3>Decision transparency — latest selected trades</h3><div class="a-log">' + ((S.decisions || []).length ? S.decisions.map(d => '<div><b>' + esc(d.symbol) + ' ' + esc(d.direction) + '</b> · ' + esc(d.strategy_id) + ' · rank ' + (d.strategy_rank || '–') + ' · bonus ' + f(d.preference_score) + ' · ' + esc(d.adaptive_mode) + ' · <span class="' + (d.finalPnl > 0 ? 'pos' : d.finalPnl < 0 ? 'neg' : '') + '">' + (d.finalPnl == null ? 'OPEN' : esc(d.finalOutcome) + ' ' + f(d.finalPnl)) + '</span><br><span class="a-k">' + esc(d.reason) + '</span></div>').join('') : 'No adaptive selections recorded yet.') + '</div></div>';
    h += '<div class="a-card"><h3>Ranking changes &amp; favourite history</h3><div class="a-log">' + ((S.events || []).length ? S.events.map(e => '<div><span class="a-k">' + ago(e.ts) + ' · ' + esc(e.type) + '</span><br>' + esc(e.detail) + '</div>').join('') : 'No changes recorded yet.') + '</div><div class="a-k" style="margin-top:6px">' + S.snapshots + ' ranking snapshots stored.</div></div>';
    if (!on && (S.shadow || []).length) h += '<div class="a-card"><h3>Shadow mode (what ON would have favoured — nothing was changed)</h3><div class="a-log">' + S.shadow.slice(0, 8).map(x => '<div><span class="a-k">' + ago(x.ts) + '</span> original first pick <b>' + esc(x.original.symbol) + ' ' + esc(x.original.strategy) + '</b> → would pick <b>' + esc(x.wouldPick.symbol) + ' ' + esc(x.wouldPick.strategy) + '</b><br><span class="a-k">' + esc(x.reason) + '</span></div>').join('') + '</div></div>';
    h += '<div class="a-card"><h3>Settings</h3><div class="a-row">' +
      [['adpMin', 'Min trades', c.minTrades], ['adpMinR', 'Min per regime', c.minRegimeTrades], ['adpRw', 'Recent weight', f(c.recentWeight)], ['adpLw', 'Long-term weight', f(c.longTermWeight)], ['adpBo', 'ON bonus', c.bonusOn], ['adpBs', 'STRONG bonus', c.bonusStrong], ['adpSk', 'STRONG skip min', c.skipMinTrades]].map(x => '<div><div class="a-k">' + x[1] + '</div><input id="' + x[0] + '" value="' + x[2] + '" onfocus="window.__adpEdit(true)"></div>').join('') +
      '<div><div class="a-k">Learn from</div><select id="adpLearn" onfocus="window.__adpEdit(true)">' + ['all', 'live', 'paper', 'lab'].map(o => '<option' + (c.learnFrom === o ? ' selected' : '') + '>' + o + '</option>').join('') + '</select></div>' +
      '<button class="btn" onclick="__adpAdv()">Save settings</button></div></div>';
    root.innerHTML = h;
  }
  window.__adpEdit = (v) => { editing = v; };
  load(); setInterval(() => { if (document.getElementById('tab-adaptive').classList.contains('active') || pending) load(); }, 3000);
  const btn = document.getElementById('adpTabBtn'); if (btn) btn.addEventListener('click', () => { editing = false; load(); });
})();
