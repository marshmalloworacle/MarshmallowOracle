/* ALPHA LIVE ROBOT v6.0: alert banners, trade controls (Take Live Trades, leverage, drawdown guard, close losing/winning),
   Insights drawer (decision history + per-position module advisor). Presentation only: every number comes from /api/v6/* (real backend events). */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ls = { get: (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (_) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) { /* private mode */ } } };
  const get = async (p) => { const r = await fetch(p, { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); };
  const post = async (p, b) => { const r = await fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Alpha': '1' }, body: JSON.stringify(b || {}) }); let j = {}; try { j = await r.json(); } catch (_) { /* non-json */ } return { ok: r.ok && j.ok !== false, body: j }; };
  const ago = (ts) => { const s = Math.max(0, Math.round((Date.now() - ts) / 1000)); return s < 90 ? s + 's ago' : s < 5400 ? Math.round(s / 60) + 'm ago' : Math.round(s / 3600) + 'h ago'; };
  // ── auto-fading messages: nothing to click, everything fades by itself; full history stays in Insights ──
  const stack = document.createElement('div'); stack.id = 'v6Toasts'; stack.setAttribute('aria-live', 'polite'); document.body.appendChild(stack);
  const curMode = () => (C && C.isLive ? 'live' : 'paper');
  function show(msg, kind, ms, sub, mode) {
    mode = mode === 'live' || mode === 'paper' ? mode : curMode();
    const t = document.createElement('div'); t.className = 'v6-toast ' + kind + ' m-' + mode; t.style.setProperty('--ms', ms + 'ms');
    t.innerHTML = '<i></i><div><span class="v6-mode ' + mode + '">' + mode.toUpperCase() + '</span><b>' + esc(msg) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</div>';
    stack.appendChild(t); while (stack.children.length > 4) stack.firstChild.remove();
    setTimeout(() => t.remove(), ms + 400);
  }
  function toast(msg, ok) { show(msg, ok ? 'ok' : 'warn', ok ? 4000 : 8000); }
  window.__v6toast = toast;
  let since = Date.now(); const lastShown = {}; let unseenCrit = false;
  const KIND = { CRITICAL: ['crit', 25000], WARNING: ['warn', 9000], INFO: ['info', 5000] };
  async function pollFeed() {
    let d; try { d = await get('/api/v6/feed?since=' + since); } catch (_) { return; }
    since = d.now || Date.now();
    for (const b of (d.events || []).slice().reverse()) {
      if (lastShown[b.id] && Date.now() - lastShown[b.id] < 60000) continue;   // repeats of the same event stay quiet for a minute
      lastShown[b.id] = Date.now(); const [k, ms] = KIND[b.severity] || KIND.INFO;
      show((b.symbol ? b.symbol + (b.direction ? ' ' + b.direction : '') + ' - ' : '') + b.reason, k, ms, (b.module || 'robot') + (b.recommend ? ' · ' + b.recommend : ''), b.mode);
      if (b.severity === 'CRITICAL') unseenCrit = true;
    }
    const fab = $('#v6Fab .dot'); if (fab) fab.style.display = unseenCrit ? 'inline-block' : 'none';
  }

  // ── controls bar ─────────────────────────────────────────────────────────────────────────────────
  const bar = document.createElement('div'); bar.id = 'v6Bar'; const header = $('header.header'); if (header) header.after(bar); else document.body.prepend(bar);
  let C = null, busy = false;
  function sizingHtml() {
    const z = C.sizing || {}, P = C.presets || { margin: [1, 2, 5, 8, 10, 20], leverage: [5, 10, 12, 20, 50] };
    const seg = (id, arr, cur, suf) => '<div class="v6-seg" id="' + id + '">' + arr.map(v => '<button data-v="' + v + '" class="' + (Number(cur) === v ? 'on' : '') + '">' + v + suf + '</button>').join('') + '</div>';
    const custom = (k, ph, ok) => ok === false ? '' : '<input type="number" min="0" step="any" data-cin="' + k + '" placeholder="' + ph + '" style="width:64px;background:var(--card-alt);border:1px solid var(--border-light);border-radius:6px;padding:5px;color:var(--text);font-size:12px"><button class="v6-btn" data-cset="' + k + '">Set</button>';
    if (!z.enabled) return '<div class="grp"><span class="l">Sizing</span><span>Manual sizing is OFF in .env (equity scaling in use)</span></div>';
    const stp = C.marginStep || 0.5, stepBtn = (d, s) => '<button class="v6-btn" data-mstep="' + d + '" title="' + (d < 0 ? 'Decrease' : 'Increase') + ' margin by ' + stp + ' USDT (next trades only)" style="min-width:30px;font-weight:800">' + s + '</button>';
    return '<div class="grp"><span class="l">Margin / trade</span>' + stepBtn(-1, '−') + '<b style="min-width:56px;text-align:center;color:var(--accent-2)" title="Current margin per new trade">' + z.margin + ' USDT</b>' + stepBtn(1, '+') + seg('v6Mar', P.margin, z.margin, '') + custom('margin', 'USDT', C.customMargin) + '</div>' +
      '<div class="grp"><span class="l">Leverage</span>' + seg('v6Lev', P.leverage, z.leverage, 'x') + custom('lev', 'x', C.customLeverage) + '</div>' +
      '<div class="grp" title="Applies to the NEXT new trade. Open trades keep their own margin, leverage and stop."><b style="color:var(--accent-2)">Next trade: ' + z.margin + ' USDT x ' + z.leverage + 'x = ' + z.notional + ' USDT position</b></div>';
  }
  function renderBar() {
    if (!C) { bar.innerHTML = '<span class="v6-note">Trade controls unavailable (cannot reach /api/v6/controls).</span>'; return; }
    const live = C.isLive, on = C.takeLiveTrades === true;
    bar.innerHTML =
      '<div class="grp"><button class="v6-take ' + (on ? 'on' : 'off') + '" id="v6Take" title="Master permission for the robot to open NEW trades. OFF at every start. Open trades keep their stops either way."><i></i>' + (live ? 'Take Live Trades' : 'Take Trades (paper)') + ': ' + (on ? 'ON' : 'OFF') + '</button></div>' +
      sizingHtml() +
      '<div class="grp"><span class="l">Drawdown</span><select id="v6Dd" title="Warn = banner only (default). Enforce = limits can block trades / cut size. Live only."><option value="warn"' + (C.drawdownMode === 'warn' ? ' selected' : '') + '>Warn only</option><option value="enforce"' + (C.drawdownMode === 'enforce' ? ' selected' : '') + '>Enforce limits</option><option value="off"' + (C.drawdownMode === 'off' ? ' selected' : '') + '>Off</option></select></div>' +
      '<div class="grp"><button class="v6-btn loss" data-close="losing">Close ALL losing</button><button class="v6-btn win" data-close="winning">Close ALL winning</button></div>' +
      (C.liveStatus && C.liveStatus.error ? '<div class="grp" style="color:var(--red)">Live cycle: ' + esc(C.liveStatus.error) + '</div>' : '');
  }
  bar.addEventListener('click', async (e) => {
    if (busy) return; const t = e.target.closest('button'); if (!t) return;
    try {
      if (t.id === 'v6Take') { busy = true; const r = await post('/api/v6/take', { on: !(C && C.takeLiveTrades === true) }); toast(r.ok ? r.body.message : (r.body.error || 'Refused'), r.ok); }
      else if (t.closest('#v6Lev')) { busy = true; const r = await post('/api/v6/leverage', { value: t.dataset.v }); toast(r.ok ? r.body.message : (r.body.error || 'Refused'), r.ok); }
      else if (t.dataset.mstep) { busy = true; const r = await post('/api/v6/margin', { delta: Number(t.dataset.mstep) }); toast(r.ok ? r.body.message : (r.body.error || 'Refused'), r.ok); }
      else if (t.closest('#v6Mar')) { busy = true; const r = await post('/api/v6/margin', { value: t.dataset.v }); toast(r.ok ? r.body.message : (r.body.error || 'Refused'), r.ok); }
      else if (t.dataset.cset) { const k = t.dataset.cset, v = ($('[data-cin="' + k + '"]', bar) || {}).value; if (!v) return; busy = true; const r = await post(k === 'margin' ? '/api/v6/margin' : '/api/v6/leverage', { value: v }); toast(r.ok ? r.body.message : (r.body.error || 'Refused'), r.ok); }
      else if (t.dataset.close) {
        const w = t.dataset.close; if (!confirm('Close ALL ' + w.toUpperCase() + ' positions now at market (reduce-only)?\n' + (w === 'losing' ? 'Winning trades keep running.' : 'Losing trades keep running.') + '\nNew-trade permission is NOT changed.')) return;
        busy = true; t.disabled = true; const r = await post('/api/v6/close-by-pnl', { which: w, confirm: true }); toast(r.ok ? (r.body.message || 'Done') : (r.body.error || 'Refused'), r.ok); t.disabled = false;
      }
    } catch (er) { toast(er.message, false); }
    busy = false; await pollControls(); pollBanners();
  });
  bar.addEventListener('change', async (e) => { if (e.target.id !== 'v6Dd') return; const m = e.target.value;
    if (m !== 'warn' && !confirm(m === 'off' ? 'Switch the drawdown guard OFF? No warnings and no limits (stop-losses stay on).' : 'ENFORCE: drawdown / daily-loss limits can reduce slots, cut leverage or block new trades again. Continue?')) { pollControls(); return; }
    const r = await post('/api/v6/drawdown-mode', { mode: m }); toast(r.ok ? r.body.message : (r.body.error || 'Refused'), r.ok); pollControls(); });
  async function pollControls() { try { C = await get('/api/v6/controls'); } catch (_) { C = null; } if (!busy) renderBar(); }

  // ── Insights drawer ──────────────────────────────────────────────────────────────────────────────
  const fab = document.createElement('button'); fab.id = 'v6Fab'; fab.innerHTML = 'Insights<span class="dot" style="display:none"></span>'; document.body.appendChild(fab);
  const dr = document.createElement('aside'); dr.id = 'v6Drawer'; dr.setAttribute('aria-label', 'Insights');
  dr.innerHTML = '<header><b>Insights</b><button class="v6-btn" id="v6X">Close</button></header><div class="tabs"><button data-t="trd" class="on">Open trades</button><button data-t="adv">Position advisor</button><button data-t="dec">Decision history</button><button data-t="perf">Performance</button><button data-t="pre">Presets</button></div><div id="v6Body"></div>'; document.body.appendChild(dr);
  const S = { tab: 'trd', f: '', q: '', open: new Set() };
  fab.onclick = () => { unseenCrit = false; const d = $('#v6Fab .dot'); if (d) d.style.display = 'none'; dr.classList.add('open'); refresh(); }; $('#v6X', dr).onclick = () => dr.classList.remove('open');
  dr.querySelector('.tabs').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; S.tab = b.dataset.t; dr.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b)); refresh(); };
  const body = $('#v6Body', dr);
  const FT = { '': 'All', BLOCK: 'Blocked', TRADE_OPENED: 'Opened', TRADE_CLOSED: 'Closed', TRADE_MODIFIED: 'Modified', TRADE_WARNING: 'Warnings', SYSTEM: 'Settings' };
  async function renderDecisions() {
    let d; try { d = await get('/api/v6/decisions?limit=150&q=' + encodeURIComponent(S.q)); } catch (e) { body.innerHTML = '<p class="v6-note">Could not load: ' + esc(e.message) + '</p>'; return; }
    let ev = d.events || []; if (S.f === 'BLOCK') ev = ev.filter(x => /BLOCKED|REJECTED|ORDER_FAILED/.test(x.type)); else if (S.f) ev = ev.filter(x => x.type === S.f);
    body.innerHTML = '<div class="v6-flt">' + Object.entries(FT).map(([k, v]) => '<button data-f="' + k + '" class="' + (S.f === k ? 'on' : '') + '">' + v + '</button>').join('') + '<input id="v6Q" placeholder="Search symbol, module, reason" value="' + esc(S.q) + '"></div>' +
      (ev.length ? ev.map(x => '<div class="v6-ev ' + x.severity + (S.open.has(x.id) ? ' open' : '') + '" data-id="' + esc(x.id) + '"><div class="h"><span><b>' + esc(x.symbol ? x.symbol + (x.direction ? ' ' + x.direction : '') : 'Robot') + '</b> · ' + esc(x.type.replace(/_/g, ' ').toLowerCase()) + (x.count > 1 ? ' <span class="v6-chip">x' + x.count + '</span>' : '') + '</span><span>' + ago(x.lastTs) + '</span></div><div>' + esc(x.reason) + '</div>' +
        '<div class="det"><div>Module: <code>' + esc(x.module || '-') + '</code>' + (x.strategy ? ' · Strategy: <code>' + esc(x.strategy) + '</code>' : '') + (x.mode ? ' · ' + esc(x.mode) : '') + '</div>' + (x.action ? '<div>Action: ' + esc(x.action) + '</div>' : '') + (x.outcome ? '<div>Outcome: ' + esc(x.outcome) + '</div>' : '') + (x.measured ? '<div>Measured: <code>' + esc(JSON.stringify(x.measured)) + '</code></div>' : '') +
        (x.recommend ? '<div>Suggestion: ' + esc(x.recommend) + '</div>' : '') + '<div>When: ' + new Date(x.ts).toLocaleString() + '</div>' + (x.snapshot ? '<div>Module switches at that moment: <code>' + esc(Object.entries(x.snapshot.modules || {}).filter(([, v]) => v).map(([k]) => k).join(', ') || 'none ON') + '</code> · drawdown guard <code>' + esc(x.snapshot.drawdownMode) + '</code> · leverage <code>' + esc(x.snapshot.leverage) + '</code></div>' : '') + '<div class="v6-note">History is fixed at the time of the event; changing modules later does not rewrite it.</div></div></div>').join('') : '<p class="v6-note">No events yet. Blocked entries, opened trades, closes and warnings appear here with the module that caused them.</p>');
  }
  const dot = (s) => '<span class="v6-dot ' + s + '"></span>';
  async function renderAdvisor() {
    let d; try { d = await get('/api/v6/advisor'); } catch (e) { body.innerHTML = '<p class="v6-note">Could not load: ' + esc(e.message) + '</p>'; return; }
    if (!d.rows.length) { body.innerHTML = '<p class="v6-note">No open positions' + (d.ageSec == null ? ' (the robot has not published a snapshot yet)' : '') + '. Positions opened in your exchange app appear here too and are marked MANUAL.</p><p class="v6-note">' + esc(d.note) + '</p>'; return; }
    body.innerHTML = '<p class="v6-note">' + esc(d.note) + (d.ageSec != null ? ' Updated ' + d.ageSec + 's ago.' : '') + '</p>' + d.rows.map(r => { const g = r.integrity || {}, pct = (v) => v == null ? '--' : v + '%', w = (v) => v == null ? 0 : v;
      return '<div class="v6-pos"><h4><span>' + esc(r.symbol) + ' ' + esc(r.side) + (r.manual ? ' <span class="v6-chip">MANUAL</span>' : '') + (r.stage ? ' <span class="v6-chip">' + esc(r.stage) + '</span>' : '') + '</span><span style="font-family:var(--font-num);color:' + (r.upnl > 0 ? 'var(--green)' : r.upnl < 0 ? 'var(--red)' : 'var(--text-muted)') + '">' + (r.upnl == null ? '' : (r.upnl >= 0 ? '+' : '') + Number(r.upnl).toFixed(4)) + '</span></h4>' +
        '<div class="v6-meters"><div class="v6-meter"><small>Entry integrity</small><b>' + pct(g.entry) + '</b><i><u style="width:' + w(g.entry) + '%"></u></i></div><div class="v6-meter"><small>Current health</small><b>' + pct(g.current) + '</b><i><u style="width:' + w(g.current) + '%"></u></i></div><div class="v6-meter"><small>Data coverage</small><b>' + pct(g.coverage) + '</b><i><u style="width:' + w(g.coverage) + '%"></u></i></div></div>' +
        '<div class="v6-note">' + esc(g.band || '') + ' alignment. A quality checklist, not a win probability.</div>' + (g.factors || []).map(f => '<div class="v6-fac">' + dot(f.status) + '<span><b style="color:var(--text)">' + esc(f.label) + '</b> - ' + esc(f.detail) + '</span></div>').join('') +
        (r.recommendations || []).map(c => '<div class="v6-rec"><b>' + esc(c.label) + '</b>' + (c.module ? ' <label style="float:right"><input type="checkbox" data-mod="' + esc(c.module) + '" ' + (c.enabled ? 'checked' : '') + '> ' + (c.enabled ? 'ON' : 'OFF') + '</label>' : '') + '<div class="r">' + esc(c.why) + '</div><div class="r">Benefit: ' + esc(c.benefit) + '</div><div class="r">Risk: ' + esc(c.risk) + '</div><div class="r v6-note">' + esc(c.note) + '</div></div>').join('') + '</div>'; }).join('');
  }
  body.addEventListener('click', (e) => {
    const fb = e.target.closest('.v6-flt button'); if (fb) { S.f = fb.dataset.f; refresh(); return; }
    const ev = e.target.closest('.v6-ev'); if (ev) { const id = ev.dataset.id; S.open.has(id) ? S.open.delete(id) : S.open.add(id); ev.classList.toggle('open'); }
  });
  let qt = null; body.addEventListener('input', (e) => { if (e.target.id === 'v6Q') { S.q = e.target.value; clearTimeout(qt); qt = setTimeout(() => refresh(true), 350); } });
  body.addEventListener('change', async (e) => { const m = e.target.dataset && e.target.dataset.mod; if (!m) return;
    const r = await post('/api/v46/features', { key: m, enabled: e.target.checked }); toast(r.ok ? 'Module ' + (e.target.checked ? 'switched ON' : 'switched OFF') + ' (applies to all positions)' : (r.body.error || 'Rejected'), r.ok); refresh(); });
  const money = (v) => (v >= 0 ? '+' : '') + Number(v).toFixed(2);
  async function renderPerf() {
    let d, w; try { d = await get('/api/v6/performance'); } catch (e) { body.innerHTML = '<p class="v6-note">Could not load: ' + esc(e.message) + '</p>'; return; }
    if (S.wi) { try { w = await get('/api/v6/whatif?module=' + encodeURIComponent(S.wi)); } catch (_) { w = null; } }
    const cell = (x) => x.trades ? x.trades + ' trades · ' + (x.winRate == null ? '--' : Math.round(x.winRate * 100) + '% wins') + ' · ' + money(x.netPnl) : 'no trades';
    body.innerHTML = '<p class="v6-note">Compares your closed trades when each module was ON versus OFF. Results are labelled low-confidence until both sides have 30+ trades. This shows correlation in your own history, not proof a module helps.</p><p class="v6-note">Closed trades recorded: <b>' + d.totalClosed + '</b></p>' +
      d.rows.map(r => '<div class="v6-pos"><h4><span>' + esc(r.label) + '</span><button class="v6-btn" data-wi="' + esc(r.key) + '">What-if</button></h4><div class="v6-fac"><span>ON: ' + cell(r.whenOn) + '</span></div><div class="v6-fac"><span>OFF: ' + cell(r.whenOff) + '</span></div>' + (r.blocks ? '<div class="v6-fac"><span>Blocked ' + r.blocks + ' entries</span></div>' : '') + '<div class="v6-note">' + esc(r.note) + '</div>' +
      (S.wi === r.key && w ? (w.ok === false ? '<div class="v6-rec">' + esc(w.error || 'No what-if for this module') + '</div>' : '<div class="v6-rec"><b>What-if (simulated)</b><div class="r">Of ' + w.evaluable + ' trades that had measurements, this filter would have blocked ' + w.wouldHaveBlocked + ' (their net result ' + money(w.blockedTradesPnl) + ').</div><div class="r">Kept trades: ' + money(w.keptTradesPnl) + '. Verdict: <b>' + esc(w.verdict) + '</b> (' + esc(w.confidence) + ').</div><div class="r v6-note">' + esc(w.note) + '</div></div>') : '') + '</div>').join('');
  }
  async function renderPresets() {
    let d; try { d = await get('/api/v6/presets'); } catch (e) { body.innerHTML = '<p class="v6-note">Could not load: ' + esc(e.message) + '</p>'; return; }
    body.innerHTML = '<p class="v6-note">A preset sets module switches and risk-budget numbers only. It never changes Take Live Trades, live authorisation, margin, leverage, drawdown mode or stop-loss. You see exactly what changes first, and you can undo.</p>' + (d.active ? '<p class="v6-note">Last applied: <b>' + esc(d.active.name) + '</b></p>' : '') +
      d.presets.map(p => '<div class="v6-pos"><h4><span>' + esc(p.label) + '</span><button class="v6-btn" data-pre="' + esc(p.name) + '">' + (S.pv === p.name ? 'Hide' : 'Preview') + '</button></h4><div class="v6-note">' + esc(p.blurb) + '</div>' +
        (S.pv === p.name ? '<div class="v6-rec">' + (p.changes.length ? p.changes.map(c => '<div class="r"><b>' + esc(c.label) + '</b>: ' + esc(c.from) + ' &rarr; ' + esc(c.to) + '</div>').join('') : '<div class="r">Already matches this preset.</div>') + (p.changes.length ? '<button class="v6-btn win" data-apply="' + esc(p.name) + '" style="margin-top:8px">Apply ' + esc(p.label) + '</button>' : '') + '</div>' : '') + '</div>').join('') + (d.canUndo ? '<button class="v6-btn loss" data-undo>Undo last preset</button>' : '');
  }
  body.addEventListener('click', async (e) => {
    const w = e.target.closest('[data-wi]'); if (w) { S.wi = S.wi === w.dataset.wi ? '' : w.dataset.wi; refresh(); return; }
    const p = e.target.closest('[data-pre]'); if (p) { S.pv = S.pv === p.dataset.pre ? '' : p.dataset.pre; refresh(); return; }
    const a = e.target.closest('[data-apply]'); if (a) { const r = await post('/api/v6/presets/apply', { name: a.dataset.apply, confirm: true }); toast(r.ok ? r.body.message : (r.body.error || 'Rejected'), r.ok); S.pv = ''; refresh(); return; }
    if (e.target.closest('[data-undo]')) { const r = await post('/api/v6/presets/revert', {}); toast(r.ok ? r.body.message : (r.body.error || 'Rejected'), r.ok); refresh(); }
  });
  // ── Open trades: per-trade panel (levels chart, protection status, close) ──
  const px = (v) => v == null || !Number.isFinite(Number(v)) ? '--' : Number(v) >= 100 ? Number(v).toFixed(2) : String(Number(Number(v).toPrecision(5)));
  const same = (a, b) => a != null && b != null && Math.abs(a - b) <= Math.abs(b) * 0.0003;
  function trailInfo(r, d) {
    const fl = d.flags || {}, long = r.side === 'LONG', moved = r.stop != null && r.initialStop != null && !same(r.stop, r.initialStop) && (long ? r.stop > r.initialStop : r.stop < r.initialStop);
    if (!r.protectedStop) return { cls: 'bad', head: 'NO STOP-LOSS on the exchange', text: 'This position has no stop. Set one in the exchange app; the robot then trails it (tightens only).' };
    if (!fl.smartTrailing) return { cls: 'warn', head: 'Trailing OFF', text: 'The Smart trailing stop module is switched OFF in Modules, so the stop will not move.' };
    if (r.manual && !d.manualExits) return { cls: moved ? 'ok' : 'warn', head: moved ? 'Trailing active (manual, trail only)' : 'Waiting (manual, trail only)', text: 'Opened outside the robot: it only tightens the stop and never auto-closes it.' };
    if (moved) return { cls: 'ok', head: 'Trailing ACTIVE', text: 'Stop moved from ' + px(r.initialStop) + ' to ' + px(r.stop) + ((r.moves || []).length ? ' (' + r.moves.length + ' move' + (r.moves.length > 1 ? 's' : '') + ').' : '.') + (r.stopReason ? ' Last: ' + r.stopReason : '') };
    return { cls: 'warn', head: 'Waiting to trail', text: 'Stop still at its original level. Trailing starts once the trade is in enough profit (stage: ' + (r.stage || 'entry') + '; progress ' + (r.progress == null ? '--' : r.progress + '% of the way to target') + ').' };
  }
  const chartKill = [];
  function drawChart(el, r) {
    if (!window.LightweightCharts) { el.innerHTML = '<p class="v6-note" style="padding:12px">Chart library not loaded (needs internet). Levels are shown above.</p>'; return; }
    const ch = LightweightCharts.createChart(el, { height: 260, layout: { background: { color: 'transparent' }, textColor: '#9DAAA3' }, grid: { vertLines: { color: 'rgba(255,255,255,.04)' }, horzLines: { color: 'rgba(255,255,255,.05)' } }, rightPriceScale: { borderVisible: false }, timeScale: { borderVisible: false, timeVisible: true } });
    const cs = ch.addCandlestickSeries({ upColor: '#00E676', downColor: '#FF5C6C', wickUpColor: '#00E676', wickDownColor: '#FF5C6C', borderVisible: false });
    const line = (price, color, title, style) => { if (price != null && Number.isFinite(Number(price))) cs.createPriceLine({ price: Number(price), color, lineWidth: 2, lineStyle: style || 0, axisLabelVisible: true, title }); };
    const moved = r.stop != null && r.initialStop != null && !same(r.stop, r.initialStop);
    line(r.entry, '#8cc2ff', 'ENTRY', 2); line(r.tp, '#00E676', 'TP', 0); line(moved ? r.initialStop : null, '#6B7771', 'SL (start)', 2); line(r.stop, moved ? '#FFC24B' : '#FF5C6C', moved ? 'TRAIL STOP' : 'SL', 0);
    get('/api/dashboard/chart/' + encodeURIComponent(r.symbol) + '?interval=15m&limit=200').then(d => {
      cs.setData((d.candles || []).map(c => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close })));
      const times = (d.candles || []).map(c => c.time);
      const mk = (r.moves || []).map(m => { const t = Math.floor(m.ts / 1000); const near = times.filter(x => x <= t).pop(); return near ? { time: near, position: r.side === 'LONG' ? 'belowBar' : 'aboveBar', color: '#FFC24B', shape: 'arrowUp', text: 'stop ' + px(m.stop) } : null; }).filter(Boolean);
      if (mk.length) cs.setMarkers(mk);
      ch.timeScale().fitContent();
    }).catch(() => { el.insertAdjacentHTML('beforeend', '<p class="v6-note" style="padding:12px">Candles unavailable right now; the level lines still show.</p>'); });
    chartKill.push(() => ch.remove());
  }
  async function renderTrades() {
    chartKill.splice(0).forEach(f => { try { f(); } catch (_) { /* gone */ } });
    let d; try { d = await get('/api/v6/advisor'); } catch (e) { body.innerHTML = '<p class="v6-note">Could not load: ' + esc(e.message) + '</p>'; return; }
    S.trMode = d.mode;
    if (!d.rows.length) { body.innerHTML = '<p class="v6-note">No open ' + d.mode.toUpperCase() + ' trades. Each open trade appears here with its chart, protection status and a Close button' + (d.ageSec == null ? ' (the robot has not published a snapshot yet)' : '') + '.</p>'; return; }
    body.innerHTML = d.rows.map(r => { const k = r.symbol + ':' + r.side, open = S.tr === k, ti = trailInfo(r, d), pnl = r.upnl;
      return '<div class="v6-pos v6-tr"><div class="row" data-open="' + esc(k) + '"><span class="v6-mode ' + d.mode + '">' + d.mode.toUpperCase() + '</span><b>' + esc(r.symbol) + ' ' + esc(r.side) + '</b>' + (r.manual ? '<span class="v6-chip">MANUAL</span>' : '') + '<span class="v6-chip">' + esc(ti.head) + '</span><span class="sp"></span><b style="color:' + (pnl > 0 ? 'var(--green)' : pnl < 0 ? 'var(--red)' : 'var(--text-muted)') + '">' + (pnl == null ? '' : (pnl >= 0 ? '+' : '') + Number(pnl).toFixed(4)) + '</b><button class="v6-btn danger" data-close="' + esc(k) + '">Close</button></div>' +
        (open ? '<div class="stats"><div>Entry<b>' + px(r.entry) + '</b></div><div>Mark<b>' + px(r.mark) + '</b></div><div>Stop now<b>' + px(r.stop) + '</b></div><div>Start stop<b>' + px(r.initialStop) + '</b></div><div>Take-profit<b>' + px(r.tp) + '</b></div><div>Stage<b>' + esc(r.stage || '--') + '</b></div><div>To stop<b>' + (r.distToStopPct == null ? '--' : r.distToStopPct + '%') + '</b></div><div>Open for<b>' + (r.hoursOpen == null ? '--' : r.hoursOpen + 'h') + '</b></div></div>' +
          '<div class="why"><span class="v6-dot ' + (ti.cls === 'ok' ? 'green' : ti.cls === 'bad' ? 'red' : 'amber') + '"></span> <b style="color:var(--text)">' + esc(ti.head) + '.</b> ' + esc(ti.text) + '</div><div class="v6-chart" data-chart="' + esc(k) + '"></div>' +
          '<div class="v6-legend"><span><i style="border-color:#8cc2ff"></i>Entry</span><span><i style="border-color:#FF5C6C"></i>Stop-loss</span><span><i style="border-color:#FFC24B"></i>Trailing stop</span><span><i style="border-color:#00E676"></i>Take-profit</span></div>' : '<div class="why">' + esc(ti.text) + '</div>') + '</div>'; }).join('');
    const o = S.tr && d.rows.find(r => r.symbol + ':' + r.side === S.tr), el = o && [...body.querySelectorAll('[data-chart]')].find(x => x.dataset.chart === S.tr);
    if (o && el) drawChart(el, o);
  }
  body.addEventListener('click', async (e) => {
    const c = e.target.closest('[data-close]');
    if (c) { e.stopPropagation(); const k = c.dataset.close, i = k.lastIndexOf(':'), sym = k.slice(0, i), side = k.slice(i + 1);
      if (c.dataset.armed !== '1') { c.dataset.armed = '1'; const was = c.textContent; c.textContent = 'Confirm close ' + sym + '?'; setTimeout(() => { if (c.isConnected) { c.dataset.armed = ''; c.textContent = was; } }, 5000); return; }
      c.disabled = true; c.textContent = 'Closing...';
      try {
        let r; if (S.trMode === 'live') r = await post('/api/live/close', { symbol: sym, confirm: true });
        else { const row = (await get('/api/v6/advisor')).rows.find(x => x.symbol === sym && x.side === side); r = await post('/api/positions/close/' + encodeURIComponent((row && row.id) || sym), {}); }
        toast(r.ok ? 'Close sent for ' + sym + ' (' + String(S.trMode || curMode()).toUpperCase() + ')' : ((r.body && (r.body.error || r.body.reason)) || 'Close rejected'), r.ok);
      } catch (er) { toast('Close failed: ' + er.message, false); }
      setTimeout(refresh, 1500); return;
    }
    const o = e.target.closest('[data-open]'); if (o && S.tab === 'trd') { S.tr = S.tr === o.dataset.open ? '' : o.dataset.open; refresh(); }
  });
  async function refresh(keepFocus) { if (!dr.classList.contains('open')) return; const q = $('#v6Q'); const hadFocus = keepFocus && q && document.activeElement === q; if (S.tab === 'dec') await renderDecisions(); else if (S.tab === 'perf') await renderPerf(); else if (S.tab === 'pre') await renderPresets(); else if (S.tab === 'trd') await renderTrades(); else await renderAdvisor(); if (hadFocus) { const n = $('#v6Q'); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } } }

  pollControls(); pollFeed();
  setInterval(() => { if (!document.hidden) { pollFeed(); pollControls(); } }, 4000);
  setInterval(() => { if (!document.hidden && dr.classList.contains('open') && !(document.activeElement && document.activeElement.id === 'v6Q')) refresh(); }, 8000);
})();
