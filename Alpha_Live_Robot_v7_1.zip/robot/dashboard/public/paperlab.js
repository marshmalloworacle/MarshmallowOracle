/* ALPHA LIVE ROBOT v7.0 — PAPER LAB page. While you trade LIVE, every qualified scanner setup also runs on a SEPARATE paper account.
   Presentation only: all numbers come from /api/lab/status (the robot's own paper journal, rows tagged LAB). Nothing here touches live orders. */
(function () {
  'use strict';
  const root = document.getElementById('plRoot'); if (!root) return;
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const f = (v, d) => (v == null || !isFinite(v)) ? '–' : Number(v).toFixed(d == null ? 2 : d);
  const sg = (v, d) => (v == null || !isFinite(v)) ? '–' : (v > 0 ? '+' : '') + Number(v).toFixed(d == null ? 2 : d);
  const pc = (v) => v == null ? '–' : Math.round(v * 100) + '%';
  const cl = (v) => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const ago = (ts) => { if (!ts) return '–'; const s = Math.max(0, Math.round((Date.now() - ts) / 1000)); return s < 90 ? s + 's ago' : s < 5400 ? Math.round(s / 60) + 'm ago' : s < 172800 ? Math.round(s / 3600) + 'h ago' : Math.round(s / 86400) + 'd ago'; };
  const sw = (on) => '<span class="sw ' + (on ? 'on' : '') + '" role="switch" aria-checked="' + on + '" onclick="__plToggle()"><i></i></span>';
  let S = null, msg = '', busy = false;

  async function load() {
    try { const r = await fetch('/api/lab/status?tz=' + new Date().getTimezoneOffset(), { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); S = await r.json(); S._err = null; }
    catch (e) { S = S || {}; S._err = 'Backend not reachable (' + e.message + ') — values may be stale.'; }
    render();
  }
  window.__plToggle = async () => {
    if (busy || !S) return; busy = true; msg = 'Saving…'; render();
    try {
      const r = await fetch('/api/lab/config', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Alpha': '1' }, body: JSON.stringify({ enabled: !S.enabled }) }); const j = await r.json().catch(() => ({}));
      msg = r.ok && j.ok !== false ? j.message : 'NOT saved: ' + (j.error || 'HTTP ' + r.status);
    } catch (e) { msg = 'NOT saved — backend not reachable: ' + e.message; }
    busy = false; await load();
  };
  const cap = '<span class="cap" title="Opened while your LIVE position limit would already have been full">▲ OVER LIVE CAP</span>';
  function render() {
    if (!S || S.ok === undefined) { root.innerHTML = '<div class="pl-card">' + esc(S && S._err || 'Loading Paper Lab…') + '</div>'; return; }
    const v = S.verdict || {}, t = S.today || {}, w = S.week || {}, tot = S.totals || {};
    let h = '';
    if (S._err) h += '<div class="pl-card neg">' + esc(S._err) + '</div>';
    h += '<div class="pl-card"><h3>PAPER LAB — scanned setups on a separate paper account</h3><div style="display:flex;gap:18px;flex-wrap:wrap;align-items:center">' +
      '<div><div class="k">Paper Lab</div>' + sw(S.enabled) + '</div><div><div class="k">Paper balance</div><div class="v">$' + f(S.balance) + '</div></div>' +
      '<div><div class="k">Realised</div><div class="v ' + cl(S.realized) + '">' + sg(S.realized) + '</div></div><div><div class="k">Unrealised</div><div class="v ' + cl(S.unrealized) + '">' + sg(S.unrealized) + '</div></div>' +
      '<div><div class="k">Open paper trades</div><div class="v">' + (S.open || []).length + '</div></div><div><div class="k">Beyond live cap</div><div class="v">' + (S.openOverCap || 0) + ' open · ' + ((S.closedOverCap || {}).n || 0) + ' closed</div></div></div>' +
      (msg ? '<div class="k" style="margin-top:10px">' + esc(msg) + '</div>' : '') +
      (!S.live ? '<div class="verdict WAIT" style="margin-top:12px">You are not in LIVE mode, so the whole robot is already running on paper. Paper Lab only runs next to live trading.</div>' : '') +
      '<div class="k" style="margin-top:10px">' + esc(S.note || '') + ' A "▲ OVER LIVE CAP" mark means the paper trade was opened when your live position limit (' + esc(S.liveCap) + ') would already have been full.</div></div>';
    h += '<div class="verdict ' + esc(v.level) + '" style="margin-bottom:14px">' + esc(v.level === 'GOOD' ? '🟢 GOOD DAY — ' : v.level === 'POOR' ? '🔴 POOR DAY — ' : v.level === 'NEUTRAL' ? '🟡 MIXED DAY — ' : '⏳ ') + esc(v.text || '') +
      '<div class="k" style="margin-top:6px;font-weight:500">Paper results only — an aid for you, never an instruction to the live robot.</div></div>';
    h += '<div class="pl-card"><h3>Today vs last 7 days</h3><div class="pl-grid">' +
      [['Today closed', t.n], ['Today win rate', pc(t.winRate)], ['Today net', sg(t.net), cl(t.net)], ['Today PF', f(t.pf)], ['7d closed', w.n], ['7d win rate', pc(w.winRate)], ['7d net', sg(w.net), cl(w.net)], ['All-time net', sg(tot.net), cl(tot.net)]]
        .map(x => '<div><div class="k">' + x[0] + '</div><div class="v ' + (x[2] || '') + '">' + x[1] + '</div></div>').join('') + '</div></div>';
    const chips = (arr, bad) => (arr || []).map(c => '<span class="chip ' + (bad ? 'neg' : 'pos') + '">' + esc(c.key) + ' ' + sg(c.net) + ' · ' + c.n + ' trades · ' + pc(c.winRate) + '</span>').join('') || '<span class="k">Not enough closed trades yet.</span>';
    h += '<div class="pl-card"><h3>Best &amp; worst coins (3+ closed trades)</h3><div class="k">BEST</div>' + chips(S.bestCoins) + '<div class="k" style="margin-top:6px">WORST</div>' + chips(S.worstCoins, true) + '</div>';
    const todayMap = {}; (S.byCoinToday || []).forEach(c => { todayMap[c.key] = c; });
    const maxAbs = Math.max(1, ...((S.byCoin || []).map(c => Math.abs(c.net || 0))));
    h += '<div class="pl-card"><h3>Performance by coin</h3><div style="overflow-x:auto"><table><thead><tr><th>Coin</th><th>Trades</th><th>Win rate</th><th>Net PnL</th><th></th><th>PF</th><th>Avg</th><th>Best</th><th>Worst</th><th>Today</th></tr></thead><tbody>' +
      ((S.byCoin || []).map(c => { const td = todayMap[c.key]; return '<tr><td><b>' + esc(c.key) + '</b></td><td>' + c.n + '</td><td>' + pc(c.winRate) + '</td><td class="' + cl(c.net) + '">' + sg(c.net) + '</td><td style="text-align:left"><span class="bar" style="width:' + Math.round(Math.abs(c.net) / maxAbs * 70) + 'px;background:' + (c.net >= 0 ? '#45D49A' : '#E47C82') + '"></span></td><td>' + f(c.pf) + '</td><td>' + sg(c.avg) + '</td><td>' + sg(c.best) + '</td><td>' + sg(c.worst) + '</td><td class="' + cl(td && td.net) + '">' + (td ? sg(td.net) + ' (' + td.n + ')' : '–') + '</td></tr>'; }).join('') || '<tr><td colspan="10" class="k">No closed paper trades yet — the lab fills as the scanner finds qualified setups.</td></tr>') + '</tbody></table></div></div>';
    h += '<div class="pl-card"><h3>Performance by strategy</h3><div style="overflow-x:auto"><table><thead><tr><th>Strategy</th><th>Trades</th><th>Win rate</th><th>Net PnL</th><th>PF</th><th>Avg</th></tr></thead><tbody>' +
      ((S.byStrategy || []).map(c => '<tr><td><b>' + esc(c.key) + '</b></td><td>' + c.n + '</td><td>' + pc(c.winRate) + '</td><td class="' + cl(c.net) + '">' + sg(c.net) + '</td><td>' + f(c.pf) + '</td><td>' + sg(c.avg) + '</td></tr>').join('') || '<tr><td colspan="6" class="k">No data yet.</td></tr>') + '</tbody></table></div></div>';
    h += '<div class="pl-card"><h3>Open paper trades</h3><div style="overflow-x:auto"><table><thead><tr><th>Coin</th><th>Side</th><th>Entry</th><th>Now</th><th>SL</th><th>TP</th><th>uPnL</th><th>Progress</th><th>Open</th></tr></thead><tbody>' +
      ((S.open || []).map(o => '<tr><td><b>' + esc(o.symbol) + '</b>' + (o.overLiveCap ? cap : '') + '</td><td>' + esc(o.side) + '</td><td>' + f(o.entry, 4) + '</td><td>' + f(o.mark, 4) + '</td><td>' + f(o.stop, 4) + '</td><td>' + f(o.tp, 4) + '</td><td class="' + cl(o.upnl) + '">' + sg(o.upnl) + '</td><td>' + (o.progress == null ? '–' : o.progress + '%') + '</td><td>' + (o.hoursOpen == null ? '–' : o.hoursOpen + 'h') + '</td></tr>').join('') || '<tr><td colspan="9" class="k">None open.</td></tr>') + '</tbody></table></div></div>';
    h += '<div class="pl-card"><h3>Recently closed (paper)</h3><div style="overflow-x:auto"><table><thead><tr><th>Coin</th><th>Side</th><th>Strategy</th><th>PnL</th><th>Result</th><th>Closed</th></tr></thead><tbody>' +
      ((S.recent || []).map(r => '<tr><td><b>' + esc(r.symbol) + '</b>' + (r.overLiveCap ? cap : '') + '</td><td>' + esc(r.side) + '</td><td>' + esc(r.strategy) + '</td><td class="' + cl(r.pnl) + '">' + sg(r.pnl) + '</td><td>' + esc(r.exit || r.outcome) + '</td><td>' + ago(r.closed) + '</td></tr>').join('') || '<tr><td colspan="6" class="k">None yet.</td></tr>') + '</tbody></table></div></div>';
    root.innerHTML = h;
  }
  load(); setInterval(() => { const a = document.getElementById('tab-paperlab'); if (a && a.classList.contains('active')) load(); }, 5000);
  const b = document.getElementById('plTabBtn'); if (b) b.addEventListener('click', load);
  fetch('/api/lab/status', { cache: 'no-store' }).then(r => r.json()).then(j => { if (j && j.live === false && b) b.style.display = 'none'; }).catch(() => { /* keep the tab visible */ });
})();
