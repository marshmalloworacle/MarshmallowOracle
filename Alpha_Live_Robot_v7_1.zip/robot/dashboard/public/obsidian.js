/* ALPHA LIVE ROBOT v5.1 shell: sidebar grouping/icons, page titles, mobile drawer, limits strip, why-not-entered, Modules page.
   Presentation + calls to EXISTING endpoints only (/api/v46/*, plus read-only /api/v5/limits). No trading logic here. */
(function () {
  'use strict';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const $ = (s, r) => (r || document).querySelector(s);
  const ICON = {
    home: '<path d="M3 11l9-8 9 8M5 10v10h14V10"/>', pos: '<path d="M4 6h16M4 12h16M4 18h10"/>', scan: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>', chart: '<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>', shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    feed: '<path d="M4 11a9 9 0 019 9M4 4a16 16 0 0116 16"/><circle cx="5" cy="19" r="1.5"/>', lab: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3"/>',
    perf: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>', book: '<path d="M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3z"/><path d="M5 17a3 3 0 013-3h11"/>', sys: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    mod: '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>' };
  const PAGES = {
    'tab-overview': ['Command Centre', 'Account, risk limits, intelligence and bot state at a glance', 'Command Centre', 'home'],
    'tab-positions': ['Open Positions', 'Every open trade with entry, stop, target and live P&L', 'Trading', 'pos'],
    'tab-scanner': ['Market Scanner', 'All scanned markets and every qualified signal — no display cap', 'Markets', 'scan'],
    'tab-opportunities': ['Opportunities', 'Qualified setups ranked by quality score', 'Markets', 'target'],
    'tab-chart': ['Candlestick Chart', 'Price action with entries and levels', 'Markets', 'chart'],
    'tab-risk': ['Risk & Exposure', 'Portfolio exposure, margin and drawdown', 'Trading', 'shield'],
    'tab-feed': ['Data Feed', 'Exchange adapters, order-book, funding and open-interest', 'Intelligence', 'feed'],
    'tab-lab': ['Strategy Lab', 'Live strategy performance and regime heat-map', 'Intelligence', 'lab'],
    'tab-analytics': ['Performance & Analytics', 'Equity, P&L, win rate and distribution from the journal', 'Intelligence', 'perf'],
    'tab-journal': ['Trade Journal', 'Paper and live trades, autopsies and exports', 'Intelligence', 'book'],
    'tab-system': ['Strategy & Health', 'Strategy settings, diagnostics and system health', 'System', 'sys'],
    'tab-exchange': ['Exchange', 'Choose the exchange, save API keys, test the connection', 'System', 'feed'],
    'tab-modules': ['Modules', 'Switch protection, risk and intelligence modules on or off', 'System', 'mod'] };
  const svg = (k) => '<svg class="ob-i" viewBox="0 0 24 24" aria-hidden="true">' + (ICON[k] || '') + '</svg>';
  const toast = (m, err) => { if (window.__v6toast) { window.__v6toast(m, !err); return; } let t = $('#obToast'); if (!t) { t = document.createElement('div'); t.id = 'obToast'; t.setAttribute('role', 'status'); document.body.appendChild(t); } t.textContent = m; t.className = 'show' + (err ? ' err' : ''); clearTimeout(t._h); t._h = setTimeout(() => { t.className = ''; }, 2600); };
  const post = async (url, body) => { const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Alpha': '1' }, body: JSON.stringify(body) }); const d = await r.json().catch(() => ({})); if (!r.ok || d.ok === false) throw new Error(d.error || 'HTTP ' + r.status); return d; };
  const getj = async (u) => { const r = await fetch(u); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); };

  // ── Modules page section + nav button ──
  const main = $('main.container') || $('main'); const nav = $('.nav-tabs');
  if (!main || !nav) return;
  const sec = document.createElement('section'); sec.id = 'tab-modules'; sec.className = 'tab-content'; main.appendChild(sec);
  const xs = document.createElement('section'); xs.id = 'tab-exchange'; xs.className = 'tab-content'; main.appendChild(xs);
  const xb = document.createElement('button'); xb.className = 'tab-btn'; xb.textContent = 'Exchange'; xb.setAttribute('onclick', "switchTab('tab-exchange', this)"); nav.appendChild(xb);
  const mb = document.createElement('button'); mb.className = 'tab-btn'; mb.textContent = 'Modules'; mb.setAttribute('onclick', "switchTab('tab-modules', this)"); nav.appendChild(mb);

  // ── Sidebar: brand, environment, groups, icons ──
  const brand = document.createElement('div'); brand.className = 'ob-brand';
  brand.innerHTML = '<div class="ob-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#42CDBE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19L12 4l8 15"/><path d="M8 14h8"/></svg></div><div class="ob-name">ALPHA<small>LIVE ROBOT</small></div>';
  const env = document.createElement('div'); env.className = 'ob-env'; env.innerHTML = 'Environment <b id="obEnv">…</b>';
  nav.insertBefore(env, nav.firstChild); nav.insertBefore(brand, nav.firstChild);
  const idOf = (b) => { const m = /switchTab\('([^']+)'/.exec(b.getAttribute('onclick') || ''); return m ? m[1] : null; };
  let lastGroup = null;
  nav.querySelectorAll('.tab-btn').forEach((b) => {
    const id = idOf(b), p = id && PAGES[id]; if (!p) return;
    if (p[2] !== lastGroup) { const g = document.createElement('div'); g.className = 'ob-group'; g.textContent = p[2]; nav.insertBefore(g, b); lastGroup = p[2]; }
    b.insertAdjacentHTML('afterbegin', svg(p[3])); b.querySelectorAll('span:not([id])').forEach(s => s.remove());
    b.childNodes.forEach(n => { if (n.nodeType === 3) n.textContent = n.textContent.replace(/[^\x00-\x7F]+/g, '').replace(/[()]/g, '').replace(/\s+/g, ' ').replace(/^\s+/, ''); });
  });
  // Group order: Command Centre, Trading, Markets, Intelligence, System — keep DOM order stable but regroup labels by moving buttons
  const order = ['Command Centre', 'Markets', 'Trading', 'Intelligence', 'System'];
  const btns = [...nav.querySelectorAll('.tab-btn')]; nav.querySelectorAll('.ob-group').forEach(g => g.remove());
  order.forEach((grp) => {
    const list = btns.filter(b => { const i = idOf(b); return i && PAGES[i] && PAGES[i][2] === grp; }); if (!list.length) return;
    const g = document.createElement('div'); g.className = 'ob-group'; g.textContent = grp; nav.appendChild(g); list.forEach(b => nav.appendChild(b));
  });

  // ── Header title + burger; wrap switchTab ──
  const hl = $('.header-left');
  if (hl) { const t = document.createElement('div'); t.className = 'ob-title'; t.innerHTML = '<h1 id="obH1">Command Centre</h1><p id="obSub"></p>'; hl.insertBefore(t, hl.firstChild);
    const bg = document.createElement('button'); bg.className = 'ob-burger'; bg.setAttribute('aria-label', 'Open navigation'); bg.innerHTML = '&#9776;'; bg.onclick = () => document.body.classList.toggle('ob-open'); hl.insertBefore(bg, hl.firstChild); }
  const setTitle = (id) => { const p = PAGES[id]; if (!p) return; const h = $('#obH1'), s = $('#obSub'); if (h) h.textContent = p[0]; if (s) s.textContent = p[1]; document.title = p[0] + ' · Alpha Live Robot'; };
  const orig = window.switchTab;
  if (typeof orig === 'function') window.switchTab = function (id, btn) { const pb = $('#modeSwitch button[data-v="paper"]'); if (pb && !pb.classList.contains('on')) pb.click();   // leave the Account view so the chosen page can show
    const r = orig.apply(this, arguments); setTitle(id); document.body.classList.remove('ob-open'); if (id === 'tab-modules') loadModules(); if (id === 'tab-exchange' && window.__obExchange) window.__obExchange.load(); window.scrollTo({ top: 0 }); return r; };
  setTitle('tab-overview');
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.body.classList.remove('ob-open'); });

  // ── Command Centre: limits strip + why-not-entered ──
  const ov = $('#tab-overview'); const strip = document.createElement('div'); strip.id = 'obLimits'; if (ov) ov.insertBefore(strip, ov.firstChild);
  const bar = (pct) => '<div class="ob-bar" role="img" aria-label="' + Math.round(pct) + ' percent used"><i class="' + (pct >= 100 ? 'bad' : pct >= 80 ? 'warn' : '') + '" style="width:' + Math.min(100, pct) + '%"></i></div>';
  function renderLimits(L, O) {
    if (!L) { strip.innerHTML = '<div class="ob-panel"><h4>Limits</h4><div class="ob-sub">Unavailable — dashboard could not read /api/v5/limits.</div></div>'; return; }
    const e = $('#obEnv'); if (e) e.textContent = L.mode === 'SIM' ? 'PAPER · SIM' : L.mode;
    const unl = !L.limit; const pct = unl ? 0 : (L.open / L.limit) * 100;
    const slots = '<div class="ob-panel"><h4>Open slots <span class="ob-tag ' + (!unl && L.open >= L.limit ? 'lock' : 'on') + '">' + (!unl && L.open >= L.limit ? 'FULL' : 'OPEN') + '</span></h4><div class="ob-big">' + L.open + ' <small>/ ' + (unl ? 'unlimited' : L.limit) + '</small></div>' + (unl ? '' : bar(pct)) +
      '<div class="ob-sub">Limiting cap: <code>' + esc(L.limitSource) + '</code> · paper ' + L.paperLimit + ' · live ' + L.liveLimit + '</div></div>';
    const size = '<div class="ob-panel"><h4>Sizing basis</h4><div class="ob-big">$' + L.startBalance + ' <small>start</small></div><div class="ob-sub">~$' + L.marginPerTrade + ' margin · ~$' + L.notionalPerTrade + ' position @ ' + L.leverage + 'x per trade (<code>ACCOUNT_BALANCE</code>, <code>SCALING_MARGIN_PCT</code>)</div></div>';
    const risk = '<div class="ob-panel"><h4>Entry pace &amp; risk caps</h4><div class="ob-big">' + (L.maxNewPerScan || '∞') + ' <small>new / scan</small></div><div class="ob-sub">' + (L.aggRiskCapPct != null ? 'Aggregate open-risk cap <code>' + L.aggRiskCapPct + '%</code> · ' : 'Paper: no aggregate cap · ') + 'margin cap <code>' + L.maxMarginPct + '%</code> (live)</div></div>';
    const nt = O && O.noTrade, rec = (nt && nt.recent) || [], by = nt && nt.counts && nt.counts.by ? Object.entries(nt.counts.by).sort((a, b) => b[1] - a[1]).slice(0, 6) : [];
    const why = '<div class="ob-panel" style="grid-column:span 2"><h4>Why not entered <span class="ob-tag">' + (rec.length ? 'LAST ' + rec.length : 'NONE YET') + '</span></h4>' +
      (by.length ? '<div class="ob-sub" style="margin:0 0 6px">Today: ' + by.map(([k, v]) => '<code>' + esc(k) + ' ×' + v + '</code>').join(' · ') + '</div>' : '') +
      '<div class="ob-why">' + (rec.length ? rec.slice(0, 12).map(r => '<div><span>' + esc(r.symbol) + ' ' + esc((r.direction || '').slice(0, 1)) + (r.score != null ? ' · ' + esc(r.score) : '') + '</span><span>' + esc(r.reason) + '</span></div>').join('') : '<div><span>—</span><span>No blocked signals recorded. Reasons appear when a qualified signal is stopped by a gate, slot limit or governor.</span></div>') + '</div></div>';
    strip.innerHTML = slots + size + risk;
  }
  async function pollLimits() { let L = null, O = null; try { L = await getj('/api/v5/limits'); } catch (_) { /* shown as unavailable */ } try { O = await getj('/api/v46/overview'); } catch (_) { /* optional */ } renderLimits(L, O); }
  pollLimits(); setInterval(() => { if (!document.hidden) pollLimits(); }, 6000);

  // ── Modules page ──
  const GROUPS = [
    ['Protection & exits', 'Stops and targets stay enforced by the backend. These modules add trailing, profit-lock and time rules on top.', ['smartTrailing', 'profitGiveback', 'partialExits', 'timeExit'], ['atrMult', 'givebackPct', 'staleHours', 'flatPct', 'maxHours']],
    ['Entry control & risk', 'Gates that decide whether a new entry is allowed. Switching one off never touches open-position stops.', ['riskTaper', 'directionControl', 'adaptiveDirection', 'correlationBlock', 'lossGovernor', 'staleDataBlock', 'spreadFilter', 'volumeConfirm', 'htfTrend', 'volatilityFilter'], ['aggRiskPct', 'taperStartPct', 'taperMinPct', 'ceilingPct', 'spreadMaxBps', 'volumeMinRatio', 'volatilityMaxRatio', 'corrRiskPct', 'corrThreshold', 'dirNotionalPct', 'govCautionPct', 'govDefensivePct', 'govHaltPct', 'govEmergencyPct', 'govWeeklyHaltPct', 'govAccountDdPct', 'govEmergencyAction', 'staleDataSec']],
    ['Intelligence & monitoring', 'Market regime, shock detection, health strip and journal detail.', ['regimeFilter', 'healthStrip', 'journalExtras', 'closeButtons'], ['shockPct']] ];
  let MS = null, V6 = null, busy = false; const openCards = new Set();
  const setHtml = (s) => { const a = document.activeElement; if (a && sec.contains(a) && (a.tagName === 'INPUT' || a.tagName === 'SELECT') && a.type !== 'checkbox') return; sec.innerHTML = s; };
  function renderModules() {
    if (!MS) { setHtml('<div class="ob-panel"><h4>Modules</h4><div class="ob-sub">Loading…</div></div>'); return; }
    const F = Object.fromEntries(MS.features.map(f => [f.key, f])), S = Object.fromEntries((MS.settings || []).map(s => [s.key, s]));
    const V = V6 ? Object.fromEntries(V6.cards.map(c => [c.key, c])) : {};
    const dotc = (c) => '<span class="v6-dot ' + c + '"></span>';
    const more = (c) => { const i = c.info || {}; return '<div class="more"><div><b>What it looks at:</b> ' + esc(i.analyses) + '</div><div><b>When it acts:</b> ' + esc(i.when) + '</div><div><b>How it affects trades:</b> ' + esc(i.influence) + '</div><div><b>Benefit:</b> ' + esc(i.benefits) + '</div><div><b>Risk:</b> ' + esc(i.risks) + '</div>' + (i.deps && i.deps.length ? '<div><b>Needs:</b> ' + esc(i.deps.join('; ')) + '</div>' : '') + '</div>'; };
    const ctl = (c, f) => c.kind === 'drawdownMode' ? '<select data-dd aria-label="Drawdown guard"><option value="warn"' + (V6.drawdownMode === 'warn' ? ' selected' : '') + '>Warn only</option><option value="enforce"' + (V6.drawdownMode === 'enforce' ? ' selected' : '') + '>Enforce</option><option value="off"' + (V6.drawdownMode === 'off' ? ' selected' : '') + '>Off</option></select>'
      : c.kind === 'slots' ? '<label class="ob-sw"><input type="checkbox" data-slotramp aria-label="Slot ramp" ' + ((c.value || {}).ramp ? 'checked' : '') + '><i></i></label>'
      : c.kind === 'take' ? '<button class="v6-btn" data-take>' + (c.enabled ? 'Turn OFF' : 'Turn ON') + '</button>' : c.kind === 'env' ? '<span class="ob-tag ' + (c.enabled ? 'on' : '') + '">' + (c.enabled ? 'ON' : 'OFF') + ' (.env)</span>'
      : '<label class="ob-sw"><input type="checkbox" data-feat="' + c.key + '" aria-label="' + esc(c.label) + '" ' + (c.enabled ? 'checked' : '') + '><i></i></label>';
    const slotsForm = (s) => '<div class="v6-slots"><label>Max slots<input type="number" min="0" max="200" data-sl="max" value="' + esc(s.max) + '"></label><label>Ramp start<input type="number" min="1" max="200" data-sl="start" value="' + esc(s.start) + '"></label><label>+1 slot per trades<input type="number" min="1" max="500" data-sl="every" value="' + esc(s.every) + '"></label><label>Min profit factor<input type="number" step="0.1" min="0" max="20" data-sl="minPF" value="' + esc(s.minPF) + '"></label><button class="v6-btn win" data-slotsave>Save slots</button><small>Max 0 = no limit. Ramp ON = start small and earn slots; OFF = all Max slots now.</small></div>';
    const card = (c) => '<div class="v6-card' + (openCards.has(c.key) ? ' open' : '') + '" data-card="' + c.key + '"><div class="top"><span class="nm">' + dotc(c.status.dot) + esc(c.label) + '</span><span style="display:flex;gap:8px;align-items:center"><button class="v6-info" data-info="' + c.key + '" aria-label="About ' + esc(c.label) + '" title="What does this do?">i</button>' + ctl(c) + '</span></div><div class="st">' + esc(c.status.label) + '</div><div class="ds">' + esc(c.desc) + '</div>' + (c.kind === 'slots' ? slotsForm(c.value || {}) : '') + (c.advice ? '<div class="adv ' + c.advice.level + '">Robot suggests: ' + esc(c.advice.text) + '</div>' : '') + more(c) + '</div>';
    const row = (f) => V[f.key] ? card(V[f.key]) : '<div class="ob-mod"><div class="t"><b>' + esc(f.label) + ' <span class="ob-tag ' + (f.enabled ? 'on' : '') + '">' + (f.enabled ? 'ON' : 'OFF') + '</span></b><small>' + esc(f.desc) + ' · default ' + (f.default ? 'ON' : 'OFF') + '</small></div><label class="ob-sw"><input type="checkbox" data-feat="' + f.key + '" aria-label="' + esc(f.label) + '" ' + (f.enabled ? 'checked' : '') + '><i></i></label></div>';
    const set = (s) => '<label class="ob-set"><span>' + esc(s.label) + '</span>' + (s.options ? '<select data-set="' + s.key + '">' + s.options.map(o => '<option ' + (o === s.value ? 'selected' : '') + '>' + esc(o) + '</option>').join('') + '</select>' : '<input type="number" data-set="' + s.key + '" value="' + esc(s.value) + '" min="' + esc(s.min) + '" max="' + esc(s.max) + '" step="any">') + '</label>';
    const locked = '<div class="ob-mod"><div class="t"><b>Stop-loss &amp; take-profit orders <span class="ob-tag lock">ALWAYS ON</span></b><small>Enforced by the backend on every position (paper, testnet and live). Not switchable by design.</small></div><label class="ob-sw locked"><input type="checkbox" checked disabled aria-label="Stop-loss always on"><i></i></label></div>';
    const core = V6 ? '<div class="ob-panel" style="margin-bottom:12px"><h4>Core controls</h4><div class="v6-cards">' + V6.cards.filter(c => c.kind !== 'switch').map(card).join('') + '</div><div class="ob-sub">' + esc(V6.note) + '</div></div>' : '';
    sec.innerHTML = core + '<p class="ob-lead">Each switch is saved in the database and applies to the robot immediately. Risk-changing modules default to OFF. Live-trading authorisation, kill switch and flatten stay under their own confirmations.</p><div class="ob-mgrid">' +
      GROUPS.map(([t, d, fk, sk], i) => '<div class="ob-panel"><h4>' + t + '</h4><div class="ob-sub" style="margin:0 0 6px">' + d + '</div>' + (i === 0 ? locked : '') + fk.filter(k => F[k]).map(k => row(F[k])).join('') +
        (sk.filter(k => S[k]).length ? '<h4 style="margin-top:14px">Tunable limits</h4>' + sk.filter(k => S[k]).map(k => set(S[k])).join('') : '') + '</div>').join('') + '</div>' +
      '<div class="ob-note">Emergency action defaults to HALT (stop new entries, keep stops). FLATTEN closes everything and is opt-in.</div>';
  }
  async function loadModules() { try { V6 = await getj('/api/v6/modules'); } catch (_) { V6 = null; } try { MS = await getj('/api/v46/state'); } catch (e) { MS = null; sec.innerHTML = '<div class="ob-panel"><h4>Modules</h4><div class="ob-sub">Could not load module state: ' + esc(e.message) + '</div></div>'; return; } renderModules(); }
  sec.addEventListener('click', async (e) => {
    const i = e.target.closest('[data-info]'); if (i) { const k = i.dataset.info; openCards.has(k) ? openCards.delete(k) : openCards.add(k); const c = i.closest('.v6-card'); if (c) c.classList.toggle('open'); return; }
    if (e.target.closest('[data-slotsave]') && !busy) { busy = true; try { const b = {}; sec.querySelectorAll('[data-sl]').forEach(i => { b[i.dataset.sl] = i.value; }); await post('/api/v6/slots', b); toast('Slots saved'); } catch (er) { toast('Rejected: ' + er.message, true); } busy = false; loadModules(); return; }
    if (e.target.closest('[data-take]') && !busy) { busy = true; try { const on = !(V6 && V6.cards.find(c => c.key === 'takeLiveTrades').enabled); await post('/api/v6/take', { on }); toast('Take Live Trades ' + (on ? 'ON' : 'OFF')); } catch (er) { toast('Rejected: ' + er.message, true); } busy = false; loadModules(); }
  });
  sec.addEventListener('change', async (e) => {
    const t = e.target; if (busy) return; busy = true;
    try {
      if (t.dataset.dd !== undefined) { await post('/api/v6/drawdown-mode', { mode: t.value }); toast('Drawdown guard: ' + t.value); }
      else if (t.dataset.slotramp !== undefined) { await post('/api/v6/slots', { ramp: t.checked }); toast('Slot ramp ' + (t.checked ? 'ON' : 'OFF')); }
      else if (t.dataset.feat) { await post('/api/v46/features', { key: t.dataset.feat, enabled: t.checked }); toast((t.getAttribute('aria-label') || 'Module') + (t.checked ? ' switched ON' : ' switched OFF')); }
      else if (t.dataset.set) { await post('/api/v46/settings', { key: t.dataset.set, value: t.value }); toast('Setting saved'); }
    } catch (er) { toast('Rejected: ' + er.message, true); }
    busy = false; loadModules();
  });
  setInterval(() => { if (sec.classList.contains('active') && !document.hidden) loadModules(); }, 15000);
})();
