/* ALPHA LIVE ROBOT — Live Trading Control Center. Plain browser JS, no dependencies.
   All data comes from /api/live/*. Every write is confirmed here AND re-validated by the server and the robot. */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ls = { get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch (_) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (_) { /* private mode */ } } };
  const n = (v, d = 2) => (v == null || !isFinite(v)) ? '–' : Number(v).toFixed(d);
  const usd = (v, d = 2) => (v == null || !isFinite(v)) ? '–' : (v < 0 ? '-$' : '$') + Math.abs(v).toFixed(d);
  const sgn = (v, d = 2) => (v == null || !isFinite(v)) ? '–' : (v >= 0 ? '+' : '-') + '$' + Math.abs(v).toFixed(d);
  const cls = (v) => v > 0 ? 'pos' : v < 0 ? 'neg' : '';
  const price = (v) => (v == null || !isFinite(v)) ? '–' : (Math.abs(v) >= 100 ? Number(v).toFixed(2) : Math.abs(v) >= 1 ? Number(v).toFixed(4) : Number(v).toPrecision(5));
  const ago = (ts) => ts ? (Math.max(0, Math.round((Date.now() - ts) / 1000)) + 's ago') : 'never';
  const api = async (path, opt) => { const r = await fetch(path, opt); let j = null; try { j = await r.json(); } catch (_) { /* non-json */ } return { status: r.status, ok: r.ok && (!j || j.ok !== false), body: j || {} }; };
  const post = (path, body) => api(path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Alpha': '1' }, body: JSON.stringify(body || {}) });

  const TABS = [['account', 'Account'], ['risk', 'Risk'], ['preview', 'Order Preview'], ['positions', 'Positions & Orders'], ['journal', 'Live Journal'], ['strategy', 'Strategy'], ['charts', 'Charts'], ['health', 'System Health']];
  const S = { view: ls.get('alpha_view2', 'live'), tab: ls.get('alpha_live_tab', 'account'), gates: null, sound: ls.get('alpha_sound', '0') === '1', lastAlert: 0, timer: null, preview: null };
  if (ls.get('alpha_density', 'comfortable') === 'compact') document.body.classList.add('compact');

  // ── sound cues (optional, user toggle) ───────────────────────────────────────────────────────────
  let actx = null;
  function beep(freq, ms, vol) { if (!S.sound) return; try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); const o = actx.createOscillator(), g = actx.createGain(); o.frequency.value = freq; g.gain.value = vol; o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + ms / 1000); } catch (_) { /* audio blocked */ } }
  const clickSound = () => beep(880, 70, 0.04), warnSound = () => { beep(330, 180, 0.08); setTimeout(() => beep(260, 260, 0.08), 200); };

  // ── toast + confirm modal ────────────────────────────────────────────────────────────────────────
  function toast(msg, ok) { if (window.__v6toast) return window.__v6toast(msg, ok); const t = document.createElement('div'); t.className = 'lv-toast' + (ok ? ' ok' : ''); t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), ok ? 5000 : 9000); }
  // v7.0: tiny coloured strategy badge (shared with the paper positions table)
  const SB = [['gps', 'GPS', '#42CDBE'], ['pullback', 'PB', '#7EA6E6'], ['momentum', 'MOM', '#E9B86A'], ['mean', 'MR', '#b58cff'], ['range', 'RF', '#ff9aa2'], ['breakout', 'BRK', '#45D49A'], ['orb', 'ORB', '#ffb86b'], ['support', 'MOM', '#E9B86A']];
  window.v7Strat = function (s) {
    if (!s) return '<span class="v7-strat none" title="Strategy not recorded for this position">?</span>';
    const k = String(s).toLowerCase(), hit = SB.find(x => k.indexOf(x[0]) >= 0) || [0, String(s).replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase(), '#A0ADB8'];
    return '<span class="v7-strat" style="--c:' + hit[2] + '" title="' + String(s).replace(/"/g, '') + '">' + hit[1] + '</span>';
  };
  function confirmModal({ title, body, word, danger, run }) {
    const m = document.createElement('div'); m.className = 'lv-modal';
    m.innerHTML = '<div><h3>' + esc(title) + '</h3><div class="lv-note">' + body + '</div>' + (word ? '<div class="lv-note">Type <b class="num">' + esc(word) + '</b> to confirm:</div><input id="cmWord" autocomplete="off">' : '') +
      '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px"><button class="lv-btn" id="cmNo">Cancel</button><button class="lv-btn ' + (danger ? 'danger' : 'gold') + '" id="cmYes" ' + (word ? 'disabled' : '') + '>Confirm</button></div></div>';
    document.body.appendChild(m);
    const yes = $('#cmYes', m), inp = $('#cmWord', m);
    if (inp) { inp.focus(); inp.addEventListener('input', () => { yes.disabled = inp.value.trim() !== word; }); }
    $('#cmNo', m).onclick = () => m.remove(); m.addEventListener('click', e => { if (e.target === m) m.remove(); });
    yes.onclick = async () => { yes.disabled = true; yes.textContent = 'Working…'; const r = await run(word ? inp.value.trim() : true); m.remove(); toast(r.ok ? (r.body.message || 'Done') : (r.body.error || 'Refused'), r.ok); poll(true); };
  }
  /** After a dashboard-requested safe restart: show a notice, wait for the server to go down and come back, then reload. */
  window.__alphaWaitRestart = waitRestart;
  function waitRestart(msg) {
    const o = document.createElement('div'); o.className = 'lv-modal'; o.innerHTML = '<div><h3>' + esc(msg || 'Restarting...') + '</h3><div class="lv-note">This page reloads by itself when the robot is back (about 10 to 20 seconds). Open positions keep their exchange stop-losses while it restarts.</div></div>';
    document.body.appendChild(o); let wentDown = false, tries = 0;
    const t = setInterval(async () => {
      tries++; try { const r = await fetch('/api/exchange/state', { cache: 'no-store' }); if (r.ok && (wentDown || tries > 25)) { clearInterval(t); location.reload(); } } catch (_) { wentDown = true; }
      if (tries > 90) { clearInterval(t); o.querySelector('.lv-note').textContent = 'Taking longer than expected. Check the terminal; if the robot did not restart, run npm run all again.'; }
    }, 1500);
  }
  const actions = {
    flatten: () => confirmModal({ title: 'Flatten ALL positions', danger: true, word: 'FLATTEN', body: 'Cancels resting entries, then closes <b>every open position at market</b> (reduce-only) and <b>pauses new entries</b>. Market closes can slip on thin coins.', run: (w) => post('/api/live/flatten', { confirm: w }) }),
    kill: () => confirmModal({ title: 'Kill switch', danger: true, word: 'KILL', body: 'Stops all NEW trading and cancels resting entries. <b>Open positions are kept</b> and stay protected by their exchange stop-loss. Clear it with “Reset kill switch”.', run: (w) => post('/api/live/kill', { confirm: w }) }),
    close: (sym) => confirmModal({ title: 'Close ' + sym, danger: true, body: 'Sends a reduce-only <b>market</b> order to close <b>' + esc(sym) + '</b> now.', run: () => post('/api/live/close', { symbol: sym, confirm: true }) }),
    pause: async () => { const r = await post('/api/live/pause'); toast(r.ok ? 'Live stopped: no new trades. Open trades keep their stops.' : r.body.error, r.ok); poll(true); },
    resume: async () => { const r = await post('/api/live/resume'); toast(r.ok ? 'Live resumed: new trades allowed' : r.body.error, r.ok); poll(true); },
    unblock: async () => { const r = await post('/api/live/unblock'); toast(r.ok ? 'Entry block cleared' : r.body.error, r.ok); poll(true); },
    resetKill: async () => { const r = await post('/api/control/emergency-reset'); toast(r.ok ? 'Kill switch cleared' : (r.body.error || 'failed'), r.ok); poll(true); },
  };
  window.__alphaLive = actions;

  // ── shell ────────────────────────────────────────────────────────────────────────────────────────
  function mountSwitch() {
    const hdr = $('.header-left') || $('.header'); if (!hdr || $('#modeSwitch')) return;
    const w = document.createElement('div'); w.className = 'mode-switch'; w.id = 'modeSwitch';
    w.innerHTML = '<button data-v="paper" class="paper">MARKETS</button><button data-v="live" class="live" id="modeLiveBtn">ACCOUNT</button>';
    hdr.appendChild(w); w.addEventListener('click', e => { const b = e.target.closest('button'); if (b) setView(b.dataset.v); });
  }
  function setView(v) {
    S.view = v; ls.set('alpha_view2', v);
    const live = v === 'live';
    document.querySelectorAll('#modeSwitch button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
    document.querySelectorAll('#modeSwitch button').forEach(b => { b.classList.remove('paper', 'live'); b.classList.add(b.dataset.v); if (b.dataset.v === v) b.classList.add('on'); });
    document.querySelectorAll('.nav-tabs, .tab-content').forEach(el => { el.style.display = live ? 'none' : ''; });
    $('#liveRoot').style.display = live ? 'block' : 'none';
    if (live) { render(); poll(true); } else { const act = document.querySelector('.tab-content.active'); if (act) act.style.display = ''; }
  }

  function shell() {
    const root = $('#liveRoot');
    root.innerHTML = '<div id="lvBar"></div><div id="lvGates" class="lv-gates"></div><div id="lvWarn"></div>' +
      '<div class="lv-tabs" id="lvTabs">' + TABS.map(t => '<button data-t="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="lvBody"></div>';
    $('#lvTabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { S.tab = b.dataset.t; ls.set('alpha_live_tab', S.tab); render(); poll(true); } });
  }

  function bar() {
    const g = S.gates || {}; const live = g.isLive;
    $('#lvBar').innerHTML = '<div class="lv-bar"><button class="lv-btn danger" data-a="flatten" ' + (live ? '' : 'disabled') + '>Flatten all<kbd>F</kbd></button>' +
      '<button class="lv-btn danger" data-a="kill" ' + (live ? '' : 'disabled') + '>Kill switch<kbd>K</kbd></button>' +
      (g.emergency ? '<button class="lv-btn gold" data-a="resetKill">Reset kill switch</button>' : '') +
      (g.paused ? '<button class="lv-btn gold" data-a="resume">Resume live (allow new trades)</button>' : '<button class="lv-btn" data-a="pause" ' + (live ? '' : 'disabled') + ' title="Stops NEW trades only. Open trades stay protected. Emergency Stop is what closes trades.">Stop live (no new trades)</button>') +
      '<button class="lv-btn" data-a="unblock" ' + (live && g.blocked ? '' : 'disabled') + '>Clear entry block</button>' +
      '<span class="grow"></span>' +
      '<button class="lv-btn" data-a="density">Density: ' + (document.body.classList.contains('compact') ? 'compact' : 'comfortable') + '</button>' +
      '<button class="lv-btn" data-a="sound">Sound: ' + (S.sound ? 'on' : 'off') + '</button></div>';
  }
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-a]'); if (!b || b.disabled) return; const a = b.dataset.a;
    if (a === 'density') { document.body.classList.toggle('compact'); ls.set('alpha_density', document.body.classList.contains('compact') ? 'compact' : 'comfortable'); bar(); return; }
    if (a === 'sound') { S.sound = !S.sound; ls.set('alpha_sound', S.sound ? '1' : '0'); clickSound(); bar(); return; }
    if (a === 'close') return actions.close(b.dataset.s);
    if (actions[a]) actions[a]();
  });
  document.addEventListener('keydown', e => {
    if (S.view !== 'live' || e.ctrlKey || e.metaKey || e.altKey || /INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || '') || document.querySelector('.lv-modal')) return;
    if (e.key === 'f' || e.key === 'F') { e.preventDefault(); if ((S.gates || {}).isLive) actions.flatten(); }
    if (e.key === 'k' || e.key === 'K') { e.preventDefault(); if ((S.gates || {}).isLive) actions.kill(); }
  });

  function gates() {
    const g = S.gates || {}; const cell = (t, v, ok) => '<div class="lv-gate ' + (ok ? 'ok' : 'bad') + '"><b>' + t + '</b>' + esc(v) + '</div>';
    const RM = g.runMode || (g.isLive ? 'LIVE' : 'SIM'); const blocked = g.connectivity && g.connectivity.blocked;
    const lb = $('#modeLiveBtn'); if (lb && g.runMode) lb.textContent = RM === 'LIVE' ? 'LIVE' : 'ACCOUNT';
    const gg = $('#lvGates'); if (gg) gg.innerHTML = cell('Mode', RM === 'LIVE' ? 'LIVE (real money)' : 'SIM (no exchange)', RM === 'TESTNET' || (RM === 'LIVE' && g.isLive)) + cell('Exchange', (g.exchange || '–').toUpperCase() + (blocked ? ' · BLOCKED' : ''), !blocked) + cell('Authorisation', g.authorised ? 'authorised (.env)' : (g.authText || 'locked'), g.authorised) +
      cell('Entries', g.emergency ? 'KILL SWITCH' : g.blocked ? 'blocked: ' + g.blocked : g.paused ? 'paused' : 'open', !g.emergency && !g.blocked && !g.paused) +
      cell('Robot loop', g.robotLastCycle ? ago(g.robotLastCycle) : 'not running', g.robotLastCycle && Date.now() - g.robotLastCycle < 15 * 60 * 1000) + cell('Engine health', g.robotError ? 'error: ' + g.robotError : 'ok', !g.robotError);
    const rst = document.querySelector('[onclick="resetAccount()"]');
    if (rst) { rst.disabled = RM !== 'SIM'; rst.title = RM !== 'SIM' ? 'Simulator only: the balance is your real exchange equity' : ''; rst.style.opacity = RM !== 'SIM' ? '.35' : ''; rst.style.cursor = RM !== 'SIM' ? 'not-allowed' : ''; }
    const rb = $('#modeRibbon');
    if (rb) {
      if (blocked) { rb.className = 'locked'; rb.textContent = 'THE EXCHANGE BLOCKS THIS SERVER (' + (g.connectivity.lastError || 'HTTP 403') + ') · market data and orders are unavailable · see the Live view for the fix'; }
      else if (RM === 'LIVE') { if (g.authorised) { rb.className = 'live'; rb.textContent = 'LIVE TRADING · REAL MONEY · ' + (g.exchange || '').toUpperCase(); } else { rb.className = 'locked'; rb.textContent = 'LIVE MODE LOCKED · authorise on the Account tab · no orders until then'; } }
      else { rb.className = 'paper'; rb.textContent = 'SIM · offline simulator · no exchange connection'; }
    }
  }

  // ── tabs ─────────────────────────────────────────────────────────────────────────────────────────
  const card = (k, v, s, c) => '<div class="card lv-card"><div class="k">' + k + '</div><div class="v num ' + (c || '') + '">' + v + '</div>' + (s ? '<div class="s">' + s + '</div>' : '') + '</div>';
  function spark(series, w = 110, h = 26) {
    if (!series || series.length < 2) return '';
    const v = series.map(x => x.e), lo = Math.min(...v), hi = Math.max(...v), r = hi - lo || 1;
    const pts = v.map((y, i) => (i / (v.length - 1) * w).toFixed(1) + ',' + (h - 2 - (y - lo) / r * (h - 4)).toFixed(1)).join(' ');
    const up = v[v.length - 1] >= v[0];
    return '<svg class="spark" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '"><polyline fill="none" stroke="' + (up ? '#57D69C' : '#A9E8DF') + '" stroke-width="1.6" points="' + pts + '"/></svg>';
  }
  const unavailable = (d) => '<div class="lv-alert">' + esc(d.reason || d.error || 'Live data unavailable') + '<div class="lv-note">Check the System Health tab. Keys go in .env (BYBIT_API_KEY / BYBIT_API_SECRET); never paste them in chat.</div></div>';
  const meter = (pct, label, sub) => '<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;font-size:12.5px"><span>' + label + '</span><span class="num">' + sub + '</span></div><div class="meter"><i style="width:' + Math.min(100, Math.max(0, pct || 0)) + '%"></i></div></div>';

  const view = {
    account(d) {
      if (!d.ok) return unavailable(d); const p = d.profile || {};
      return (d.stale ? '<div class="lv-alert gold">Showing the last good reading (' + ago(d.fetchedAt) + '): ' + esc(d.error || 'exchange not answering') + '</div>' : '') +
        '<div class="lv-note">Source: <b>' + esc((d.exchange || '').toUpperCase()) + '' + '</b> · fetched ' + ago(d.fetchedAt) + ' · read-only</div>' +
        '<div class="lv-grid">' + card('Equity', usd(d.equity), d.marginMode === 'ISOLATED_MARGIN' ? 'isolated margin ✓' : esc(d.marginMode || '')) + card('Available', usd(d.available)) + card('Margin used', usd(d.marginUsed)) +
        card('Unrealised P&L', sgn(d.unrealized), '', cls(d.unrealized)) +
        card('Day P&L', sgn(d.dayPnl) + spark(d.equitySeries), d.dayPnlPct != null ? n(d.dayPnlPct) + '% of day start' : 'robot has not set the day anchor yet', cls(d.dayPnl)) +
        card('Drawdown from peak', n(d.drawdown * 100, 1) + '%', 'peak ' + usd(d.peakEquity), d.drawdown > 0.05 ? 'neg' : '') +
        card('Tier', esc(p.tier || '–'), esc(p.state || '')) + card('Slots', esc(p.slots), p.slotsCap > p.slots ? 'cap ' + p.slotsCap : '') + card('Leverage', esc(p.leverage) + 'x', 'isolated') + card('Risk / trade', n((p.riskPerTrade || 0) * 100, 2) + '%') + '</div>' +
        '<div class="card lv-card" style="margin-bottom:12px"><div class="k">Scaling reasons</div><div class="lv-note">' + esc((p.reasons || []).join(' · ')) + '</div></div>' +
        '<div class="card lv-card"><div class="k">Go-live authorisation</div><div class="lv-note">' + esc((S.gates || {}).authText || '') + '. Live trading is authorised only from .env: TRADING_MODE=LIVE, LIVE_TRADING_ENABLED=true and LIVE_AUTHORIZE=true, then restart the robot. Take Live Trades (the button) is a separate switch and starts OFF.</div></div>' + checklist();
    },
    risk(d) {
      if (!d.ok) return unavailable(d);
      return '<div class="lv-grid">' + card('Slots', d.slots.used + ' / ' + d.slots.allowed, 'cap ' + d.slots.cap) + card('Tier', esc(d.tier), esc(d.state)) + card('Leverage', d.leverage + 'x') + card('Risk / trade', n(d.riskPerTrade * 100, 2) + '%') + '</div>' +
        '<div class="card lv-card">' + meter(d.daily.usedPct, 'Daily loss used', d.daily.anchored ? sgn(d.daily.dayPnl) + ' of limit −' + usd(d.daily.limitUsd) + ' (' + n(d.daily.limitPct * 100, 0) + '%)' : 'day anchor not set (robot not running yet)') +
        meter(d.openRisk.pctEquity / d.openRisk.capPct * 100, 'Open risk if every stop hits', n(d.openRisk.pctEquity) + '% of equity (cap ' + n(d.openRisk.capPct, 0) + '%)') +
        meter(d.margin.usedPct / d.margin.capPct * 100, 'Margin in use', n(d.margin.usedPct, 1) + '% (cap ' + n(d.margin.capPct, 0) + '%)') +
        meter(d.drawdown.pct / d.drawdown.defendAt * 100, 'Drawdown toward defensive mode', n(d.drawdown.pct, 1) + '% (reduces at ' + n(d.drawdown.reduceAt, 0) + '%, defends at ' + n(d.drawdown.defendAt, 0) + '%)') + '</div>' +
        (d.unprotected.length ? '<div class="lv-alert">UNPROTECTED POSITIONS (no exchange stop-loss seen): ' + esc(d.unprotected.join(', ')) + '</div>' : '') +
        '<div class="card" style="padding:0;overflow:auto"><table class="lv"><thead><tr><th>Symbol</th><th>Side</th><th>Risk to stop</th><th>Stop distance</th><th>Liquidation distance</th><th>Stop-loss</th></tr></thead><tbody>' +
        (d.positions.map(x => '<tr><td>' + esc(x.symbol) + '</td><td>' + esc(x.side) + '</td><td class="n">' + usd(x.riskUsd) + '</td><td class="n">' + n(x.stopDistancePct) + '%</td><td class="n">' + n(x.liqDistancePct) + '%</td><td>' + (x.protected ? '<span class="pill ok">on exchange</span>' : '<span class="pill bad">NONE</span>') + '</td></tr>').join('') || '<tr><td colspan="6" class="lv-note">No open positions.</td></tr>') + '</tbody></table></div>' + checklist();
    },
    preview() {
      const f = S.preview;
      return '<div class="lv-note">Preview only: sizes the idea exactly like the robot would and runs every risk rule. <b>Nothing is sent to the exchange.</b></div>' +
        '<div class="card lv-card"><div class="lv-form"><div><label>Symbol</label><input id="pvSym" placeholder="SOLUSDT" value="' + esc(ls.get('pv_sym', '')) + '"></div><div><label>Direction</label><select id="pvDir"><option>LONG</option><option>SHORT</option></select></div>' +
        '<div><label>Entry</label><input id="pvEntry" inputmode="decimal"></div><div><label>Stop-loss</label><input id="pvSl" inputmode="decimal"></div><div><label>Take-profit</label><input id="pvTp" inputmode="decimal"></div><div><button class="lv-btn gold" id="pvGo">Preview</button></div></div></div><div id="pvOut"></div>';
    },
    positions(d) {
      if (!d.ok && !d.positions) return unavailable(d);
      const rows = d.positions.map(p => '<tr><td>' + esc(p.symbol) + window.v7Strat(p.strategy) + '</td><td>' + esc(p.side) + '</td><td class="n">' + n(p.qty, 4) + '</td><td class="n">' + price(p.entry) + '</td><td class="n">' + price(p.mark) + '</td><td class="n ' + cls(p.upnl) + '">' + sgn(p.upnl) + (p.upnlPctOnMargin != null ? ' (' + n(p.upnlPctOnMargin, 0) + '%)' : '') + '</td><td class="n">' + price(p.stopLoss) + '</td><td class="n">' + price(p.takeProfit) + '</td><td class="n">' + price(p.liquidationPrice) + '</td><td>' + (p.protected ? '<span class="pill ok">SL set</span>' : '<span class="pill bad">NO STOP</span>') + '</td><td><button class="lv-btn danger" data-a="close" data-s="' + esc(p.symbol) + '" ' + ((S.gates || {}).isLive ? '' : 'disabled') + '>Close</button></td></tr>').join('');
      const oo = (d.openOrders || []).map(o => '<tr><td>' + esc(o.symbol) + window.v7Strat(o.strategy) + '</td><td>' + esc(o.side) + (o.reduceOnly ? ' (reduce)' : '') + '</td><td class="n">' + n(o.qty, 4) + '</td><td class="n">' + price(o.price) + '</td><td>' + esc(o.status) + '</td></tr>').join('');
      const rc = (d.records || []).map(r => '<tr><td>' + esc(r.symbol) + '</td><td>' + esc(r.direction) + '</td><td>' + esc(r.state) + '</td><td class="n">' + n(r.filledQty, 4) + '/' + n(r.qty, 4) + '</td><td>' + (r.protected === true ? '<span class="pill ok">yes</span>' : r.protected === false ? '<span class="pill bad">NO</span>' : '–') + '</td><td>' + esc(r.strategy || '–') + '</td><td class="n">' + new Date(r.updatedAt).toLocaleTimeString() + '</td></tr>').join('');
      return (d.stale ? '<div class="lv-alert gold">Last good reading (' + ago(d.fetchedAt) + '). The exchange is not answering.</div>' : '') + '<div class="lv-note">From exchange · ' + ago(d.fetchedAt) + '</div>' +
        '<div class="card" style="padding:0;overflow:auto;margin-bottom:14px"><table class="lv"><thead><tr><th>Symbol</th><th>Side</th><th>Qty</th><th>Entry</th><th>Mark</th><th>Unrealised</th><th>SL</th><th>TP</th><th>Liq.</th><th>Protection</th><th></th></tr></thead><tbody>' + (rows || '<tr><td colspan="11" class="lv-note">No open positions.</td></tr>') + '</tbody></table></div>' +
        '<div class="k lv-note">OPEN ORDERS</div><div class="card" style="padding:0;overflow:auto;margin-bottom:14px"><table class="lv"><thead><tr><th>Symbol</th><th>Side</th><th>Qty</th><th>Price</th><th>Status</th></tr></thead><tbody>' + (oo || '<tr><td colspan="5" class="lv-note">None.</td></tr>') + '</tbody></table></div>' +
        '<div class="k lv-note">ORDER LIFECYCLE (robot records)</div><div class="card" style="padding:0;overflow:auto"><table class="lv"><thead><tr><th>Symbol</th><th>Side</th><th>State</th><th>Filled</th><th>Stop verified</th><th>Strategy</th><th>Updated</th></tr></thead><tbody>' + (rc || '<tr><td colspan="7" class="lv-note">No live orders yet.</td></tr>') + '</tbody></table></div>';
    },
    journal(d) {
      const s = d.stats || {};
      const row = (t) => '<tr><td>' + esc(t.symbol) + '</td><td>' + esc(t.direction) + '</td><td>' + esc(t.strategy_name || '–') + '</td><td class="n">' + price(t.entry) + '</td><td class="n">' + price(t.exit_price) + '</td><td class="n ' + cls(t.pnl) + '">' + sgn(t.pnl, 4) + '</td><td class="n">' + n(t.fee, 4) + '</td><td>' + esc(t.exit_reason || t.outcome || '') + '</td><td class="n">' + (t.close_time ? new Date(t.close_time).toLocaleString() : '') + '</td></tr>';
      return '<div class="lv-grid">' + card('Closed live trades', s.trades || 0) + card('Net P&L', sgn(s.totalPnl, 4), 'after fees', cls(s.totalPnl)) + card('Win rate', n((s.winRate || 0) * 100, 0) + '%') + card('Profit factor', n(s.profitFactor), '≥1.2 unlocks scaling') + card('Expectancy / trade', sgn(s.expectancy, 4), '', cls(s.expectancy)) + card('Fees paid', usd(s.fees, 4)) + '</div>' +
        '<div class="lv-note">Real trades only (separate from the paper journal). Realised P&amp;L is as reported by the exchange.</div>' +
        '<div class="k lv-note">OPEN</div><div class="card" style="padding:0;overflow:auto;margin-bottom:14px"><table class="lv"><thead><tr><th>Symbol</th><th>Side</th><th>Strategy</th><th>Entry</th><th>Exit</th><th>P&L</th><th>Fee</th><th>Result</th><th>Closed</th></tr></thead><tbody>' + ((d.open || []).map(row).join('') || '<tr><td colspan="9" class="lv-note">None.</td></tr>') + '</tbody></table></div>' +
        '<div class="k lv-note">CLOSED</div><div class="card" style="padding:0;overflow:auto"><table class="lv"><thead><tr><th>Symbol</th><th>Side</th><th>Strategy</th><th>Entry</th><th>Exit</th><th>P&L</th><th>Fee</th><th>Result</th><th>Closed</th></tr></thead><tbody>' + ((d.closed || []).map(row).join('') || '<tr><td colspan="9" class="lv-note">No closed live trades yet.</td></tr>') + '</tbody></table></div>';
    },
    strategy(d) {
      return '<div class="lv-note">Performance of each strategy on <b>real</b> trades only.</div><div class="card" style="padding:0;overflow:auto"><table class="lv"><thead><tr><th>Strategy</th><th>Trades</th><th>Win rate</th><th>Profit factor</th><th>Net P&L</th></tr></thead><tbody>' +
        ((d.strategies || []).map(x => '<tr><td>' + esc(x.name) + '</td><td class="n">' + x.trades + '</td><td class="n">' + n(x.winRate * 100, 0) + '%</td><td class="n">' + n(x.profitFactor) + '</td><td class="n ' + cls(x.pnl) + '">' + sgn(x.pnl, 4) + '</td></tr>').join('') || '<tr><td colspan="5" class="lv-note">No closed live trades yet.</td></tr>') + '</tbody></table></div>';
    },
    charts(d) {
      return '<div class="lv-charts"><div class="card lv-card"><div class="k">Cumulative realised P&amp;L</div>' + line((d.curve || []).map(p => ({ x: p.t, y: p.pnl })), '#A9E8DF') + '</div>' +
        '<div class="card lv-card"><div class="k">Account equity (robot samples)</div>' + line(((d.equity || [])).map(p => ({ x: p.t, y: p.e })), '#A9E8DF') + '</div>' +
        '<div class="card lv-card"><div class="k">Daily P&amp;L</div>' + bars((d.daily || []).map(x => ({ l: x.d.slice(5), v: x.pnl }))) + '</div>' +
        '<div class="card lv-card"><div class="k">P&amp;L by strategy</div>' + bars((d.strategies || []).map(x => ({ l: x.name.slice(0, 10), v: x.pnl }))) + '</div></div>';
    },
    health(d) {
      return '<div class="card lv-card"><div class="k">System checks</div>' + (d.checks || []).map(c => '<div class="chk"><span class="pill ' + (c.ok ? 'ok' : 'bad') + '">' + (c.ok ? 'OK' : 'FAIL') + '</span><b>' + esc(c.name) + '</b><span class="d">' + esc(c.detail) + '</span></div>').join('') + '</div>' +
        '<div class="card lv-card" style="margin-top:12px"><div class="k">Alerts (also sent to Telegram)</div><div id="lvFeed" style="max-height:340px;overflow:auto;font-size:12.5px"></div></div>';
    },
  };

  function line(pts, color) {
    if (!pts || pts.length < 2) return '<div class="lv-note">Not enough data yet.</div>';
    const W = 420, H = 150, pad = 8, xs = pts.map(p => p.x), ys = pts.map(p => p.y), x0 = Math.min(...xs), x1 = Math.max(...xs) || 1, y0 = Math.min(0, ...ys), y1 = Math.max(0, ...ys), yr = (y1 - y0) || 1, xr = (x1 - x0) || 1;
    const P = pts.map(p => ((p.x - x0) / xr * (W - 2 * pad) + pad).toFixed(1) + ',' + (H - pad - (p.y - y0) / yr * (H - 2 * pad)).toFixed(1)).join(' ');
    const zero = (H - pad - (0 - y0) / yr * (H - 2 * pad)).toFixed(1);
    return '<svg viewBox="0 0 ' + W + ' ' + H + '"><line x1="' + pad + '" x2="' + (W - pad) + '" y1="' + zero + '" y2="' + zero + '" stroke="rgba(255,255,255,.15)" stroke-dasharray="3 3"/><polyline fill="none" stroke="' + color + '" stroke-width="2" points="' + P + '"/></svg><div class="lv-note num">last ' + n(ys[ys.length - 1], 4) + '</div>';
  }
  function bars(items) {
    if (!items.length) return '<div class="lv-note">Not enough data yet.</div>';
    const W = 420, H = 150, pad = 18, mx = Math.max(...items.map(i => Math.abs(i.v))) || 1, bw = (W - 2 * pad) / items.length, mid = H / 2;
    return '<svg viewBox="0 0 ' + W + ' ' + H + '">' + items.map((i, k) => { const h = Math.abs(i.v) / mx * (H / 2 - 14); const x = pad + k * bw + bw * .15; return '<rect x="' + x.toFixed(1) + '" y="' + (i.v >= 0 ? mid - h : mid).toFixed(1) + '" width="' + (bw * .7).toFixed(1) + '" height="' + Math.max(1, h).toFixed(1) + '" rx="2" fill="' + (i.v >= 0 ? '#57D69C' : '#A9E8DF') + '"/><text x="' + (x + bw * .35).toFixed(1) + '" y="' + (H - 2) + '" font-size="8" fill="#A3A9B8" text-anchor="middle">' + esc(i.l) + '</text>'; }).join('') + '<line x1="' + pad + '" x2="' + (W - pad) + '" y1="' + mid + '" y2="' + mid + '" stroke="rgba(255,255,255,.15)"/></svg>';
  }
  function checklist() {
    return '<div class="card lv-card" style="margin-top:12px"><div class="k">Live trading checklist</div><div class="lv-note">☐ Keys have NO withdrawal permission · ☐ Account is ISOLATED margin, one-way position mode · ☐ Rehearsed on testnet · ☐ Telegram /status works · ☐ You can reach the exchange app · ☐ Start with few slots (SCALING_MAX_SLOTS=3) · ☐ Only money you can afford to lose</div></div>';
  }

  // ── preview wiring ───────────────────────────────────────────────────────────────────────────────
  function bindPreview() {
    const go = $('#pvGo'); if (!go) return;
    go.onclick = async () => {
      const body = { symbol: $('#pvSym').value, direction: $('#pvDir').value, entry: $('#pvEntry').value, stopLoss: $('#pvSl').value, takeProfit: $('#pvTp').value };
      ls.set('pv_sym', body.symbol); go.disabled = true; const r = await post('/api/live/preview', body); go.disabled = false; S.preview = r.body; showPreview(r.body);
    };
    if (S.preview) showPreview(S.preview);
  }
  function showPreview(r) {
    const o = $('#pvOut'); if (!o) return;
    if (r.ok === false) { o.innerHTML = unavailable(r); return; }
    const z = r.sizing, f = r.fees, l = r.liquidation;
    o.innerHTML = '<div class="lv-grid" style="margin-top:12px">' + card('Verdict', r.wouldAccept ? 'PASSES RISK RULES' : 'WOULD BE REJECTED', r.wouldSendNow ? 'robot would send it now' : 'nothing is sent from here', r.wouldAccept ? 'pos' : 'neg') +
      (z ? card('Size', n(z.qty, 4), usd(z.notional) + ' notional · ' + usd(z.margin) + ' margin · ' + z.leverage + 'x') + card('Risk to stop', usd(z.riskUsd, 3), n(z.riskPctEquity * 100, 2) + '% of equity') + card('Reward at target', usd(z.rewardUsd, 3), 'R:R ' + n(z.rr)) : '') +
      (f ? card('Round-trip fees', usd(f.roundTripUsd, 3), (f.assumed ? 'assumed ' : '') + n(f.takerFeeRate * 100, 3) + '% taker · net R:R ' + n(f.netRewardUsd / f.netRiskUsd)) : '') + (l ? card('Liquidation', price(l.price), n(l.distancePct) + '% away · stop ' + n(l.stopDistancePct) + '%') : '') + '</div>' +
      '<div class="card lv-card">' + r.checks.map(c => '<div class="chk"><span class="pill ' + (c.ok ? 'ok' : (c.name.startsWith('gate:') ? 'gold' : 'bad')) + '">' + (c.ok ? 'OK' : 'NO') + '</span><b>' + esc(c.name) + '</b><span class="d">' + esc(c.detail) + '</span></div>').join('') + '</div>';
  }

  // ── polling ──────────────────────────────────────────────────────────────────────────────────────
  const PATH = { account: '/api/live/account', risk: '/api/live/risk', positions: '/api/live/positions', health: '/api/live/health', journal: '/api/live/journal', strategy: '/api/live/journal', charts: '/api/live/journal' };
  function render() { if (!$('#lvBody')) shell(); document.querySelectorAll('#lvTabs button').forEach(b => b.classList.toggle('on', b.dataset.t === S.tab)); bar(); gates(); if (S.tab === 'preview') { $('#lvBody').innerHTML = view.preview(); bindPreview(); } if (S.tab === 'lab') { $('#lvBody').innerHTML = view.lab();  } }
  let busy = false;
  async function poll(force) {
    if (S.view !== 'live' || (busy && !force)) return; busy = true;
    try {
      const g = await api('/api/live/gates'); S.gates = g.body; gates(); bar();
      const feed = await api('/api/live/feed'); handleFeed(feed.body.alerts || []);
      if (S.tab === 'preview') return;
      const r = await api(PATH[S.tab]); let d = r.body; const body = $('#lvBody'); if (!body) return;
      if (S.tab === 'charts') { const a = await api('/api/live/account'); d = { ...d, equity: (a.body.equitySeries || []) }; }
      // v6.3 fix: the page refreshes every 5s and used to wipe what you were typing (e.g. the go-live phrase), so Authorise sent an empty phrase.
      const act = document.activeElement; if (act && body.contains(act) && /^(INPUT|TEXTAREA|SELECT)$/.test(act.tagName) && act.type !== 'checkbox') return;   // never re-render while you are typing
      const keep = {}; body.querySelectorAll('input,select,textarea').forEach(i => { if (i.id) keep[i.id] = i.type === 'checkbox' ? { c: i.checked } : { v: i.value }; });
      body.innerHTML = view[S.tab](d);
      Object.keys(keep).forEach(id => { const i = document.getElementById(id); if (i) { if ('c' in keep[id]) i.checked = keep[id].c; else if (keep[id].v !== '') i.value = keep[id].v; } });
      if (S.tab === 'health') { const el = $('#lvFeed'); if (el) el.innerHTML = (feed.body.alerts || []).slice().reverse().map(a => '<div style="padding:6px 0;border-bottom:1px solid rgba(255,255,255,.06)"><span class="num" style="color:#737A8C">' + new Date(a.ts).toLocaleTimeString() + '</span> <b class="' + (a.severity === 'CRITICAL' ? 'neg' : a.severity === 'WARNING' ? 'warn' : '') + '">' + esc(a.title) + '</b><div style="color:var(--text-muted);white-space:pre-line">' + esc(a.message) + '</div></div>').join('') || '<div class="lv-note">No alerts yet.</div>'; }
      const warn = []; if (g.body.blocked) warn.push('ENTRIES BLOCKED: ' + esc(g.body.blocked)); if (g.body.emergency) warn.push('KILL SWITCH ACTIVE: no new trades'); if (g.body.paused) warn.push('Entries are PAUSED'); if (g.body.robotError) warn.push('Robot error: ' + esc(g.body.robotError)); const cn = g.body.connectivity; if (cn && cn.blocked) warn.push('BYBIT REFUSES THIS SERVER (' + esc(cn.lastError || 'HTTP 403') + ') on ' + esc(g.body.baseUrl || '') + '. The IP or country is blocked, so nothing can load. Run the robot from an allowed region (VPS in Singapore/Europe, or your own PC), or set BYBIT_BASE_URL.'); if (g.body.runMode === 'TESTNET' && !g.body.keysPresent) warn.push('No Bybit TESTNET API keys found. Add BYBIT_API_KEY / BYBIT_API_SECRET to .env and restart.');
      $('#lvWarn').innerHTML = warn.map(w => '<div class="lv-alert">' + w + '</div>').join('');
    } catch (e) { const b = $('#lvBody'); if (b) b.innerHTML = '<div class="lv-alert">Dashboard could not reach the server: ' + esc(e.message) + '</div>'; }
    finally { busy = false; }
  }
  function handleFeed(alerts) {
    if (!alerts.length) return; const newest = alerts[alerts.length - 1].ts;
    if (!S.lastAlert) { S.lastAlert = newest; return; }
    const fresh = alerts.filter(a => a.ts > S.lastAlert); S.lastAlert = newest;
    if (fresh.some(a => a.severity === 'CRITICAL' || /UNPROTECTED|BLOCKED|NO STOP/i.test(a.title))) warnSound(); else if (fresh.some(a => /Filled|Order placed|Win|Loss/i.test(a.title))) clickSound();
  }

  // ── boot ─────────────────────────────────────────────────────────────────────────────────────────
  function boot() {
    if (!$('#liveRoot')) return; mountSwitch(); shell(); setView(S.view);
    document.querySelectorAll('#modeSwitch button').forEach(b => b.classList.toggle('on', b.dataset.v === S.view));
    const refreshGates = async () => { try { S.gates = (await api('/api/live/gates')).body; gates(); if (S.view === 'live') bar(); } catch (_) { /* server restarting */ } };
    refreshGates(); setInterval(refreshGates, 10000);
    if (S.timer) clearInterval(S.timer); S.timer = setInterval(() => poll(false), 5000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
