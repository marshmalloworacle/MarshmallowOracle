/* ALPHA LIVE ROBOT v6.7 — entry-block banner (auto-clear countdown, force-clear) + manual "Take" from the Market Scanner.
   Everything shown comes from the backend (/api/live/entry-block, /api/scanner/take-preview). Nothing is simulated. */
(function () {
  'use strict';
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const H = { 'Content-Type': 'application/json', 'X-Alpha': '1' };
  const post = async (url, body) => { const r = await fetch(url, { method: 'POST', headers: H, body: JSON.stringify(body || {}) }); let j = {}; try { j = await r.json(); } catch (_) { /* non-json */ } return { ok: r.ok && j.ok !== false, status: r.status, body: j }; };
  const fx = (v) => (v == null || !isFinite(v)) ? '–' : (Math.abs(v) >= 100 ? Number(v).toFixed(2) : Math.abs(v) >= 1 ? Number(v).toFixed(4) : Number(v).toPrecision(5));

  function toast(msg, ok) {
    if (window.__v6toast) return window.__v6toast(msg, ok);
    const t = document.createElement('div');
    t.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:100001;max-width:420px;padding:12px 16px;border-radius:8px;font-size:13px;font-weight:600;color:#fff;box-shadow:0 8px 30px rgba(0,0,0,.45);background:' + (ok ? '#1f7a5c' : '#9b2c2c');
    t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), ok ? 6000 : 11000);
  }

  // ── Entry-block banner ───────────────────────────────────────────────────────────────────────
  let bar = null, clearedShownAt = 0, lastClearedTs = null, st = null;
  function ensureBar() {
    if (bar) return bar;
    bar = document.createElement('div'); bar.id = 'v67EntryBlock';
    bar.style.cssText = 'display:none;position:sticky;top:0;z-index:9999;padding:9px 16px;font-size:13px;font-weight:600;align-items:center;gap:12px;flex-wrap:wrap;border-bottom:1px solid rgba(255,255,255,.12)';
    document.body.insertBefore(bar, document.body.firstChild); return bar;
  }
  function renderBar() {
    const b = ensureBar();
    if (!st || !st.isLive) { b.style.display = 'none'; return; }
    const now = Date.now();
    if (st.blocked) {
      const left = st.remainingSec;
      const when = st.autoClearSec > 0 ? (left > 0 ? ('checks the exchange and clears in ' + left + 's') : 'checking the exchange now…') : 'auto-clear is off (ENTRY_BLOCK_AUTOCLEAR_SEC=0)';
      b.style.cssText += ';display:flex;background:#5b1f24;color:#ffd9d9';
      b.innerHTML = '<span>⛔ ENTRIES BLOCKED: ' + esc(st.reason) + ' — <span style="font-weight:500">' + esc(when) + (st.forceClear ? ' (FORCE mode: clears even if unresolved)' : ' (VERIFIED mode: clears once nothing is unresolved)') + '</span></span>' +
        '<span style="flex:1"></span><label style="font-weight:500;cursor:pointer"><input type="checkbox" id="v67Force" ' + (st.forceClear ? 'checked' : '') + '> Force-clear after wait even if unresolved</label>' +
        '<button id="v67ClearNow" style="padding:4px 10px;border-radius:6px;border:1px solid #ffb4b4;background:transparent;color:#fff;cursor:pointer;font-weight:700">Force clear now</button>';
      const f = document.getElementById('v67Force'); if (f) f.onchange = async () => { const r = await post('/api/live/entry-block/force', { enabled: f.checked }); toast(r.ok ? (f.checked ? 'Force-clear ON: the block clears after the wait even if unresolved' : 'Verified mode: the block clears only once resolved') : (r.body.error || 'Not applied'), r.ok); if (!r.ok) f.checked = !f.checked; poll(); };
      const c = document.getElementById('v67ClearNow'); if (c) c.onclick = async () => { c.disabled = true; const r = await post('/api/live/entry-block/clear-now'); toast(r.ok ? 'Entry block cleared' : (r.body.error || 'Not cleared'), r.ok); poll(); };
      return;
    }
    if (now - clearedShownAt < 12000) {
      const lc = st.lastCleared || {};
      b.style.cssText += ';display:flex;background:#12503f;color:#d7fff0';
      b.innerHTML = '<span>✅ Entry block cleared' + (lc.mode ? ' (' + (lc.mode === 'forced' ? 'forced' : 'verified') + ')' : '') + ' — new trades can open.</span>';
      return;
    }
    b.style.display = 'none';
  }
  async function poll() {
    try {
      const r = await fetch('/api/live/entry-block', { cache: 'no-store' }); if (!r.ok) return; const j = await r.json();
      const prevBlocked = st && st.blocked; st = j;
      const lcTs = j.lastCleared && j.lastCleared.at;
      if (lcTs && lcTs !== lastClearedTs) { if (lastClearedTs !== null || (Date.now() - lcTs) < 20000) clearedShownAt = Date.now(); lastClearedTs = lcTs; }
      else if (prevBlocked && !j.blocked) clearedShownAt = Date.now();
      renderBar();
    } catch (_) { /* dashboard offline: keep last render */ }
  }
  setInterval(poll, 2000); setTimeout(poll, 600);
  setInterval(renderBar, 1000);

  // ── Manual Take ──────────────────────────────────────────────────────────────────────────────
  function modal(html) {
    const m = document.createElement('div');
    m.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(5,8,12,.72);display:flex;align-items:center;justify-content:center;padding:16px';
    m.innerHTML = '<div style="background:#14191f;border:1px solid #2a343f;border-radius:12px;padding:20px 22px;max-width:480px;width:100%;color:#e8eef2;box-shadow:0 20px 60px rgba(0,0,0,.6)">' + html + '</div>';
    m.addEventListener('click', e => { if (e.target === m) m.remove(); });
    document.body.appendChild(m); return m;
  }
  const row = (k, v, c) => '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #222b34;font-size:13px"><span style="color:#8b98a5">' + k + '</span><b style="color:' + (c || '#e8eef2') + '">' + v + '</b></div>';
  const busyKeys = new Set();
  window.v67Take = async function (symbol, direction, strategyId, btn) {
    const key = symbol + '|' + direction; if (busyKeys.has(key)) return;
    const m = modal('<h3 style="margin:0 0 8px;color:#4fe3d0">Take ' + esc(symbol) + ' ' + esc(direction) + '</h3><div style="color:#8b98a5;font-size:13px">Re-checking the setup against the market right now…</div>');
    busyKeys.add(key);
    const r = await post('/api/scanner/take-preview', { symbol, direction, strategyId });
    busyKeys.delete(key);
    if (!r.ok) { m.firstChild.innerHTML = '<h3 style="margin:0 0 8px;color:#ff817f">Cannot take ' + esc(symbol) + '</h3><div style="font-size:13px;line-height:1.5">' + esc(r.body.error || r.body.message || 'Refused') + '</div><div style="text-align:right;margin-top:14px"><button id="v67X" class="btn">Close</button></div>'; m.querySelector('#v67X').onclick = () => m.remove(); return; }
    const p = (r.body.result || r.body); const live = p.mode === 'LIVE';
    const needOver = !!p.overridesSlots, needRisk = !!p.needsRiskConfirm, needDir = !!p.directionConflict, SZ = (live && p.sizing && p.sizing.enabled) ? p.sizing : null;
    const slotLine = needOver ? row('Open positions', p.openCount + ' / limit ' + p.slotLimit + ' — OVER LIMIT', '#e0b25a') : row('Open positions', p.openCount + ' / limit ' + (p.slotLimit || '∞') + (p.hardCap > 0 ? ' (hard cap ' + p.hardCap + ')' : ''));
    const riskLine = p.openRiskPctAfter != null ? row('Total open risk after this trade', p.openRiskPctAfter + '% of equity' + (needRisk ? ' (confirm level ' + p.riskConfirmPct + '%)' : ''), needRisk ? '#ff817f' : null) : '';
    const warn = (needDir ? '<div class="v7-warn amber">⚠ <b>Direction mode conflict.</b> ' + esc(p.directionConflict.reason) + '. Your explicit Take overrides the direction mode for this one trade (open positions and other entries are unaffected).<label><input type="checkbox" class="v7chk"> Yes, take this ' + esc(p.direction) + ' anyway</label></div>' : '') + (needOver ? '<div class="v7-warn amber">⚠ <b>You are going over your position limit</b> (' + p.openCount + ' open, limit ' + p.slotLimit + '). Great setups are allowed, but this adds risk on top of what is already open.<label><input type="checkbox" class="v7chk"> Yes, take it even though I am over my limit</label></div>' : '') +
      (needRisk ? '<div class="v7-warn red">⛔ <b>High total risk.</b> If every stop-loss hit you could lose about <b>' + p.openRiskPctAfter + '%</b> of equity. The normal aggregate-risk cap is bypassed for this one trade only; stop-loss, daily-loss limit, kill switch and exchange limits still apply.<label><input type="checkbox" class="v7chk"> I understand and still want to proceed</label></div>' : '');
    m.firstChild.innerHTML = '<h3 style="margin:0 0 4px;color:#4fe3d0">Take ' + esc(p.symbol) + ' ' + esc(p.direction) + ' <span style="font-size:11px;padding:2px 7px;border-radius:5px;background:' + (live ? '#7a1f24' : '#1f4f7a') + ';color:#fff;vertical-align:middle">' + esc(p.mode) + '</span></h3>' +
      '<div style="color:#8b98a5;font-size:12px;margin-bottom:8px">Fresh re-validation passed. ' + esc(p.strategy || '') + ' · score ' + esc(p.score) + '</div>' +
      row('Entry (fresh)', fx(p.entry)) + row('Live price', fx(p.livePrice) + ' (drift ' + p.driftPct + '% / max ' + p.maxDriftPct + '%)') + row('Stop-loss', fx(p.stopLoss), '#ff817f') + row('Take-profit', fx(p.takeProfit), '#57d69c') +
      row('Risk:Reward', '1:' + (p.riskReward ? Number(p.riskReward).toFixed(2) : '–')) + row('Risk this trade (approx.)', '$' + p.riskUsd) + slotLine + riskLine + warn +
      (SZ ? '<div style="margin:10px 0;padding:10px;border:1px solid #29333D;border-radius:8px"><div style="font-size:12px;color:#8b98a5;margin-bottom:6px">Trade size (margin) — this trade only, your saved default stays <b>' + esc(SZ.margin) + ' USDT</b></div>' +
        '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><button type="button" class="btn" data-sz="-1" style="min-width:32px;font-weight:800">−</button><input id="v67Sz" type="number" step="any" min="' + esc(SZ.min) + '" value="' + esc(SZ.margin) + '" style="width:84px;background:#0A0C10;border:1px solid #29333D;border-radius:6px;padding:6px;color:#F1F5F7;font-size:14px;font-weight:700"> <span style="font-size:12px">USDT</span><button type="button" class="btn" data-sz="1" style="min-width:32px;font-weight:800">+</button>' +
        (SZ.presets || []).slice(0, 8).map(v => '<button type="button" class="btn" data-szp="' + v + '" style="padding:4px 8px;font-size:12px">' + v + '</button>').join('') + '</div>' +
        '<div id="v67SzInfo" style="font-size:12px;color:#57d69c;margin-top:6px"></div></div>' : '') +
      '<div style="font-size:11px;color:#8b98a5;margin:10px 0">Final size, leverage, margin, daily-loss and exchange minimums are enforced by the risk engine when you confirm. If anything fails, nothing is sent.</div>' +
      '<div style="display:flex;gap:8px;justify-content:flex-end"><button id="v67No" class="btn">Cancel</button><button id="v67Yes" class="btn" style="background:' + (live ? '#b3262e' : '#14877a') + ';color:#fff;font-weight:700">' + (live ? 'Confirm LIVE order' : 'Confirm paper trade') + '</button></div>';
    const yes = m.querySelector('#v67Yes'), chks = Array.from(m.querySelectorAll('.v7chk'));
    const sync = () => { const ok = chks.every(c => c.checked) && szSync(); yes.disabled = !ok; yes.style.opacity = ok ? '1' : '.45'; yes.style.cursor = ok ? 'pointer' : 'not-allowed'; };
    const szIn = m.querySelector('#v67Sz'), szInfo = m.querySelector('#v67SzInfo');
    const szSync = () => { if (!szIn) return true; const v = Number(szIn.value), ok = Number.isFinite(v) && v >= Number(SZ.min) && v <= 100000 && (SZ.custom !== false || (SZ.presets || []).includes(v));
      szInfo.style.color = ok ? '#57d69c' : '#ff817f'; szInfo.textContent = ok ? '= ' + (v * SZ.leverage).toFixed(2) + ' USDT position at ' + SZ.leverage + 'x' + (v !== Number(SZ.margin) ? ' (differs from your default)' : '') : 'Enter at least ' + SZ.min + ' USDT' + (SZ.custom === false ? ' (a preset)' : '');
      return ok; };
    if (szIn) { m.querySelectorAll('[data-sz]').forEach(b => b.onclick = () => { const st = Number(SZ.step) || 0.5; szIn.value = Math.max(Number(SZ.min), Math.round((Number(szIn.value || 0) + Number(b.dataset.sz) * st) * 10000) / 10000); sync(); });
      m.querySelectorAll('[data-szp]').forEach(b => b.onclick = () => { szIn.value = b.dataset.szp; sync(); }); szIn.addEventListener('input', sync); }
    chks.forEach(c => c.addEventListener('change', sync)); sync();
    m.querySelector('#v67No').onclick = () => m.remove();
    yes.onclick = async () => {
      if (yes.disabled) return; yes.disabled = true; yes.textContent = 'Placing…';
      const t = await post('/api/scanner/take', { symbol, direction, strategyId, confirmOver: needOver, confirmRisk: needRisk, confirmDirection: needDir, marginUsdt: szIn ? Number(szIn.value) : undefined });
      m.remove();
      if (t.ok && t.body.queued) toast('Queued — the robot has not confirmed yet. Check Positions before retrying.', false);
      else if (t.ok) { const q = t.body.result || {}; toast('Taken: ' + (q.symbol || symbol) + ' ' + (q.direction || direction) + ' (' + (q.mode || '').toUpperCase() + ')' + (q.slotOverridden ? ' — position limit overridden' : ''), true); if (typeof fetchScanner === 'function') fetchScanner(); }
      else toast(t.body.error || 'Refused', false);
    };
  };
})();
