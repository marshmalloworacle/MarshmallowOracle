/* v4.6 control strip: mode + API status, directional control, health, feature switches. Polls /api/v46/state. */
(function () {
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const root = document.createElement('div'); root.id = 'v46';
  const ribbon = document.getElementById('modeRibbon');
  (ribbon && ribbon.parentNode ? ribbon.parentNode : document.body).insertBefore(root, ribbon ? ribbon.nextSibling : document.body.firstChild);
  let S = null, open = false, lastErr = null;

  const fmtLeft = (ms) => { if (ms == null) return ''; const m = Math.ceil(ms / 60000); return m >= 60 ? Math.floor(m / 60) + 'h ' + (m % 60) + 'm' : m + 'm'; };
  const DIRS = [['ADAPTIVE', 'ADAPTIVE'], ['AUTO', 'AUTO'], ['BOTH', 'BOTH'], ['LONG_ONLY', 'LONG ONLY'], ['SHORT_ONLY', 'SHORT ONLY'], ['PAUSE', 'PAUSE NEW TRADES']];

  async function post(url, body) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({})); if (!r.ok || d.ok === false) throw new Error(d.error || 'HTTP ' + r.status); return d;
  }
  function render() {
    if (!S) { root.innerHTML = '<div class="row"><span class="pill">' + (lastErr ? 'control strip: ' + esc(lastErr) : 'loading…') + '</span></div>'; return; }
    const d = S.direction, isLive = S.mode === 'LIVE';
    const modeBadge = '<span class="badge ' + (isLive ? 'live' : 'paper') + '">' + (S.mode === 'SIM' ? 'PAPER' : esc(S.mode)) + '</span>';
    const api = '<span class="pill"><span class="dot ' + (S.apiStatus === 'CONNECTED' ? 'OK' : S.apiStatus === 'ERROR' ? 'DOWN' : '') + '"></span>API ' + esc(S.apiStatus) + '</span>';
    const dirBtns = DIRS.map(([m, l]) => '<button class="' + (m === 'PAUSE' ? 'pause ' : '') + (d.mode === m ? 'on' : '') + '" data-dir="' + m + '">' + l + '</button>').join('');
    const dur = '<select id="v46dur"><option value="">until changed</option>' + S.presets.map(h => '<option value="' + h + '">' + h + 'H</option>').join('') + '<option value="custom">custom…</option></select> <input id="v46cust" type="number" min="0.1" step="0.5" placeholder="hrs" style="display:none">';
    const timer = d.expiresAt ? '<span class="pill">⏱ ' + fmtLeft(d.remainingMs) + ' left → back to ' + esc(d.defaultMode) + '</span>' : '';
    const blocked = '<span class="pill" title="' + esc(Object.entries(d.reasons || {}).map(([k, v]) => k + ' ×' + v).join('\n')) + '">blocked entries: ' + (d.blocked || 0) + '</span>';
    const H = S.health, hp = Object.entries({ Robot: H.robot, Scanner: H.scanner, 'Market data': H.marketData, Exchange: H.exchange, 'Position mgr': H.positionManager, DB: H.database, Reconcile: H.reconciliation })
      .map(([k, v]) => '<span class="pill" title="' + esc(v.detail) + '"><span class="dot ' + (v.status === 'N/A' ? '' : v.status) + '"></span>' + k + ' ' + v.status + '</span>').join('');
    const feats = S.features.map(f => '<label class="sw"><input type="checkbox" data-feat="' + f.key + '" ' + (f.enabled ? 'checked' : '') + '><span>' + esc(f.label) + '<small>' + esc(f.desc) + '</small></span></label>').join('');
    const sets = (S.settings || []).map(x => x.options ? '<label class="set"><span>' + esc(x.label) + '</span><select data-set="' + x.key + '">' + x.options.map(o => '<option ' + (o === x.value ? 'selected' : '') + '>' + o + '</option>').join('') + '</select></label>' : '<label class="set"><span>' + esc(x.label) + '</span><input type="number" data-set="' + x.key + '" value="' + x.value + '" min="' + x.min + '" max="' + x.max + '" step="any"></label>').join('');
    root.innerHTML = '<div class="row">' + modeBadge + api + '<span class="seg">' + dirBtns + '</span>' + dur + timer + blocked + '</div>' +
      '<div class="row">' + hp + '<span class="link" id="v46tog">' + (open ? 'hide' : 'features ▾') + '</span></div>' +
      '<div class="feat ' + (open ? 'open' : '') + '">' + feats + '</div><div class="feat ' + (open ? 'open' : '') + '"><b style="grid-column:1/-1">Tunable limits (apply instantly)</b>' + sets + '</div>';
  }
  async function poll() { try { S = await (await fetch('/api/v46/state')).json(); lastErr = null; } catch (e) { lastErr = e.message; } render(); }

  root.addEventListener('click', async (e) => {
    const t = e.target;
    if (t.id === 'v46tog') { open = !open; render(); return; }
    if (t.dataset && t.dataset.dir) {
      let sel = root.querySelector('#v46dur'), hrs = sel ? sel.value : '';
      if (hrs === 'custom') hrs = (root.querySelector('#v46cust') || {}).value || '';
      try { await post('/api/v46/direction', { mode: t.dataset.dir, hours: hrs || null }); } catch (er) { alert('Direction change failed: ' + er.message); }
      poll();
    }
  });
  root.addEventListener('change', async (e) => {
    const t = e.target;
    if (t.id === 'v46dur') { const c = root.querySelector('#v46cust'); if (c) c.style.display = t.value === 'custom' ? '' : 'none'; }
    if (t.dataset && t.dataset.set) { try { await post('/api/v46/settings', { key: t.dataset.set, value: t.value }); } catch (er) { alert('Setting rejected: ' + er.message); } poll(); return; }
    if (t.dataset && t.dataset.feat) {
      try { await post('/api/v46/features', { key: t.dataset.feat, enabled: t.checked }); } catch (er) { alert('Switch failed: ' + er.message); }
      poll();
    }
  });
  poll(); setInterval(poll, 5000);
  setInterval(() => { if (S && S.direction && S.direction.expiresAt) { S.direction.remainingMs = Math.max(0, S.direction.expiresAt - Date.now()); if (!root.querySelector('select:focus,input:focus')) render(); } }, 30000);
})();
