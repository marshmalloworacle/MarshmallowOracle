/* v5 mission-control cards. Reads /api/v46/overview. Every value says whether it is live, estimated, stale, unknown or off. */
(function () {
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const host = document.getElementById('tab-overview') || document.querySelector('main') || document.body;
  const root = document.createElement('div'); root.id = 'v5cards'; host.insertBefore(root, host.firstChild);
  const f1 = (v, d = 1, suf = '') => (v == null || !Number.isFinite(v) ? '<small>UNKNOWN</small>' : Number(v).toFixed(d) + suf);
  const age = (ts) => { if (!ts) return null; const s = Math.round((Date.now() - ts) / 1000); return s < 90 ? s + 's' : Math.round(s / 60) + 'm'; };
  const cls = (v, w, b) => (v == null ? '' : v >= b ? 'bad' : v >= w ? 'warn' : '');
  const kv = (k, v, note) => '<div class="kv"><span>' + k + (note ? ' <small>' + note + '</small>' : '') + '</span><b>' + v + '</b></div>';
  const card = (t, body, chip, wide) => '<section class="v5c' + (wide ? ' wide' : '') + '"><h4><span>' + t + '</span>' + (chip || '') + '</h4>' + body + '</section>';
  const chip = (txt, c) => '<span class="chip ' + (c || '') + '">' + esc(txt) + '</span>';
  const off = (what) => '<div class="ph">Switched OFF — enable “' + esc(what) + '” in features ▾ to enforce this.<br>Values below are tracked only.</div>';
  const ph = (t) => '<div class="ph">' + t + '</div>';

  function market(d) {
    const i = d.intel; if (!i) return card('Market Intelligence', ph('UNKNOWN — waiting for the robot’s first market scan'), chip('NO DATA', 'warn'));
    const a = Date.now() - i.ts, stale = a > 5 * 60e3, sc = i.sentiment.score;
    const gauge = sc == null ? ph('Sentiment UNKNOWN (not enough data)') : '<div class="bat" style="--r:' + (100 - sc) + '%"><i></i><span>' + sc + ' · ' + esc(i.sentiment.label) + '</span></div>';
    return card('Market Intelligence', gauge +
      kv('Confidence', i.sentiment.confidence == null ? '<small>UNKNOWN</small>' : i.sentiment.confidence + '%', 'estimate') +
      kv('BTC', esc(i.btc.trend) + ' · 24h ' + f1(i.btc.ch24, 2, '%')) + kv('ETH', esc(i.eth.trend) + ' · 24h ' + f1(i.eth.ch24, 2, '%')) +
      kv('Breadth', i.breadth.upPct == null ? '<small>UNKNOWN</small>' : f1(i.breadth.upPct, 0, '% up'), esc(i.breadth.scope)) +
      kv('Volatility', esc(i.btc.volatility) + (i.btc.atrRatio ? ' · ATR×' + i.btc.atrRatio : ''), 'BTC') +
      kv('Volume Δ', i.volume.changePct == null ? '<small>UNKNOWN (building history)</small>' : f1(i.volume.changePct, 1, '%'), 'rolling 24h turnover') +
      kv('Funding (median)', i.funding.median == null ? '<small>UNKNOWN</small>' : f1(i.funding.median * 100, 4, '%'), 'exchange-wide') +
      kv('Buy/sell flow', '<small>UNAVAILABLE</small>', 'no aggressor data from the exchange') +
      kv('Regime', esc(i.regime.state), 'since ' + age(i.regime.since)) + kv('Bias', esc(i.bias.recommendation), 'suggestion') +
      (i.shock.active ? '<div class="kv"><span class="dn">⚠ MARKET SHOCK</span><b>BTC 1h ' + f1(i.shock.btc1hPct, 1, '%') + '</b></div>' : ''),
      chip(stale ? 'STALE ' + age(i.ts) : 'LIVE · ' + age(i.ts) + ' ago', stale ? 'bad' : 'ok'));
  }
  function portfolio(d) {
    const p = d.portfolio, on = d.features.correlationBlock; if (!p) return card('Portfolio Risk', ph('UNKNOWN — no portfolio snapshot yet'), chip('NO DATA', 'warn'));
    const cap = p.caps.aggRiskPct, ar = p.aggRiskPct;
    const body = (on ? '' : off('Correlation / exposure block')) +
      '<div class="meter"><i class="' + cls(ar, cap * 0.7, cap) + '" style="width:' + Math.min(100, (ar || 0) / cap * 100) + '%"></i></div>' +
      kv('Open risk to stops', f1(ar, 2, '% of equity') + ' / cap ' + cap + '%') + kv('Risk budget left', ar == null ? '<small>UNKNOWN</small>' : f1(Math.max(0, cap - ar), 2, '%')) +
      kv('Positions', p.n) + kv('Notional L / S', '<span class="up">' + Math.round(p.longNotional) + '</span> / <span class="dn">' + Math.round(p.shortNotional) + '</span>') +
      kv('Dominant side', f1(p.dominantSidePct, 0, '%'), 'cap ' + p.caps.dirNotionalPct + '% (3+ pos)') + kv('Largest asset', f1(p.largestAssetPct, 0, '% of notional')) +
      kv('Margin used', f1(p.marginUsedPct, 1, '%')) + kv('Nearest liquidation', p.minLiqDistPct == null || !Number.isFinite(p.minLiqDistPct) ? '<small>UNKNOWN</small>' : f1(p.minLiqDistPct, 1, '%')) +
      kv('Correlated group risk', p.hasCorrData ? f1(p.topGroupRiskPct, 2, '%') + ' / cap ' + p.caps.corrRiskPct + '%' : '<small>UNKNOWN (switch correlation on)</small>') +
      (p.corrPairs && p.corrPairs.length ? '<div class="kv"><span>High correlation</span><b>' + p.corrPairs.slice(0, 3).map(x => esc(x.a.replace('USDT', '')) + '/' + esc(x.b.replace('USDT', '')) + ' ' + x.corr).join(', ') + '</b></div>' : '') +
      (p.unknownStops && p.unknownStops.length ? '<div class="kv"><span class="dn">No stop on exchange</span><b>' + esc(p.unknownStops.join(', ')) + '</b></div>' : '');
    return card('Portfolio Risk', body, chip(on ? 'ENFORCED' : 'TRACKING ONLY', on ? 'ok' : ''));
  }
  function governor(d) {
    const g = d.governor, on = d.features.lossGovernor, c = (d.settings || []).reduce((m, s) => (m[s.key] = s.value, m), {});
    if (!g) return card('Loss Governor', ph('UNKNOWN — waiting for equity from the robot'), chip('NO DATA', 'warn'));
    const lv = g.level, tone = lv === 'NORMAL' ? 'ok' : lv === 'CAUTION' ? 'warn' : 'bad';
    const row = (k, v, w, b) => kv(k, '<span class="' + (v >= b ? 'dn' : '') + '">' + f1(v, 2, '%') + '</span>', 'halt ' + b + '%') + '<div class="meter"><i class="' + cls(v, w, b) + '" style="width:' + Math.min(100, v / b * 100) + '%"></i></div>';
    return card('Loss Governor', (on ? '' : off('Daily/weekly loss governor')) +
      row('Daily drawdown (UTC day)', g.daily || 0, c.govCautionPct, c.govHaltPct) + row('Weekly drawdown', g.weekly || 0, c.govWeeklyHaltPct * 0.5, c.govWeeklyHaltPct) + row('From equity peak', g.account || 0, c.govAccountDdPct * 0.5, c.govAccountDdPct) +
      kv('Day start equity', f1(g.dayStart, 2)) + kv('Reasons', esc((g.reasons || []).join('; ') || 'none')) +
      (g.emergency ? '<div class="kv"><span class="dn">EMERGENCY ' + (g.emergency.verified ? '(verified flat)' : g.emergency.acted ? '(flatten sent, verifying)' : '(entries halted)') + '</span><b><button class="act" data-ack="1">Acknowledge</button></b></div>' : ''),
      chip(lv.replace('_', ' ') + (on ? '' : ' · not enforced'), on ? tone : ''));
  }
  function protection(d) {
    const rows = d.protection || [];
    const head = '<tr><th>Symbol</th><th>Side</th><th>Entry</th><th>Mark</th><th>Initial SL</th><th>Stop now</th><th>Stage</th><th>Peak</th><th>Giveback</th><th>To stop</th><th>Liq dist</th><th>uPnL</th><th>Age</th><th>Stop</th></tr>';
    const body = rows.map(r => '<tr><td><b>' + esc(r.symbol.replace('USDT', '')) + '</b></td><td class="' + (r.side === 'LONG' ? 'up' : 'dn') + '">' + r.side + '</td><td>' + r.entry + '</td><td>' + f1(r.mark, 4) + '</td><td>' + f1(r.initialStop, 4) + '</td><td title="' + esc(r.stopReason || '') + '">' + f1(r.stop, 4) + '</td><td>' + (r.stage ? r.stage + '%' : '—') + '</td><td>' + f1(r.peakProgress, 0, '%') + '</td><td>' + f1(r.givebackPct, 0, '%') + '</td><td>' + f1(r.distToStopPct, 2, '%') + '</td><td>' + (r.liqDistPct == null ? '<small>n/a</small>' : r.liqDistPct + '%') + '</td><td class="' + (r.upnl >= 0 ? 'up' : 'dn') + '">' + f1(r.upnl, 2) + '</td><td>' + r.hoursOpen + 'h</td><td>' + (r.protectedStop ? chip('SL SET', 'ok') : chip('NO STOP', 'bad')) + '</td></tr>').join('');
    const anyOn = d.features.smartTrailing || d.features.profitGiveback || d.features.timeExit || d.features.partialExits;
    return card('Live position protection · ' + esc(d.book.toUpperCase()), (anyOn ? '' : off('Smart trailing / giveback / time exits')) +
      (rows.length ? '<div class="scroll"><table>' + head + body + '</table></div><div class="kv"><span><small>Stage/Peak/Giveback use % of distance to take-profit. Peak = best progress reached. Positions are managed on every price tick.</small></span><b></b></div>' : ph('No open positions')),
      chip(rows.length + ' open', rows.length ? 'ok' : ''), true);
  }
  function noTrade(d) {
    const n = d.noTrade, counts = n.counts && n.counts.by ? Object.entries(n.counts.by).sort((a, b) => b[1] - a[1]) : [];
    const chips = counts.map(([k, v]) => chip(k + ' ×' + v)).join(' ');
    const list = (n.recent || []).slice(0, 8).map(r => '<div class="kv"><span>' + esc(r.symbol) + ' ' + esc(r.direction) + ' <small>' + age(r.ts) + ' ago</small></span><b title="' + esc(r.reason) + '">' + esc(String(r.reason).slice(0, 70)) + '</b></div>').join('');
    return card('Why trades were blocked', (counts.length ? '<div style="margin-bottom:6px">' + chips + '</div>' : '') + (list || ph('Nothing blocked recently')), chip('today'));
  }
  function perf(d) {
    const p = d.performance; if (!p || !p.overall || !p.overall.n) return card('Performance intelligence', ph('No closed trades yet — metrics appear after the first trades'), chip('EMPTY'));
    const o = p.overall, row = (k, s) => '<tr><td>' + esc(k) + '</td><td>' + s.n + (s.lowSample ? '*' : '') + '</td><td>' + f1(s.winRate, 0, '%') + '</td><td>' + (s.profitFactor == null ? '∞' : f1(s.profitFactor, 2)) + '</td><td>' + f1(s.expectancy, 3) + '</td></tr>';
    const dirs = Object.entries(p.byDirection).map(([k, s]) => row(k, s)).join(''), strat = Object.entries(p.byStrategy).slice(0, 5).map(([k, s]) => row(k, s)).join('');
    return card('Performance intelligence', kv('Trades', o.n + (o.lowSample ? ' <small>(*low sample &lt; 30)</small>' : '')) + kv('Win rate', f1(o.winRate, 1, '%')) + kv('Profit factor', o.profitFactor == null ? '∞' : f1(o.profitFactor, 2)) + kv('Expectancy / trade', f1(o.expectancy, 3)) + kv('Avg R', o.avgR == null ? '<small>UNKNOWN</small>' : f1(o.avgR, 2)) + kv('Max drawdown', f1(o.maxDrawdown, 2)) + kv('Fees paid', f1(o.fees, 2)) +
      (p.protection && p.protection.n ? kv('Avg giveback from peak', f1(p.protection.avgGivebackPct, 0, '%')) + kv('Stale/time exits', p.protection.staleExits) : '') +
      '<div class="scroll" style="margin-top:6px"><table><tr><th>Group</th><th>n</th><th>Win</th><th>PF</th><th>Exp</th></tr>' + dirs + strat + '</table></div>', chip('journal'));
  }
  let busy = false;
  async function tick() {
    if (busy) return; busy = true;
    try { const d = await (await fetch('/api/v46/overview')).json(); root.innerHTML = market(d) + portfolio(d) + governor(d) + noTrade(d) + perf(d) + protection(d); }
    catch (e) { root.innerHTML = card('Mission control', ph('Unavailable: ' + esc(e.message)), chip('ERROR', 'bad'), true); }
    busy = false;
  }
  root.addEventListener('click', async (e) => { if (e.target.dataset && e.target.dataset.ack) { if (!confirm('Acknowledge the emergency? Entries stay halted until drawdown rules clear.')) return; const r = await fetch('/api/v46/governor/ack', { method: 'POST' }); const j = await r.json(); alert(j.message); tick(); } });
  tick(); setInterval(tick, 4000);
})();
