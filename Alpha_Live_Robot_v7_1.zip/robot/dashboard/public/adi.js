/* ALPHA LIVE ROBOT v7.1 - ADAPTIVE DIRECTIONAL INTELLIGENCE card (Adaptive tab). Presentation only: all data from /api/adi/status. */
(function () {
  'use strict';
  const host = document.getElementById('tab-adaptive'); if (!host) return;
  const root = document.createElement('div'); root.id = 'adiRoot'; host.insertBefore(root, host.firstChild);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const H = { 'Content-Type': 'application/json', 'X-Alpha': '1' };
  const MODE_LABEL = { ADAPTIVE: 'ADAPTIVE', AUTO: 'AUTO', BOTH: 'BOTH', LONG_ONLY: 'LONG ONLY', SHORT_ONLY: 'SHORT ONLY', PAUSE: 'PAUSE NEW' };
  const css = document.createElement('style'); css.textContent =
    '#adiRoot .c{background:var(--card-bg,#10151B);border:1px solid var(--border,#29333D);border-radius:12px;padding:14px 16px;margin-bottom:14px}' +
    '#adiRoot h3{margin:0 0 4px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--text-muted,#A0ADB8)}#adiRoot .sub{font-size:12px;color:var(--text-dim,#71808B);margin:0 0 10px}' +
    '#adiRoot .r{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:8px 0}#adiRoot .seg button{padding:7px 12px;border:1px solid var(--border,#29333D);background:transparent;color:var(--text-muted,#A0ADB8);cursor:pointer;font-weight:700;font-size:12px}' +
    '#adiRoot .seg button:first-child{border-radius:8px 0 0 8px}#adiRoot .seg button:last-child{border-radius:0 8px 8px 0}#adiRoot .seg button.on{background:var(--accent,#42CDBE);color:#07110f;border-color:var(--accent,#42CDBE)}' +
    '#adiRoot .b{padding:7px 14px;border-radius:8px;border:1px solid var(--border,#29333D);background:var(--card-alt,#151C23);color:var(--text,#F1F5F7);cursor:pointer;font-weight:700;font-size:12px}#adiRoot .b.go{background:var(--accent,#42CDBE);color:#07110f;border-color:var(--accent,#42CDBE)}' +
    '#adiRoot .m{padding:9px 12px;border-radius:8px;font-size:13px;margin:8px 0}#adiRoot .m.warn{background:rgba(233,184,106,.12);color:#E9B86A}#adiRoot .m.ok{background:rgba(69,212,154,.12);color:#45D49A}#adiRoot .m.bad{background:rgba(228,124,130,.12);color:#E47C82}' +
    '#adiRoot .g{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}#adiRoot .k{font-size:11px;color:var(--text-dim,#71808B);text-transform:uppercase;letter-spacing:.06em}#adiRoot .v{font-size:15px;font-weight:700}' +
    '#adiRoot table{width:100%;border-collapse:collapse;font-size:12.5px}#adiRoot th,#adiRoot td{padding:6px 8px;text-align:left;border-bottom:1px solid var(--border,#29333D);vertical-align:top}#adiRoot th{font-size:11px;color:var(--text-dim,#71808B);text-transform:uppercase}' +
    '#adiRoot .tag{display:inline-block;padding:1px 7px;border-radius:99px;font-size:10.5px;font-weight:700;border:1px solid var(--border,#29333D);color:var(--text-muted,#A0ADB8)}#adiRoot .tag.live{color:#45D49A;border-color:#45D49A}#adiRoot .tag.rst{color:#E9B86A;border-color:#E9B86A}' +
    '#adiRoot details{margin-top:8px}#adiRoot summary{cursor:pointer;font-weight:700;font-size:12.5px;color:var(--accent-2,#A9E8DF)}#adiRoot input[type=number],#adiRoot select{background:#0A0C10;border:1px solid var(--border,#29333D);color:var(--text,#F1F5F7);border-radius:6px;padding:4px 6px;font-size:12px}';
  document.head.appendChild(css);
  let S = null, msg = null, err = null;
  const call = async (url, body) => { const r = await fetch(url, { method: 'POST', headers: H, body: JSON.stringify(body || {}) }); const d = await r.json().catch(() => ({})); if (!r.ok || d.ok === false) throw new Error(d.error || 'HTTP ' + r.status); return d; };
  const act = async (url, body) => { try { const d = await call(url, body); S = d; msg = { t: 'ok', m: d.message || 'Saved' }; } catch (e) { msg = { t: 'bad', m: e.message }; } render(); setTimeout(() => { msg = null; render(); }, 7000); };

  function render() {
    if (!S) { root.innerHTML = '<div class="c"><h3>Adaptive Directional Intelligence</h3><div class="sub">' + (err ? esc(err) : 'loading…') + '</div></div>'; return; }
    const st = S.status, rec = st.recommendation, d = S.direction, cfg = S.config, byKey = {}; cfg.settings.forEach(s => { byKey[s.key] = s; });
    const modeBtns = S.modes.map(m => '<button class="' + (d.mode === m ? 'on' : '') + '" data-mode="' + m + '">' + MODE_LABEL[m] + '</button>').join('');
    const eff = '<b>' + esc((d.effective || 'BOTH').replace('_', ' ')) + '</b> <span style="color:var(--text-dim,#71808B)">- ' + esc(d.via || '') + '</span>';
    let recHtml = '<div class="m warn">No recommendation yet. ' + (st.enabled ? 'It appears after the first refresh.' : 'ADI is OFF.') + '</div>';
    if (rec) {
      const L = rec.long, Sh = rec.short;
      recHtml = '<div class="g"><div><div class="k">Recommendation</div><div class="v">' + esc(rec.direction.replace('_', ' ')) + '</div></div><div><div class="k">Confidence</div><div class="v">' + rec.confidence + ' / 100</div></div>' +
        '<div><div class="k">LONG score</div><div class="v">' + (L.score == null ? '–' : L.score) + '</div><div class="sub">' + L.trades.effective + ' counted trades · ' + esc(L.basis) + '</div></div>' +
        '<div><div class="k">SHORT score</div><div class="v">' + (Sh.score == null ? '–' : Sh.score) + '</div><div class="sub">' + Sh.trades.effective + ' counted trades · ' + esc(Sh.basis) + '</div></div>' +
        '<div><div class="k">Order bias</div><div class="v">L ' + (rec.bias.LONG > 0 ? '+' : '') + rec.bias.LONG + ' / S ' + (rec.bias.SHORT > 0 ? '+' : '') + rec.bias.SHORT + '</div></div></div>' +
        '<ul style="margin:8px 0 0 18px;font-size:12.5px;line-height:1.5">' + rec.reasons.map(r => '<li>' + esc(r) + '</li>').join('') + '</ul>' +
        '<div class="sub" style="margin-top:6px">Computed ' + new Date(rec.ts).toLocaleTimeString() + (rec.inactive ? ' (ADI inactive - stale)' : '') + '</div>';
    }
    const a = st.approval;
    let approve = '';
    if (st.pendingApproval) approve = '<div class="m warn">ADI recommends <b>' + esc(rec.direction.replace('_', ' ')) + '</b> but it is <b>not applied</b>: ' + esc(st.authority.why) + '. Open positions are never touched.</div>';
    else if (rec && rec.direction !== 'BOTH' && st.authority.applies) approve = '<div class="m ok">Recommendation can apply to NEW entries (' + esc(st.authority.why) + ') while the mode is AUTO.</div>';
    const appBtns = (a && a.valid ? '<span class="tag live">approved ' + esc(a.direction.replace('_', ' ')) + '</span> <button class="b" data-act="revoke">Withdraw approval</button>' : (rec && rec.direction !== 'BOTH' ? '<button class="b go" data-act="approve">Approve ' + esc(rec.direction.replace('_', ' ')) + '</button>' : ''));
    const hist = st.history.length ? '<table><tr><th>When</th><th>Recommended</th><th>Conf.</th><th>L / S score</th><th>Trades L/S</th></tr>' + st.history.slice(0, 10).map(h => '<tr><td>' + new Date(h.ts).toLocaleString() + '</td><td>' + esc(h.direction.replace('_', ' ')) + '</td><td>' + h.confidence + '</td><td>' + (h.longScore == null ? '–' : h.longScore) + ' / ' + (h.shortScore == null ? '–' : h.shortScore) + '</td><td>' + h.trades.long + ' / ' + h.trades.short + '</td></tr>').join('') + '</table>' : '<div class="sub">No history yet.</div>';
    const groups = {}; cfg.settings.forEach(s => { (groups[s.group] = groups[s.group] || []).push(s); });
    const ctl = (s) => {
      if (!s.runtimeEditable) return '<span class="tag rst">' + (s.locked ? 'locked' : 'restart · .env') + '</span>';
      const c = s.choices ? '<select data-set="' + s.key + '">' + s.choices.map(o => '<option ' + (o === s.value ? 'selected' : '') + '>' + o + '</option>').join('') + '</select>'
        : s.type === 'bool' ? '<input type="checkbox" data-set="' + s.key + '" ' + (s.value ? 'checked' : '') + '>' : '<input type="number" data-set="' + s.key + '" value="' + esc(s.value) + '" min="' + s.min + '" max="' + s.max + '" style="width:80px">';
      return c + ' <span class="tag live">live</span>';
    };
    const cfgHtml = Object.entries(groups).map(([g, list]) => '<details><summary>' + esc(g) + '</summary><table>' + list.map(s => '<tr><td><code>' + esc(s.key) + '</code><div class="sub" style="margin:2px 0 0">' + esc(s.desc) + '</div></td><td>' + (s.type === 'bool' && !s.runtimeEditable ? (s.value ? 'true' : 'false') : (s.runtimeEditable ? '' : esc(s.value))) + ' ' + ctl(s) + '</td><td><span class="tag">' + esc(s.source) + '</span></td></tr>').join('') + '</table></details>').join('');
    root.innerHTML = '<div class="c"><h3>Adaptive Directional Intelligence <span class="tag ' + (st.enabled ? 'live' : '') + '">' + (st.enabled ? 'ON' : 'OFF') + '</span> <span class="tag">' + esc(st.runMode) + '</span></h3>' +
      '<div class="sub">Direction rules govern NEW entries only. Open positions, their stops and take-profits are never closed, reversed or edited by a direction change. Manual Take can override the mode (with a confirmation).</div>' +
      '<div class="r"><label><input type="checkbox" data-set="ADI_ENABLED" ' + (st.enabled ? 'checked' : '') + '> ADI enabled</label><span class="seg">' + modeBtns + '</span></div>' +
      '<div class="r">Effective now: ' + eff + '</div>' +
      '<div class="r">Allow: <label><input type="checkbox" data-set="ALLOW_LONG_TRADES" ' + (byKey.ALLOW_LONG_TRADES.value ? 'checked' : '') + '> LONG</label> <label><input type="checkbox" data-set="ALLOW_SHORT_TRADES" ' + (byKey.ALLOW_SHORT_TRADES.value ? 'checked' : '') + '> SHORT</label></div>' +
      (msg ? '<div class="m ' + msg.t + '">' + esc(msg.m) + '</div>' : '') + (cfg.errors.length ? '<div class="m bad">' + cfg.errors.map(esc).join('<br>') + '</div>' : '') + (cfg.warnings.length ? '<div class="m warn">' + cfg.warnings.map(esc).join('<br>') + '</div>' : '') + '</div>' +
      '<div class="c"><h3>Recommendation</h3>' + recHtml + approve + '<div class="r">' + appBtns + ' <button class="b" data-act="refresh">Refresh now</button></div><details><summary>Recommendation history</summary>' + hist + '</details></div>' +
      '<div class="c"><h3>ADI settings</h3><div class="sub">' + esc(cfg.howTo) + ' "live" = saved from here, applied at once, kept across restarts. "restart · .env" = edit .env then restart.</div>' + cfgHtml + '<div class="r"><button class="b" data-act="reset">Clear dashboard overrides (back to .env)</button></div></div>';
  }
  root.addEventListener('click', (e) => {
    const t = e.target.closest('[data-mode],[data-act]'); if (!t) return;
    if (t.dataset.mode) { fetch('/api/v46/direction', { method: 'POST', headers: H, body: JSON.stringify({ mode: t.dataset.mode, hours: null }) }).then(r => r.json()).then(d => { if (d.ok === false) throw new Error(d.error); msg = { t: 'ok', m: 'Direction mode set to ' + t.dataset.mode + ' for NEW entries only.' }; poll(); }).catch(er => { msg = { t: 'bad', m: er.message }; render(); }); return; }
    const a = t.dataset.act;
    if (a === 'refresh') act('/api/adi/refresh'); else if (a === 'approve') act('/api/adi/approve'); else if (a === 'revoke') act('/api/adi/revoke');
    else if (a === 'reset' && window.confirm('Clear all dashboard overrides for ADI settings and go back to the .env values?')) act('/api/adi/config/reset');
  });
  root.addEventListener('change', (e) => {
    const t = e.target; if (!t.dataset || !t.dataset.set) return;
    const v = t.type === 'checkbox' ? t.checked : t.value; act('/api/adi/config', { settings: { [t.dataset.set]: v } });
  });
  async function poll() { try { S = await (await fetch('/api/adi/status')).json(); err = null; } catch (e) { err = e.message; } if (!root.querySelector('input:focus,select:focus')) render(); }
  poll(); setInterval(poll, 8000);
})();
