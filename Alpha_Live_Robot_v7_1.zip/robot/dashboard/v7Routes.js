'use strict';
/** v7.0 routes: Paper Lab (LIVE-mode separate paper account) and the per-position chart. Read-only apart from the Paper Lab on/off switch. */
const config = require('../src/config');
const journal = require('../src/journal/store');
const lab = require('../src/intelligence/paperLab');
const dataFeed = require('../src/market/dataFeed');
const TFS = ['5m', '15m', '1h'];

function create({ sendJson, parseBody }) {
  const guard = (req, res) => {
    if (req.headers['x-alpha'] !== '1') { sendJson(res, 403, { ok: false, error: 'Missing X-Alpha header (request must come from the dashboard).' }); return false; }
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) { sendJson(res, 403, { ok: false, error: 'Cross-site request refused.' }); return false; } } catch (_) { sendJson(res, 403, { ok: false, error: 'Bad origin.' }); return false; } }
    return true;
  };
  const num = (v) => (v == null || v === '' || !Number.isFinite(Number(v)) ? null : Number(v));
  async function chart(url) {
    const symbol = String(url.searchParams.get('symbol') || '').toUpperCase(), tf = TFS.includes(url.searchParams.get('tf')) ? url.searchParams.get('tf') : '15m';
    const mode = url.searchParams.get('mode') === 'live' ? 'live' : 'paper';
    if (!/^[A-Z0-9]{3,20}$/.test(symbol)) return { code: 400, body: { ok: false, error: 'bad symbol' } };
    const rows = (mode === 'live' ? journal.getState('protection_view') : journal.getState('protection_view_paper')) || [];
    const id = url.searchParams.get('id'), row = rows.find(r => (id && r.id === id) || (!id && r.symbol === symbol)) || rows.find(r => r.symbol === symbol);
    if (!row) return { code: 404, body: { ok: false, error: `No open ${mode} position found for ${symbol} (it may just have closed).` } };
    const raw = await dataFeed.getCandles(symbol, tf, 120);
    const candles = raw.map(c => ({ t: Number(c.time ?? c.timestamp ?? c.openTime ?? c.t ?? (Array.isArray(c) ? c[0] : 0)), o: Number(c.open ?? c.o), h: Number(c.high ?? c.h), l: Number(c.low ?? c.l), c: Number(c.close ?? c.c) })).filter(c => c.t && isFinite(c.c));
    const stop = num(row.stop), initial = num(row.initialStop), entry = num(row.entry), long = String(row.side || row.direction).toUpperCase() === 'LONG';
    const moved = stop != null && initial != null && Math.abs(stop - initial) > Math.abs(entry || 1) * 1e-6;
    const trailingOn = moved && (long ? stop > initial : stop < initial);
    return { code: 200, body: { ok: true, symbol, tf, mode, side: long ? 'LONG' : 'SHORT', candles, openTime: row.openTime || null,
      levels: { entry, stop, initialStop: initial, tp: num(row.tp), mark: num(row.mark), liq: num(row.liq ?? row.liquidationPrice), trailing: trailingOn ? stop : null, trailingLabel: trailingOn ? (/BREAKEVEN/i.test(row.stopReason || '') ? 'Break-even stop' : 'Trailing / moved stop') : null },
      stopMoves: (row.moves || row.stopMoves || []).map(m => ({ t: num(m.ts ?? m.t ?? m.time), to: num(m.to ?? m.stop ?? m.price), why: m.reason || m.why || null })).filter(m => m.to != null),
      upnl: num(row.upnl), progress: num(row.progress), ts: Date.now() } };
  }
  async function handle(req, res, pathname, method) {
    if (!pathname.startsWith('/api/lab/') && !pathname.startsWith('/api/v7/')) return false;
    const url = new URL(req.url, 'http://x');
    try {
      if (method === 'GET' && pathname === '/api/lab/status') { sendJson(res, 200, lab.status({ tzOffsetMin: Number(url.searchParams.get('tz')) || 0 })); return true; }
      if (method === 'POST' && pathname === '/api/lab/config') {
        if (!guard(req, res)) return true;
        const b = await parseBody(req); lab.setEnabled(b && b.enabled);
        sendJson(res, 200, { ok: true, enabled: lab.enabled(), message: lab.enabled() ? 'Paper Lab ON — new scanned setups will run on the paper account.' : 'Paper Lab OFF — no new paper trades; open ones keep being managed.' }); return true;
      }
      if (method === 'GET' && pathname === '/api/v7/position-chart') { const r = await chart(url); sendJson(res, r.code, r.body); return true; }
      return false;
    } catch (e) { sendJson(res, /must be/.test(e.message) ? 400 : 500, { ok: false, error: e.message }); return true; }
  }
  return { handle };
}
module.exports = { create };
