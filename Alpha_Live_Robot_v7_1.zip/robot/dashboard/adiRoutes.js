'use strict';
/** v7.1 ADI routes (Adaptive Directional Intelligence). Read: status + effective config (ADI keys only, never secrets).
 *  Write: whitelisted runtime settings, refresh, approve/revoke. Safety settings (live approval, DIRECTION_CHANGE_*) are .env-only. */
const config = require('../src/config');
const adi = require('../src/intelligence/adi');
const adiConfig = require('../src/control/adiConfig');
const direction = require('../src/control/direction');

function create({ sendJson, parseBody }) {
  const guard = (req, res) => {
    if (req.headers['x-alpha'] !== '1') { sendJson(res, 403, { ok: false, error: 'Missing X-Alpha header (request must come from the dashboard).' }); return false; }
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) { sendJson(res, 403, { ok: false, error: 'Cross-site request refused.' }); return false; } } catch (_) { sendJson(res, 403, { ok: false, error: 'Bad origin.' }); return false; } }
    return true;
  };
  const snapshot = () => ({ ok: true, status: adi.status(!!config.isLive), config: adiConfig.describe(), direction: { ...direction.get(), ...direction.effective() }, modes: direction.MODES });
  async function handle(req, res, pathname, method) {
    if (!pathname.startsWith('/api/adi/')) return false;
    try {
      if (method === 'GET' && pathname === '/api/adi/status') { sendJson(res, 200, snapshot()); return true; }
      if (method === 'POST') {
        if (!guard(req, res)) return true;
        const body = (await parseBody(req)) || {};
        if (pathname === '/api/adi/config') {
          const changed = adiConfig.setRuntime(body.settings || body);
          sendJson(res, 200, { ...snapshot(), message: `Saved ${changed.join(', ')}. Applies immediately and survives restarts.` }); return true;
        }
        if (pathname === '/api/adi/config/reset') { adiConfig.resetRuntime(Array.isArray(body.keys) ? body.keys : null); sendJson(res, 200, { ...snapshot(), message: 'Dashboard overrides cleared - back to .env values.' }); return true; }
        if (pathname === '/api/adi/refresh') { adi.recommendation({ force: true }); sendJson(res, 200, { ...snapshot(), message: 'Recommendation recomputed.' }); return true; }
        if (pathname === '/api/adi/approve') { adi.approve({ by: 'dashboard' }); sendJson(res, 200, { ...snapshot(), message: 'Approved. ADI may apply this recommendation to NEW entries until it changes (max 24h). Open positions are never touched.' }); return true; }
        if (pathname === '/api/adi/revoke') { adi.revoke(); sendJson(res, 200, { ...snapshot(), message: 'Approval withdrawn.' }); return true; }
      }
      return false;
    } catch (e) { sendJson(res, /cannot be changed|not an ADI|must|out of range|conflict|off/i.test(e.message) ? 400 : 500, { ok: false, error: e.message }); return true; }
  }
  return { handle };
}
module.exports = { create };
