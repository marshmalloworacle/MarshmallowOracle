'use strict';
/** v6.8 Adaptive Winning Strategy Engine routes. Reads straight from the shared DB; writes only the saved setting (validated).
 *  The robot applies it on its next 3 s tick; `applied.confirmed` turns true ONLY when the running robot reports the same mode. */
const adaptive = require('../src/intelligence/adaptive');

function create({ sendJson, parseBody }) {
  const guard = (req, res) => {
    if (req.headers['x-alpha'] !== '1') { sendJson(res, 403, { ok: false, error: 'Missing X-Alpha header (request must come from the dashboard).' }); return false; }
    const origin = req.headers.origin;
    if (origin) { try { if (new URL(origin).host !== req.headers.host) { sendJson(res, 403, { ok: false, error: 'Cross-site request refused.' }); return false; } } catch (_) { sendJson(res, 403, { ok: false, error: 'Bad origin.' }); return false; } }
    return true;
  };
  async function handle(req, res, pathname, method) {
    if (!pathname.startsWith('/api/adaptive/')) return false;
    try {
      if (method === 'GET' && pathname === '/api/adaptive/status') { sendJson(res, 200, adaptive.status()); return true; }
      if (method === 'POST' && pathname === '/api/adaptive/config') {
        if (!guard(req, res)) return true;
        const body = await parseBody(req);
        adaptive.setCfg(body || {});
        const s = adaptive.status();
        sendJson(res, 200, { ok: true, saved: true, cfg: s.cfg, applied: s.applied,
          message: s.applied.confirmed ? 'Saved and confirmed by the running robot.' : 'Saved. Waiting for the robot to confirm — it is not applied until the robot reports the same mode.' });
        return true;
      }
      return false;
    } catch (e) { sendJson(res, e && /must|one of|at least/.test(e.message) ? 400 : 500, { ok: false, saved: false, error: e.message }); return true; }
  }
  return { handle };
}
module.exports = { create };
