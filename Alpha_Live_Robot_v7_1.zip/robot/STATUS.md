# v5.2.1 patch: see CHANGELOG_v5_2_1.md (Bitget setTradingStop + stop read-back + npm run bitget:stops + npm run paper)

# v5.2 (exchange-neutral, Exchange tab, GO LIVE, Bitget UTA, early trailing) — latest
- See CHANGELOG_v5_2.md. Testnet removed; modes SIM/LIVE. Unverified against live Bitget/MEXC servers: run `npm run bitget:verify`.

# v5.1 (dashboard redesign + limits + Bitget)
- Bitget adapter + public WebSocket for bybit/bitget/mexc (EXCHANGE=bybit|bitget|mexc). Run `npm run bitget:verify` before use; Bitget/MEXC streams are unverified against live servers.
- Obsidian Graphite x Sea-Glass Teal theme (`dashboard/public/obsidian.css`, `obsidian.js`), sidebar shell, Modules page, slots/sizing strip. See CHANGELOG_v5_1.md.
- Defaults: ACCOUNT_BALANCE=100, MAX_OPEN_POSITIONS_PAPER=50, MAX_OPEN_POSITIONS_LIVE=12, MAX_NEW_PER_SCAN 20 paper / 10 live, SCANNER_DISPLAY_LIMIT=0 (unlimited lists), GOV_EMERGENCY_ACTION=HALT.
- Page widgets: scanner chips, position cards, strategy panel (obsidian-pages.js). 328 offline tests pass. Not built: BTC/ETH/SOL quote strip with sparklines (no price endpoint verified), per-page redesign of the Account (live) view beyond the colour/shell layer.

## v5.0 — DONE: switchable protection, per-tick stops, partials, stale exits, portfolio risk, governor, intel, journal extras, cards. See CHANGELOG_v5_0.md.
User decisions: stale/flat trades exit after 6-12h (default 8h, setting), 24h max hold only if in profit; real ATR on signals; protection every tick; emergency default HALT; theme Graphite+Neon Teal; every position individually closable.
NEXT (recommended): 1 week TESTNET with features switched on one at a time; join live extras to live_trades; slippage/funding in net estimate.

## v4.6 (this chat) — switchable protection + control strip
Done: feature flags, direction control (backend-enforced), protection maths + live applier, paper smart trailing, teal control strip, optimistic close. See CHANGELOG_v4_6.md (includes honest NOT-DONE list). User decisions: apply to testnet+live; safe features ON, risk-changing OFF; 24h exit = close only if in profit else tighten stop; every position individually closable (paper+live) with instant UI; theme Graphite + Neon Teal.
NEXT: partial exits, correlation/aggregate-risk + loss governor, sentiment/regime panel, protection columns in positions table, journal fields.

## v4.5 changes (testnet default + graphite/violet UI)
- TRADING_MODE=TESTNET is now the default: the real live order path against Bybit testnet (fake money). LIVE = mainnet (still triple-gated). SIM = offline simulator for tests only. Old PAPER maps to SIM; update your .env.
- Testnet Lab tab: one-click real testnet orders (limit entry/cancel, market buy with SL/TP, move stop, trailing, partial close, close) and a full self-test.
- HTTP 403/451 from Bybit now fails fast with a visible 'server blocked' banner instead of retry floods. BYBIT_BASE_URL override added (testnet hosts only in TESTNET mode).
- Dashboard restyled Graphite + Soft Violet (Manrope / DM Mono), focus states, reduced-motion support.

# STATUS.md — GPS Crypto Robot (resume file)
> New chat? Upload the latest zip + this file and say "continue from STATUS.md". Do NOT re-read the old chat. Update this file after every stage.

**Version:** v4.4 (live MEXC/Bybit build; see LIVE_MEXC.md + CHANGELOG_v4_4.md) — previously 1.3.1 (v4.3.1 DB-init hotfix) · Node >=20 (tested 22), zero npm deps, SQLite via `node:sqlite` · Codespaces: `npm run start:all`, forward port 3000 · PAPER mode (live is triple-gated)
**Tests:** `npm test` (all must pass; 192+ at last run) · Offline demo: `EXCHANGE=sim npm run start:all` · `npm run validate:quick`

## User decisions (final)
Paper balance $100 default, any amount allowed (50/300/1500…), reset anytime · only setups score >= 85 trade (FILL off) · leverage 10x · NO cap on open positions / total risk / daily loss / consecutive losses (all = 0 → unlimited) · risk/trade 1.5% minimum (can be higher) · black & teal theme · must work in Codespaces · save tokens.

## Stage checklist
- [x] v4.2: blank scanner/journal/opportunities fixed; 10+ positions; ALL strategies; SL/TP on qualified; close-orphan fix; theme
- [x] S1 Account: unlimited caps, equity sizing, depleted guard, `RESET_ACCOUNT` cmd + `/api/account/reset`, `/api/dashboard/account`, Risk-tab account card
- [x] S2 Liquidation awareness: `liquidationPrice()`, SL must be inside 80% of liq distance (`LIQ_SAFETY`), Liq Price column
- [x] S3 Exchange layer: `src/exchanges/index.js` facade (EXCHANGE=bybit|sim), `sim.js` deterministic offline exchange, base.js contract extended (getOrderBook/getFundingHistory/getOpenInterestHistory)
- [x] S4 WebSocket: `src/exchanges/ws/{miniws,managed,bybitStream}.js` (zero-dep RFC6455 client, reconnect/heartbeat/stale watchdog, public tickers+kline+orderbook, private auth stream), `src/market/liveFeed.js`, REST fallback, event-driven SL/TP on ticks. Client cross-checked against the `ws` lib (frames up to 64-bit, ping/pong, reconnect+resubscribe) — NOT tested against real Bybit (sandbox has no access).
- [x] S5 `dataFeed` candle cache (full fetch once, then tail refresh) + WS kline overlay; meta cache 5 min
- [x] S6 Microstructure `src/market/microstructure.js`: spread, depth, slippage walk, imbalance, funding momentum, OI momentum; vetoes (spread/slippage/thin book; funding veto optional)
- [x] S7 Validation: `src/validation/{metrics,validator,evidence,liveStats}.js`, `npm run validate[:quick]`, writes data/validation/latest.json + reports/VALIDATION_REPORT.md; walk-forward windows, regime-selection OOS test, score sweep, Monte Carlo, `EVIDENCE_GATING` (off by default)
- [x] S8 Dashboard: Data Feed tab, Strategy Lab tab, account card, feed pill, Liq column, blocked badges
- [x] S9 UI alignment fixed; e2e run on sim exchange OK (scan→open→liq price→feed→reset)
- [x] S10 205 tests pass; CHANGELOG_v4_3.md; zip delivered as Trading_Robot_Master_Pro_v4_3.zip
- [x] S10b v4.3.1 hotfix: `no such table: paper_trades` = failed init (e.g. 'database is locked' while robot+dashboard start together) was CACHED as a schema-less handle. Fixed in `src/journal/store.js` (cache only after verified init, busy-retry, WAL->DELETE fallback, corrupt file quarantined), `start-all.js` inits DB once first, `.env` loader strips inline comments + reads repo-root .env, new `npm run db:check | db:reset -- --yes | setup`, `.devcontainer/`, tests/db_init.test.js (211 pass)
- [ ] S11 (**NEXT, user in Codespaces**) 1) update .env from .env.example 2) `npm run start:all`, check Data Feed tab shows WS LIVE 3) run `npm run validate -- --years=2 --top=15` in Codespaces on REAL Bybit data, then decide `EVIDENCE_GATING`
- [ ] Deferred: 2nd real exchange (Binance/OKX), kill-switch persistence, sentiment layer

## v4.4 live build (latest chat)
User decisions: build all 3 layers (shared small-account layer, MEXC adapter, Bybit live adapter) · has a live Bybit account · LIVE daily loss stop 5% (paper unlimited) · slots grow with equity (2 under $30) · leverage 10x start, scale 5x–20x by tier/drawdown · theme black+gold+crimson-pink.
**Key finding:** MEXC futures API order placement is account-dependent (`apiAllowed`); bypass/session-token libraries were NOT used. Use `npm run mexc:verify` first; Bybit is the fallback.
- [x] `src/risk/scaling.js`, RiskEngine live profile + daily stop · [x] `src/exchanges/mexc.js` · [x] Bybit signed endpoints · [x] `src/execution/orderManager.js` · [x] live.js stub removed · [x] robot `_liveCycle/_openLive` · [x] dashboard theme + Live Account tab + `/api/live/*` · [x] `mexc:verify` / `bybit:verify` · [x] LIVE_MEXC.md · 252 tests pass (offline mocks only)
- [ ] **NEXT (user, in Codespaces):** copy .env.example → .env, run `npm run bybit:verify` and/or `npm run mexc:verify`, paste the output; then Bybit TESTNET rehearsal (BYBIT_TESTNET=true, LIVE mode) per LIVE_MEXC.md
- [x] v4.4b: slots 4/5/6/7/8/10/12 (risk = min(1.5%, 6%/slots)), min-size override (≤3% equity risk), glass black+crimson-pink+gold theme, live_stats from exchange closed PnL, MEXC wrong-host guard + 401/1005 diagnostics. 284 tests.
- [ ] (v4.4d: ALPHA LIVE ROBOT, 284 tests) MEXC private auth still FAILING for user (1005 on contract.mexc.com; 401 on api.mexc.com = spot host). Awaiting user's key-permission checks (see LIVE_MEXC.md). Bybit not yet verified.
- [ ] Not built yet: MEXC futures WebSocket (REST polling now) · journal real live trades/fees · funding-fee accounting · persist `live` PnL in analytics tabs · visual check of the new theme in a real browser (not done in sandbox)

## Where things live
robot loop `src/robot.js` (analyse all → rank → micro check → open → persist; `_onLiveTicker`) · paper `src/paper/engine.js` · risk `src/risk/engine.js` · router `src/strategy/router.js` · feed `src/market/{dataFeed,liveFeed,microstructure}.js` · server `dashboard/server.js` · UI `dashboard/public/index.html` (v4.2/4.2.1 JS blocks at the end of the script)

## Key env
`RISK_PER_TRADE=0.015 MAX_OPEN_POSITIONS=0 MAX_PORTFOLIO_EXPOSURE=0 MAX_DAILY_LOSS=0 MIN_SCORE=85 FILL_TO_TARGET=false EXCHANGE=bybit WS_ENABLED=true MICRO_CHECKS=true MAX_SPREAD_BPS=15 MAX_SLIP_BPS=30 MIN_DEPTH_MULTIPLE=3 FUNDING_VETO=false EVIDENCE_GATING=false ENFORCE_FREE_MARGIN=false LIQ_SAFETY=0.8 SIZE_ON_EQUITY=true MAX_NEW_PER_SCAN=10`

## Caveats to tell the user
Sim/validation numbers on synthetic data prove nothing about real edge · paper allows margin > equity (real exchange would reject; set ENFORCE_FREE_MARGIN=true before going live) · old `.env` values override new defaults
