# v6.5 (includes 6.0 - 6.3.1)
- Live trading is authorised ONLY from .env. Three lines: TRADING_MODE=LIVE, LIVE_TRADING_ENABLED=true, LIVE_AUTHORIZE=true. The robot authorises itself at every start. Take Live Trades (the button) is separate and still starts OFF.
- Removed: Authorise live trading box, Revoke live auth button, GO LIVE and Back to paper buttons, and their API routes (they now answer "Removed in v6.5").
- Dashboard shows the exact reason when not authorised (e.g. "LIVE_AUTHORIZE is not true in .env"), in the Authorisation tile, the Account view and the startup log.
- Kept: Pause/Resume, Start, Take Live Trades, Stop live, Flatten, Kill switch, Emergency Stop, exchange selector and API key entry.
