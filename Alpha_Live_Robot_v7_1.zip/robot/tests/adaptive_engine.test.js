'use strict';
process.env.TRADING_MODE = 'SIM';
process.env.ROBOT_SKIP_DOTENV = '1';
process.env.ROBOT_DATA_DIR = require('fs').mkdtempSync(require('path').join(require('os').tmpdir(), 'adp-'));
delete process.env.ADAPTIVE_STRATEGY_ENABLED;
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const journal = require('../src/journal/store');
let adaptive = require('../src/intelligence/adaptive');

let seq = 0, clock = Date.now() - 90 * 24 * 3600 * 1000;
const dbx = () => journal.getDb();
function clean() {
  adaptive.recentEvents(); // creates the adaptive tables on first use
  dbx().exec("DELETE FROM paper_trades; DELETE FROM live_trades; DELETE FROM adaptive_decisions; DELETE FROM adaptive_events; DELETE FROM adaptive_snapshots; DELETE FROM robot_state WHERE key LIKE 'adaptive_%'");
  adaptive._reset(); clock = Date.now() - 90 * 24 * 3600 * 1000;
}
function add(o) {
  const t = o.t || (clock += 60000);
  const row = { id: o.id || `t${++seq}`, strategyId: o.s, strategyName: o.name || o.s, strategyVersion: '1', symbol: o.sym || 'BTCUSDT', direction: o.dir || 'LONG', entry: 100, stopLoss: 99, takeProfit: 102, positionSize: 1,
    pnl: o.open ? null : o.pnl, fee: 0.1, outcome: o.open ? null : (o.pnl > 0 ? 'WIN' : 'LOSS'), score: 80, riskReward: 2, regime: o.regime === undefined ? 'STRONG_TREND' : o.regime, openTime: t - 30000, closeTime: o.open ? null : t };
  if (o.live) { journal.saveLiveTrade(row); } else journal.savePaperTrade(row);
  return row.id;
}
const many = (s, pnls, extra = {}) => pnls.forEach(p => add({ s, pnl: p, ...extra }));
const rep = (arr, n) => Array.from({ length: n }, (_, i) => arr[i % arr.length]);
const sig = (strategyId, score, o = {}) => ({ strategyId, strategyName: strategyId, symbol: o.symbol || 'S' + (++seq), direction: o.direction || 'LONG', score, tier: o.tier || 'QUALIFIED', regime: { canonicalRegime: o.regime || 'STRONG_TREND' } });
const names = (q) => q.map(s => s.strategyId);

test('1-4 historical PnL, win rate, profit factor, expectancy, drawdown, streaks are exact', () => {
  const s = adaptive.stats([10, -5, 10, -5, -5, 20].map(pnl => ({ pnl })));
  assert.equal(s.n, 6); assert.equal(s.netPnl, 25); assert.equal(s.winRate, 0.5); assert.ok(Math.abs(s.profitFactor - 40 / 15) < 1e-9);
  assert.ok(Math.abs(s.expectancy - 25 / 6) < 1e-9); assert.equal(s.avgWin, 40 / 3); assert.equal(s.avgLoss, 5); assert.equal(s.maxDrawdown, 10);
  assert.equal(s.maxWinStreak, 1); assert.equal(s.maxLossStreak, 2); assert.ok(Math.abs(s.payoff - (40 / 3) / 5) < 1e-9);
});

test('realized only: open trades, duplicate ids and unknown strategies are never counted', () => {
  clean();
  many('gps_v1', [5, 5, -3]); add({ s: 'gps_v1', open: true }); add({ s: 'gps_v1', id: 'dup', pnl: 7 }); add({ s: 'gps_v1', id: 'dup', pnl: 7 }); add({ s: null, pnl: 9 });
  const tr = adaptive.loadTrades('all');
  assert.equal(tr.length, 4); assert.equal(tr.filter(t => t.strategyId === 'gps_v1').reduce((a, t) => a + t.pnl, 0), 14);
  add({ s: 'gps_v1', pnl: 100, live: true });   // live journal is pooled and tagged
  assert.equal(adaptive.loadTrades('all').length, 5); assert.equal(adaptive.loadTrades('live').length, 1); assert.equal(adaptive.loadTrades('paper').length, 4);
});

test('5 minimum sample size: a few lucky wins never create a favourite or a bonus', () => {
  clean(); many('lucky', [10, 10, 10, 10, 10]);
  const c = { ...adaptive.cfg(), mode: 'ON' }, r = adaptive.getRanking({ cfg: c, force: true }), e = r.entries.find(x => x.strategyId === 'lucky');
  assert.equal(e.eligible, false); assert.equal(e.status, 'LEARNING'); assert.equal(r.favourite, null);
  assert.equal(adaptive.prefFor(sig('lucky', 80), r, c, 'ON').bonus, 0);
});

test('6 ranking: net profitability, expectancy and PF beat raw win rate; favourite is the proven winner', () => {
  clean();
  many('A', rep([10, 10, 10, -5], 40)); many('B', rep([5, -5], 40)); many('C', rep([5, -5, -5, -5], 40)); many('D', rep([1, 1, 1, 1, -10], 40));
  const r = adaptive.getRanking({ cfg: adaptive.cfg(), force: true }), order = r.entries.map(e => e.strategyId);
  assert.deepEqual(order.slice(0, 2), ['A', 'B']); assert.ok(order.indexOf('D') > order.indexOf('B')); assert.equal(r.favourite, 'A');
  const D = r.entries.find(e => e.strategyId === 'D'); assert.ok(D.winRate >= 0.79 && D.netPnl < 0);   // high win rate, still not favoured
});

test('7 recent vs long-term weighting changes the score', () => {
  clean(); const rows = [...rep([10, 10, -5], 30), ...rep([-8], 10)].map(pnl => ({ pnl }));
  const base = adaptive.cfg(), recentHeavy = adaptive.edge(rows, { ...base, recentWeight: 0.9, longTermWeight: 0.1 }).score, longHeavy = adaptive.edge(rows, { ...base, recentWeight: 0.1, longTermWeight: 0.9 }).score;
  assert.ok(longHeavy > recentHeavy + 1, `${longHeavy} vs ${recentHeavy}`);
});

test('8 market-regime ranking: the best strategy overall is not favoured where another one wins', () => {
  clean();
  many('trendy', rep([10, 10, 10, -5], 60), { regime: { canonicalRegime: 'STRONG_TREND' } });
  many('trendy', rep([-8, -8, 2], 30), { regime: { canonicalRegime: 'RANGE' } });
  many('meanrev', rep([6, 6, 6, -4], 40), { regime: JSON.stringify({ canonicalRegime: 'RANGE' }) });
  many('meanrev', rep([-6, -6, 2], 21), { regime: 'STRONG_TREND' });
  const c = adaptive.cfg(), r = adaptive.getRanking({ cfg: c, force: true });
  assert.equal(r.entries.find(e => e.strategyId === 'trendy').rank < r.entries.find(e => e.strategyId === 'meanrev').rank, true, 'trendy is best overall');
  const bo = (id, regime) => adaptive.prefFor(sig(id, 80, { regime }), r, c, 'ON').bonus;
  assert.ok(bo('meanrev', 'RANGE') > bo('trendy', 'RANGE'), 'range: mean reversion preferred');
  assert.ok(bo('trendy', 'STRONG_TREND') > bo('meanrev', 'STRONG_TREND'), 'trend: trendy preferred');
});

test('9 deterioration is detected, preference is cut, recovery is detected', () => {
  clean(); many('G', rep([8, 8, -4], 45)); many('H', [...rep([-6], 12), ...rep([8, 8, -4], 18)]);
  const c = adaptive.cfg(), before = adaptive.getRanking({ cfg: c, force: true }), b0 = adaptive.prefFor(sig('G', 80), before, c, 'ON').bonus;
  many('G', rep([-9, -9, 2], 12));
  const after = adaptive.getRanking({ cfg: c, force: true }), g = after.entries.find(e => e.strategyId === 'G');
  assert.equal(g.trend, 'DETERIORATING'); assert.ok(adaptive.prefFor(sig('G', 80), after, c, 'ON').bonus < b0);
  clean(); many('H', [...rep([-6, -6, 2], 15), ...rep([8, 8, -4], 15)]);
  assert.equal(adaptive.getRanking({ cfg: adaptive.cfg(), force: true }).entries.find(e => e.strategyId === 'H').trend, 'RECOVERING');
});

test('10 favourite replacement uses hysteresis, then promotes a better strategy and logs it', () => {
  const mk = (id, shrunk, extra = {}) => ({ strategyId: id, name: id, eligible: true, netPnl: 50, shrunk, trend: 'STEADY', ...extra });
  assert.equal(adaptive.decideFavourite([mk('A', 70), mk('B', 74)], 'A').id, 'A', 'within margin: stays');
  assert.equal(adaptive.decideFavourite([mk('A', 70), mk('B', 77)], 'A').id, 'B', 'clearly better: replaced');
  assert.equal(adaptive.decideFavourite([mk('A', 70, { trend: 'DETERIORATING' }), mk('B', 71)], 'A').id, 'B', 'deteriorating favourite loses the margin');
  clean(); many('A', rep([10, 10, -5], 40)); many('B', rep([4, -4, -4], 40));
  assert.equal(adaptive.getRanking({ cfg: adaptive.cfg(), force: true, persist: true }).favourite, 'A');
  many('A', rep([-9, -9, 2], 30)); many('B', rep([9, 9, -3], 40));
  const r = adaptive.getRanking({ cfg: adaptive.cfg(), force: true, persist: true });
  assert.equal(r.favourite, 'B'); assert.ok(adaptive.recentEvents().some(e => e.type === 'FAVOURITE' && /A → B/.test(e.detail)));
  assert.ok(adaptive.status().snapshots >= 1);
});

test('11 OFF restores the original selection order exactly (and never mutates scores)', () => {
  clean(); many('good', rep([10, 10, -5], 40)); many('bad', rep([5, -6, -6], 40));
  const q = [sig('bad', 90), sig('good', 80)], f = [sig('good', 70, { tier: 'FILL' })], scores = [...q, ...f].map(s => s.score);
  adaptive.setCfg({ mode: 'OFF' });
  const o = adaptive.order(q, f, { persist: false });
  assert.equal(o.mode, 'OFF'); assert.deepEqual(o.queue, [...q, ...f]); o.queue.forEach((s, i) => assert.strictEqual(s, [...q, ...f][i])); assert.equal(o.skipped.length, 0);
  assert.deepEqual([...q, ...f].map(s => s.score), scores);
});

test('12-13 ON changes real selection; STRONG applies a stronger preference', () => {
  clean(); many('good', rep([10, 10, -5], 40)); many('bad', rep([5, -6, -6], 40));
  const c = adaptive.cfg(), r = adaptive.getRanking({ cfg: c, force: true });
  const bOn = (id) => adaptive.prefFor(sig(id, 80), r, c, 'ON').bonus, bSt = (id) => adaptive.prefFor(sig(id, 80), r, c, 'STRONG').bonus;
  assert.ok(Math.abs(bSt('good')) > Math.abs(bOn('good')) && bSt('good') <= c.bonusStrong * 1.25 + 1e-9); assert.ok(bOn('good') <= c.bonusOn && bOn('bad') < 0);
  const gap = (bOn('good') - bOn('bad')) + 1, mkq = () => [sig('bad', 80 + gap), sig('good', 80)];
  adaptive.setCfg({ mode: 'OFF' }); assert.deepEqual(names(adaptive.order(mkq(), [], {}).queue), ['bad', 'good']);
  adaptive.setCfg({ mode: 'ON' }); assert.deepEqual(names(adaptive.order(mkq(), [], {}).queue), ['bad', 'good'], 'ON: small advantage, original leader keeps first place');
  adaptive.setCfg({ mode: 'STRONG' }); const s = adaptive.order(mkq(), [], {});
  assert.deepEqual(names(s.queue), ['good', 'bad'], 'STRONG flips it'); assert.match(s.queue[0]._adaptive.reason, /FAVOURED/);
  const q2 = [sig('bad', 82), sig('good', 80)]; adaptive.setCfg({ mode: 'ON' });
  assert.equal(adaptive.order(q2, [], {}).queue[0].strategyId, 'good', 'ON flips a close call');
});

test('14-15 toggle, mode selection and validation; defaults to OFF', () => {
  clean(); assert.equal(adaptive.cfg().mode, 'OFF'); assert.equal(adaptive.cfg().enabled, false);
  assert.equal(adaptive.setCfg({ enabled: true }).mode, 'ON'); assert.equal(adaptive.setCfg({ mode: 'STRONG' }).mode, 'STRONG');
  assert.equal(adaptive.setCfg({ enabled: false }).mode, 'OFF'); assert.equal(adaptive.setCfg({ enabled: true }).mode, 'STRONG', 'toggle ON restores last mode');
  for (const bad of [{ mode: 'MAX' }, { minTrades: 2 }, { minTrades: 'x' }, { enabled: 'yes' }, { recentWeight: -1 }, { learnFrom: 'x' }, { bonusOn: 10, bonusStrong: 5 }, { skipMinTrades: 1 }])
    assert.throws(() => adaptive.setCfg(bad), undefined, JSON.stringify(bad));
  const w = adaptive.setCfg({ recentWeight: 3, longTermWeight: 1 }); assert.ok(Math.abs(w.recentWeight - 0.75) < 1e-9 && Math.abs(w.longTermWeight - 0.25) < 1e-9);
});

test('16 settings survive a restart (module reload) and the dashboard value beats the .env default', () => {
  clean(); adaptive.setCfg({ mode: 'STRONG', minTrades: 22, learnFrom: 'live' });
  delete require.cache[require.resolve('../src/intelligence/adaptive')]; adaptive = require('../src/intelligence/adaptive');
  const c = adaptive.cfg(); assert.equal(c.mode, 'STRONG'); assert.equal(c.minTrades, 22); assert.equal(c.learnFrom, 'live');
  process.env.ADAPTIVE_STRATEGY_ENABLED = 'true'; process.env.ADAPTIVE_STRATEGY_MODE = 'ON';
  assert.equal(adaptive.cfg().mode, 'STRONG', 'saved dashboard setting wins over .env');
  adaptive.setCfg({ mode: 'OFF' }); assert.equal(adaptive.cfg().mode, 'OFF', 'saved OFF wins over ENABLED=true');
  delete process.env.ADAPTIVE_STRATEGY_ENABLED; delete process.env.ADAPTIVE_STRATEGY_MODE;
});

test('16b dashboard API: header guard, validation errors, and never claims "applied" before the robot confirms', async () => {
  clean(); const routes = require('../dashboard/adaptiveRoutes').create({ sendJson: (res, code, body) => { res.code = code; res.body = body; }, parseBody: async (req) => req.body });
  const call = async (method, p, body, hdr = { 'x-alpha': '1' }) => { const res = {}; await routes.handle({ headers: hdr, body, url: p }, res, p, method); return res; };
  assert.equal((await call('POST', '/api/adaptive/config', { mode: 'ON' }, {})).code, 403);
  assert.equal((await call('POST', '/api/adaptive/config', { mode: 'WRONG' })).code, 400);
  const saved = await call('POST', '/api/adaptive/config', { mode: 'ON' });
  assert.equal(saved.code, 200); assert.equal(saved.body.saved, true); assert.equal(saved.body.applied.confirmed, false); assert.match(saved.body.message, /not applied|Waiting/i);
  adaptive.heartbeat();                       // what the running robot does every 3 s
  assert.equal((await call('GET', '/api/adaptive/status')).body.applied.confirmed, true);
  adaptive.setCfg({ mode: 'STRONG' });        // saved again, robot has not re-confirmed yet
  assert.equal((await call('GET', '/api/adaptive/status')).body.applied.confirmed, false);
  adaptive.heartbeat(); assert.equal(adaptive.status().applied.confirmed, true);
});

test('17-18 journal records are accurate, link to the final outcome and never duplicate', () => {
  clean(); many('good', rep([10, 10, -5], 40)); adaptive.setCfg({ mode: 'ON' });
  const s1 = sig('good', 80, { symbol: 'ETHUSDT' }), s2 = sig('good', 79, { symbol: 'SOLUSDT' });
  adaptive.order([s1, s2], [], {});
  assert.equal(adaptive.noteSelected(s1, { tradeId: 'T1', runMode: 'paper' }), true);
  assert.equal(adaptive.noteSelected(s1, { tradeId: 'T1', runMode: 'paper' }), false, 'same trade id is not recorded twice');
  assert.equal(adaptive.noteSelected(s1, { tradeId: null, runMode: 'paper' }), false, 'same setup in the same minute is not recorded twice');
  const d = adaptive.recentDecisions(5); assert.equal(d.length, 1);
  assert.equal(d[0].symbol, 'ETHUSDT'); assert.equal(d[0].strategy_id, 'good'); assert.equal(d[0].adaptive_mode, 'ON'); assert.ok(d[0].strategy_rank >= 1); assert.ok(d[0].win_rate > 0.5); assert.ok(d[0].net_pnl > 0);
  assert.ok(d[0].profit_factor > 1); assert.equal(d[0].regime, 'STRONG_TREND'); assert.equal(d[0].base_score, 80); assert.ok(d[0].reason.length > 10); assert.equal(d[0].finalOutcome, 'OPEN');
  assert.equal(d[0].competing[0].symbol, 'SOLUSDT');
  add({ s: 'good', id: 'T1', pnl: 12, sym: 'ETHUSDT' });
  const d2 = adaptive.recentDecisions(5)[0]; assert.equal(d2.finalOutcome, 'WIN'); assert.equal(d2.finalPnl, 12);
});

test('19 no duplicate execution, no invented trades, score and risk fields untouched', () => {
  clean(); many('good', rep([10, 10, -5], 40)); adaptive.setCfg({ mode: 'STRONG' });
  const q = [sig('good', 80), sig('bad', 85), sig('good', 78)], f = [sig('good', 70, { tier: 'FILL' })], all = [...q, ...f], sc = all.map(s => s.score), keys = all.map(s => Object.keys(s).filter(k => k !== '_adaptive').join());
  const o = adaptive.order(q, f, {});
  assert.equal(new Set(o.queue).size, o.queue.length); assert.equal(o.queue.length + o.skipped.length, all.length); o.queue.forEach(s => assert.ok(all.includes(s)));
  assert.deepEqual(all.map(s => s.score), sc); assert.deepEqual(all.map(s => Object.keys(s).filter(k => k !== '_adaptive').join()), keys);
  for (const s of all) for (const k of ['leverage', 'margin', 'size', 'stopLoss', 'positionSize', 'sizeFactor']) assert.equal(k in (s._adaptive || {}), false, k);
  const src = fs.readFileSync(path.join(__dirname, '../src/robot.js'), 'utf8'), iA = src.indexOf('adaptive.order('), iG = src.indexOf('gate.check(sig, gateCtx)', iA);
  assert.ok(iA > 0 && iG > iA, 'every queued setup still passes the existing gate / risk engine after adaptive ordering');
  assert.match(src, /catch \(e\) \{ logger\.warn\(`adaptive engine skipped \(original order used\)/);
});

test('20 NO TRADE: nothing qualified means nothing is selected, in every mode', () => {
  clean(); many('good', rep([10, 10, -5], 40));
  for (const m of ['OFF', 'ON', 'STRONG']) { adaptive.setCfg({ mode: m }); const o = adaptive.order([], [], {}); assert.deepEqual(o.queue, []); assert.deepEqual(o.skipped, []); }
});

test('21 STRONG skips a strategy with proven losses (>=50 trades, negative expectancy, PF<1); ON never skips', () => {
  clean(); many('loser', rep([3, -6, -6], 60)); many('good', rep([10, 10, -5], 40));
  adaptive.setCfg({ mode: 'ON' }); assert.equal(adaptive.order([sig('loser', 90)], [], {}).skipped.length, 0);
  adaptive.setCfg({ mode: 'STRONG' }); const o = adaptive.order([sig('loser', 90), sig('good', 80)], [], {});
  assert.deepEqual(names(o.queue), ['good']); assert.equal(o.skipped.length, 1); assert.match(o.skipped[0]._adaptive.skip, /SKIPPED \(STRONG\)/);
  clean(); many('loser', rep([3, -6, -6], 40)); adaptive.setCfg({ mode: 'STRONG' });
  assert.equal(adaptive.order([sig('loser', 90)], [], {}).skipped.length, 0, 'under 50 trades: never skipped');
});

test('22 repetitive selection is discouraged (repeat losses on the same setup, same-strategy pile-ups)', () => {
  clean(); many('good', rep([10, 10, -5], 40)); add({ s: 'good', sym: 'XRPUSDT', pnl: -4, t: Date.now() - 3600000 }); add({ s: 'good', sym: 'XRPUSDT', pnl: -4, t: Date.now() - 1800000 });
  adaptive.setCfg({ mode: 'ON' });
  const a = sig('good', 80, { symbol: 'XRPUSDT' }), b = sig('good', 80, { symbol: 'ADAUSDT' }); adaptive.order([a, b], [], {});
  assert.equal(a._adaptive.repetitionPenalty, 5); assert.equal(b._adaptive.repetitionPenalty, 0);
  clean(); many('good', rep([10, 10, -5], 40)); adaptive.setCfg({ mode: 'ON' });
  const q = [sig('good', 80), sig('good', 80), sig('good', 80), sig('other', 85)];
  assert.equal(adaptive.order(q, [], {}).queue.indexOf(q[3]), 2, 'same-strategy pile-up is spread: a different strategy breaks the run (without the penalty it would be last)');
});

test('23 recovery after a robot restart: favourite, snapshots and events are rebuilt from the journal', () => {
  clean(); many('A', rep([10, 10, -5], 40)); adaptive.setCfg({ mode: 'ON' }); adaptive.refresh({ signals: [sig('A', 80)] });
  const before = adaptive.status(); assert.equal(before.intel.favourite.strategyId, 'A');
  delete require.cache[require.resolve('../src/intelligence/adaptive')]; adaptive = require('../src/intelligence/adaptive');
  const after = adaptive.status(); assert.equal(after.intel.favourite.strategyId, 'A'); assert.equal(after.cfg.mode, 'ON'); assert.ok(after.events.length >= 1); assert.ok(after.snapshots >= 1);
  assert.equal(after.closedTrades, 40);
});

test('24 SIMULATED paper-style competition: the engine really changes selection and (in this simulated world) improves PnL', () => {
  // Strategy B looks better on raw score every scan (+3) but loses money; A scores lower but wins. One slot per scan.
  let x = 12345; const rnd = () => (x = (x * 1103515245 + 12345) % 2147483648) / 2147483648;
  const N = 260, A = [], B = [], sa = [], sb = [];
  for (let i = 0; i < N; i++) { A.push(rnd() < 0.6 ? 10 : -6); B.push(rnd() < 0.4 ? 8 : -8); sa.push(75 + rnd() * 2); sb.push(78 + rnd() * 2); }
  const run = (mode) => {
    clean(); adaptive.setCfg({ mode, minTrades: 10, minRegimeTrades: 10 }); let pnl = 0, a = 0;
    for (let i = 0; i < N; i++) {
      const q = [sig('B', sb[i], { symbol: 'S' + i }), sig('A', sa[i], { symbol: 'T' + i })];
      adaptive.refresh({ signals: q, scanCount: i });
      const pick = adaptive.order(q, [], { signals: q }).queue[0], p = pick.strategyId === 'A' ? A[i] : B[i]; pnl += p; if (pick.strategyId === 'A') a++;
      add({ s: pick.strategyId, pnl: p, sym: pick.symbol });
    }
    return { pnl, aShare: a / N };
  };
  const off = run('OFF'), on = run('ON');
  assert.equal(off.aShare, 0, 'OFF: original selection always takes the higher raw score (B)');
  assert.ok(on.aShare > 0.5, `ON shifts selection toward the proven strategy (A share ${on.aShare})`);
  assert.ok(on.pnl > off.pnl, `ON ${on.pnl} vs OFF ${off.pnl} (SIMULATED data — not evidence of live profitability)`);
  console.log(`      SIMULATED: OFF pnl=${off.pnl} A-share=${off.aShare.toFixed(2)} | ON pnl=${on.pnl} A-share=${on.aShare.toFixed(2)}`);
});

test('25 the engine can never throw into trading: broken DB state falls back safely', () => {
  clean(); dbx().prepare("INSERT OR REPLACE INTO robot_state (key, value, updated_at) VALUES ('adaptive_cfg', '{not json', 1)").run();
  assert.equal(adaptive.cfg().mode, 'OFF', 'unreadable saved setting falls back to the safe .env default (OFF)');   // and the robot wraps order() in try/catch (test 19)
  assert.deepEqual(adaptive.order([sig('x', 80)], [], {}).queue.map(s => s.strategyId), ['x']);
});
