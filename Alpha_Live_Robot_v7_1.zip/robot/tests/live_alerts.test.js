'use strict';
const test = require('node:test');
const assert = require('node:assert');
const AlertCenter = require('../src/notifications/liveAlerts');
const OrderManager = require('../src/execution/orderManager');
const config = require('../src/config');
const Robot = require('../src/robot');
const bybitFacade = require('../src/exchanges');

function mem() { const m = {}; return { get: k => m[k] ?? null, set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); }, m }; }

test('alert centre: feed persisted (cap 100), telegram dispatched, cooldown and category filter honoured', async () => {
  const sent = []; const store = mem(); let t = 1000;
  const a = new AlertCenter({ notifier: { dispatch: async (e) => { sent.push(e); } }, store, now: () => t, categories: ['safety', 'slots'] });
  assert.ok(await a.emit({ category: 'safety', severity: 'CRITICAL', title: 'X', message: 'm' }));
  assert.strictEqual(await a.emit({ category: 'orders', title: 'hidden' }), false);              // category off
  assert.ok(await a.emit({ category: 'safety', title: 'Y', key: 'k', cooldownMs: 60000 }));
  assert.strictEqual(await a.emit({ category: 'safety', title: 'Y', key: 'k', cooldownMs: 60000 }), false);   // cooldown
  t += 61000; assert.ok(await a.emit({ category: 'safety', title: 'Y', key: 'k', cooldownMs: 60000 }));
  assert.strictEqual(sent.length, 3); assert.strictEqual(sent[0].severity, 'CRITICAL');
  for (let i = 0; i < 130; i++) await a.emit({ category: 'slots', title: `s${i}` });
  assert.strictEqual(a.feed().length, 100);
});

test('alert centre never throws when Telegram fails', async () => {
  const a = new AlertCenter({ notifier: { dispatch: async () => { throw new Error('tg down'); } }, store: mem(), categories: ['safety'] });
  assert.ok(await a.emit({ category: 'safety', title: 'still recorded' })); assert.strictEqual(a.feed().length, 1);
});

test('order manager emits placed / stop-confirmed / blocked events', async () => {
  const ev = []; let stops = [];
  const ex = { getPositions: async () => [{ symbol: 'SOLUSDT' }], getStopOrders: async () => stops, getOrder: async () => ({ orderId: '1', status: 'Filled', filledQty: 0.2, avgPrice: 100 }),
    placeOrder: async () => ({ orderId: '1' }), cancelOrder: async () => ({}) };
  ex.getPositions = async () => [];
  const om = new OrderManager({ exchange: ex, store: mem(), onEvent: (e) => ev.push(e) });
  const sig = { id: 'a', symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104 };
  const r = await om.submitEntry(sig, 0.2, { leverage: 10 });
  assert.ok(ev.some(e => /Order placed/.test(e.title) && e.category === 'orders'));
  ex.getPositions = async () => [{ symbol: 'SOLUSDT' }]; stops = [{ symbol: 'SOLUSDT', stopLoss: 98.5, long: true }];
  await om.reconcile();
  assert.ok(ev.some(e => /Stop-loss confirmed/.test(e.title)));
  stops = []; om.get(r.order.id).protected = null; om._save(om.get(r.order.id));
  await om.verifyProtection(om.get(r.order.id));
  assert.ok(ev.some(e => e.category === 'safety' && e.severity === 'CRITICAL' && /BLOCKED/.test(e.title)));
});

test('robot live cycle: start heartbeat, grouped scale-up alert, daily-stop alert, paused gate (fake exchange)', async () => {
  const saved = { mode: config.mode, le: config.liveEnabled, ex: config.exchange, isLive: config.isLive, start: config.scaling.startSlots };
  Object.assign(config, { mode: 'LIVE', liveEnabled: true, exchange: 'bybit', isLive: true }); config.scaling.startSlots = 3; require('../src/control/runtime').setSlotConfig({ ramp: true, start: 3, every: 10, minPF: 1.2, max: 12 });   // v6.0.2: ramp is now your setting
  const fake = { equity: 25, closed: [], getAccountBalance: async () => ({ equity: fake.equity, available: fake.equity }), getPositions: async () => [], getMarginMode: async () => 'ISOLATED_MARGIN',
    getClosedTrades: async () => fake.closed, getOrder: async () => null, getStopOrders: async () => [] };
  bybitFacade._use(fake);
  const j = require('../src/journal/store');
  for (const k of ['live_day', 'live_peak_equity', 'live_profile_prev', 'live_closed_seen', 'live_stats', 'live_alerts', 'live_orders', 'live_entries_blocked']) j.setState(k, null);
  try {
    const r = new Robot(); r.scanCount = 1;
    const got = []; r.alerts = { emit: async (e) => { got.push(e); return true; } };
    await r._liveCycle();
    assert.ok(got.some(e => /started/.test(e.title) && e.category === 'heartbeat'));
    // proven edge appears -> slots 3 -> 5 in ONE grouped message
    fake.closed = [...Array(14).fill({ symbol: 'A', pnl: 0.6, closedAt: 5 }), ...Array(6).fill({ symbol: 'B', pnl: -0.3, closedAt: 6 })];
    r.scanCount = 6; await r._liveCycle(); r.scanCount = 11; await r._liveCycle();
    const up = got.filter(e => e.category === 'slots');
    assert.ok(up.length >= 1 && /Slots 3 → 5/.test(up[up.length - 1].message), JSON.stringify(up));
    // daily stop
    fake.equity = 22; r.scanCount = 12; await r._liveCycle();
    assert.ok(got.some(e => /DAILY LOSS STOP/.test(e.title) && e.severity === 'CRITICAL'));
    // pause blocks entries and is persisted
    r.paused = true; r._liveOk = true; assert.strictEqual((await r._openLive({ symbol: 'SOLUSDT' })).reason, 'PAUSED');
  } finally {
    bybitFacade._use(null); Object.assign(config, { mode: saved.mode, liveEnabled: saved.le, exchange: saved.ex, isLive: saved.isLive }); config.scaling.startSlots = saved.start; require('../src/journal/store').setState('slot_cfg', null);
  }
});

test('PAUSE / RESUME commands in LIVE: Take Live Trades is OFF at every start (v5.2.4) and alerted', async () => {
  const saved = { mode: config.mode, le: config.liveEnabled, isLive: config.isLive };
  Object.assign(config, { mode: 'LIVE', liveEnabled: true, isLive: true });
  const j = require('../src/journal/store'); j.setState('live_paused', null);
  try {
    const r = new Robot(); const got = []; r.alerts = { emit: async (e) => { got.push(e); return true; } };
    await r._executeCommand({ type: 'PAUSE', payload: {} });
    assert.strictEqual(r.paused, true); assert.strictEqual(j.getState('live_paused'), true);
    assert.strictEqual(new Robot().paused, true);                        // a restart always starts with Take Live Trades OFF
    await r._executeCommand({ type: 'RESUME', payload: {} });
    assert.strictEqual(r.paused, false); assert.strictEqual(j.getState('live_paused'), false);
    assert.strictEqual(new Robot().paused, true);                        // ...even after it was switched ON before the restart (TAKE_LIVE_TRADES_ON_START=false)
    assert.deepStrictEqual(got.map(e => e.category), ['safety', 'safety']);
  } finally { Object.assign(config, { mode: saved.mode, liveEnabled: saved.le, isLive: saved.isLive }); j.setState('live_paused', null); }
});
