'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const run = (env, code) => spawnSync(process.execPath, ['-e', code], { cwd: path.resolve(__dirname, '..'), env: { PATH: process.env.PATH, ROBOT_SKIP_DOTENV: '1', ...env }, encoding: 'utf8' });
const probe = "const c=require('./src/config');console.log(JSON.stringify({m:c.runMode,live:c.isLive,tn:c.bybit.testnet,url:c.bybit.baseUrl,note:!!c.legacyModeNote}))";
const J = (env) => JSON.parse(run(env, probe).stdout);

test('v5.2: default mode is SIM (paper) and sends no orders', () => {
  const o = J({}); assert.strictEqual(o.m, 'SIM'); assert.strictEqual(o.live, false); assert.strictEqual(o.tn, false);
});
test('legacy TESTNET and LIVE+BYBIT_TESTNET resolve to SIM, never to real money', () => {
  const a = J({ TRADING_MODE: 'TESTNET' }); assert.strictEqual(a.m, 'SIM'); assert.strictEqual(a.live, false); assert.strictEqual(a.note, true);
  const b = J({ TRADING_MODE: 'LIVE', LIVE_TRADING_ENABLED: 'true', BYBIT_TESTNET: 'true' }); assert.strictEqual(b.m, 'SIM'); assert.strictEqual(b.live, false);
  assert.strictEqual(J({ TRADING_MODE: 'garbage' }).m, 'SIM');
});
test('LIVE stays locked without LIVE_TRADING_ENABLED', () => {
  const o = J({ TRADING_MODE: 'LIVE' }); assert.strictEqual(o.m, 'LIVE'); assert.strictEqual(o.live, false);
  assert.strictEqual(J({ TRADING_MODE: 'LIVE', LIVE_TRADING_ENABLED: 'true' }).live, true);
});
test('legacy PAPER and the sim exchange resolve to SIM', () => {
  assert.strictEqual(J({ TRADING_MODE: 'PAPER' }).m, 'SIM'); assert.strictEqual(J({ TRADING_MODE: 'LIVE', LIVE_TRADING_ENABLED: 'true', EXCHANGE: 'sim' }).live, false);
});
test('Bybit always talks to mainnet host', () => { assert.strictEqual(J({}).url, 'https://api.bybit.com'); });
