'use strict';
process.env.TRADING_MODE = 'SIM';
process.env.ROBOT_SKIP_DOTENV = '1';
process.env.ROBOT_DATA_DIR = require('fs').mkdtempSync(require('path').join(require('os').tmpdir(), 'v7-'));
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const path = require('path');
const config = require('../src/config');
const journal = require('../src/journal/store');
const gate = require('../src/risk/gate');
const portfolio = require('../src/risk/portfolio');
const intel = require('../src/market/intel');
const PaperEngine = require('../src/paper/engine');
const lab = require('../src/intelligence/paperLab');
const adaptive = require('../src/intelligence/adaptive');
const TradingRobot = require('../src/robot');
const dbx = () => journal.getDb();
const R = (...p) => fs.readFileSync(path.join(__dirname, '..', ...p), 'utf8');

const sigFor = (symbol, o = {}) => ({ symbol, strategyId: 'gps_v1', strategyName: 'GPS', strategyVersion: '1', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 105, riskReward: 2.5, score: 90, tier: 'QUALIFIED', decision: 'TRADE', cluster: 'L1', timestamp: Date.now() + (o.t || 0), regime: { canonicalRegime: 'STRONG_TREND' }, ...o });

// ── manual Take: no fixed cap, confirmation over the position limit, 2nd confirmation on high open risk ─────────
function robotWith(prices = {}) {
  const r = new TradingRobot(); r.paused = false;
  r.paperEngine.analyzeMarket = async (symbol) => ({ symbol, signals: [sigFor(symbol)] });
  r._getTickerMap = async () => Object.fromEntries(Object.keys(prices).map(k => [k, { lastPrice: prices[k] }]));
  r._normPositions = () => []; r._equityNow = () => 1000; r._updateState = () => {}; r._writeHeartbeat = () => {};
  r._noteOutcomeOpen = async () => {}; r.notifier = { notifySignal: async () => {} };
  r.riskEngine.cfg.accountBalance = 1000; r.paperEngine.balance = 1000; r.paperEngine.riskEngine.cfg.accountBalance = 1000;
  return r;
}
async function withStubs(snapRisk, fn) {
  const saved = { gp: gate.prepare, gc: gate.check, gn: gate.noteOpened, ir: intel.refresh, mc: config.microChecks, live: config.isLive };
  gate.prepare = async () => ({ intel: null, snap: { aggRisk: snapRisk }, gov: null, f: {} });
  gate.noteOpened = () => {}; intel.refresh = async () => {}; config.microChecks = false; config.isLive = false;
  try { await fn(); } finally { Object.assign(gate, { prepare: saved.gp, check: saved.gc, noteOpened: saved.gn }); intel.refresh = saved.ir; config.microChecks = saved.mc; config.isLive = saved.live; }
}

test('manual take: going over the position limit needs an explicit confirmation (enforced by the robot, not just the page)', async () => {
  await withStubs(0, async () => {
    gate.check = async () => ({ allowed: true, sizeFactor: 1 });
    const r = robotWith({ SOLUSDT: 100, ETHUSDT: 100, XRPUSDT: 100 }); r.riskEngine.cfg.maxOpenPositions = 1;
    const first = await r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps_v1' });   // 0 open of 1: no confirmation needed
    assert.equal(first.slotOverridden, false);
    const pv = await r._prepareTake({ symbol: 'ETHUSDT', direction: 'LONG', strategyId: 'gps_v1' });
    assert.equal(pv.overridesSlots, true); assert.equal(pv.hardCap, 0, 'no fixed cap by default');
    await assert.rejects(() => r._takeSetup({ symbol: 'ETHUSDT', direction: 'LONG', strategyId: 'gps_v1' }), /CONFIRM_REQUIRED/);
    assert.equal(r.paperEngine.getOpenTrades().filter(t => t.symbol === 'ETHUSDT').length, 0, 'nothing opened without confirmation');
    const ok = await r._takeSetup({ symbol: 'ETHUSDT', direction: 'LONG', strategyId: 'gps_v1', confirmOver: true });   // retry right after a refusal is allowed
    assert.equal(ok.slotOverridden, true);
    // no fixed cap: a third and fourth over-limit take also work once confirmed (limited only by the engine's own position cap)
    const third = await r._takeSetup({ symbol: 'XRPUSDT', direction: 'LONG', strategyId: 'gps_v1', confirmOver: true }); assert.equal(third.mode, 'paper');
    assert.equal(r.paperEngine.getOpenTrades().length, 3);
  });
});

test('manual take: high total open risk (> 15% of equity) needs a second confirmation; the aggregate cap is bypassed only then', async () => {
  await withStubs(200, async () => {          // 200 USDT of open stop-risk on 1000 equity = 20%
    const seen = [];
    gate.check = async (sig, ctx) => { seen.push(!!ctx.overrideAggregate); return ctx.overrideAggregate ? { allowed: true, sizeFactor: 1, overridden: ['PORTFOLIO: aggregate stop-risk 9% > cap 8%'] } : { allowed: false, reasons: ['PORTFOLIO: aggregate stop-risk 9% > cap 8%'] }; };
    const r = robotWith({ SOLUSDT: 100 });
    const pv = await r._prepareTake({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps_v1' });
    assert.equal(pv.needsRiskConfirm, true); assert.ok(pv.openRiskPctAfter > 15); assert.ok(pv.riskBlocked && /PORTFOLIO/.test(pv.riskBlocked[0]));
    await assert.rejects(() => r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps_v1' }), /CONFIRM_RISK_REQUIRED/);
    const ok = await r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps_v1', confirmRisk: true });
    assert.equal(ok.symbol, 'SOLUSDT'); assert.equal(seen[seen.length - 1], true, 'override flag reached the gate only because the user confirmed');
  });
  await withStubs(0, async () => {            // small open risk: no second confirmation, gate not overridden
    let flagged = null; gate.check = async (sig, ctx) => { flagged = !!ctx.overrideAggregate; return { allowed: true, sizeFactor: 1 }; };
    const pv = await robotWith({ SOLUSDT: 100 })._prepareTake({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps_v1' });
    assert.equal(pv.needsRiskConfirm, false); assert.equal(flagged, false);
  });
});

test('gate: the confirmed override passes ONLY the aggregate open-risk caps (correlation, governor etc. still block)', async () => {
  const saved = portfolio.checkEntry;
  portfolio.checkEntry = () => ({ reasons: ['PORTFOLIO: aggregate stop-risk 9.0% > cap 8%', 'CORRELATION: SOL joins a correlated group'] });
  try {
    const ctx = { f: { correlationBlock: true }, caps: { aggRiskPct: 8, ceilingPct: 100, corrRiskPct: 4, corrThreshold: 0.7, taperStartPct: 60, taperMinPct: 30, staleDataSec: 120 }, equity: 1000, riskPerTrade: 0.01, snap: {}, returns: {}, runMode: 'SIM', now: Date.now(), minScore: 70, sizing: null };
    const s = sigFor('SOLUSDT');
    const plain = await gate.check(s, { ...ctx }); assert.equal(plain.allowed, false); assert.equal(plain.reasons.length, 2);
    const ov = await gate.check(s, { ...ctx, overrideAggregate: true });
    assert.equal(ov.allowed, false, 'still blocked by correlation'); assert.equal(ov.reasons.length, 1); assert.match(ov.reasons[0], /^CORRELATION/); assert.match(ov.overridden[0], /^PORTFOLIO/);
  } finally { portfolio.checkEntry = saved; }
});

// ── Paper Lab: separate paper account while LIVE ─────────────────────────────────────────────────────────────
function labEngine() { return new PaperEngine({}, { maxOpenPositions: 50, accountBalance: 1000, riskPerTrade: 0.01 }); }
const asLive = (fn) => { const keep = config.isLive; config.isLive = true; try { return fn(); } finally { config.isLive = keep; } };

test('paper lab: trades are tagged LAB, kept out of every normal paper view, restored only in live mode, and keep their own balance', () => {
  dbx().exec('DELETE FROM paper_trades; DELETE FROM trade_extras');
  const plain = labEngine(); const pr = plain.openFromSignal(sigFor('PLAINUSDT')); assert.equal(pr.action, 'OPENED');      // normal paper trade
  const e = labEngine(); const lr = asLive(() => e.openFromSignal(sigFor('LABUSDT'))); assert.equal(lr.action, 'OPENED');
  const rows = dbx().prepare('SELECT symbol, mode FROM paper_trades ORDER BY symbol').all();
  assert.deepEqual(rows.map(r => r.mode + ':' + r.symbol), ['LAB:LABUSDT', 'PAPER:PLAINUSDT']);
  assert.deepEqual(journal.getOpenPaperTrades().map(r => r.symbol), ['PLAINUSDT'], 'normal views never show lab rows');
  assert.deepEqual(journal.getOpenPaperTrades('lab').map(r => r.symbol), ['LABUSDT']);
  assert.equal(journal.getOpenPaperTrades('all').length, 2); assert.deepEqual(journal.getPaperTrades(10).map(r => r.symbol), ['PLAINUSDT']);
  // restart in LIVE mode adopts only lab rows; restart in paper mode adopts only normal rows
  const liveRestart = labEngine(); asLive(() => liveRestart.restoreFromJournal()); assert.deepEqual(liveRestart.getOpenTrades().map(t => t.symbol), ['LABUSDT']);
  const paperRestart = labEngine(); paperRestart.restoreFromJournal(); assert.deepEqual(paperRestart.getOpenTrades().map(t => t.symbol), ['PLAINUSDT']);
  // closing a lab trade: realised pnl stays in the lab only
  const t = liveRestart.getOpenTrades()[0]; const closed = asLive(() => liveRestart.closeTrade(t.id, 'MANUAL_CLOSE', 105));
  assert.ok(closed && closed.pnl > 0);
  assert.equal(journal.getClosedPaperTrades(10).length, 0, 'closed lab trade is not in the normal paper journal'); assert.equal(journal.getClosedPaperTrades(10, 'lab').length, 1);
  const again = labEngine(); asLive(() => again.restoreFromJournal()); assert.ok(Math.abs(again.balance - (again.startBalance + closed.pnl)) < 1e-6, 'lab balance = start + lab realised only');
  const plainBalance = labEngine(); plainBalance.restoreFromJournal(); assert.equal(plainBalance.balance, plainBalance.startBalance, 'normal paper balance unaffected by lab pnl');
});

test('paper lab scan: takes every qualified setup up to the paper cap and marks those beyond the live cap; OFF opens nothing', async () => {
  dbx().exec('DELETE FROM paper_trades; DELETE FROM trade_extras; DELETE FROM robot_state');
  const e = labEngine(), fake = { running: true, paperEngine: e, riskEngine: { cfg: { maxOpenPositions: 1 } }, _writePaperView() {} };
  const q = ['AAAUSDT', 'BBBUSDT', 'CCCUSDT'].map((s, i) => sigFor(s, { t: i }));
  const n = await asLive(() => TradingRobot.prototype._labScan.call(fake, q)); assert.equal(n, 3, 'lab is not limited by the live slot cap');
  const ex = require('../src/journal/extras'); const flags = ['AAAUSDT', 'BBBUSDT', 'CCCUSDT'].map(s => !!ex.get(e.getOpenTrades().find(t => t.symbol === s).id).overLiveCap);
  assert.deepEqual(flags, [false, true, true], 'trades opened when the live cap (1) would already be full are marked');
  assert.equal(lab.status().openOverCap >= 0, true);
  lab.setEnabled(false); const n2 = await asLive(() => TradingRobot.prototype._labScan.call(fake, [sigFor('DDDUSDT')])); assert.equal(n2, 0); lab.setEnabled(true);
  assert.throws(() => lab.setEnabled('yes'));
  const src = R('src', 'robot.js');   // the live path is untouched and lab failures can never stop live trading; lab closes do not spam live notifications
  assert.match(src, /await this\._labScan\(qualified\); \} catch \(e\) \{ logger\.warn\(`paper lab skipped \(live trading unaffected\)/);
  assert.match(src, /if \(!config\.isLive\) await this\.notifier\.notifyTradeClosed\(t\)/);
  assert.match(src, /openTrades: config\.isLive \? 0 : this\.paperEngine\.openTrades\.size/);
});

test('paper lab: per-coin / strategy statistics, local-day boundary and the good / poor / wait day verdict', () => {
  const T = Date.UTC(2026, 10, 13, 12, 0), mk = (symbol, pnl, close) => ({ id: symbol + close, symbol, pnl, strategy_name: 'S', strategy_id: 's', outcome: pnl > 0 ? 'WIN' : 'LOSS', close_time: close });
  assert.equal(lab.dayStart(Date.UTC(2026, 10, 13, 23, 30), -60), Date.UTC(2026, 10, 13, 23, 0), 'Lagos (UTC+1): 23:30 UTC is already the next local day, which started at 23:00 UTC');
  assert.equal(lab.dayStart(Date.UTC(2026, 10, 13, 12, 0), -60), Date.UTC(2026, 10, 12, 23, 0));
  const good = [...[10, 10, 10, 10, -5].map((p, i) => mk('SOL', p, T - i * 60000)), mk('BTC', -3, T - 7 * 86400000 * 0.5)];
  const s = lab.summarize(good, T, 0);
  assert.equal(s.today.n, 5); assert.equal(s.today.net, 35); assert.equal(s.today.winRate, 0.8); assert.equal(s.verdict.level, 'GOOD');
  const coin = s.byCoin.find(c => c.key === 'SOL'); assert.equal(coin.n, 5); assert.equal(coin.wins, 4); assert.equal(coin.pf, 8); assert.equal(s.byCoin[0].key, 'SOL', 'sorted by net pnl');
  assert.equal(s.week.n, 6);
  const poor = lab.summarize([-5, -5, -5, 2, -5, -5].map((p, i) => mk('ETH', p, T - i * 60000)), T, 0); assert.equal(poor.verdict.level, 'POOR');
  assert.equal(lab.summarize([5, 5].map((p, i) => mk('ETH', p, T - i * 60000)), T, 0).verdict.level, 'WAIT');
  assert.equal(lab.summarize([5, -5, 5, -5, 5, -4].map((p, i) => mk('ETH', p, T - i * 60000)), T, 0).verdict.level, 'NEUTRAL');
  const old = lab.summarize([mk('SOL', 9, T - 3 * 86400000)], T, 0); assert.equal(old.today.n, 0);
});

test('adaptive engine: Paper Lab trades are tagged separately and can be learned from, excluded, or learned alone', () => {
  dbx().exec('DELETE FROM paper_trades; DELETE FROM live_trades');
  const base = { strategyId: 'gps_v1', strategyName: 'GPS', strategyVersion: '1', symbol: 'BTCUSDT', direction: 'LONG', entry: 100, stopLoss: 99, takeProfit: 102, positionSize: 1, fee: 0.1, score: 80, riskReward: 2, regime: 'STRONG_TREND', openTime: 1000, closeTime: 2000 };
  journal.savePaperTrade({ ...base, id: 'p1', pnl: 5, outcome: 'WIN' });
  journal.savePaperTrade({ ...base, id: 'l1', pnl: -2, outcome: 'LOSS', dbMode: 'LAB' });
  journal.saveLiveTrade({ ...base, id: 'v1', pnl: 3, outcome: 'WIN' });
  const n = (f) => adaptive.loadTrades(f).length; const tags = adaptive.loadTrades('all').map(t => t.mode).sort();
  assert.deepEqual(tags, ['lab', 'live', 'paper']); assert.equal(n('all'), 3); assert.equal(n('paper'), 1); assert.equal(n('lab'), 1); assert.equal(n('live'), 1);
  assert.equal(adaptive.validate({ learnFrom: 'lab' }).learnFrom, 'lab');
});

// ── dashboard routes: chart data, lab status/switch ─────────────────────────────────────────────────────────
test('routes: position chart returns candles + SL / TP / trailing levels; lab switch is guarded; bad input is refused', async () => {
  const dataFeed = require('../src/market/dataFeed'), keep = dataFeed.getCandles;
  const now = Date.now(); dataFeed.getCandles = async () => Array.from({ length: 30 }, (_, i) => ({ time: now - (30 - i) * 900000, open: 100 + i * 0.1, high: 101 + i * 0.1, low: 99 + i * 0.1, close: 100.5 + i * 0.1 }));
  try {
    journal.setState('protection_view_paper', [{ id: 'SOLUSDT_gps_v1_1', symbol: 'SOLUSDT', side: 'LONG', entry: 100, mark: 103, initialStop: 98, stop: 101, tp: 106, upnl: 3, progress: 40, moves: [{ ts: now - 600000, to: 101, reason: 'BREAKEVEN' }] }]);
    const routes = require('../dashboard/v7Routes').create({ sendJson: (res, code, body) => { res.code = code; res.body = body; }, parseBody: async (req) => req.body });
    const call = async (method, url, body, hdr = { 'x-alpha': '1' }) => { const res = {}; const u = new URL(url, 'http://x'); await routes.handle({ headers: hdr, body, url }, res, u.pathname, method); return res; };
    const ok = await call('GET', '/api/v7/position-chart?symbol=SOLUSDT&tf=15m&mode=paper'); assert.equal(ok.code, 200);
    assert.equal(ok.body.candles.length, 30); assert.equal(ok.body.levels.tp, 106); assert.equal(ok.body.levels.stop, 101); assert.equal(ok.body.levels.initialStop, 98); assert.equal(ok.body.levels.trailing, 101);
    assert.match(ok.body.levels.trailingLabel, /Break-even|Trailing/); assert.equal(ok.body.stopMoves.length, 1); assert.equal(ok.body.side, 'LONG');
    assert.equal((await call('GET', '/api/v7/position-chart?symbol=SOLUSDT&tf=99x')).body.tf, '15m', 'unknown timeframe falls back to 15m');
    assert.equal((await call('GET', '/api/v7/position-chart?symbol=NOPEUSDT')).code, 404);
    assert.equal((await call('GET', '/api/v7/position-chart?symbol=../../etc')).code, 400);
    assert.equal((await call('POST', '/api/lab/config', { enabled: false }, {})).code, 403);
    assert.equal((await call('POST', '/api/lab/config', { enabled: 'no' })).code, 400);
    const off = await call('POST', '/api/lab/config', { enabled: false }); assert.equal(off.code, 200); assert.equal(off.body.enabled, false);
    assert.equal((await call('GET', '/api/lab/status?tz=-60')).body.enabled, false); await call('POST', '/api/lab/config', { enabled: true });
    assert.equal((await call('GET', '/api/lab/status')).body.ok, true);
  } finally { dataFeed.getCandles = keep; }
});

// ── Positions & Orders: strategy shown even when the lifecycle record is gone ───────────────────────────────
test('live read model: strategy comes from the lifecycle record, then the live journal; shown as a small badge', () => {
  const LiveReadModel = require('../src/live/readModel');
  const rm = Object.create(LiveReadModel.prototype);
  rm._recs = () => [{ symbol: 'ETHUSDT', strategy: 'Pullback', createdAt: 5 }];
  rm.journal = { getOpenLiveTrades: () => [{ symbol: 'BTCUSDT', strategy_name: 'Breakout' }], getClosedLiveTrades: () => [{ symbol: 'SOLUSDT', strategy_id: 'orb_v1' }] };
  assert.equal(rm._stratFor('ETHUSDT'), 'Pullback'); assert.equal(rm._stratFor('BTCUSDT'), 'Breakout'); assert.equal(rm._stratFor('SOLUSDT'), 'orb_v1'); assert.equal(rm._stratFor('XRPUSDT'), null);
  const live = R('dashboard', 'public', 'live.js');
  assert.match(live, /window\.v7Strat\(p\.strategy\)/); assert.match(live, /window\.v7Strat\(o\.strategy\)/); assert.doesNotMatch(live, /<th>Protection<\/th><th>Strategy<\/th>/, 'the wide Strategy column was replaced by the badge');
  assert.match(R('dashboard', 'public', 'index.html'), /window\.v7Strat\(t\.strategy\)/);
});

test('dashboard wiring: tab, scripts, back/home, scroll helpers, unified notifications and assets are all registered', () => {
  const html = R('dashboard', 'public', 'index.html'), v7 = R('dashboard', 'public', 'v7.js'), srv = R('dashboard', 'server.js'), lr = R('dashboard', 'liveRoutes.js');
  for (const x of ['id="plTabBtn"', 'id="tab-paperlab"', 'id="plRoot"', '/paperlab.js', '/v7.js', '/v7.css']) assert.ok(html.includes(x), x);
  for (const x of ["'/v7.js'", "'/paperlab.js'", "'/v7.css'", "'/adaptive.js'"]) assert.ok(lr.includes(x), x);
  assert.match(srv, /v7Routes\.handle/); assert.match(srv, /confirmOver: body\.confirmOver === true, confirmRisk: body\.confirmRisk === true/);
  for (const x of ['v7Back', 'v7Home', 'v7-topbar', 'v7Jump', 'v7-chartbtn', '/api/v7/position-chart', 'data-a="close"', 'closePosition']) assert.ok(v7.includes(x) || x === 'data-a="close"' || x === 'closePosition', x);
  assert.match(v7, /button\[data-a="close"\]\[data-s\]/); assert.match(v7, /closePosition\\\(/);
  for (const f of ['v67.js', 'live.js', 'obsidian.js', 'obsidian-pages.js']) assert.match(R('dashboard', 'public', f), /window\.__v6toast/, f + ' uses the unified notifications');
  assert.match(html, /window\.__v6toast\(String\(msg\), true\)/);
  const css = R('dashboard', 'public', 'v7.css'); assert.match(css, /#v6Toasts\{top:calc/); assert.match(css, /v7in/); assert.match(css, /\.v6-toast\.v7-gone/);
  assert.match(R('dashboard', 'public', 'v67.js'), /confirmOver: needOver, confirmRisk: needRisk/);
  assert.match(R('src', 'config.js'), /manualTakeRiskConfirmPct/); assert.match(R('.env.example'), /PAPER_LAB_ENABLED/);
});
