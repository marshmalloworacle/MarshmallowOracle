'use strict';
const test = require('node:test');
const assert = require('node:assert');
const config = require('../src/config');
const OrderManager = require('../src/execution/orderManager');
const { previewOrder } = require('../src/live/preview');
const LiveReadModel = require('../src/live/readModel');
const journal = require('../src/journal/store');

function mem() { const m = {}; return { get: k => m[k] ?? null, set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); }, m }; }
const rules = { qtyStep: 0.01, minQty: 0.01, minNotional: 1, takerFeeRate: null };
const account = { equity: 25, available: 25 };
const input = { symbol: 'solusdt', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104 };
const flags = { isLive: true, authorised: true, paused: false, blocked: null, emergency: false };

test('preview: good idea passes, sized like the live path, nothing sent', () => {
  const r = previewOrder({ input, account, profile: null, positions: [], rules, flags });
  assert.ok(r.wouldAccept, JSON.stringify(r.checks.filter(c => !c.ok)));
  assert.ok(r.sizing.qty > 0 && r.sizing.riskUsd <= 25 * 0.02 + 1e-9);
  assert.ok(r.fees.roundTripUsd > 0 && r.fees.assumed === true);
  assert.ok(r.liquidation.price < 100 && r.wouldSendNow);
});

test('preview: wrong-side stop, bad R:R, full slots, same symbol, no margin, daily limit and gates all reported', () => {
  const bad = previewOrder({ input: { ...input, stopLoss: 101 }, account, rules, flags });
  assert.ok(!bad.wouldAccept && bad.checks.some(c => /right side/.test(c.name) && !c.ok));
  assert.ok(!previewOrder({ input: { ...input, takeProfit: 100.5 }, account, rules, flags }).wouldAccept);
  const full = previewOrder({ input, account, profile: { slots: 2, leverage: 10, riskPerTrade: 0.013, marginPerSlot: 5 }, positions: [{ symbol: 'A' }, { symbol: 'B' }], rules, flags });
  assert.ok(full.checks.find(c => c.name === 'slot available' && !c.ok));
  assert.ok(previewOrder({ input, account, positions: [{ symbol: 'SOLUSDT' }], rules, flags }).checks.find(c => /no open position/.test(c.name) && !c.ok));
  assert.ok(previewOrder({ input, account: { equity: 25, available: 0.01 }, rules, flags }).checks.find(c => /free margin/.test(c.name) && !c.ok));
  assert.ok(previewOrder({ input, account, rules, flags, riskState: { dayPnl: -2, dailyLimitUsd: 1.25 } }).checks.find(c => /daily loss/.test(c.name) && !c.ok));
  const paper = previewOrder({ input, account, rules, flags: { ...flags, isLive: false } });
  assert.ok(paper.wouldAccept && !paper.wouldSendNow);            // passes rules but the robot would not send in PAPER
  assert.ok(!previewOrder({ input, account, rules: null, flags }).wouldAccept);
});

test('preview: wide stop is rejected against liquidation distance at 20x', () => {
  const r = previewOrder({ input: { ...input, stopLoss: 94, takeProfit: 112 }, account, profile: { slots: 6, leverage: 20, riskPerTrade: 0.013, marginPerSlot: 5 }, rules, flags });
  assert.ok(r.checks.find(c => /inside liquidation/.test(c.name) && !c.ok));
});

function fakeEx(over = {}) {
  const calls = [];
  const ex = { calls,
    getAccountBalance: async () => ({ equity: 25, available: 20, margin: 5, unrealized: 0.2 }),
    getPositions: async () => [{ symbol: 'SOLUSDT', side: 'LONG', qty: 0.5, entry: 100, liquidationPrice: 91, margin: 5, leverage: 10 }],
    getOpenOrders: async () => [], getStopOrders: async () => [{ symbol: 'SOLUSDT', stopLoss: 98.5, takeProfit: 104, long: true }],
    getMarginMode: async () => 'ISOLATED_MARGIN', getTickers: async () => [{ markPrice: '101', lastPrice: '101' }], ping: async () => ({ latencyMs: 80, driftMs: 40 }),
    placeOrder: async (p) => { calls.push(['place', p]); return { orderId: 'C1' }; }, cancelOrder: async (...a) => { calls.push(['cancel', ...a]); }, ...over };
  return ex;
}
const savedCfg = { ex: config.exchange, k: config.bybit.apiKey, s: config.bybit.apiSecret };
function useBybitKeys() { config.exchange = 'bybit'; config.bybit.apiKey = 'k'; config.bybit.apiSecret = 's'; }
function restore() { config.exchange = savedCfg.ex; config.bybit.apiKey = savedCfg.k; config.bybit.apiSecret = savedCfg.s; }

test('read model: account from the EXCHANGE (not saved state), positions with mark/uPnL/protection, never writes', async () => {
  useBybitKeys();
  try {
    const ex = fakeEx(); const rm = new LiveReadModel({ exchange: ex, journal });
    const a = await rm.account();
    assert.ok(a.ok && a.source === 'exchange' && a.equity === 25 && a.marginMode === 'ISOLATED_MARGIN');
    const p = await rm.positions();
    assert.strictEqual(p.positions[0].mark, 101); assert.ok(Math.abs(p.positions[0].upnl - 0.5) < 1e-9); assert.strictEqual(p.positions[0].protected, true);
    const r = await rm.risk(); assert.ok(r.ok && r.unprotected.length === 0 && r.openRisk.usd > 0);
    const h = await rm.health(); assert.ok(h.checks.find(c => c.name === 'exchange reachable').ok);
    assert.strictEqual(ex.calls.length, 0);                          // read model performed no order call at all
  } finally { restore(); }
});

test('read model: no keys -> clear reason; exchange failure -> last good snapshot flagged stale', async () => {
  config.exchange = 'bybit'; const sk = config.bybit.apiKey; config.bybit.apiKey = '';
  try { const rm = new LiveReadModel({ exchange: fakeEx(), journal }); const a = await rm.account(); assert.ok(!a.ok && /not set/.test(a.reason)); } finally { config.bybit.apiKey = sk; restore(); }
  useBybitKeys();
  try {
    let fail = false; let t = 0; const ex = fakeEx({ getAccountBalance: async () => { if (fail) throw new Error('exchange down'); return { equity: 25, available: 20, margin: 5, unrealized: 0 }; } });
    const rm = new LiveReadModel({ exchange: ex, journal, ttlMs: 10, now: () => (t += 100) });
    assert.ok((await rm.account()).ok); fail = true;
    const s = await rm.account(); assert.ok(s.ok && s.stale && /exchange down/.test(s.error));
  } finally { restore(); }
});

test('read model: unprotected position is flagged', async () => {
  useBybitKeys();
  try { const rm = new LiveReadModel({ exchange: fakeEx({ getStopOrders: async () => [] }), journal }); const r = await rm.risk(); assert.deepStrictEqual(r.unprotected, ['SOLUSDT']); } finally { restore(); }
});

test('order manager: closePosition sends ONE reduce-only market order; flatten closes all and reports remaining', async () => {
  const placed = []; let open = [{ symbol: 'A', side: 'LONG', qty: 1 }, { symbol: 'B', side: 'SHORT', qty: 2 }];
  const ex = { getPositions: async () => open, getOpenOrders: async () => [], cancelOrder: async () => ({}), placeOrder: async (p) => { placed.push(p); open = open.filter(x => x.symbol !== p.symbol); return { orderId: 'X' }; } };
  const om = new OrderManager({ exchange: ex, store: mem() });
  const f = await om.flatten('test');
  assert.deepStrictEqual(f.closed.map(x => x.symbol), ['A', 'B']); assert.deepStrictEqual(f.remaining, []);
  assert.ok(placed.every(p => p.reduceOnly === true && p.orderType === 'Market'));
  assert.deepStrictEqual(placed.map(p => p.side), ['Sell', 'Buy']);
  assert.strictEqual((await om.closePosition('ZZZ')).reason, 'NO_OPEN_POSITION');
});

test('order manager: failed close is reported (and a timeout whose position is gone counts as closed)', async () => {
  const ex = { getPositions: async () => [{ symbol: 'A', side: 'LONG', qty: 1 }], placeOrder: async () => { throw new Error('Rate limit'); } };
  const r = await new OrderManager({ exchange: ex, store: mem() }).closePosition('A'); assert.ok(!r.ok && /Rate limit/.test(r.reason));
  let gone = false; const ex2 = { getPositions: async () => (gone ? [] : [{ symbol: 'A', side: 'LONG', qty: 1 }]), placeOrder: async () => { gone = true; const e = new Error('timeout'); e.ambiguous = true; throw e; } };
  const r2 = await new OrderManager({ exchange: ex2, store: mem() }).closePosition('A'); assert.ok(r2.ok && r2.verified);
});

test('order manager: cancelAllEntries cancels resting entries only (never reduce-only exits)', async () => {
  const cancelled = [];
  const ex = { getOpenOrders: async () => [{ symbol: 'A', orderId: '1', reduceOnly: false }, { symbol: 'B', orderId: '2', reduceOnly: true }], cancelOrder: async (s, id) => { cancelled.push(id); } };
  const r = await new OrderManager({ exchange: ex, store: mem() }).cancelAllEntries(); assert.deepStrictEqual(cancelled, ['1']); assert.deepStrictEqual(r.cancelled, ['A']);
});

test('robot commands: FLATTEN_LIVE pauses + alerts, KILL_LIVE sets emergency and keeps positions, both refuse outside LIVE', async () => {
  const Robot = require('../src/robot'); const saved = { mode: config.mode, le: config.liveEnabled, isLive: config.isLive };
  const closed = []; const ex = { getPositions: async () => (closed.length ? [] : [{ symbol: 'A', side: 'LONG', qty: 1 }]), getOpenOrders: async () => [], cancelOrder: async () => ({}), placeOrder: async (p) => { closed.push(p); return { orderId: 'Z' }; } };
  try {
    Object.assign(config, { mode: 'PAPER', isLive: false });
    const r0 = new Robot(); await assert.rejects(() => r0._executeCommand({ type: 'FLATTEN_LIVE', payload: {} }), /Not in LIVE/);
    Object.assign(config, { mode: 'LIVE', liveEnabled: true, isLive: true });
    const r = new Robot(); const got = []; r.alerts = { emit: async (e) => { got.push(e); } };
    r.liveExecution.orders = new OrderManager({ exchange: ex, store: mem() });
    const out = await r._executeCommand({ type: 'FLATTEN_LIVE', payload: {} });
    assert.deepStrictEqual(out.closed, ['A']); assert.strictEqual(r.paused, true); assert.ok(got.some(e => /FLATTEN/.test(e.title)));
    journal.setState('emergency_stop', false); journal.setState('live_paused', false);
    const r2 = new Robot(); r2.alerts = { emit: async (e) => { got.push(e); } }; r2.liveExecution.orders = new OrderManager({ exchange: ex, store: mem() }); closed.length = 0;
    await r2._executeCommand({ type: 'KILL_LIVE', payload: {} });
    assert.strictEqual(journal.getState('emergency_stop'), true); assert.strictEqual(closed.length, 0);   // kill switch never closes positions
  } finally { Object.assign(config, { mode: saved.mode, liveEnabled: saved.le, isLive: saved.isLive }); journal.setState('emergency_stop', false); journal.setState('live_paused', false); }
});

test('live journal: filled orders and exchange closes land in live_trades (real trades only)', () => {
  const Robot = require('../src/robot'); const r = new Robot(); const store = mem();
  r.liveExecution.orders = new OrderManager({ exchange: {}, store });
  const rec = { id: 'gpsJRN1', symbol: 'JRNUSDT', direction: 'LONG', side: 'Buy', qty: 1, entry: 10, stopLoss: 9.85, takeProfit: 10.4, strategy: 'GPS', state: 'FILLED', createdAt: Date.now() - 60000, updatedAt: Date.now(), filledQty: 1, avgPrice: 10, history: [] };
  r.liveExecution.orders._save(rec);
  r._journalOpenLive();
  const open = journal.getLiveTrades(500).find(t => t.id === 'gpsJRN1'); assert.ok(open && open.close_time == null && open.strategy_name === 'GPS');
  r._journalClosedLive([{ symbol: 'JRNUSDT', direction: 'LONG', qty: 1, entry: 10, exit: 9.85, pnl: -0.16, fee: 0.01, closedAt: 1700000099000 }]);
  const done = journal.getClosedLiveTrades(500).find(t => t.id === 'gpsJRN1'); assert.ok(done && done.exit_reason === 'STOP_LOSS_HIT' && done.outcome === 'LOSS' && done.pnl === -0.16);
  r._journalClosedLive([{ symbol: 'JRNUSDT', direction: 'LONG', qty: 1, entry: 10, exit: 9.85, pnl: -0.16, fee: 0.01, closedAt: 1700000099000 }]);   // idempotent
  assert.strictEqual(journal.getClosedLiveTrades(500).filter(t => t.symbol === 'JRNUSDT').length, 1);
});

test('dashboard routes: read endpoints work, writes need LIVE + confirmation word, assets whitelisted', async () => {
  const server = require('../dashboard/server');
  await new Promise(r => server.listen(0, r)); const base = `http://127.0.0.1:${server.address().port}`;
  const saved = { isLive: config.isLive };
  try {
    for (const p of ['/live.js', '/live.css']) { const r = await fetch(base + p); assert.strictEqual(r.status, 200); }
    assert.strictEqual((await fetch(base + '/../../package.json')).status === 200 && false, false);
    const g = await (await fetch(base + '/api/live/gates')).json(); assert.ok(g.ok);
    const j = await (await fetch(base + '/api/live/journal')).json(); assert.ok(j.ok && Array.isArray(j.closed));
    const pv = await (await fetch(base + '/api/live/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })).json(); assert.ok(pv.ok === false || pv.checks);
    const post = (p, b) => fetch(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b || {}) });
    config.isLive = false; assert.strictEqual((await post('/api/live/flatten', { confirm: 'FLATTEN' })).status, 400);
    config.isLive = true;
    assert.strictEqual((await post('/api/live/flatten', {})).status, 400);                         // no confirmation word
    assert.strictEqual((await post('/api/live/kill', { confirm: 'nope' })).status, 400);
    assert.strictEqual((await post('/api/live/close', { symbol: 'SOLUSDT' })).status, 400);        // confirm=true missing
    const off = await post('/api/live/flatten', { confirm: 'FLATTEN' });                           // valid, but the robot process is not running in tests
    assert.strictEqual(off.status, 409); assert.match((await off.json()).error, /stop-loss/);
  } finally { config.isLive = saved.isLive; await new Promise(r => server.close(r)); }
});
