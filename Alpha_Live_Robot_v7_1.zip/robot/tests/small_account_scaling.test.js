'use strict';
const test = require('node:test');
const assert = require('node:assert');
const scalingMod = require('../src/risk/scaling');
const { fitPosition } = scalingMod;
// Tier-table tests run with the ramp OFF (startSlots 0); the ramp has its own tests below.
const computeProfile = (o = {}) => scalingMod.computeProfile({ ...o, config: { startSlots: 0, ...(o.config || {}) } });
const RiskEngine = require('../src/risk/engine');

const good = { trades: 30, profitFactor: 1.6, expectancy: 0.4 };

test('small accounts keep many slots: $7 -> 5, $20 -> 6, $30 -> 6, $50 -> 8, $100 -> 10, $200 -> 12', () => {
  for (const [eq, n] of [[7, 5], [20, 6], [30, 6], [50, 8], [100, 10], [200, 12]]) assert.strictEqual(computeProfile({ equity: eq }).slots, n, `$${eq}`);
});

test('aggregate open risk is capped: slots x risk <= 8%', () => {
  for (const eq of [7, 20, 50, 200, 600, 2000]) { const p = computeProfile({ equity: eq }); assert.ok(p.slots * p.riskPerTrade <= 0.08 + 1e-9, `${eq}`); }
});

test('tiny account: exchange-minimum size used only when its risk stays under the cap', () => {
  const rules = { qtyStep: 1, minQty: 1, minNotional: 0.01 };
  const ok = fitPosition({ entry: 5, stopLoss: 4.8, equity: 7, riskPerTrade: 0.012, leverage: 10, marginPerSlot: 0.84, rules, minSizeRiskCap: 0.03 });
  assert.ok(ok.ok && ok.bumped && ok.qty === 1 && ok.riskUsd <= 7 * 0.03 + 1e-9);   // risk-based qty 0.42 -> bumped to the 1-unit minimum
  const big = fitPosition({ entry: 150, stopLoss: 147, equity: 7, riskPerTrade: 0.012, leverage: 10, marginPerSlot: 0.84, rules, minSizeRiskCap: 0.03 });
  assert.strictEqual(big.ok, false);                                          // 1 unit = $15 margin at 10x: skipped, never forced
});

test('leverage above base needs proven edge; unlocks with it, capped at max', () => {
  assert.strictEqual(computeProfile({ equity: 2000, stats: null }).leverage, 10);
  assert.strictEqual(computeProfile({ equity: 2000, stats: good }).leverage, 20);
  assert.ok(computeProfile({ equity: 2000, stats: good, config: { maxLeverage: 15 } }).leverage <= 15);
});

test('drawdown scales down hard', () => {
  const mild = computeProfile({ equity: 190, peakEquity: 200, stats: good });   // 5% dd
  assert.strictEqual(mild.state, 'REDUCED');
  assert.ok(mild.leverage < 15 && mild.slots === 11);
  const deep = computeProfile({ equity: 170, peakEquity: 200, stats: good });   // 15% dd
  assert.strictEqual(deep.state, 'DEFENSIVE');
  assert.deepStrictEqual([deep.slots, deep.leverage], [1, 5]);
  assert.ok(deep.riskPerTrade < 0.01);
});

test('risk never exceeds the hard ceiling', () => {
  assert.ok(computeProfile({ equity: 100, config: { baseRisk: 0.5 } }).riskPerTrade <= 0.02);
});

test('fitPosition: $20 account, 1.5% risk, 1.5% stop -> ~$20 notional, ~$2 margin', () => {
  const f = fitPosition({ entry: 100, stopLoss: 98.5, equity: 20, riskPerTrade: 0.015, leverage: 10, marginPerSlot: 6, rules: { qtyStep: 0.01, minQty: 0.01, minNotional: 5 } });
  assert.ok(f.ok); assert.ok(f.riskUsd <= 0.3 + 1e-9); assert.ok(f.margin <= 6);
});

test('fitPosition shrinks to slot margin and skips below exchange minimum', () => {
  const s = fitPosition({ entry: 100, stopLoss: 99.9, equity: 20, riskPerTrade: 0.015, leverage: 10, marginPerSlot: 4, rules: { qtyStep: 0.01, minQty: 0.01, minNotional: 5 } });
  assert.ok(s.ok && s.shrunk && s.margin <= 4 + 1e-9);
  const tiny = fitPosition({ entry: 100, stopLoss: 90, equity: 5, riskPerTrade: 0.015, leverage: 10, marginPerSlot: 3, rules: { qtyStep: 0.01, minQty: 0.01, minNotional: 5 } });
  assert.strictEqual(tiny.ok, false);   // 0.0075 risk -> qty < min, never rounded UP
});

test('RiskEngine with scaling: slots cap open positions and size never exceeds risk budget', () => {
  const cfg = require('../src/config'); const keep = cfg.scaling.startSlots; cfg.scaling.startSlots = 0;
  require('../src/control/runtime').setSlotConfig({ ramp: false, max: 6 });   // v6.0.2: slots are your setting, not an equity tier
  const r = new RiskEngine({ accountBalance: 20, scaling: true, maxOpenPositions: 0 });
  r.refreshProfile({ equity: 20, peakEquity: 20 });
  assert.strictEqual(r.cfg.maxOpenPositions, 6);
  const sig = { symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104, riskReward: 2.7 };
  const ok = r.check(sig, [], { rules: { qtyStep: 0.01, minQty: 0.01, minNotional: 5 } });
  assert.ok(ok.approved, ok.reason);
  assert.ok(ok.riskAmount <= 20 * 0.0133 + 1e-9);   // 6 slots -> 8%/6 = 1.33% each
  const full = r.check(sig, ['A', 'B', 'C', 'D', 'E', 'F'].map(symbol => ({ symbol })));
  assert.strictEqual(full.approved, false);
  assert.match(full.reason, /MAX_POSITIONS/);
});

test('paper RiskEngine unchanged: scaling off and no daily stop by default', () => {
  const r = new RiskEngine({ accountBalance: 100 });
  assert.strictEqual(r.cfg.scalingEnabled, false);
  assert.strictEqual(r.profile, null);
});

test('statsFromClosed: PF, expectancy and win rate from realised PnL; edge unlocks leverage', () => {
  const { statsFromClosed } = require('../src/risk/scaling');
  const closed = [...Array(14).fill({ pnl: 0.6 }), ...Array(8).fill({ pnl: -0.3 })];
  const s = statsFromClosed(closed);
  assert.strictEqual(s.trades, 22); assert.ok(s.profitFactor > 3 && s.expectancy > 0);
  assert.ok(computeProfile({ equity: 200, stats: s }).leverage > computeProfile({ equity: 200, stats: null }).leverage);
  assert.deepStrictEqual(statsFromClosed([]).trades, 0);
});

test('slot count is configurable: fixed override and cap; risk still honours the 6% aggregate budget', () => {
  const fixed = computeProfile({ equity: 20, config: { slotsOverride: 8 } });
  assert.strictEqual(fixed.slots, 8); assert.ok(fixed.slots * fixed.riskPerTrade <= 0.08 + 1e-9);
  assert.strictEqual(computeProfile({ equity: 2000, config: { maxSlots: 6 } }).slots, 6);
  assert.strictEqual(computeProfile({ equity: 20, config: { slotsOverride: 8 }, peakEquity: 30 }).slots, 1);   // drawdown still overrides
});

test('margin sizing: $20 account, 5% margin = $1, 10x -> ~$10 position; wide stop cuts it back to the risk budget', () => {
  const base = { equity: 20, riskPerTrade: 0.0133, leverage: 10, marginPerSlot: 2, rules: { qtyStep: 0.001, minQty: 0.001, minNotional: 1 }, sizing: 'margin', marginPct: 0.05 };
  const tight = fitPosition({ ...base, entry: 100, stopLoss: 98.5 });
  assert.ok(tight.ok && Math.abs(tight.margin - 1) < 0.01 && Math.abs(tight.notional - 10) < 0.2, JSON.stringify(tight));
  const wide = fitPosition({ ...base, entry: 100, stopLoss: 93 });             // 7% stop: $10 would risk $0.70 > $0.27 budget
  assert.ok(wide.ok && wide.riskUsd <= 20 * 0.0133 + 1e-9 && wide.margin < 1);
  const grown = fitPosition({ ...base, equity: 100, marginPerSlot: 10, entry: 100, stopLoss: 98.5 });
  assert.ok(grown.margin > 4.9 && grown.margin <= 5.01);                        // position size grows with equity
});

test('liquidation: isolated 10x -> loss capped at margin, and robot stop sits inside liquidation distance', () => {
  const { liquidationPrice } = require('../src/risk/engine');
  assert.ok(liquidationPrice('LONG', 100, 10, 0.005) < 92 && liquidationPrice('LONG', 100, 10, 0.005) > 89);
});

test('slot ramp: starts at 3, earns +1 per 10 closed trades while PF holds, never above tier/max, resets if edge lost', () => {
  const win = (n, w = 0.6, l = -0.3, nl = 6) => [...Array(n).fill({ pnl: w }), ...Array(nl).fill({ pnl: l })];
  const { statsFromClosed } = require('../src/risk/scaling');
  assert.strictEqual(scalingMod.computeProfile({ equity: 25, config: { startSlots: 3 } }).slots, 3);                                   // no history: start slots
  assert.strictEqual(scalingMod.computeProfile({ equity: 25, stats: statsFromClosed(win(14)), config: { startSlots: 3 } }).slots, 5);  // 20 trades, PF 2.0 -> 3 + 2
  assert.strictEqual(scalingMod.computeProfile({ equity: 25, stats: statsFromClosed(win(60)), config: { startSlots: 3 } }).slots, 6);  // earned 9 but the $25 tier allows 6
  assert.strictEqual(scalingMod.computeProfile({ equity: 500, stats: statsFromClosed(win(60)), config: { startSlots: 3, maxSlots: 7 } }).slots, 7);
  assert.strictEqual(scalingMod.computeProfile({ equity: 25, stats: statsFromClosed([...win(2), ...Array(20).fill({ pnl: -0.5 })]), config: { startSlots: 3 } }).slots, 3);   // edge lost -> back to start
  assert.strictEqual(scalingMod.computeProfile({ equity: 25, config: { startSlots: 0 } }).slots, 6);        // ramp disabled -> tier
  assert.strictEqual(scalingMod.computeProfile({ equity: 25, config: { slotsOverride: 8 } }).slots, 8);     // explicit override wins
});

test('SCALING_TIERS env format parses; bad input falls back to built-in', () => {
  const run = (v) => { const code = "process.env.SCALING_TIERS=" + JSON.stringify(v) + ";console.log(JSON.stringify(require('./src/config').scaling.tiers||null))"; return JSON.parse(require('node:child_process').execFileSync(process.execPath, ['-e', code], { cwd: require('node:path').join(__dirname, '..'), encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim().split('\n').pop()); };
  assert.deepStrictEqual(run('0:4:10,50:8:12').map(t => [t.minEquity, t.slots, t.leverage]), [[0, 4, 10], [50, 8, 12]]);
  assert.strictEqual(run('garbage'), null);
  assert.strictEqual(run('50:8:10,0:4:10'), null);   // must ascend
});

test('undefined / NaN config values (unset env) never override the defaults', () => {
  const p = scalingMod.computeProfile({ equity: 25, config: { tiers: undefined, baseLeverage: NaN, maxOpenRisk: undefined, startSlots: 0 } });
  assert.strictEqual(p.slots, 6); assert.ok(p.leverage >= 5 && p.riskPerTrade > 0);
});
