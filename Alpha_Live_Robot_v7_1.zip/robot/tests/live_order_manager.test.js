'use strict';
const test = require('node:test');
const assert = require('node:assert');
const OrderManager = require('../src/execution/orderManager');
const LiveExecution = require('../src/execution/live');
const config = require('../src/config');

const sig = { id: 's1', symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104, strategy: 'GPS', timestamp: 1 };
function mem() { const m = {}; return { get: k => m[k] ?? null, set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); }, m }; }
function fake(over = {}) {
  const ex = { placed: [], positions: [], stops: [], orders: {}, now: 0,
    getPositions: async () => ex.positions, getStopOrders: async () => ex.stops,
    getOrder: async (_s, { clientOrderId }) => ex.orders[clientOrderId] || null,
    placeOrder: async (p) => { ex.placed.push(p); return { orderId: 'X' + ex.placed.length, clientOrderId: p.clientOrderId }; },
    cancelOrder: async () => ({}), ...over };
  return ex;
}
const mk = (ex, store = mem(), clock = { t: 1000 }) => ({ om: new OrderManager({ exchange: ex, store, now: () => clock.t }), store, clock });

test('persists intent, sends once with SL/TP + client id, state ACCEPTED', async () => {
  const ex = fake(); const { om, store } = mk(ex);
  const r = await om.submitEntry(sig, 0.2, { leverage: 10, orderType: 'Limit', offsetBps: 5 });
  assert.ok(r.success); assert.strictEqual(r.state, 'ACCEPTED');
  const p = ex.placed[0];
  assert.deepStrictEqual([p.side, p.qty, p.stopLoss, p.takeProfit, p.leverage], ['Buy', 0.2, 98.5, 104, 10]);
  assert.ok(p.clientOrderId.length <= 32);
  assert.ok(p.price > 100 && p.price < 100.1);                    // marketable limit: crosses by 5 bps
  assert.strictEqual(store.m.live_orders[p.clientOrderId].history[0].state, 'INTENT');
});

test('same signal twice (retry / restart / duplicate event) never places a 2nd order', async () => {
  const ex = fake(); const { om, store } = mk(ex);
  await om.submitEntry(sig, 0.2, { leverage: 10 });
  const again = await new OrderManager({ exchange: ex, store }).submitEntry(sig, 0.2, { leverage: 10 });   // simulates a restart
  assert.ok(again.duplicate); assert.strictEqual(ex.placed.length, 1);
});

test('one position per symbol: open exchange position blocks entry (fail closed if positions unreadable)', async () => {
  const ex = fake({ positions: [{ symbol: 'SOLUSDT' }] }); const { om } = mk(ex);
  assert.match((await om.submitEntry(sig, 0.2, {})).reason, /SYMBOL_BUSY/);
  const ex2 = fake({ getPositions: async () => { throw new Error('down'); } });
  assert.match((await mk(ex2).om.submitEntry(sig, 0.2, {})).reason, /POSITION_CHECK_FAILED/);
  assert.strictEqual(ex2.placed.length, 0);
});

test('ambiguous timeout: looks the order up by client id; if found, recovers without resubmitting', async () => {
  const ex = fake(); let id;
  ex.placeOrder = async (p) => { id = p.clientOrderId; ex.placed.push(p); const e = new Error('timeout'); e.ambiguous = true; throw e; };
  ex.getOrder = async () => ({ orderId: '77', status: 'New', filledQty: 0 });
  const { om } = mk(ex); const r = await om.submitEntry(sig, 0.2, {});
  assert.ok(r.success && r.recovered); assert.strictEqual(ex.placed.length, 1); assert.strictEqual(om.get(id).state, 'ACCEPTED');
});

test('ambiguous and unresolvable: state UNKNOWN, entries BLOCKED, no resubmission', async () => {
  const ex = fake({ placeOrder: async () => { const e = new Error('timeout'); e.ambiguous = true; throw e; } });
  const { om } = mk(ex); const r = await om.submitEntry(sig, 0.2, {});
  assert.strictEqual(r.state, 'UNKNOWN');
  assert.ok(om.blocked());
  const next = await om.submitEntry({ ...sig, symbol: 'ETHUSDT', id: 's2' }, 0.1, {});
  assert.match(next.reason, /ENTRIES_BLOCKED/);
});

test('definite rejection is REJECTED (not blocked)', async () => {
  const ex = fake({ placeOrder: async () => { throw new Error('Balance insufficient'); } });
  const { om } = mk(ex); const r = await om.submitEntry(sig, 0.2, {});
  assert.strictEqual(r.state, 'REJECTED'); assert.ok(!om.blocked());
});

test('fill without exchange-side stop-loss => unprotected incident, entries blocked, position NOT auto-closed by default', async () => {
  const ex = fake(); const { om } = mk(ex);
  const r = await om.submitEntry(sig, 0.2, { leverage: 10 });
  ex.orders[r.order.id] = { orderId: 'X1', status: 'Filled', filledQty: 0.2, avgPrice: 100 };
  ex.positions = [{ symbol: 'SOLUSDT' }]; ex.stops = [];
  const s = await om.reconcile();
  assert.strictEqual(s.incidents, 1); assert.ok(om.blocked());
  assert.strictEqual(om.get(r.order.id).protected, false);
  assert.strictEqual(ex.placed.length, 1);                         // no automatic close under policy=alert
});

test('fill with verified stop-loss is protected; entries stay open; closed position detected', async () => {
  const ex = fake(); const { om } = mk(ex);
  const r = await om.submitEntry(sig, 0.2, {});
  ex.orders[r.order.id] = { orderId: 'X1', status: 'Filled', filledQty: 0.2, avgPrice: 100 };
  ex.positions = [{ symbol: 'SOLUSDT' }]; ex.stops = [{ symbol: 'SOLUSDT', stopLoss: 98.5, long: true }];
  assert.strictEqual((await om.reconcile()).protectedOk, 1); assert.ok(!om.blocked());
  ex.positions = [];
  assert.strictEqual((await om.reconcile()).closed, 1);
  assert.strictEqual(om.get(r.order.id).state, 'CLOSED');
});

test('partial fill is tracked with filled quantity and still verified for protection', async () => {
  const ex = fake(); const { om } = mk(ex);
  const r = await om.submitEntry(sig, 1, {});
  ex.orders[r.order.id] = { orderId: 'X1', status: 'PartiallyFilled', filledQty: 0.4, avgPrice: 100 };
  ex.stops = [{ symbol: 'SOLUSDT', stopLoss: 98.5, long: true }];
  await om.reconcile();
  const rec = om.get(r.order.id);
  assert.deepStrictEqual([rec.state, rec.filledQty, rec.protected], ['PARTIAL', 0.4, true]);
});

test('stale unfilled entry is cancelled after the TTL', async () => {
  let cancelled = 0; const ex = fake({ cancelOrder: async () => { cancelled++; } });
  const { om, clock } = mk(ex); const r = await om.submitEntry(sig, 0.2, {});
  ex.orders[r.order.id] = { orderId: 'X1', status: 'New', filledQty: 0 };
  clock.t += (config.liveEntryTtlSec + 5) * 1000;
  await om.reconcile(); assert.strictEqual(cancelled, 1);
});

test('LiveExecution: gates still fail closed in PAPER; stub is gone but nothing is sent without LIVE gates', async () => {
  const ex = fake(); const live = new LiveExecution({ exchange: ex, orderManager: new OrderManager({ exchange: ex, store: mem() }) });
  const res = await live.submitOrder(sig, 0.2, { approved: true });
  assert.strictEqual(res.success, false); assert.strictEqual(res.failedGate, 'MODE_GATE');
  assert.strictEqual(ex.placed.length, 0);
});

test('LiveExecution: with every gate open the order reaches the exchange once', async () => {
  const ex = fake(); const live = new LiveExecution({ exchange: ex, orderManager: new OrderManager({ exchange: ex, store: mem() }) });
  const saved = { mode: config.mode, le: config.liveEnabled, ex: config.exchange, k: config.mexc.apiKey, s: config.mexc.apiSecret };
  Object.assign(config, { mode: 'LIVE', liveEnabled: true, exchange: 'mexc' }); config.mexc.apiKey = 'k'; config.mexc.apiSecret = 's';
  try {
    live.confirmLiveMode();
    const res = await live.submitOrder(sig, 0.2, { approved: true, leverage: 10 });
    assert.ok(res.success, res.reason); assert.strictEqual(ex.placed.length, 1);
    assert.strictEqual((await live.submitOrder(sig, 0.2, { approved: true })).duplicate, true); assert.strictEqual(ex.placed.length, 1);
  } finally { Object.assign(config, { mode: saved.mode, liveEnabled: saved.le, exchange: saved.ex }); config.mexc.apiKey = saved.k; config.mexc.apiSecret = saved.s; }
});

test('v6.5.1: a stop tightened by trailing/break-even is still protected (no false "unprotected" block); a looser or missing stop is not', async () => {
  for (const [stop, long, want] of [[101.2, true, true], [100.05, true, true], [98.5, true, true], [97.0, true, false], [0, true, false]]) {
    const ex = fake(); const { om } = mk(ex);
    const r = await om.submitEntry(sig, 0.2, {});
    ex.orders[r.order.id] = { orderId: 'X1', status: 'Filled', filledQty: 0.2, avgPrice: 100 };
    ex.positions = [{ symbol: 'SOLUSDT' }]; ex.stops = stop ? [{ symbol: 'SOLUSDT', stopLoss: stop, long }] : [];
    const s = await om.reconcile();
    assert.strictEqual(s.protectedOk, want ? 1 : 0, `stop ${stop}`); assert.strictEqual(!!om.blocked(), !want, `stop ${stop} blocked`);
  }
  const ex = fake(); const { om } = mk(ex); const sh = { ...sig, id: 's2', symbol: 'ETHUSDT', direction: 'SHORT', entry: 100, stopLoss: 101.5, takeProfit: 96 };
  const r = await om.submitEntry(sh, 0.2, {}); ex.orders[r.order.id] = { orderId: 'X1', status: 'Filled', filledQty: 0.2, avgPrice: 100 };
  ex.positions = [{ symbol: 'ETHUSDT' }]; ex.stops = [{ symbol: 'ETHUSDT', stopLoss: 99.2, long: false }];
  assert.strictEqual((await om.reconcile()).protectedOk, 1, 'short with a trailed (lower) stop is protected');
});
