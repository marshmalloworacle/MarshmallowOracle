'use strict';
const test = require('node:test');
const assert = require('node:assert');
const crypto = require('node:crypto');
const EventEmitter = require('events');
const bitget = require('../src/exchanges/bitget');
const { BitgetPublicStream, MexcPublicStream } = require('../src/exchanges/ws/publicStreams');
const I = bitget._internals;

class FakeWS extends EventEmitter { constructor() { super(); this.sent = []; setImmediate(() => this.emit('open')); } send(m) { this.sent.push(m); } close() {} terminate() {} }

test('Bitget signature = base64 HMAC-SHA256(ts + METHOD + path?query + body)', () => {
  const expected = crypto.createHmac('sha256', 'sec').update('1700000000000GET/api/v2/mix/account/accounts?productType=USDT-FUTURES').digest('base64');
  assert.strictEqual(I.sign('sec', '1700000000000', 'get', '/api/v2/mix/account/accounts', 'productType=USDT-FUTURES', ''), expected);
  const post = crypto.createHmac('sha256', 'sec').update('1POST/api/v2/mix/order/place-order{"a":1}').digest('base64');
  assert.strictEqual(I.sign('sec', '1', 'POST', '/api/v2/mix/order/place-order', '', '{"a":1}'), post);
});
test('query string is sorted and skips empty values', () => {
  assert.strictEqual(I.queryString({ symbol: 'BTCUSDT', productType: 'USDT-FUTURES', x: undefined, y: '' }), 'productType=USDT-FUTURES&symbol=BTCUSDT');
});
test('size/price rounding follows contract precision', () => {
  const c = { priceEndStep: '1', pricePlace: '2', sizeMultiplier: '0.001', volumePlace: '3' };
  assert.strictEqual(I.tickOf(c), 0.01); assert.strictEqual(I.stepOf(c), 0.001);
  assert.strictEqual(I.floorTo(0.12789, 0.001), 0.127);
});
test('ticker and order mapping produce Bybit-shaped fields', () => {
  const t = I.mapTicker({ symbol: 'BTCUSDT', lastPr: '100', markPrice: '101', bidPr: '99', askPr: '101', usdtVolume: '5000', baseVolume: '50', change24h: '0.02', fundingRate: '0.0001', holdingAmount: '10' });
  assert.strictEqual(t.lastPrice, '100'); assert.strictEqual(t.price24hPcnt, '0.02'); assert.strictEqual(t.openInterestValue, '1000');
  const o = I.mapOrder({ orderId: '1', clientOid: 'c1', symbol: 'BTCUSDT', state: 'partially_filled', side: 'buy', size: '2', baseVolume: '1', priceAvg: '100', fee: '-0.05', reduceOnly: 'NO', presetStopLossPrice: '90' });
  assert.strictEqual(o.status, 'PartiallyFilled'); assert.strictEqual(o.side, 'Buy'); assert.strictEqual(o.fee, 0.05); assert.strictEqual(o.stopLoss, 90);
});
test('placeOrder refuses without credentials (never reaches the network with an unsigned order)', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: '', apiSecret: '', passphrase: '', accountType: 'classic' });
  I.resetCache();
  const origFetch = global.fetch; let calls = 0;
  global.fetch = async (url) => { calls++; return { ok: true, json: async () => ({ code: '00000', data: [{ symbol: 'BTCUSDT', priceEndStep: '1', pricePlace: '1', sizeMultiplier: '0.001', volumePlace: '3', minTradeNum: '0.001', quoteCoin: 'USDT', symbolType: 'perpetual' }] }) }; };
  try { await assert.rejects(() => bitget.placeOrder({ symbol: 'BTCUSDT', side: 'Buy', qty: 0.01, orderType: 'Market' }), /credentials missing/); }
  finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('Bitget stream: subscribe frames, ticker, candle and book parsing', async () => {
  let ws; const Impl = function () { ws = new FakeWS(); return ws; };
  const s = new BitgetPublicStream({ url: 'wss://x', Impl });
  const ticks = []; s.on('ticker', t => ticks.push(t)); s.start(); await new Promise(r => setImmediate(r));
  s.subscribe(['tickers.BTCUSDT', 'kline.15.BTCUSDT', 'orderbook.50.BTCUSDT']);
  const sent = ws.sent.map(x => JSON.parse(x));
  assert.deepStrictEqual(sent[0].args.map(a => a.channel), ['ticker', 'candle15m', 'books15']);
  ws.emit('message', JSON.stringify({ action: 'snapshot', arg: { instType: 'USDT-FUTURES', channel: 'ticker', instId: 'BTCUSDT' }, data: [{ instId: 'BTCUSDT', lastPr: '100.5', markPrice: '100.4', fundingRate: '0.0001' }], ts: Date.now() }));
  ws.emit('message', JSON.stringify({ action: 'update', arg: { channel: 'candle15m', instId: 'BTCUSDT' }, data: [['1700000000000', '1', '2', '0.5', '1.5', '10', '15']] }));
  ws.emit('message', JSON.stringify({ action: 'snapshot', arg: { channel: 'books15', instId: 'BTCUSDT' }, data: [{ bids: [['100', '2']], asks: [['101', '3']], ts: '1' }] }));
  ws.emit('message', 'pong');
  assert.strictEqual(ticks[0].lastPrice, 100.5);
  assert.strictEqual(s.getKline('BTCUSDT', '15').close, 1.5);
  assert.deepStrictEqual(s.getBook('BTCUSDT').asks[0], ['101', '3']);
  assert.strictEqual(s.getTickerMap().BTCUSDT.markPrice, 100.4);
  s.stop();
});
test('MEXC stream: subscribe frames, ticker, kline (contract-size scaled) and book', async () => {
  let ws; const Impl = function () { ws = new FakeWS(); return ws; };
  const s = new MexcPublicStream({ url: 'wss://y', Impl, csOf: () => 0.1 });
  s.start(); await new Promise(r => setImmediate(r));
  s.subscribe(['tickers.ETHUSDT', 'kline.15.ETHUSDT', 'orderbook.50.ETHUSDT']);
  assert.deepStrictEqual(ws.sent.map(x => JSON.parse(x).method), ['sub.ticker', 'sub.kline', 'sub.depth.full']);
  assert.strictEqual(JSON.parse(ws.sent[0]).param.symbol, 'ETH_USDT');
  ws.emit('message', JSON.stringify({ channel: 'push.ticker', symbol: 'ETH_USDT', data: { symbol: 'ETH_USDT', lastPrice: 2000, fairPrice: 2001, fundingRate: 0.0002 } }));
  ws.emit('message', JSON.stringify({ channel: 'push.kline', symbol: 'ETH_USDT', data: { symbol: 'ETH_USDT', interval: 'Min15', t: 1700000000, o: 1, h: 2, l: 0.5, c: 1.5, q: 100, a: 150 } }));
  ws.emit('message', JSON.stringify({ channel: 'push.depth.full', symbol: 'ETH_USDT', data: { bids: [[1999, 10, 20]], asks: [[2001, 10, 30]] } }));
  ws.emit('message', JSON.stringify({ channel: 'pong', data: 1 }));
  assert.strictEqual(s.getTickerMap().ETHUSDT.lastPrice, 2000);
  assert.strictEqual(s.getKline('ETHUSDT', '15').volume, 10);
  assert.strictEqual(s.getBook('ETHUSDT').bids.length, 1);
  s.stop();
});
test('facade lists bitget with websocket, and live gate demands passphrase', () => {
  const ex = require('../src/exchanges');
  const b = ex.info().adapters.find(a => a.id === 'bitget');
  assert.ok(b && b.websocket === true && ex.info().adapters.find(a => a.id === 'mexc').websocket === true);
});
test('placeOrder builds a correct signed one-way isolated order (mocked HTTP, nothing is sent)', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: 'classic' });
  I.resetCache();
  const origFetch = global.fetch; const calls = [];
  global.fetch = async (url, opts) => {
    calls.push({ url, opts }); const path = new URL(url).pathname;
    const data = path.endsWith('/contracts') ? [{ symbol: 'BTCUSDT', priceEndStep: '1', pricePlace: '1', sizeMultiplier: '0.001', volumePlace: '3', minTradeNum: '0.001', quoteCoin: 'USDT', symbolType: 'perpetual' }]
      : path.endsWith('/accounts') ? [{ marginCoin: 'USDT', posMode: 'one_way_mode' }] : path.endsWith('/place-order') ? { orderId: '42', clientOid: 'c1' } : {};
    return { ok: true, json: async () => ({ code: '00000', msg: 'success', data }) };
  };
  try {
    const r = await bitget.placeOrder({ symbol: 'BTCUSDT', side: 'Sell', qty: 0.01279, orderType: 'Limit', price: 65000.123, leverage: 10, clientOrderId: 'c1', stopLoss: 66000.55, takeProfit: 63000 });
    assert.strictEqual(r.orderId, '42'); assert.strictEqual(r.qty, 0.012);
    const post = calls.filter(c => c.opts.method === 'POST'); assert.strictEqual(post.length, 2);   // set-leverage + place-order
    const order = JSON.parse(post[1].opts.body);
    assert.deepStrictEqual({ s: order.size, p: order.price, side: order.side, m: order.marginMode, r: order.reduceOnly, sl: order.presetStopLossPrice, tp: order.presetStopSurplusPrice },
      { s: '0.012', p: '65000.1', side: 'sell', m: 'isolated', r: 'NO', sl: '66000.6', tp: '63000.0' });
    for (const h of ['ACCESS-KEY', 'ACCESS-SIGN', 'ACCESS-TIMESTAMP', 'ACCESS-PASSPHRASE']) assert.ok(post[1].opts.headers[h], h);
  } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('placeOrder refuses hedge mode instead of changing the account', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: 'classic' });
  I.resetCache();
  const origFetch = global.fetch; let posts = 0;
  global.fetch = async (url, opts) => { if (opts.method === 'POST') posts++; const path = new URL(url).pathname;
    const data = path.endsWith('/contracts') ? [{ symbol: 'BTCUSDT', priceEndStep: '1', pricePlace: '1', sizeMultiplier: '0.001', volumePlace: '3', minTradeNum: '0.001', quoteCoin: 'USDT', symbolType: 'perpetual' }] : [{ marginCoin: 'USDT', posMode: 'hedge_mode' }];
    return { ok: true, json: async () => ({ code: '00000', data }) }; };
  try { await assert.rejects(() => bitget.placeOrder({ symbol: 'BTCUSDT', side: 'Buy', qty: 0.01, orderType: 'Market' }), /one_way_mode/); assert.strictEqual(posts, 0); }
  finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});

const mockUta = (settings, calls) => async (url, opts) => {
  const u = new URL(url); calls.push({ path: u.pathname, q: u.search, opts }); const p = u.pathname;
  const data = p.endsWith('/contracts') ? [{ symbol: 'BTCUSDT', priceEndStep: '1', pricePlace: '1', sizeMultiplier: '0.001', volumePlace: '3', minTradeNum: '0.001', quoteCoin: 'USDT', symbolType: 'perpetual' }]
    : p === '/api/v3/account/settings' ? settings : p === '/api/v3/trade/place-order' ? { orderId: '77', clientOid: 'c9' }
    : p === '/api/v3/position/current-position' ? { list: [{ symbol: 'BTCUSDT', posSide: 'long', total: '0.01', avgPrice: '100', markPrice: '101', unrealisedPnl: '0.01', leverage: '10', positionBalance: '0.1', liqPrice: '91', marginMode: 'isolated' }] }
    : p === '/api/v3/account/assets' ? { accountEquity: '120.5', unrealisedPnl: '0.01', assets: [{ coin: 'USDT', available: '100.2' }] } : {};
  return { ok: true, json: async () => ({ code: '00000', msg: 'success', data }) };
};
test('UTA: order is sent to /api/v3 one-way, isolated, reduceOnly flag, TP/SL presets, 32-char clientOid rule', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: 'uta' }); I.resetCache();
  const origFetch = global.fetch; const calls = []; global.fetch = mockUta({ holdMode: 'one_way_mode' }, calls);
  try {
    const r = await bitget.placeOrder({ symbol: 'BTCUSDT', side: 'Buy', qty: 0.01279, orderType: 'Limit', price: 65000.123, leverage: 10, clientOrderId: 'c9', stopLoss: 64000.55, takeProfit: 67000 });
    assert.strictEqual(r.orderId, '77'); assert.strictEqual(r.qty, 0.012);
    const body = JSON.parse(calls.find(c => c.path === '/api/v3/trade/place-order').opts.body);
    assert.deepStrictEqual({ cat: body.category, qty: body.qty, p: body.price, side: body.side, m: body.marginMode, ro: body.reduceOnly, sl: body.stopLoss, tp: body.takeProfit, tif: body.timeInForce, noPos: body.posSide, noMC: body.marginCoin },
      { cat: 'USDT-FUTURES', qty: '0.012', p: '65000.1', side: 'buy', m: 'isolated', ro: 'no', sl: '64000.6', tp: '67000.0', tif: 'gtc', noPos: undefined, noMC: undefined });
    assert.ok(calls.some(c => c.path === '/api/v3/account/set-leverage'));
    await assert.rejects(() => bitget.placeOrder({ symbol: 'BTCUSDT', side: 'Buy', qty: 0.01, orderType: 'Market', clientOrderId: 'x'.repeat(40) }), /clientOid/);
  } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('UTA: hedge mode or unreadable mode refuses to trade; nothing is posted', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: 'uta' }); I.resetCache();
  const origFetch = global.fetch;
  try {
    for (const settings of [{ holdMode: 'hedge_mode' }, {}]) {
      const calls = []; global.fetch = mockUta(settings, calls);
      await assert.rejects(() => bitget.placeOrder({ symbol: 'BTCUSDT', side: 'Buy', qty: 0.01, orderType: 'Market' }), /one-way|Cannot confirm/);
      assert.strictEqual(calls.filter(c => c.opts.method === 'POST').length, 0);
    }
  } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('UTA: positions and balance map to the robot shape', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: 'uta' }); I.resetCache();
  const origFetch = global.fetch; global.fetch = mockUta({ holdMode: 'one_way_mode' }, []);
  try {
    const pos = await bitget.getPositions(); assert.strictEqual(pos[0].side, 'LONG'); assert.strictEqual(pos[0].qty, 0.01); assert.strictEqual(pos[0].liquidationPrice, 91); assert.strictEqual(pos[0].margin, 0.1);
    const bal = await bitget.getAccountBalance(); assert.strictEqual(bal.equity, 120.5); assert.strictEqual(bal.available, 100.2); assert.strictEqual(bal.margin, 0.1);
  } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('auto account type: UTA when /account/settings works, Classic when Bitget says no', async () => {
  const config = require('../src/config'); const saved = { ...config.bitget };
  Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: 'auto' }); I.resetCache();
  const origFetch = global.fetch;
  try {
    global.fetch = mockUta({ holdMode: 'one_way_mode' }, []); assert.strictEqual(await bitget.accountType(), 'uta');
    I.resetCache();
    global.fetch = async () => ({ ok: true, json: async () => ({ code: '40084', msg: 'not a UTA account', data: null }) });
    assert.strictEqual(await bitget.accountType(), 'classic');
  } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});

const setCfg = (type) => { const config = require('../src/config'); const saved = { ...config.bitget }; Object.assign(config.bitget, { apiKey: 'k', apiSecret: 's', passphrase: 'p', baseUrl: 'https://mock', accountType: type }); I.resetCache(); return { config, saved }; };
const posRow = { symbol: 'BTCUSDT', posSide: 'long', total: '0.01', avgPrice: '100', markPrice: '101', unrealisedPnl: '0.01', leverage: '10', positionBalance: '0.1', liqPrice: '91' };
const contractRow = { symbol: 'BTCUSDT', priceEndStep: '1', pricePlace: '1', sizeMultiplier: '0.001', volumePlace: '3', minTradeNum: '0.001', quoteCoin: 'USDT', symbolType: 'perpetual' };

test('UTA: stop-loss and take-profit are read back from tpsl strategy orders (type=tpsl, pending only, one-way side inference)', async () => {
  const { config, saved } = setCfg('uta'); const origFetch = global.fetch; const calls = [];
  global.fetch = async (url, opts) => { const u = new URL(url); calls.push(u); const p = u.pathname;
    const data = p.endsWith('/contracts') ? [contractRow] : p === '/api/v3/trade/unfilled-strategy-orders' ? { list: [
      { orderId: 'A1', symbol: 'BTCUSDT', side: 'sell', posSide: '', stopLoss: '95', takeProfit: '110', status: 'pending' },
      { orderId: 'A2', symbol: 'BTCUSDT', side: 'buy', stopLoss: '120', status: 'cancelled' }] } : {};
    return { ok: true, json: async () => ({ code: '00000', data }) }; };
  try {
    const s = await bitget.getStopOrders('BTCUSDT');
    assert.strictEqual(s.length, 1); assert.strictEqual(s[0].long, true); assert.strictEqual(s[0].stopLoss, 95); assert.strictEqual(s[0].takeProfit, 110); assert.strictEqual(s[0].slOrderId, 'A1');
    assert.strictEqual(calls.find(u => u.pathname.endsWith('unfilled-strategy-orders')).searchParams.get('type'), 'tpsl');
  } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('Classic: pos_loss / pos_profit plan orders (set in the app) and loss_plan are both read back', async () => {
  const { config, saved } = setCfg('classic'); const origFetch = global.fetch;
  global.fetch = async (url) => { const p = new URL(url).pathname;
    const data = p.endsWith('/contracts') ? [contractRow] : p.endsWith('orders-plan-pending') ? { entrustedList: [
      { orderId: 'P1', symbol: 'BTCUSDT', planType: 'pos_loss', triggerPrice: '95', side: 'sell', posSide: 'long' },
      { orderId: 'P2', symbol: 'BTCUSDT', planType: 'pos_profit', triggerPrice: '110', side: 'sell', posSide: 'long' }] } : {};
    return { ok: true, json: async () => ({ code: '00000', data }) }; };
  try { const s = await bitget.getStopOrders('BTCUSDT'); assert.strictEqual(s[0].stopLoss, 95); assert.strictEqual(s[0].takeProfit, 110); assert.strictEqual(s[0].long, true); assert.strictEqual(s[0].slOrderId, 'P1'); }
  finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
});
test('trailing: setTradingStop modifies the existing stop order (UTA and Classic), places one when none exists', async () => {
  for (const type of ['uta', 'classic']) {
    const { config, saved } = setCfg(type); const origFetch = global.fetch; let stopsPresent = true; const posts = [];
    global.fetch = async (url, opts) => { const u = new URL(url); const p = u.pathname; if (opts.method === 'POST') posts.push({ p, b: JSON.parse(opts.body) });
      const data = p.endsWith('/contracts') ? [contractRow]
        : p === '/api/v3/position/current-position' ? { list: [posRow] }
        : p === '/api/v2/mix/position/all-position' ? [{ symbol: 'BTCUSDT', holdSide: 'long', total: '0.01', openPriceAvg: '100', marginSize: '0.1', leverage: '10', marginMode: 'isolated' }]
        : p === '/api/v3/trade/unfilled-strategy-orders' ? { list: stopsPresent ? [{ orderId: 'S1', symbol: 'BTCUSDT', posSide: 'long', side: 'sell', stopLoss: '95', status: 'pending' }] : [] }
        : p.endsWith('orders-plan-pending') ? { entrustedList: stopsPresent ? [{ orderId: 'S1', symbol: 'BTCUSDT', planType: 'pos_loss', triggerPrice: '95', side: 'sell', posSide: 'long' }] : [] } : {};
      return { ok: true, json: async () => ({ code: '00000', data }) }; };
    try {
      await bitget.setTradingStop({ symbol: 'BTCUSDT', stopLoss: 99.456 });
      const mod = posts.find(x => /modify-(strategy|tpsl)-order/.test(x.p)); assert.ok(mod, `${type}: modify call`); assert.strictEqual(mod.b.orderId, 'S1');
      assert.strictEqual(String(mod.b.stopLoss || mod.b.triggerPrice), '99.5');
      posts.length = 0; stopsPresent = false;
      await bitget.setTradingStop({ symbol: 'BTCUSDT', stopLoss: 99.456 });
      assert.ok(posts.find(x => /place-(strategy|tpsl)-order/.test(x.p)), `${type}: place call`);
    } finally { global.fetch = origFetch; Object.assign(config.bitget, saved); I.resetCache(); }
  }
});
