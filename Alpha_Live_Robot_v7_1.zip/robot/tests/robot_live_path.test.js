'use strict';
const test = require('node:test');
const assert = require('node:assert');
const config = require('../src/config');
const OrderManager = require('../src/execution/orderManager');
const { TradingRobot } = (() => { const m = require('../src/robot'); return { TradingRobot: m.TradingRobot || m }; })();

function mem() { const m = {}; return { get: k => m[k] ?? null, set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); } }; }
const sig = { id: 'q1', symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104, riskReward: 2.7, strategy: 'GPS', timestamp: 5 };

test('live entry path: unauthorised -> nothing sent; authorised -> sized to slot, one order, duplicate blocked', async (t) => {
  const Robot = TradingRobot;
  if (typeof Robot !== 'function') return t.skip('robot class not exported');
  const placed = [];
  const ex = { placed, getPositions: async () => [], getStopOrders: async () => [], getOrder: async () => null,
    placeOrder: async (p) => { placed.push(p); return { orderId: 'A1', clientOrderId: p.clientOrderId }; }, cancelOrder: async () => ({}) };
  const saved = { mode: config.mode, le: config.liveEnabled, ex: config.exchange, isLive: config.isLive, k: config.mexc.apiKey, s: config.mexc.apiSecret };
  Object.assign(config, { mode: 'LIVE', liveEnabled: true, exchange: 'mexc', isLive: true }); config.mexc.apiKey = 'k'; config.mexc.apiSecret = 's';
  try {
    const r = new Robot(); r.paused = false;   // v5.2.4: Take Live Trades starts OFF; this test switches it ON
    r.liveExecution.orders = new OrderManager({ exchange: ex, store: mem() });
    r.riskEngine.cfg.scalingEnabled = true;
    r.riskEngine.refreshProfile({ equity: 20, peakEquity: 20 });
    r.riskEngine.cfg.accountBalance = 20;
    r._liveOk = true; r._livePositions = [];
    require('../src/exchanges/rules').getRules = () => ({ qtyStep: 0.01, minQty: 0.01, minNotional: 1 });
    require('../src/exchanges/rules').refresh = async () => ({});

    const locked = await r._openLive(sig);
    assert.strictEqual(locked.ok, false); assert.match(locked.reason, /NOT_AUTHORIZED/); assert.strictEqual(placed.length, 0);

    r.liveExecution.confirmLiveMode();
    const ok = await r._openLive(sig);
    assert.ok(ok.ok, ok.reason); assert.strictEqual(placed.length, 1);
    assert.ok(placed[0].qty * 1.5 <= 20 * 0.015 + 1e-9);               // risk <= 1.5% of $20 = $0.30
    assert.strictEqual(placed[0].leverage, 10);
    const again = await r._openLive({ ...sig });                        // same signal again
    assert.strictEqual(placed.length, 1);

    r._liveOk = false;
    assert.match((await r._openLive({ ...sig, id: 'q2', symbol: 'ETHUSDT' })).reason, /UNVERIFIED/);   // fails closed
  } finally { Object.assign(config, { mode: saved.mode, liveEnabled: saved.le, exchange: saved.ex, isLive: saved.isLive }); config.mexc.apiKey = saved.k; config.mexc.apiSecret = saved.s; }
});

test('live gate: non-isolated Bybit account margin mode pauses entries (fail closed)', async (t) => {
  const bybit = require('../src/exchanges');
  const Robot = require('../src/robot');
  const saved = { mode: config.mode, le: config.liveEnabled, ex: config.exchange, isLive: config.isLive };
  Object.assign(config, { mode: 'LIVE', liveEnabled: true, exchange: 'bybit', isLive: true });
  const fake = { getAccountBalance: async () => ({ equity: 25, available: 25 }), getPositions: async () => [], getMarginMode: async () => 'REGULAR_MARGIN', getClosedTrades: async () => [], getOrder: async () => null, getStopOrders: async () => [] };
  bybit._use(fake);
  try { const r = new Robot(); await r._liveCycle(); assert.strictEqual(r._liveOk, false); }
  finally { bybit._use(null); Object.assign(config, { mode: saved.mode, liveEnabled: saved.le, exchange: saved.ex, isLive: saved.isLive }); }
});
