'use strict';
process.env.TRADING_MODE = 'SIM';
const test = require('node:test');
const assert = require('node:assert');
const portfolio = require('../src/risk/portfolio');
const governor = require('../src/risk/governor');
const intel = require('../src/market/intel');
const gate = require('../src/risk/gate');
const flags = require('../src/features/flags');
const pcfg = require('../src/protection/config');
const journal = require('../src/journal/store');
const extras = require('../src/journal/extras');
const perf = require('../src/validation/perf');
const PaperEngine = require('../src/paper/engine');

const walk = (seed, n = 60) => { let x = 100, a = seed, out = []; for (let i = 0; i < n; i++) { a = (a * 9301 + 49297) % 233280; x *= 1 + ((a / 233280) - 0.5) * 0.02; out.push(x); } return out; };
const pos = (symbol, side, qty = 1, entry = 100, stop = 98) => ({ symbol, side, qty, entry, stop, mark: entry, leverage: 5 });

test('portfolio: aggregate stop risk, locked profit counts as zero risk, missing stop is flagged', () => {
  const s = portfolio.snapshot([pos('A', 'LONG', 1, 100, 98), pos('B', 'LONG', 2, 100, 101), { ...pos('C', 'SHORT'), stop: null }], 1000);
  assert.equal(s.aggRisk, 2); assert.deepEqual(s.unknownStops, ['C']);
});
test('portfolio: correlated same-direction positions group; opposite direction is a hedge, not added', () => {
  const base = walk(7), ret = { A: portfolio.returnsFromCloses(base), B: portfolio.returnsFromCloses(base.map(v => v * 1.01)), C: portfolio.returnsFromCloses(base) };
  const same = portfolio.snapshot([pos('A', 'LONG'), pos('B', 'LONG')], 1000, ret, 0.75);
  assert.equal(same.groups.length, 1); assert.equal(same.topGroup.symbols.length, 2);
  const hedge = portfolio.snapshot([pos('A', 'LONG'), pos('C', 'SHORT')], 1000, ret, 0.75);
  assert.equal(hedge.groups.length, 2);
});
test('portfolio: entry check blocks on aggregate-risk and correlated-group caps; risk never silently raised', () => {
  const base = walk(3), ret = { A: portfolio.returnsFromCloses(base), N: portfolio.returnsFromCloses(base) };
  const snap = portfolio.snapshot([pos('A', 'LONG', 10, 100, 98)], 1000, ret, 0.75);      // 20 risk = 2%
  const caps = { aggRiskPct: 8, corrRiskPct: 3, dirNotionalPct: 80, corrThreshold: 0.75 };
  const r = portfolio.checkEntry({ symbol: 'N', direction: 'LONG', riskUsd: 15, notional: 500 }, snap, caps, ret);
  assert.equal(r.allowed, false); assert.match(r.reasons.join(), /CORRELATION/);
  const r2 = portfolio.checkEntry({ symbol: 'N', direction: 'LONG', riskUsd: 70, notional: 500 }, snap, { ...caps, corrRiskPct: 50 }, ret);
  assert.match(r2.reasons.join(), /aggregate/);
});
test('governor: levels escalate, emergency latches through a daily reset until acknowledged', () => {
  const t0 = Date.UTC(2026, 9, 21, 10); const m = 'tg' + Date.now();
  assert.equal(governor.update(m, 1000, t0).level, 'NORMAL');
  assert.equal(governor.update(m, 975, t0 + 1000).level, 'CAUTION');
  assert.equal(governor.update(m, 960, t0 + 2000).level, 'DEFENSIVE');
  assert.equal(governor.update(m, 945, t0 + 3000).level, 'ENTRY_HALT');
  assert.equal(governor.update(m, 910, t0 + 4000).level, 'EMERGENCY');
  const next = governor.update(m, 1000, t0 + 26 * 3600e3);                                 // new UTC day, equity recovered
  assert.equal(next.level, 'EMERGENCY');
  assert.equal(governor.acknowledge(m), true);
  assert.notEqual(governor.update(m, 1000, t0 + 27 * 3600e3).level, 'EMERGENCY');
});
test('governor: baselines persist (daily start survives a fresh read) and weekly/account drawdown halt entries', () => {
  const m = 'tw' + Date.now(), t0 = Date.UTC(2026, 9, 19, 9);
  governor.update(m, 1000, t0);
  const g = governor.update(m, 890, t0 + 3 * 86400e3);                                      // day 4: daily dd ~0, weekly 11%
  assert.equal(g.level, 'ENTRY_HALT'); assert.match(g.reasons.join(), /weekly/);
  assert.equal(governor.get(m).weekStart, 1000);
});
test('intel: unknown stays UNKNOWN, buy/sell flow is UNAVAILABLE, sentiment from breadth', () => {
  const tk = (n, ch) => Array.from({ length: n }, (_, i) => ({ symbol: 'S' + i + 'USDT', turnover24h: String(1e6 + i), price24hPcnt: String(ch), fundingRate: '0.0001' }));
  const r = intel.compute({ tickers: tk(40, 0.03), candles: {}, now: 1e12 }).intel;
  assert.equal(r.flow.status, 'UNAVAILABLE'); assert.equal(r.volume.changePct, null); assert.equal(r.btc.trend, 'UNKNOWN');
  assert.ok(r.breadth.upPct === 100);
  assert.equal(r.sentiment.label, 'UNKNOWN');                                               // too few components -> no fake verdict
});
test('intel: shock enters immediately, leaves only after hold time', () => {
  const mk = (n, i = 0) => Array.from({ length: n }, (_, k) => ({ time: k, open: 100, high: 101, low: 99, close: 100 + (k === n - 1 ? i : 0), volume: 1 }));
  const k = (move) => ({ '4h': mk(60), '1h': mk(60, move), '15m': mk(60) });
  let r = intel.compute({ tickers: [], candles: { BTCUSDT: k(5), ETHUSDT: k(0) }, now: 1e12 });
  assert.equal(r.intel.regime.state, 'MARKET_SHOCK');
  r = intel.compute({ tickers: [], candles: { BTCUSDT: k(0), ETHUSDT: k(0) }, now: 1e12 + 5 * 60e3, prevRegime: r.regimeState });
  assert.equal(r.intel.regime.state, 'MARKET_SHOCK');                                       // hysteresis: still shocked after 5 min
});
test('gate: stale data, governor halt and regime shock block; everything OFF changes nothing', async () => {
  for (const k of Object.keys(flags.all())) flags.set(k, false);
  const base = { f: flags.all(), caps: pcfg.get(), intel: null, gov: { block: true, level: 'ENTRY_HALT', reasons: ['x'] }, snap: portfolio.snapshot([], 1000), returns: {}, equity: 1000, minScore: 70, riskPerTrade: 0.01, runMode: 'TESTNET', now: Date.now(), bias: {}, positions: [] };
  const sig = { symbol: 'X', direction: 'LONG', entry: 100, stopLoss: 98, score: 80 };
  assert.equal((await gate.check(sig, base)).allowed, true);
  assert.match((await gate.check(sig, { ...base, f: { ...base.f, staleDataBlock: true } })).reasons[0], /STALE_DATA/);
  assert.match((await gate.check(sig, { ...base, f: { ...base.f, lossGovernor: true } })).reasons[0], /GOVERNOR: ENTRY_HALT/);
  const shock = { ts: Date.now(), regime: { state: 'MARKET_SHOCK' }, shock: { btc1hPct: -4 }, bias: {} };
  assert.match((await gate.check(sig, { ...base, intel: shock, f: { ...base.f, regimeFilter: true } })).reasons[0], /MARKET_SHOCK/);
  flags.set('directionControl', true); flags.set('staleDataBlock', true);
});
test('gate: CAUTION raises the score bar instead of halting', async () => {
  const f = { ...flags.all(), lossGovernor: true };
  const ctx = { f, caps: pcfg.get(), intel: null, gov: { block: false, level: 'CAUTION', minScoreAdd: 5, reasons: [] }, snap: portfolio.snapshot([], 1000), returns: {}, equity: 1000, minScore: 70, riskPerTrade: 0.01, runMode: 'SIM', now: Date.now(), bias: {}, positions: [] };
  assert.equal((await gate.check({ symbol: 'X', direction: 'LONG', entry: 1, stopLoss: 0.9, score: 72 }, ctx)).allowed, false);
  assert.equal((await gate.check({ symbol: 'X', direction: 'LONG', entry: 1, stopLoss: 0.9, score: 76 }, ctx)).allowed, true);
});
test('settings: bounded, persisted, rejected when out of range', () => {
  assert.throws(() => pcfg.set('staleHours', 0)); assert.throws(() => pcfg.set('nope', 1)); assert.throws(() => pcfg.set('govEmergencyAction', 'EXPLODE'));
  assert.equal(pcfg.set('staleHours', 6).staleHours, 6); pcfg.set('staleHours', 8);
});
test('paper: partial close books realised P&L, shrinks size, final close totals include the partial', () => {
  const e = new PaperEngine(); const bal0 = e.balance;
  const t = { id: 'P1', symbol: 'SOLUSDT', strategyId: 'gps_v1', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 106, positionSize: 10, cluster: 'ALT_GENERAL', openTime: Date.now() - 1000, initialRisk: 2, initialStopLoss: 98 };
  e.openTrades.set('SOLUSDT_gps_v1', t); e.riskEngine.state.totalExposure = 1000;
  const rec = e.partialClose('P1', 0.3, 104, 50);
  assert.equal(t.positionSize, 7); assert.ok(rec.net > 11 && rec.net < 12); assert.ok(e.balance > bal0);
  const c = e.closeTrade('P1', 'TEST', 102);
  assert.ok(Math.abs(c.pnl - (rec.net + (102 - 100) * 7 - 7 * 100 * 0.00055 - 7 * 102 * 0.00055)) < 0.05, 'closed pnl = partial + remainder');
  assert.equal(e.partialClose('nope', 0.3, 1), null);
});
test('journal extras + performance: additive table, metrics by direction, low-sample flag', () => {
  extras.merge('X1', { resultR: 1.5, givebackFromPeak: 0.2, peakR: 2 }); extras.merge('X1', { exitReason: 'STAGE' });
  assert.equal(extras.get('X1').resultR, 1.5); assert.equal(extras.get('X1').exitReason, 'STAGE');
  const d = journal.getDb();
  d.prepare("INSERT OR REPLACE INTO paper_trades (id,strategy_name,direction,regime,pnl,fee,initial_risk,exit_reason,close_time,symbol) VALUES ('X1','GPS','LONG','BULL',3,0.1,2,'STAGE',1,'A'),('X2','GPS','SHORT','BULL',-1,0.1,2,'SL',2,'B')").run();
  const p = perf.build();
  assert.ok(p.overall.n >= 2 && p.overall.lowSample === true); assert.ok(p.byDirection.LONG && p.byDirection.SHORT);
  d.prepare("DELETE FROM paper_trades WHERE id IN ('X1','X2')").run();
});
