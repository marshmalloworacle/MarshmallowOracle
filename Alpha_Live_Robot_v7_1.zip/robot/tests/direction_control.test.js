'use strict';
process.env.TRADING_MODE = 'SIM';
const test = require('node:test');
const assert = require('node:assert');
const dir = require('../src/control/direction');
const flags = require('../src/features/flags');

test('LONG_ONLY blocks SHORT, allows LONG; BOTH restores', () => {
  flags.set('directionControl', true);
  dir.set('LONG_ONLY', { hours: null });
  assert.equal(dir.check('SHORT').allowed, false);
  assert.equal(dir.check('LONG').allowed, true);
  dir.set('BOTH');
  assert.equal(dir.check('SHORT').allowed, true);
});
test('PAUSE blocks both; timed override expires back to the previous mode (lazy, restart-safe)', () => {
  const t0 = Date.now();
  dir.set('BOTH');
  dir.set('PAUSE', { hours: 1, now: t0 });
  assert.equal(dir.check('LONG', t0 + 1000).allowed, false);
  assert.ok(dir.get(t0 + 1000).remainingMs > 0);
  assert.equal(dir.get(t0 + 3601e3).mode, 'BOTH');
  assert.equal(dir.check('SHORT', t0 + 3601e3).allowed, true);
});
test('blocked entries are counted with reasons', () => {
  dir.set('SHORT_ONLY');
  const before = dir.get().blocked;
  dir.check('LONG');
  assert.equal(dir.get().blocked, before + 1);
  dir.set('BOTH');
});
test('feature off => direction ignored', () => {
  dir.set('PAUSE'); flags.set('directionControl', false);
  assert.equal(dir.check('LONG').allowed, true);
  flags.set('directionControl', true); dir.set('BOTH');
});
test('invalid mode / duration rejected', () => {
  assert.throws(() => dir.set('NOPE'));
  assert.throws(() => dir.set('PAUSE', { hours: -1 }));
});
