'use strict';
const test = require('node:test');
const assert = require('node:assert');
const crypto = require('node:crypto');
const config = require('../src/config');
const mexc = require('../src/exchanges/mexc');
const { toMexc, fromMexc, sign, paramString, resetCache } = mexc._internals;

const DETAIL = [{ symbol: 'SOL_USDT', baseCoin: 'SOL', quoteCoin: 'USDT', settleCoin: 'USDT', state: 0, contractSize: 1, volUnit: 1, minVol: 1, maxVol: 1e6,
  priceUnit: 0.01, maxLeverage: 50, apiAllowed: true, takerFeeRate: 0.0002, makerFeeRate: 0, maintenanceMarginRate: 0.01 },
  { symbol: 'BTC_USDT', baseCoin: 'BTC', quoteCoin: 'USDT', settleCoin: 'USDT', state: 0, contractSize: 0.0001, volUnit: 1, minVol: 1, maxVol: 5e6, priceUnit: 0.5, maxLeverage: 125, apiAllowed: false },
  { symbol: 'OLD_USDT', baseCoin: 'OLD', quoteCoin: 'USDT', settleCoin: 'USDT', state: 3, contractSize: 1, volUnit: 1, minVol: 1, maxVol: 1, priceUnit: 1, maxLeverage: 5 }];

function mockFetch(routes, log = []) {
  globalThis.fetch = async (url, opts = {}) => {
    log.push({ url, opts });
    const u = new URL(url);
    const hit = routes[`${opts.method || 'GET'} ${u.pathname}`];
    if (!hit) return { ok: false, status: 404, json: async () => ({}) };
    const r = typeof hit === 'function' ? hit(u, opts) : hit;
    if (r instanceof Error) throw r;
    return { ok: true, status: 200, json: async () => r };
  };
  return log;
}
const realFetch = globalThis.fetch;
test.beforeEach(() => { resetCache(); config.mexc.apiKey = 'AK'; config.mexc.apiSecret = 'SECRET'; });
test.after(() => { globalThis.fetch = realFetch; });

test('symbol conversion only at the boundary', () => {
  assert.strictEqual(toMexc('BTCUSDT'), 'BTC_USDT');
  assert.strictEqual(toMexc('SOL_USDT'), 'SOL_USDT');
  assert.strictEqual(fromMexc('BTC_USDT'), 'BTCUSDT');
});

test('signature = HMAC-SHA256(secret, accessKey + reqTime + params) in hex; GET params sorted + encoded', () => {
  assert.strictEqual(paramString('GET', { b: 'x y', a: 1, c: undefined }), 'a=1&b=x%20y');
  const expected = crypto.createHmac('sha256', 'SECRET').update('AK1700000000000a=1&b=2').digest('hex');
  assert.strictEqual(sign('SECRET', 'AK', '1700000000000', 'a=1&b=2'), expected);
  assert.strictEqual(paramString('POST', { symbol: 'X', vol: 1 }), '{"symbol":"X","vol":1}');
});

test('instruments: USDT perps only, qty in base units, apiAllowed carried through', async () => {
  mockFetch({ 'GET /api/v1/contract/detail': { success: true, code: 0, data: DETAIL } });
  const list = await mexc.getInstruments();
  assert.deepStrictEqual(list.map(i => i.symbol), ['SOLUSDT', 'BTCUSDT']);   // OLD (state 3) excluded
  const btc = list.find(i => i.symbol === 'BTCUSDT');
  assert.strictEqual(btc.lotSizeFilter.qtyStep, '0.0001');
  assert.strictEqual(btc.apiAllowed, false);
});

test('klines: seconds -> ms, volume converted by contract size', async () => {
  mockFetch({
    'GET /api/v1/contract/detail': { success: true, data: DETAIL },
    'GET /api/v1/contract/kline/BTC_USDT': { success: true, data: { time: [100, 200], open: [1, 2], close: [2, 3], high: [3, 4], low: [0.5, 1], vol: [10000, 20000], amount: [5, 6] } },
  });
  const k = await mexc.getKlines('BTCUSDT', '15', 200);
  assert.strictEqual(k[0].time, 100000);
  assert.strictEqual(k[1].volume, 2);   // 20000 contracts * 0.0001
});

test('private call sends ApiKey, Request-Time and a valid signature; secret never sent', async () => {
  const log = mockFetch({ 'GET /api/v1/private/account/asset/USDT': { success: true, data: { equity: 25.5, availableBalance: 20, positionMargin: 5.5, unrealized: 0.1 } } });
  const b = await mexc.getAccountBalance();
  assert.strictEqual(b.equity, 25.5);
  const h = log[0].opts.headers;
  assert.strictEqual(h.ApiKey, 'AK');
  assert.strictEqual(h.Signature, sign('SECRET', 'AK', h['Request-Time'], ''));
  assert.ok(!JSON.stringify(log[0]).includes('SECRET'));
});

test('placeOrder: base qty -> whole contracts, correct side codes, external id, TP/SL attached', async () => {
  const log = mockFetch({
    'GET /api/v1/contract/detail': { success: true, data: DETAIL },
    'POST /api/v1/private/order/submit': { success: true, code: 0, data: { orderId: '123' } },
  });
  const r = await mexc.placeOrder({ symbol: 'SOLUSDT', side: 'Sell', qty: 2.7, orderType: 'Limit', price: 150, leverage: 10, clientOrderId: 'gps_abc', stopLoss: 155, takeProfit: 140 });
  const body = JSON.parse(log.find(l => l.url.includes('submit')).opts.body);
  assert.deepStrictEqual([body.vol, body.side, body.type, body.openType, body.externalOid, body.stopLossPrice, body.takeProfitPrice], [2, 3, 1, 1, 'gps_abc', 155, 140]);
  assert.strictEqual(r.orderId, '123');
});

test('placeOrder refuses when apiAllowed=false (no request is sent)', async () => {
  const log = mockFetch({ 'GET /api/v1/contract/detail': { success: true, data: DETAIL } });
  await assert.rejects(() => mexc.placeOrder({ symbol: 'BTCUSDT', side: 'Buy', qty: 0.01, orderType: 'Market', leverage: 10 }), /apiAllowed=false/);
  assert.ok(!log.some(l => l.url.includes('submit')));
});

test('POST timeout is flagged ambiguous and is NOT retried', async () => {
  let posts = 0;
  mockFetch({ 'GET /api/v1/contract/detail': { success: true, data: DETAIL }, 'POST /api/v1/private/order/submit': () => { posts++; return new Error('timeout'); } });
  await assert.rejects(() => mexc.placeOrder({ symbol: 'SOLUSDT', side: 'Buy', qty: 1, orderType: 'Market', leverage: 5 }), e => e.ambiguous === true);
  assert.strictEqual(posts, 1);
});

test('API-level failure surfaces code and message without credentials', async () => {
  mockFetch({ 'GET /api/v1/private/position/open_positions': { success: false, code: 602, message: 'Verify failed' }, 'GET /api/v1/contract/detail': { success: true, data: DETAIL } });
  await assert.rejects(() => mexc.getPositions(), e => e.code === 602 && !/SECRET/.test(e.message));
});

test('order state mapping: partial fill and statuses', () => {
  const m = mexc._internals.mapOrder({ orderId: 1, symbol: 'SOL_USDT', state: 2, dealVol: 1, vol: 3, side: 1, externalOid: 'c1' });
  assert.strictEqual(m.status, 'PartiallyFilled');
  assert.strictEqual(mexc._internals.mapOrder({ orderId: 2, symbol: 'SOL_USDT', state: 3, side: 2 }).reduceOnly, true);
});

test('wrong host (api.mexc.com is SPOT) is refused before any request is sent', async () => {
  const log = mockFetch({});
  const saved = config.mexc.baseUrl; config.mexc.baseUrl = 'https://api.mexc.com';
  try {
    await assert.rejects(() => mexc.getAccountBalance(), e => e.code === 'WRONG_HOST' && /contract\.mexc\.com/.test(e.message));
    assert.strictEqual(log.length, 0);
  } finally { config.mexc.baseUrl = saved; }
});

test('HTTP 401 / code 1005 surface MEXC detail and a plain-English next step (no secrets)', async () => {
  globalThis.fetch = async () => ({ ok: false, status: 401, json: async () => ({ success: false, code: 1005, message: 'Network error' }) });
  await assert.rejects(() => mexc.getAccountBalance(), (e) => {
    assert.match(e.message, /HTTP 401/); assert.match(e.message, /Network error/);
    const why = mexc.explain(e); assert.match(why, /FUTURES permission/); assert.ok(!/SECRET|AK/.test(why + e.message));
    return true;
  });
  assert.match(mexc.explain({ code: 406 }), /whitelist/);
  assert.match(mexc.explain({ code: 703 }), /Futures read/);
});

test('closed trades map realised PnL for live stats', async () => {
  mockFetch({ 'GET /api/v1/contract/detail': { success: true, data: DETAIL }, 'GET /api/v1/private/position/list/history_positions': { success: true, data: [
    { symbol: 'SOL_USDT', state: 3, positionType: 2, closeVol: 3, openAvgPrice: 150, closeAvgPrice: 148, realised: 0.42, totalFee: 0.02, updateTime: 1700000000000 }, { symbol: 'ETH_USDT', state: 1, realised: 9 }] } });
  const t = await mexc.getClosedTrades(10);
  assert.deepStrictEqual(t.map(x => [x.symbol, x.pnl, x.direction, x.qty, x.exit, x.fee]), [['SOLUSDT', 0.42, 'SHORT', 3, 148, 0.02]]);
});

test('verify() never calls a write endpoint', async () => {
  const log = mockFetch({
    'GET /api/v1/contract/ping': { success: true, data: Date.now() }, 'GET /api/v1/contract/detail': { success: true, data: DETAIL },
    'GET /api/v1/private/account/asset/USDT': { success: true, data: { equity: 7, availableBalance: 7 } },
    'GET /api/v1/private/position/open_positions': { success: true, data: [] }, 'GET /api/v1/private/order/list/open_orders': { success: true, data: [] } });
  const r = await mexc.verify();
  assert.ok(r.checks.find(c => c.name === 'account read').ok);
  assert.ok(log.every(l => (l.opts.method || 'GET') === 'GET'));
});
