'use strict';
process.env.TRADING_MODE = 'SIM';
const test = require('node:test');
const assert = require('node:assert');
const { evaluate, progress, isTighter } = require('../src/protection/stops');

const long = (o = {}) => ({ side: 'LONG', entry: 100, stop: 98, initialStop: 98, target: 106, mark: 100, atr: 1, openedAt: Date.now(), leverage: 10, ...o });
const short = (o = {}) => ({ side: 'SHORT', entry: 100, stop: 102, initialStop: 102, target: 94, mark: 100, atr: 1, openedAt: Date.now(), leverage: 10, ...o });
const on = { smartTrailing: true };

test('profit bases are distinct and explicit', () => {
  const p = long({ mark: 103 });
  assert.equal(progress(p, 'TP', 103), 50);          // 3 of 6 to target
  assert.equal(progress(p, 'R', 103), 150);          // 3 / 2 risk
  assert.equal(progress(p, 'PRICE', 103), 3);
  assert.equal(progress(p, 'MARGIN', 103), 30);      // 3% x 10x
});
test('v5.2: no stage below 15% of target; with ATR off the stop is unchanged', () => {
  const r = evaluate(long({ mark: 100.5, atr: 0 }), null, on);
  assert.equal(r.stage, null); assert.equal(r.stop, 98);
});
test('v5.2: trailing is armed from the open: ATR trail follows the peak before any stage, and never loosens', () => {
  let r = evaluate(long({ mark: 100.5, atr: 0.5 }), null, on);         // peak +0.5, trail = 100.5 - 1.5*0.5 = 99.75 (tighter than 98)
  assert.equal(r.stage, null); assert.ok(r.stop > 98 && r.stop < 100); assert.equal(r.reason, 'ATR_TRAIL_OPEN');
  const s1 = r.stop;
  r = evaluate(long({ mark: 99.9, stop: s1, atr: 0.5 }), r.state, on);  // pullback never loosens
  assert.equal(r.stop, s1);
  const off = evaluate(long({ mark: 100.5, atr: 0.5 }), null, { smartTrailing: false });
  assert.equal(off.stop, 98);
});
test('v5.2: first stage at 15% of target locks break-even + buffer', () => {
  const r = evaluate(long({ mark: 101, atr: 0 }), null, on);            // 16.7% of the way to TP
  assert.equal(r.stage, 15); assert.ok(r.stop > 100 && r.stop < 100.1);
});
test('LONG: stage 1 moves stop to break-even+buffer, later stages ratchet up only', () => {
  let r = evaluate(long({ mark: 102, atr: 0 }), null, on);      // 33% of TP, ATR off -> pure break-even lock
  assert.equal(r.stage, 30); assert.ok(r.stop > 100 && r.stop < 100.5);
  const s1 = r.stop;
  r = evaluate(long({ mark: 104.2, stop: s1, atr: 0 }), r.state, on);   // 70% of TP
  assert.ok(r.stop > s1);
  const s2 = r.stop;
  r = evaluate(long({ mark: 101, stop: s2, atr: 0 }), r.state, on);     // pullback must never loosen
  assert.equal(r.stop, s2);
});
test('SHORT mirror: stop only moves down', () => {
  let r = evaluate(short({ mark: 98 }), null, on);
  assert.equal(r.stage, 30); assert.ok(r.stop < 100);
  const s1 = r.stop;
  r = evaluate(short({ mark: 99.5, stop: s1 }), r.state, on);
  assert.equal(r.stop, s1);
  r = evaluate(short({ mark: 95, stop: s1 }), r.state, on);
  assert.ok(r.stop < s1);
});
test('stop never placed at/over the market', () => {
  const r = evaluate(long({ mark: 105.9, atr: 0.01 }), null, on);
  assert.ok(r.stop < 105.9);
});
test('feature off => nothing changes', () => {
  const r = evaluate(long({ mark: 105 }), null, { smartTrailing: false });
  assert.equal(r.stop, 98); assert.equal(r.partial, null); assert.equal(r.exit, null);
});
test('giveback tightens after peak retreat', () => {
  let r = evaluate(long({ mark: 104.5 }), null, { profitGiveback: true });
  r = evaluate(long({ mark: 102.5, stop: r.stop }), r.state, { profitGiveback: true });
  assert.equal(r.reason, 'GIVEBACK_TIGHTEN'); assert.ok(r.stop > 98);
});
test('partial exit fires once per step', () => {
  const cfg = { partial: { enabled: true, steps: [{ stage: 50, fraction: 0.3 }] } };
  let r = evaluate(long({ mark: 103.1 }), null, { partialExits: true }, cfg);
  assert.deepEqual(r.partial, { stage: 50, fraction: 0.3 });
  r.state.partialsDone.push(50);
  r = evaluate(long({ mark: 103.2 }), r.state, { partialExits: true }, cfg);
  assert.equal(r.partial, null);
});
test('stale exit: losing or going-nowhere trade closes after staleHours; winners keep trailing; profit closes at max hold', () => {
  const h = (n) => Date.now() - n * 3600e3;
  let r = evaluate(long({ mark: 99, openedAt: h(9) }), null, { timeExit: true });
  assert.equal(r.exit.reason, 'STALE_EXIT_LOSING');
  r = evaluate(long({ mark: 100.4, openedAt: h(9) }), null, { timeExit: true });          // tiny profit, <15% of target -> going nowhere
  assert.equal(r.exit.reason, 'STALE_EXIT_FLAT');
  r = evaluate(long({ mark: 99, openedAt: h(3) }), null, { timeExit: true });             // too young
  assert.equal(r.exit, null);
  r = evaluate(long({ mark: 104, openedAt: h(10), atr: 0 }), null, { timeExit: true, smartTrailing: true });   // 67% to target: a real winner
  assert.equal(r.exit, null);
  r = evaluate(long({ mark: 104, openedAt: h(25) }), null, { timeExit: true });
  assert.equal(r.exit.reason, 'TIME_EXIT_MAX_HOLD_PROFIT');
  r = evaluate(long({ mark: 99, openedAt: h(9) }), null, { timeExit: true }, { timeExit: { whenLosing: 'TIGHTEN' } });
  assert.equal(r.exit, null); assert.ok(r.stop > 98);                                     // legacy tighten option still available
  r = evaluate(long({ mark: 99, openedAt: h(6.5) }), null, { timeExit: true }, { timeExit: { staleHours: 6 } });
  assert.equal(r.exit.reason, 'STALE_EXIT_LOSING');                                       // 6h is configurable
});
test('isTighter direction helper', () => {
  assert.ok(isTighter('LONG', 98, 99)); assert.ok(!isTighter('LONG', 99, 98));
  assert.ok(isTighter('SHORT', 102, 101)); assert.ok(!isTighter('SHORT', 101, 102));
});
