'use strict';
process.env.TRADING_MODE = 'SIM';
const test = require('node:test');
const assert = require('node:assert');
const OrderManager = require('../src/execution/orderManager');
const PaperEngine = require('../src/paper/engine');
const dir = require('../src/control/direction');
const flags = require('../src/features/flags');
const journal = require('../src/journal/store');
const live = require('../src/protection/live');

const sig = (d) => ({ id: 's' + d, symbol: 'SOLUSDT', direction: d, entry: 100, stopLoss: d === 'LONG' ? 98.5 : 101.5, takeProfit: d === 'LONG' ? 104 : 96, strategy: 'GPS', timestamp: 1 });
const mem = () => { const m = {}; return { get: k => m[k] ?? null, set: (k, v) => { m[k] = JSON.parse(JSON.stringify(v)); }, m }; };

test('live entry path: LONG_ONLY blocks SHORT at the backend, no exchange order sent', async () => {
  flags.set('directionControl', true); dir.set('LONG_ONLY');
  const ex = { placed: [], getPositions: async () => [], placeOrder: async (p) => { ex.placed.push(p); return { orderId: 'X' }; } };
  const om = new OrderManager({ exchange: ex, store: mem() });
  const r = await om.submitEntry(sig('SHORT'), 1, {});
  assert.equal(r.success, false); assert.match(r.reason, /LONG ONLY/); assert.equal(ex.placed.length, 0);
  const ok = await om.submitEntry(sig('LONG'), 1, {});
  assert.equal(ok.success, true);
  dir.set('BOTH');
});
test('paper entry path: PAUSE blocks, BOTH restores', () => {
  const e = new PaperEngine();
  dir.set('PAUSE');
  const r = e.openFromSignal({ ...sig('LONG'), strategyId: 'gps', timestamp: Date.now() });
  assert.equal(r.action, 'SKIPPED'); assert.match(r.reason, /paused/);
  dir.set('BOTH');
});
test('existing positions keep protection while direction is restricted (protection runs independent of direction)', async () => {
  dir.set('PAUSE'); flags.set('smartTrailing', true);
  const calls = [];
  const ex = { setTradingStop: async (p) => { calls.push(p); ex.stop = p.stopLoss; }, getStopOrders: async () => [{ stopLoss: ex.stop, long: true }] };
  const pos = [{ symbol: 'SOLUSDT', side: 'LONG', qty: 1, entry: 100, stopLoss: 98, takeProfit: 106, markPrice: 104.5, createdTime: Date.now() - 3600e3, leverage: 10 }];
  const r = await live.run({ exchange: ex, orders: { list: () => [], closePosition: async () => ({ ok: true }) }, positions: pos });
  assert.equal(calls.length, 1); assert.ok(calls[0].stopLoss > 98); assert.ok(r.actions[0].verified);
  dir.set('BOTH'); flags.set('smartTrailing', false);
});
test('failed stop update: visible alert, no crash, old exchange stop untouched', async () => {
  flags.set('smartTrailing', true);
  const alerts = [];
  const ex = { setTradingStop: async () => { throw new Error('rate limited'); }, getStopOrders: async () => [] };
  const pos = [{ symbol: 'ETHUSDT', side: 'SHORT', qty: 1, entry: 100, stopLoss: 102, takeProfit: 94, markPrice: 97, createdTime: Date.now(), leverage: 10 }];
  const r = await live.run({ exchange: ex, orders: { list: () => [], closePosition: async () => ({ ok: true }) }, positions: pos, alert: (a) => alerts.push(a) });
  assert.ok(r.actions[0].error); assert.equal(alerts.length, 1); assert.match(alerts[0].message, /previous exchange stop is still active/);
  flags.set('smartTrailing', false);
});
test('time exit sends ONE close even across repeated cycles (idempotent)', async () => {
  flags.set('timeExit', true);
  let closes = 0;
  const orders = { list: () => [{ symbol: 'BTCUSDT', direction: 'LONG' }], closePosition: async () => { closes++; return { ok: true }; } };   // a record exists = opened by the robot
  const pos = [{ symbol: 'BTCUSDT', side: 'LONG', qty: 1, entry: 100, stopLoss: 98, takeProfit: 106, markPrice: 99, createdTime: Date.now() - 9 * 3600e3, leverage: 5 }];
  const ex = { setTradingStop: async () => {}, getStopOrders: async () => [] };
  await live.run({ exchange: ex, orders, positions: pos }); await live.run({ exchange: ex, orders, positions: pos });
  assert.equal(closes, 1);
  flags.set('timeExit', false);
  journal.setState('protection_state', {});
});
test('all protection features OFF => live protection does nothing (v4.5 behaviour)', async () => {
  for (const k of ['smartTrailing', 'profitGiveback', 'timeExit', 'riskTaper']) flags.set(k, false);
  const r = await live.run({ exchange: {}, orders: {}, positions: [{ symbol: 'X', side: 'LONG' }] });
  assert.equal(r.skipped, 'features off');
});

test('paper engine: smart trailing ON ratchets stop up, never down; OFF keeps legacy behaviour', () => {
  const row = () => ({ id: 'SOLUSDT_gps_v1_' + Date.now(), symbol: 'SOLUSDT', strategyId: 'gps_v1', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 106,
    positionSize: 2, cluster: 'ALT_GENERAL', openTime: Date.now() - 60000, initialRisk: 2, initialStopLoss: 98, trailingActive: false, trailingStopPrice: null, atr: 1 });
  flags.set('smartTrailing', true);
  const e = new PaperEngine(); const t = row(); e.openTrades.set('SOLUSDT_gps_v1', t);
  e.updateTrades('SOLUSDT', 104.5);
  const s1 = t.stopLoss; assert.ok(s1 > 100, 'locked above entry'); assert.ok(t.stage >= 60);
  e.updateTrades('SOLUSDT', 102.5);
  assert.equal(t.stopLoss, s1, 'pullback never loosens the stop');
  flags.set('smartTrailing', false);
});
