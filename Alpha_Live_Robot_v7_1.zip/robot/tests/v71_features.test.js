'use strict';
// v7.1: stale-data self-heal, ADI configuration service, direction modes, approval rules, open-position protection, Manual Take override.
const path = require('path'), os = require('os'), fs = require('fs');
process.env.ROBOT_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'v71-'));
process.env.ROBOT_SKIP_DOTENV = '1';
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert');
const { spawnSync } = require('child_process');

const journal = require('../src/journal/store');
const adiConfig = require('../src/control/adiConfig');
const direction = require('../src/control/direction');
const adi = require('../src/intelligence/adi');
const selfHeal = require('../src/control/selfHeal');
const ROOT = path.resolve(__dirname, '..');

const ADI_ENV = Object.keys(adiConfig.SCHEMA).concat(['TRADING_DIRECTION_MODE']);
function resetAll() {
  for (const k of ADI_ENV) delete process.env[k];
  const d = journal.getDb();
  for (const t of ['paper_trades', 'live_trades', 'scan_sessions']) d.exec(`DELETE FROM ${t}`);
  for (const k of ['adi_cfg', 'adi_recommendation', 'adi_history', 'adi_approval', 'direction_control']) journal.setState(k, null);
}
let seq = 0;
function addTrades(dir, n, pnl, mode = 'paper') {
  for (let i = 0; i < n; i++) {
    const t = { id: `x${++seq}`, strategyId: 'gps', strategyName: 'GPS', strategyVersion: '1', score: 90, riskReward: 2, symbol: 'SOLUSDT', direction: dir, entry: 100, stopLoss: 99, takeProfit: 102, positionSize: 1, pnl: typeof pnl === 'function' ? pnl(i) : pnl, fee: 0.05,
      outcome: 'X', openTime: 1000 + seq, closeTime: 2000 + seq, regime: 'TREND' };
    if (mode === 'live') journal.saveLiveTrade(t); else journal.savePaperTrade({ ...t, dbMode: 'PAPER' });
  }
}
const mixed = (win, loss) => (i) => (i % 3 === 0 ? loss : win);

describe('v7.1 self-heal (stale BTCUSDT rows)', () => {
  beforeEach(resetAll);
  const open = (id, mode = 'PAPER') => journal.savePaperTrade({ id, strategyId: 'gps', strategyName: 'GPS', strategyVersion: '1', score: 90, riskReward: 2, symbol: 'BTCUSDT', direction: 'LONG', entry: 50000, stopLoss: 49500, takeProfit: 51000, positionSize: 0.001, openTime: Date.now(), dbMode: mode });
  it('removes TEST_ rows and, in LIVE, plain-paper open rows the robot cannot manage; keeps Paper Lab rows and closed history', () => {
    open('TEST_TRADE_1'); open('real_paper'); open('lab_1', 'LAB');
    addTrades('LONG', 2, 1);
    const r = selfHeal.run({ isLive: true });
    assert.strictEqual(r.removedTestRows, 1); assert.strictEqual(r.removedOrphans, 1);
    const ids = journal.getOpenPaperTrades('all').map(x => x.id);
    assert.deepStrictEqual(ids, ['lab_1']);
    assert.strictEqual(journal.getClosedPaperTrades(100, 'all').length, 2, 'closed trades are never touched');
  });
  it('in PAPER mode only test rows go; genuine open paper rows stay', () => {
    open('TEST_TRADE_2'); open('real_paper');
    selfHeal.run({ isLive: false });
    assert.deepStrictEqual(journal.getOpenPaperTrades().map(x => x.id), ['real_paper']);
  });
  it('old unfinished scan sessions are stopped, a fresh one is kept; force clears all', () => {
    const now = Date.now();
    journal.saveScanSession({ id: 's_old', status: 'PAUSED', startedAt: now - 30 * 3600e3, completedSymbols: ['BTCUSDT'], failedSymbols: [], qualifiedSetups: [], config: {} });
    journal.getDb().prepare('UPDATE scan_sessions SET updated_at=? WHERE id=?').run(now - 30 * 3600e3, 's_old');     // saveScanSession stamps "now"; age it
    journal.saveScanSession({ id: 's_new', status: 'PAUSED', startedAt: now, completedSymbols: [], failedSymbols: [], qualifiedSetups: [], config: {} });
    const st = (id) => journal.getDb().prepare('SELECT status FROM scan_sessions WHERE id=?').get(id).status;
    selfHeal.run({ isLive: false });
    assert.strictEqual(st('s_old'), 'STOPPED'); assert.strictEqual(st('s_new'), 'PAUSED');
    selfHeal.run({ isLive: false, force: true });
    assert.strictEqual(st('s_new'), 'STOPPED');
  });
  it('a ghost row can be removed on demand (close fallback) and closed rows cannot', () => {
    open('ghost'); assert.strictEqual(selfHeal.removeOrphanRow('ghost'), 1);
    addTrades('LONG', 1, 1); assert.strictEqual(selfHeal.removeOrphanRow(`x${seq}`), 0);
  });
  it('the shipped package has no database file', () => {
    const files = fs.existsSync(path.join(ROOT, 'data')) ? fs.readdirSync(path.join(ROOT, 'data')) : [];
    assert.ok(!files.some(f => /\.db/.test(f)) || process.env.ROBOT_DATA_DIR !== path.join(ROOT, 'data'), 'data/ must not hold robot.db in the zip');
  });
});

describe('v7.1 ADI configuration service', () => {
  beforeEach(resetAll);
  it('recognises every ADI variable from the prompt (37) and .env.example documents all of them', () => {
    const wanted = `ADI_ENABLED ADI_DIRECTION_MODE ADI_AUTO_LEARNING ADI_PAPER_LEARNING ADI_LIVE_LEARNING ADI_LIVE_AUTO_APPLY TRADING_DIRECTION_MODE ALLOW_LONG_TRADES ALLOW_SHORT_TRADES ADI_DIRECTIONAL_BIAS_ENABLED ADI_DIRECTION_SWITCH_APPROVAL_REQUIRED
      ADI_PERFORMANCE_WINDOW_MODE ADI_RECENT_WINDOW_TRADES ADI_LONG_TERM_WINDOW_TRADES ADI_MIN_COMPLETED_TRADES ADI_PAPER_WEIGHT ADI_LIVE_WEIGHT ADI_RISK_ADJUSTED_SCORING ADI_INCLUDE_FEES ADI_INCLUDE_FUNDING ADI_PERFORMANCE_DECAY_ENABLED ADI_RECOMMENDATION_REFRESH_MINUTES
      ADI_STRATEGY_LEARNING_ENABLED ADI_STRATEGY_DIRECTION_ANALYSIS ADI_STRATEGY_AUTO_PRIORITY ADI_MARKET_REGIME_ANALYSIS ADI_ADAPTIVE_CONFIDENCE_THRESHOLD ADI_PERFORMANCE_DECAY_SENSITIVITY
      DIRECTION_CHANGE_CLOSE_EXISTING_POSITIONS DIRECTION_CHANGE_CANCEL_PROTECTIVE_ORDERS DIRECTION_CHANGE_MODIFY_EXISTING_POSITIONS DIRECTION_CHANGE_APPLIES_TO_NEW_ENTRIES_ONLY
      ADI_GENERATE_RECOMMENDATIONS ADI_REQUIRE_LIVE_APPROVAL ADI_PAPER_AUTO_ADAPT ADI_LIVE_AUTO_DIRECTION_SWITCH ADI_SAVE_RECOMMENDATION_HISTORY`.split(/\s+/);
    assert.strictEqual(wanted.length, 37);
    const example = fs.readFileSync(path.join(ROOT, '.env.example'), 'utf8');
    for (const k of wanted) { assert.ok(adiConfig.SCHEMA[k], `${k} not recognised`); assert.ok(new RegExp(`^${k}=`, 'm').test(example), `${k} missing from .env.example`); }
  });
  it('.env.example values equal the effective defaults (no silent divergence)', () => {
    const ex = {}; for (const l of fs.readFileSync(path.join(ROOT, '.env.example'), 'utf8').split(/\r?\n/)) { const m = /^([A-Z_]+)=([^\s#]*)/.exec(l); if (m) ex[m[1]] = m[2]; }
    const e = adiConfig.fromEnv(ex);
    assert.deepStrictEqual(e.errors, []); assert.deepStrictEqual(e.warnings, []);
    for (const k of Object.keys(adiConfig.SCHEMA)) assert.strictEqual(e.values[k], adiConfig.SCHEMA[k].def, `${k}: .env.example differs from the built-in default`);
  });
  it('parses booleans and numbers correctly and rejects bad values with clear messages', () => {
    const e = adiConfig.fromEnv({ ADI_ENABLED: 'FALSE', ADI_PAPER_LEARNING: '0', ADI_RECENT_WINDOW_TRADES: '75', ADI_PAPER_WEIGHT: '0.25', ADI_LIVE_WEIGHT: '0.75' });
    assert.strictEqual(e.values.ADI_ENABLED, false); assert.strictEqual(e.values.ADI_PAPER_LEARNING, false);
    assert.strictEqual(e.values.ADI_RECENT_WINDOW_TRADES, 75); assert.strictEqual(e.values.ADI_PAPER_WEIGHT, 0.25); assert.deepStrictEqual(e.errors, []);
    const bad = adiConfig.fromEnv({ ADI_ENABLED: 'maybe', ADI_MIN_COMPLETED_TRADES: 'ten', ADI_ADAPTIVE_CONFIDENCE_THRESHOLD: '150', ADI_DIRECTION_MODE: 'SIDEWAYS', ADI_PERFORMANCE_WINDOW_MODE: 'x' });
    assert.strictEqual(bad.errors.length, 5);
    assert.ok(bad.errors.some(m => /ADI_ENABLED="maybe" is not a valid true\/false/.test(m)));
    assert.ok(bad.errors.some(m => /ADI_ADAPTIVE_CONFIDENCE_THRESHOLD=150 is out of range \(0 to 100\)/.test(m)));
    assert.ok(bad.errors.some(m => /ADI_DIRECTION_MODE="SIDEWAYS" must be one of/.test(m)));
  });
  it('accepts "LONG ONLY" style mode names', () => {
    assert.strictEqual(adiConfig.fromEnv({ TRADING_DIRECTION_MODE: 'long only' }).values.EFFECTIVE_DIRECTION_MODE, 'LONG_ONLY');
    assert.strictEqual(adiConfig.fromEnv({ ADI_DIRECTION_MODE: 'short-only' }).values.EFFECTIVE_DIRECTION_MODE, 'SHORT_ONLY');
  });
  it('blocks conflicting directional settings and resolves mode sources deterministically', () => {
    assert.ok(adiConfig.fromEnv({ ALLOW_LONG_TRADES: 'false', ALLOW_SHORT_TRADES: 'false' }).errors.some(m => /forbid every trade/.test(m)));
    assert.ok(adiConfig.fromEnv({ TRADING_DIRECTION_MODE: 'LONG_ONLY', ALLOW_LONG_TRADES: 'false' }).errors.some(m => /conflicts with ALLOW_LONG_TRADES/.test(m)));
    const both = adiConfig.fromEnv({ ADI_DIRECTION_MODE: 'AUTO', TRADING_DIRECTION_MODE: 'BOTH' });
    assert.strictEqual(both.values.EFFECTIVE_DIRECTION_MODE, 'BOTH'); assert.ok(both.warnings.some(m => /using TRADING_DIRECTION_MODE/.test(m)));
    assert.strictEqual(adiConfig.fromEnv({ ADI_DIRECTION_MODE: 'AUTO' }).values.EFFECTIVE_DIRECTION_MODE, 'AUTO');
    assert.ok(adiConfig.fromEnv({ ADI_LONG_TERM_WINDOW_TRADES: '10', ADI_RECENT_WINDOW_TRADES: '50' }).errors.some(m => /must be >=/.test(m)));
  });
  it('open-position protection keys are locked: unsafe values stop startup', () => {
    for (const [k, v] of [['DIRECTION_CHANGE_CLOSE_EXISTING_POSITIONS', 'true'], ['DIRECTION_CHANGE_CANCEL_PROTECTIVE_ORDERS', 'true'], ['DIRECTION_CHANGE_MODIFY_EXISTING_POSITIONS', 'true'], ['DIRECTION_CHANGE_APPLIES_TO_NEW_ENTRIES_ONLY', 'false']]) {
      const e = adiConfig.fromEnv({ [k]: v }); assert.ok(e.errors.some(m => m.startsWith(k)), k); assert.strictEqual(e.values[k], adiConfig.SCHEMA[k].def);
    }
    process.env.DIRECTION_CHANGE_CLOSE_EXISTING_POSITIONS = 'true';
    assert.throws(() => adiConfig.validateOrThrow({ warn() {}, log() {} }), /Invalid ADI configuration in \.env[\s\S]*DIRECTION_CHANGE_CLOSE_EXISTING_POSITIONS/);
  });
  it('live approval wins over live auto settings (warning, never an unsafe live apply)', () => {
    const e = adiConfig.fromEnv({ ADI_REQUIRE_LIVE_APPROVAL: 'true', ADI_LIVE_AUTO_DIRECTION_SWITCH: 'true' });
    assert.ok(e.warnings.some(m => /ADI_REQUIRE_LIVE_APPROVAL=true wins/.test(m)));
    process.env.ADI_LIVE_AUTO_DIRECTION_SWITCH = 'true'; assert.strictEqual(adiConfig.effective().values.liveNeedsApproval, true);
  });
  it('dashboard overrides persist, win over .env, are validated, and safety keys are .env-only', () => {
    process.env.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD = '60';
    assert.strictEqual(adiConfig.cfg().ADI_ADAPTIVE_CONFIDENCE_THRESHOLD, 60);
    adiConfig.setRuntime({ ADI_ADAPTIVE_CONFIDENCE_THRESHOLD: 80, ADI_ENABLED: false });
    assert.strictEqual(adiConfig.cfg().ADI_ADAPTIVE_CONFIDENCE_THRESHOLD, 80); assert.strictEqual(adiConfig.cfg().ADI_ENABLED, false);
    assert.strictEqual(adiConfig.effective().source.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD, 'dashboard');
    assert.throws(() => adiConfig.setRuntime({ ADI_REQUIRE_LIVE_APPROVAL: false }), /cannot be changed from the dashboard/);
    assert.throws(() => adiConfig.setRuntime({ DIRECTION_CHANGE_CLOSE_EXISTING_POSITIONS: true }), /cannot be changed from the dashboard/);
    assert.throws(() => adiConfig.setRuntime({ ADI_ADAPTIVE_CONFIDENCE_THRESHOLD: 500 }), /out of range/);
    assert.throws(() => adiConfig.setRuntime({ ALLOW_LONG_TRADES: false, ALLOW_SHORT_TRADES: false }), /forbid every trade/);
    assert.strictEqual(adiConfig.cfg().ALLOW_LONG_TRADES, true, 'a rejected patch changes nothing');
    adiConfig.resetRuntime(); assert.strictEqual(adiConfig.cfg().ADI_ADAPTIVE_CONFIDENCE_THRESHOLD, 60);
  });
  it('describe() marks live vs restart settings and never contains secrets', () => {
    process.env.BYBIT_API_SECRET = 'SUPERSECRETVALUE'; process.env.BYBIT_API_KEY = 'KEYVALUE123';
    const d = adiConfig.describe(), json = JSON.stringify(d);
    assert.ok(!json.includes('SUPERSECRETVALUE') && !json.includes('KEYVALUE123'));
    assert.strictEqual(d.settings.find(s => s.key === 'ADI_ENABLED').runtimeEditable, true);
    assert.strictEqual(d.settings.find(s => s.key === 'ADI_RECENT_WINDOW_TRADES').needsRestart, true);
    assert.ok(/\.env/.test(d.howTo));
    delete process.env.BYBIT_API_SECRET; delete process.env.BYBIT_API_KEY;
  });
});

describe('v7.1 direction modes', () => {
  beforeEach(resetAll);
  const allowed = (d, o) => direction.check(d, { dryRun: true, ...(o || {}) }).allowed;
  it('fixed modes behave as before', () => {
    direction.set('BOTH'); assert.ok(allowed('LONG') && allowed('SHORT'));
    direction.set('LONG_ONLY'); assert.ok(allowed('LONG') && !allowed('SHORT'));
    direction.set('SHORT_ONLY'); assert.ok(!allowed('LONG') && allowed('SHORT'));
    direction.set('PAUSE'); assert.ok(!allowed('LONG') && !allowed('SHORT'));
    direction.set('long only'); assert.strictEqual(direction.get().mode, 'LONG_ONLY');
  });
  it('ADAPTIVE never blocks; AUTO without an approved recommendation never blocks', () => {
    direction.set('ADAPTIVE'); assert.ok(allowed('LONG') && allowed('SHORT'));
    direction.set('AUTO'); assert.ok(allowed('LONG') && allowed('SHORT'));
    assert.strictEqual(direction.effective().effective, 'BOTH');
  });
  it('ADI OFF: ADAPTIVE/AUTO act like BOTH, explicit modes and ALLOW_* still work', () => {
    adiConfig.setRuntime({ ADI_ENABLED: false });
    direction.set('AUTO'); assert.ok(allowed('LONG') && allowed('SHORT')); assert.match(direction.effective().via, /ADI is OFF/);
    direction.set('LONG_ONLY'); assert.ok(!allowed('SHORT'));
    adiConfig.setRuntime({ ALLOW_SHORT_TRADES: false }); direction.set('BOTH'); assert.ok(allowed('LONG') && !allowed('SHORT'));
    assert.match(direction.check('SHORT', { dryRun: true }).reason, /ALLOW_SHORT_TRADES=false/);
  });
  it('ALLOW_* are hard permissions even for Manual Take; the MODE is overridable by Manual Take', () => {
    direction.set('LONG_ONLY');
    assert.ok(!allowed('SHORT')); assert.ok(allowed('SHORT', { manual: true }), 'manual take overrides the mode');
    const c = direction.manualConflict('SHORT'); assert.strictEqual(c.conflict, true); assert.match(c.reason, /LONG ONLY/);
    assert.deepStrictEqual(direction.manualConflict('LONG'), {});
    adiConfig.setRuntime({ ALLOW_SHORT_TRADES: false });
    assert.ok(!allowed('SHORT', { manual: true })); assert.strictEqual(direction.manualConflict('SHORT').permissionBlocked, true);
  });
  it('blocked entries are counted, dry-run checks are not', () => {
    direction.set('LONG_ONLY'); direction.check('SHORT', { dryRun: true }); assert.strictEqual(direction.get().blocked || 0, 0);
    direction.check('SHORT'); direction.check('SHORT'); assert.strictEqual(direction.get().blocked, 2);
  });
  it('timed override still reverts', () => {
    const t0 = Date.now(); direction.set('BOTH'); direction.set('SHORT_ONLY', { hours: 1, now: t0 });
    assert.strictEqual(direction.get(t0 + 1000).mode, 'SHORT_ONLY'); assert.strictEqual(direction.get(t0 + 2 * 3600e3).mode, 'BOTH');
  });
  it('initial mode comes from .env; dashboard choice wins; an edited .env value wins once, then dashboard wins again', () => {
    process.env.TRADING_DIRECTION_MODE = 'SHORT_ONLY'; assert.strictEqual(direction.get().mode, 'SHORT_ONLY');
    direction.set('LONG_ONLY'); assert.strictEqual(direction.get().mode, 'LONG_ONLY', 'dashboard choice persists over .env');
    assert.strictEqual(direction.get().mode, 'LONG_ONLY', 'a refresh/poll never resets it');
    process.env.TRADING_DIRECTION_MODE = 'BOTH'; assert.strictEqual(direction.get().mode, 'BOTH', 'edited .env applies once');
    direction.set('SHORT_ONLY'); assert.strictEqual(direction.get().mode, 'SHORT_ONLY', 'then the dashboard wins again');
  });
  it('an old DB saved before v7.1 keeps its mode on first load', () => {
    journal.setState('direction_control', { mode: 'LONG_ONLY', defaultMode: 'LONG_ONLY', source: 'dashboard', expiresAt: null, blocked: 3, reasons: {} });
    process.env.TRADING_DIRECTION_MODE = 'ADAPTIVE'; assert.strictEqual(direction.get().mode, 'LONG_ONLY');
  });
  it('changing direction mode never touches open positions (structural guard)', () => {
    journal.savePaperTrade({ id: 'open1', strategyId: 'gps', strategyName: 'GPS', strategyVersion: '1', score: 90, riskReward: 2, symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 104, positionSize: 1, openTime: Date.now(), dbMode: 'PAPER', trailingStopPrice: 99 });
    const before = JSON.stringify(journal.getOpenPaperTrades());
    for (const m of ['ADAPTIVE', 'AUTO', 'LONG_ONLY', 'SHORT_ONLY', 'PAUSE', 'BOTH']) direction.set(m);
    adi.recommendation({ force: true });
    assert.strictEqual(JSON.stringify(journal.getOpenPaperTrades()), before);
    const src = fs.readFileSync(path.join(ROOT, 'src/control/direction.js'), 'utf8') + fs.readFileSync(path.join(ROOT, 'src/intelligence/adi.js'), 'utf8');
    assert.ok(!/closeTrade|closePosition|cancelOrder|amendOrder|setTradingStop|closeAllTrades/.test(src), 'direction/ADI code must not reference any close/cancel/modify call');
  });
});

describe('v7.1 ADI engine, approval and bias', () => {
  beforeEach(resetAll);
  it('insufficient evidence = BOTH, confidence 0, with a clear reason', () => {
    addTrades('LONG', 5, 1);
    const r = adi.recommendation({ force: true });
    assert.strictEqual(r.direction, 'BOTH'); assert.strictEqual(r.confidence, 0); assert.match(r.reasons[0], /Not enough evidence/);
  });
  it('recommends LONG ONLY when SHORT clearly loses and confidence clears the threshold', () => {
    addTrades('LONG', 60, mixed(1, -0.3)); addTrades('SHORT', 60, mixed(-0.5, 0.2));
    const r = adi.recommendation({ force: true });
    assert.strictEqual(r.direction, 'LONG_ONLY'); assert.ok(r.confidence >= 70, `confidence ${r.confidence}`); assert.ok(r.bias.LONG > 0 && r.bias.SHORT < 0);
  });
  it('stays BOTH when the weaker direction is still profitable (bias only)', () => {
    addTrades('LONG', 60, mixed(1.5, -0.2)); addTrades('SHORT', 60, mixed(0.5, -0.3));
    const r = adi.recommendation({ force: true });
    assert.strictEqual(r.direction, 'BOTH'); assert.ok(r.bias.LONG > r.bias.SHORT);
  });
  it('paper results cannot hide poor live results', () => {
    addTrades('LONG', 40, mixed(2, -0.1), 'paper'); addTrades('LONG', 40, mixed(-1, 0.2), 'live');
    addTrades('SHORT', 40, mixed(0.2, -0.2), 'paper'); addTrades('SHORT', 40, mixed(0.2, -0.2), 'live');
    const r = adi.analyse(); assert.strictEqual(r.long.guarded, true); assert.ok(r.long.score <= r.long.live.score + 10.01);
  });
  it('weights normalise: a source with too little data is ignored, never diluted', () => {
    addTrades('LONG', 40, mixed(1, -0.3), 'paper'); addTrades('LONG', 3, -5, 'live');
    const r = adi.analyse(); assert.strictEqual(r.long.basis, 'paper only'); assert.strictEqual(r.long.weights.paper, 1);
    process.env.ADI_MIN_COMPLETED_TRADES = '2'; process.env.ADI_PAPER_WEIGHT = '0.4'; process.env.ADI_LIVE_WEIGHT = '0.6';
    const r2 = adi.analyse(); assert.strictEqual(r2.long.basis, 'live+paper'); assert.strictEqual(r2.long.weights.live, 0.6);
  });
  it('learning switches and the fee setting are honoured', () => {
    addTrades('LONG', 30, mixed(1, -0.3), 'paper'); addTrades('SHORT', 30, mixed(1, -0.3), 'paper');
    process.env.ADI_PAPER_LEARNING = 'false'; const r = adi.analyse(); assert.strictEqual(r.sources.paper, 0); assert.strictEqual(r.direction, 'BOTH');
    delete process.env.ADI_PAPER_LEARNING;
    const net = adi.analyse().long.expectancy; process.env.ADI_INCLUDE_FEES = 'false'; const gross = adi.analyse().long.expectancy;
    assert.ok(gross > net, 'fees added back = gross is higher');
  });
  it('paper AUTO applies with ADI_PAPER_AUTO_ADAPT; LIVE needs your approval, which expires when the recommendation changes', () => {
    addTrades('LONG', 60, mixed(1, -0.3)); addTrades('SHORT', 60, mixed(-0.5, 0.2));
    direction.set('AUTO');
    assert.strictEqual(direction.effective(Date.now(), false).effective, 'LONG_ONLY', 'paper auto-adapt');
    assert.strictEqual(direction.effective(Date.now(), true).effective, 'BOTH', 'live: pending approval, nothing applied');
    assert.strictEqual(adi.status(true).pendingApproval, true);
    adiConfig.setRuntime({ ADI_PAPER_AUTO_ADAPT: false });
    assert.strictEqual(direction.effective(Date.now(), false).effective, 'BOTH', 'paper auto-adapt off => needs approval too');
    adi.approve();
    assert.strictEqual(direction.effective(Date.now(), true).effective, 'LONG_ONLY', 'approved');
    assert.strictEqual(direction.check('SHORT', { dryRun: true, isLive: true }).allowed, false);
    journal.setState('adi_approval', { ...journal.getState('adi_approval'), ts: Date.now() - 25 * 3600e3 });
    assert.strictEqual(direction.effective(Date.now(), true).effective, 'BOTH', 'approval expires after 24h');
    adi.approve(); journal.setState('adi_approval', { ...journal.getState('adi_approval'), direction: 'SHORT_ONLY' });
    assert.strictEqual(adi.approval().valid, false, 'approval is tied to the recommended direction');
    adi.revoke(); assert.strictEqual(adi.approval().valid, false);
  });
  it('ADI_REQUIRE_LIVE_APPROVAL=true beats live auto switches; only with both off in .env can live auto-apply', () => {
    addTrades('LONG', 60, mixed(1, -0.3)); addTrades('SHORT', 60, mixed(-0.5, 0.2)); direction.set('AUTO'); adi.recommendation({ force: true });
    process.env.ADI_LIVE_AUTO_DIRECTION_SWITCH = 'true';
    assert.strictEqual(adi.authority(true).applies, false);
    process.env.ADI_REQUIRE_LIVE_APPROVAL = 'false'; assert.strictEqual(adi.authority(true).applies, false, 'ADI_DIRECTION_SWITCH_APPROVAL_REQUIRED still true');
    process.env.ADI_DIRECTION_SWITCH_APPROVAL_REQUIRED = 'false'; assert.strictEqual(adi.authority(true).applies, true);
  });
  it('bias only re-orders, never adds/removes setups, and is inactive when ADI is off / bias off / live unapproved', () => {
    addTrades('LONG', 60, mixed(1, -0.3)); addTrades('SHORT', 60, mixed(-0.5, 0.2)); adi.recommendation({ force: true });
    const q = [{ symbol: 'A', direction: 'SHORT', score: 90 }, { symbol: 'B', direction: 'LONG', score: 88 }];
    const out = adi.applyBias(q.map(x => ({ ...x })), false);
    assert.deepStrictEqual(out.map(s => s.symbol), ['B', 'A'], 'LONG favoured in paper'); assert.strictEqual(out.length, 2);
    assert.deepStrictEqual(adi.applyBias(q.map(x => ({ ...x })), true).map(s => s.symbol), ['A', 'B'], 'live: no change without approval');
    adiConfig.setRuntime({ ADI_DIRECTIONAL_BIAS_ENABLED: false }); assert.deepStrictEqual(adi.applyBias(q.map(x => ({ ...x })), false).map(s => s.symbol), ['A', 'B']);
    adiConfig.setRuntime({ ADI_DIRECTIONAL_BIAS_ENABLED: true, ADI_ENABLED: false }); assert.deepStrictEqual(adi.applyBias(q.map(x => ({ ...x })), false).map(s => s.symbol), ['A', 'B']);
    assert.strictEqual(adi.recommendation().inactive, true, 'ADI off: recommendation is stale/inactive, not regenerated');
  });
  it('history is saved (capped) when enabled and skipped when disabled', () => {
    addTrades('LONG', 30, mixed(1, -0.3)); addTrades('SHORT', 30, mixed(1, -0.3));
    adi.recommendation({ force: true }); assert.strictEqual(journal.getState('adi_history').length, 1);
    process.env.ADI_SAVE_RECOMMENDATION_HISTORY = 'false'; adi.recommendation({ force: true }); assert.strictEqual(journal.getState('adi_history').length, 1);
  });
  it('strategy-engine gates map the ADI strategy switches; ADI off leaves the engine as in v7.0', () => {
    assert.deepStrictEqual(adi.strategyGates(), { ordering: true, direction: true, regime: true });
    process.env.ADI_STRATEGY_AUTO_PRIORITY = 'false'; process.env.ADI_MARKET_REGIME_ANALYSIS = 'false';
    assert.deepStrictEqual(adi.strategyGates(), { ordering: false, direction: true, regime: false });
    process.env.ADI_ENABLED = 'false'; assert.deepStrictEqual(adi.strategyGates(), { ordering: true, direction: true, regime: true });
  });
});

describe('v7.1 persistence across restart and .env upgrade', () => {
  beforeEach(resetAll);
  it('dashboard settings and direction mode survive a restart (new process, same DB)', () => {
    adiConfig.setRuntime({ ADI_ADAPTIVE_CONFIDENCE_THRESHOLD: 85, ALLOW_SHORT_TRADES: false }); direction.set('LONG_ONLY');
    const code = "const a=require('./src/control/adiConfig'),d=require('./src/control/direction');const c=a.cfg();console.log(JSON.stringify({t:c.ADI_ENABLED&&c.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD,s:c.ALLOW_SHORT_TRADES,m:d.get().mode,src:a.effective().source.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD}))";
    const r = spawnSync(process.execPath, ['-e', code], { cwd: ROOT, env: { PATH: process.env.PATH, ROBOT_DATA_DIR: process.env.ROBOT_DATA_DIR, ROBOT_SKIP_DOTENV: '1', NODE_NO_WARNINGS: '1' }, encoding: 'utf8' });
    assert.deepStrictEqual(JSON.parse(r.stdout.trim().split('\n').pop()), { t: 85, s: false, m: 'LONG_ONLY', src: 'dashboard' });
  });
  it('a robot started with an invalid ADI value refuses to start with a clear message', () => {
    const r = spawnSync(process.execPath, ['-e', "require('./src/control/adiConfig').validateOrThrow({warn(){},log(){}})"], { cwd: ROOT, env: { PATH: process.env.PATH, ROBOT_DATA_DIR: process.env.ROBOT_DATA_DIR, ROBOT_SKIP_DOTENV: '1', ADI_PAPER_WEIGHT: '2', NODE_NO_WARNINGS: '1' }, encoding: 'utf8' });
    assert.notStrictEqual(r.status, 0); assert.match(r.stderr, /ADI_PAPER_WEIGHT=2 is out of range/);
  });
  it('env:upgrade appends only missing variables and leaves every existing line (incl. API keys) untouched', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'envup-')); fs.mkdirSync(path.join(dir, 'src/scripts'), { recursive: true });
    fs.copyFileSync(path.join(ROOT, 'src/scripts/env-upgrade.js'), path.join(dir, 'src/scripts/env-upgrade.js'));
    fs.copyFileSync(path.join(ROOT, '.env.example'), path.join(dir, '.env.example'));
    const mine = '# my settings\nBYBIT_API_KEY=abc123\nBYBIT_API_SECRET="s3cr3t value"\nADI_ENABLED=false\nMIN_SCORE=91\nCUSTOM_THING=keep-me\n';
    fs.writeFileSync(path.join(dir, '.env'), mine);
    const r = spawnSync(process.execPath, [path.join(dir, 'src/scripts/env-upgrade.js')], { encoding: 'utf8' });
    assert.strictEqual(r.status, 0, r.stderr);
    const after = fs.readFileSync(path.join(dir, '.env'), 'utf8');
    assert.ok(after.startsWith(mine), 'existing content unchanged byte for byte');
    assert.ok(/^ADI_DIRECTION_MODE=ADAPTIVE/m.test(after) && /^TRADING_DIRECTION_MODE=/m.test(after));
    assert.strictEqual((after.match(/^ADI_ENABLED=/gm) || []).length, 1, 'existing ADI_ENABLED is not duplicated');
    assert.ok(/^ADI_ENABLED=false/m.test(after)); assert.ok(fs.readdirSync(dir).some(f => f.startsWith('.env.bak-')));
    const again = spawnSync(process.execPath, [path.join(dir, 'src/scripts/env-upgrade.js')], { encoding: 'utf8' });
    assert.match(again.stdout, /Nothing to do/);
  });
});

describe('v7.1 trade size (margin) controls', () => {
  const rt = require('../src/control/runtime');
  beforeEach(() => { journal.setState('margin_choice', null); });
  it('presets default to include 1.5 and 2 and are read from MANUAL_MARGIN_PRESETS; junk entries are ignored', () => {
    assert.ok(rt.MARGINS.includes(1.5) && rt.MARGINS.includes(2) && rt.MARGINS.includes(1));
    assert.deepStrictEqual(rt.parseList('2, 1.5;abc,-3,0,1.5,5', [9]), [1.5, 2, 5]);
    assert.deepStrictEqual(rt.parseList('junk', [9]), [9]); assert.deepStrictEqual(rt.parseList(undefined, [1, 2]), [1, 2]);
    assert.deepStrictEqual(rt.parseList('5,10.5,200', [9], { int: true, max: 125 }), [5]);
  });
  it('decimal margins can be set (1 -> 1.5 -> 2 -> 2.75) and persist', () => {
    assert.strictEqual(rt.setMarginChoice(1.5), 1.5); assert.strictEqual(rt.sizing().margin, 1.5);
    assert.strictEqual(rt.setMarginChoice('2'), 2); assert.strictEqual(rt.setMarginChoice(2.75), 2.75); assert.strictEqual(rt.marginChoice(), 2.75);
    assert.throws(() => rt.setMarginChoice(0), /positive/); assert.throws(() => rt.setMarginChoice(-1), /positive/); assert.throws(() => rt.setMarginChoice('abc'), /positive/);
  });
  it('+ / - move by MANUAL_MARGIN_STEP (default 0.5), never below the minimum, floating-point safe', () => {
    rt.setMarginChoice(1); assert.strictEqual(rt.adjustMargin(1), 1.5); assert.strictEqual(rt.adjustMargin(1), 2); assert.strictEqual(rt.adjustMargin(-1), 1.5);
    rt.setMarginChoice(0.3); assert.throws(() => rt.setMarginChoice(0.05), /at least/);
    rt.setMarginChoice(0.5); rt.adjustMargin(-1); assert.ok(rt.marginChoice() >= 0.1);
    rt.setMarginChoice(0.1); let v = 0.1; for (let i = 0; i < 3; i++) v = rt.adjustMargin(1); assert.strictEqual(v, 1.6);
  });
  it('per-trade size: overrides one trade only, leaves the saved default alone, validates', () => {
    rt.setMarginChoice(1);
    assert.deepStrictEqual(rt.resolveMargin(1, undefined), { margin: 1, overridden: false });
    assert.deepStrictEqual(rt.resolveMargin(1, 1.5), { margin: 1.5, overridden: true });
    assert.deepStrictEqual(rt.resolveMargin(1, 1), { margin: 1, overridden: false });
    assert.throws(() => rt.resolveMargin(1, 0), /positive/); assert.throws(() => rt.resolveMargin(1, 'x'), /positive/); assert.throws(() => rt.resolveMargin(1, 0.01), /at least/);
    assert.strictEqual(rt.marginChoice(), 1, 'saved default unchanged');
  });
  it('the sizing result carries margin x leverage = position for the next trade', () => {
    rt.setMarginChoice(1.5); const z = rt.sizing(); assert.strictEqual(z.notional, Number((z.margin * z.leverage).toFixed(4)));
  });
  it('.env.example documents the new size settings', () => {
    const ex = fs.readFileSync(path.join(ROOT, '.env.example'), 'utf8');
    for (const k of ['MANUAL_DEFAULT_MARGIN', 'MANUAL_MARGIN_PRESETS', 'MANUAL_MARGIN_STEP', 'MANUAL_MARGIN_MIN', 'MANUAL_LEVERAGE_PRESETS']) assert.ok(new RegExp(`^${k}=`, 'm').test(ex), k);
  });
});

describe('v7.1 dashboard assets', () => {
  it('every local script/stylesheet referenced by index.html is on the static allowlist and exists', () => {
    const html = fs.readFileSync(path.join(ROOT, 'dashboard/public/index.html'), 'utf8');
    const routes = fs.readFileSync(path.join(ROOT, 'dashboard/liveRoutes.js'), 'utf8');
    const refs = [...html.matchAll(/(?:src|href)="(\/[A-Za-z0-9_.-]+\.(?:js|css))"/g)].map(m => m[1]);
    assert.ok(refs.includes('/adi.js') && refs.includes('/v7.js'));
    for (const r of refs) { assert.ok(fs.existsSync(path.join(ROOT, 'dashboard/public', r)), `${r} missing on disk`); assert.ok(routes.includes(`'${r}'`) || fs.readFileSync(path.join(ROOT, 'dashboard/server.js'), 'utf8').includes(`'${r}'`), `${r} is not served by the dashboard (would 404)`); }
  });
});
