'use strict';
// v5.2.4: warn-only drawdown, leverage choice, manual-trade protection, decision log, close by PnL
const test = require('node:test');
const assert = require('node:assert');
const config = require('../src/config');
const journal = require('../src/journal/store');
const flags = require('../src/features/flags');
const scaling = require('../src/risk/scaling');
const runtime = require('../src/control/runtime');
const dl = require('../src/decisions/log');
const live = require('../src/protection/live');
const RiskEngine = require('../src/risk/engine');

test('scaling: drawdown past DEFENSIVE only WARNS in warn mode, enforce keeps the old cut', () => {
  const a = scaling.computeProfile({ equity: 80, peakEquity: 100, config: { drawdownMode: 'warn' } });
  assert.notStrictEqual(a.state, 'DEFENSIVE'); assert.strictEqual(a.drawdownWarning, 'DEFENSIVE'); assert.ok(a.slots > 1);
  const b = scaling.computeProfile({ equity: 80, peakEquity: 100, config: { drawdownMode: 'enforce' } });
  assert.strictEqual(b.state, 'DEFENSIVE'); assert.strictEqual(b.slots, 1);
  const c = scaling.computeProfile({ equity: 80, peakEquity: 100, config: {} });   // default (undefined) = legacy enforce
  assert.strictEqual(c.state, 'DEFENSIVE');
});

test('risk engine (live): daily-loss and loss-streak limits warn but do not block in warn mode; enforce still blocks', () => {
  const saved = { isLive: config.isLive }; config.isLive = true;
  try {
    journal.setState('drawdown_mode', 'warn');
    const re = new RiskEngine({ accountBalance: 1000, maxDailyLoss: 0.05, maxOpenPositions: 5 });
    re.state.dailyPnL = -80; re.state.dailyLossDate = new Date().toDateString();
    const sig = { symbol: 'ETHUSDT', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 104 };
    const warn = re.check(sig, [], {});
    assert.ok(!/MAX_DAILY_LOSS/.test(warn.reason || ''), 'not blocked by the daily loss limit in warn mode');
    assert.ok(dl.list({ type: 'TRADE_WARNING' }).some(x => x.module === 'drawdownGuard'), 'warning recorded');
    journal.setState('drawdown_mode', 'enforce');
    const hard = re.check(sig, [], {});
    assert.strictEqual(hard.approved, false); assert.match(hard.reason, /MAX_DAILY_LOSS_REACHED/);
  } finally { config.isLive = saved.isLive; journal.setState('drawdown_mode', null); }
});

test('leverage choice accepts whole numbers 1-125 (or 0 = auto) and is applied to the live profile', () => {
  assert.throws(() => runtime.setLeverageChoice(0.5)); assert.throws(() => runtime.setLeverageChoice(200));
  runtime.setLeverageChoice(20);
  const saved = { isLive: config.isLive }; config.isLive = true;
  try {
    const re = new RiskEngine({ accountBalance: 100 }); re.cfg.scalingEnabled = true;
    const p = re.refreshProfile({ equity: 100, peakEquity: 100 });
    assert.strictEqual(p.leverage, 20); assert.strictEqual(re.cfg.leverage, 20);
  } finally { config.isLive = saved.isLive; runtime.setLeverageChoice(0); }
  assert.strictEqual(runtime.leverageChoice(), 0);
});

test('manual (app-opened) trades: stop is trailed, but they are never auto-closed unless MANUAL_TRADE_EXITS=true', async () => {
  flags.set('timeExit', true);
  const saved = config.manualTradeExits; let closes = 0; let stops = 0;
  const orders = { list: () => [], closePosition: async () => { closes++; return { ok: true }; } };   // no robot record = manual
  const pos = () => [{ symbol: 'BTCUSDT', side: 'LONG', qty: 1, entry: 100, stopLoss: 98, takeProfit: 106, markPrice: 99, createdTime: Date.now() - 9 * 3600e3, leverage: 5 }];
  const ex = { setTradingStop: async () => { stops++; }, getStopOrders: async () => [] };
  try {
    config.manualTradeExits = false; journal.setState('protection_state', {});
    await live.run({ exchange: ex, orders, positions: pos() });
    assert.strictEqual(closes, 0, 'manual trade must not be closed by time exit');
    config.manualTradeExits = true; journal.setState('protection_state', {});
    await live.run({ exchange: ex, orders, positions: pos() });
    assert.strictEqual(closes, 1, 'opt-in allows exits');
  } finally { config.manualTradeExits = saved; flags.set('timeExit', false); journal.setState('protection_state', {}); }
});

test('manual trade without an exchange stop raises a visible warning instead of silence', async () => {
  flags.set('smartTrailing', true);
  const orders = { list: () => [], closePosition: async () => ({ ok: true }) };
  await live.run({ exchange: {}, orders, positions: [{ symbol: 'XRPUSDT', side: 'SHORT', qty: 10, entry: 2, stopLoss: 0, markPrice: 1.9 }] });
  assert.ok(dl.list({ symbol: 'XRPUSDT' }).some(x => x.module === 'manualProtection' && x.severity === 'WARNING'));
});

test('decision log: dedups identical events, keeps module snapshot, filters, banners hide INFO', () => {
  journal.setState(dl.KEY, []);
  dl.record({ type: 'MODULE_BLOCKED', severity: 'WARNING', symbol: 'BTCUSDT', module: 'staleDataBlock', reason: 'STALE: data 400s old', key: 'k1' });
  dl.record({ type: 'MODULE_BLOCKED', severity: 'WARNING', symbol: 'BTCUSDT', module: 'staleDataBlock', reason: 'STALE: data 400s old', key: 'k1' });
  dl.record({ type: 'TRADE_OPENED', severity: 'INFO', symbol: 'ETHUSDT', module: 'liveExecution', reason: 'opened', cooldownMs: 0 });
  const all = dl.list({}); assert.strictEqual(all.length, 2);
  const w = all.find(x => x.key === 'k1'); assert.strictEqual(w.count, 2); assert.ok(w.snapshot && w.snapshot.modules);
  assert.strictEqual(dl.banners().length, 1);
  assert.strictEqual(dl.moduleOf('GOVERNOR: ENTRY_HALT'), 'lossGovernor');
  assert.strictEqual(dl.record({ type: 'X' }), null);
});

test('first startup defaults: 1 USDT margin x 10x, notional 10', () => {
  journal.setState('margin_choice', null); journal.setState('leverage_choice', null);
  const z = runtime.sizing(); assert.deepStrictEqual([z.enabled, z.margin, z.leverage, z.notional], [true, 1, 10, 10]);
});
test('margin/leverage changes persist (DB) and are read fresh for the next trade; invalid values rejected', () => {
  runtime.setMarginChoice(5); runtime.setLeverageChoice(20);
  const z = runtime.sizing(); assert.deepStrictEqual([z.margin, z.leverage, z.notional], [5, 20, 100]);
  assert.throws(() => runtime.setMarginChoice(0)); assert.throws(() => runtime.setMarginChoice(-3));
  journal.setState('margin_choice', null); journal.setState('leverage_choice', null);
});
test('fixed-margin sizing: qty = margin x leverage / price, floored to step; below-minimum and contract-max handled with exact reasons', () => {
  const saved = { isLive: config.isLive, over: config.leverageOverMax }; config.isLive = true;
  try {
    const re = new RiskEngine({ accountBalance: 100, maxOpenPositions: 5 });
    const sig = { symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104, riskReward: 2.7 };
    const rules = { qtyStep: 0.1, minQty: 0.1, minNotional: 5, maxLeverage: 25 };
    let v = re.check(sig, [], { rules, fixedSizing: { margin: 1, leverage: 10 } });
    assert.ok(v.approved, v.reason); assert.strictEqual(v.positionSize, 0.1); assert.strictEqual(v.leverage, 10); assert.strictEqual(v.marginUsd, 1);
    v = re.check(sig, [], { rules, fixedSizing: { margin: 5, leverage: 20 } });
    assert.ok(v.approved, v.reason); assert.strictEqual(v.positionSize, 1);            // 100 USDT notional at price 100
    v = re.check(sig, [], { rules, fixedSizing: { margin: 1, leverage: 2 } });          // 2 USDT notional < min 5
    assert.strictEqual(v.approved, false); assert.match(v.reason, /SIZE_SKIPPED.*below the contract minimum/);
    config.leverageOverMax = 'cap';
    v = re.check(sig, [], { rules, fixedSizing: { margin: 10, leverage: 50 } });       // contract max 25x
    if (v.approved) { assert.strictEqual(v.leverage, 25); assert.match(v.sizeNote, /capped 50x -> 25x/); } else assert.match(v.reason, /SL_TOO_CLOSE_TO_LIQUIDATION/);
    config.leverageOverMax = 'skip';
    v = re.check(sig, [], { rules, fixedSizing: { margin: 10, leverage: 50 } });
    assert.strictEqual(v.approved, false); assert.match(v.reason, /LEVERAGE_ABOVE_CONTRACT_MAX/);
  } finally { config.isLive = saved.isLive; config.leverageOverMax = saved.over; }
});
test('max open positions still enforced with fixed sizing', () => {
  const re = new RiskEngine({ accountBalance: 100, maxOpenPositions: 1 });
  const v = re.check({ symbol: 'ETHUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104 }, [{ symbol: 'BTCUSDT', positionSize: 1, entry: 50 }], { rules: { qtyStep: 0.01, minQty: 0.01, minNotional: 5 }, fixedSizing: { margin: 1, leverage: 10 } });
  assert.strictEqual(v.approved, false); assert.match(v.reason, /MAX_POSITIONS_REACHED/);
});

// ── v6.0 ────────────────────────────────────────────────────────────────────────────────────────
const gate = require('../src/risk/gate');
const filters = require('../src/risk/filters');
const presets = require('../src/intelligence/presets');
const outcomes = require('../src/intelligence/outcomes');
const pcfgMod = require('../src/protection/config');

function ctxFor(aggRisk, equity = 100) {
  return { f: { ...flags.all(), riskTaper: true, correlationBlock: false, staleDataBlock: false, lossGovernor: false, regimeFilter: false, adaptiveDirection: false, spreadFilter: false, volumeConfirm: false, htfTrend: false, volatilityFilter: false },
    caps: pcfgMod.get(), intel: null, gov: null, snap: { aggRisk, aggRiskPct: aggRisk / equity * 100, equity, groups: [], n: 0 }, equity, riskPerTrade: 0.015, minScore: 80, runMode: 'LIVE', now: Date.now(), sizing: { enabled: true, margin: 5, leverage: 20, notional: 100 }, positions: [], bias: {} };
}
const S = { symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98.5, takeProfit: 104, score: 90 };   // risk of one 100 USDT trade = 1.5 USDT = 1.5% of 100

test('soft risk budget: full size when risk is low, smooth shrink as the cap nears, never a wall until the hard ceiling', async () => {
  const low = await gate.check(S, ctxFor(1));       assert.ok(low.allowed); assert.strictEqual(low.sizeFactor, 1);
  const mid = await gate.check(S, ctxFor(6));       assert.ok(mid.allowed); assert.ok(mid.sizeFactor < 1 && mid.sizeFactor > 0.25, `factor ${mid.sizeFactor}`);   // 6% of an 8% cap = 75% used
  const atCap = await gate.check(S, ctxFor(8));     assert.ok(atCap.allowed, 'still trading at the old hard-wall level'); assert.strictEqual(atCap.sizeFactor, 0.25);
  const over = await gate.check(S, ctxFor(11));     assert.ok(over.allowed && over.sizeFactor <= 0.25, 'above the cap trades still open, smaller');
  const ceil = await gate.check(S, ctxFor(12));     assert.strictEqual(ceil.allowed, false); assert.match(ceil.reasons[0], /RISK_BUDGET/);   // ceiling = 150% of 8% = 12%
});
test('soft risk budget OFF: no taper, behaves as before', async () => {
  const c = ctxFor(8); c.f.riskTaper = false; const r = await gate.check(S, c); assert.strictEqual(r.sizeFactor, 1);
});
test('entry filters: block on bad measurements, fail OPEN when data is missing', () => {
  const caps = pcfgMod.get(), f = { spreadFilter: true, volumeConfirm: true, htfTrend: true, volatilityFilter: true };
  assert.strictEqual(filters.reasons(S, {}, f, caps).length, 0, 'unknown data never blocks');
  const bad = filters.reasons(S, { spreadBps: 40, depthUsd: 5000, volRatio: 0.3, htfTrend: 'DOWN', atrRatio: 4 }, f, caps, 100);
  assert.strictEqual(bad.length, 4); assert.ok(bad.some(x => /^SPREAD_FILTER/.test(x)) && bad.some(x => /^HTF_TREND/.test(x)));
  assert.strictEqual(filters.reasons(S, { spreadBps: 3, depthUsd: 90000, volRatio: 1.4, htfTrend: 'UP', atrRatio: 1.1 }, f, caps, 100).length, 0);
});
test('filters.measure computes volume, trend, volatility and spread from provided data (stubbed feed)', async () => {
  const mk = (n, v) => Array.from({ length: n }, (_, i) => ({ open: 100 + i * 0.1, high: 101 + i * 0.1, low: 99 + i * 0.1, close: 100 + i * 0.1, volume: v }));
  const feed = { getCandles: async (s, tf) => (tf === '4h' ? mk(90, 1) : mk(80, 1000)) };
  const mi = { evaluate: async () => ({ book: { spreadBps: 4.2, depthUsd: 50000, slipBps: 1 } }) };
  const m = await filters.measure(S, ['spread', 'volume', 'htf', 'vol'], 100, { dataFeed: feed, micro: mi });
  assert.strictEqual(m.spreadBps, 4.2); assert.strictEqual(m.volRatio, 1); assert.strictEqual(m.htfTrend, 'UP'); assert.ok(m.atrRatio > 0);
});
test('presets: preview lists changes, apply never touches live permissions, undo restores', () => {
  flags.set('htfTrend', false); pcfgMod.set('aggRiskPct', 8);
  const pv = presets.preview('conservative'); assert.ok(pv.changes.some(c => c.key === 'htfTrend' && c.to === 'ON')); assert.match(pv.unchanged, /Take Live Trades/);
  const before = { lev: journal.getState('leverage_choice'), paused: journal.getState('live_paused'), dd: journal.getState('drawdown_mode') };
  presets.applyPreset('conservative'); assert.strictEqual(flags.all().htfTrend, true); assert.strictEqual(pcfgMod.get().aggRiskPct, 6);
  assert.deepStrictEqual({ lev: journal.getState('leverage_choice'), paused: journal.getState('live_paused'), dd: journal.getState('drawdown_mode') }, before);
  presets.revert(); assert.strictEqual(flags.all().htfTrend, false); assert.strictEqual(pcfgMod.get().aggRiskPct, 8);
  assert.throws(() => presets.revert()); assert.throws(() => presets.preview('nope'));
});
test('performance tracker + what-if: attributed by module state at entry; simulated; small samples flagged', () => {
  journal.setState('outcome_open', {}); journal.setState('outcome_done', []);
  flags.set('spreadFilter', false);
  for (let i = 0; i < 4; i++) { outcomes.noteOpen({ symbol: 'A' + i, direction: 'LONG', mode: 'live', measured: { spreadBps: i < 2 ? 30 : 3 }, regime: 'RANGE', aggRiskPct: 2 }); outcomes.noteClose({ symbol: 'A' + i, mode: 'live', pnl: i < 2 ? -1 : 0.5 }); }
  const w = outcomes.whatIf('spreadFilter'); assert.ok(w.simulated); assert.strictEqual(w.wouldHaveBlocked, 2); assert.strictEqual(w.blockedTradesPnl, -2); assert.strictEqual(w.verdict, 'NOT ENOUGH DATA');
  const p = outcomes.performance(); const row = p.rows.find(r => r.key === 'spreadFilter'); assert.strictEqual(row.whenOff.trades, 4); assert.match(row.note, /Not enough trades/);
  assert.strictEqual(outcomes.whatIf('bogus').ok, false);
});

test('bybit wallet parsing: blank availability fields never read as 0 available', () => {
  const { parseWallet } = require('../src/exchanges/bybit');
  const uta = parseWallet({ accountType: 'UNIFIED', totalEquity: '25.4', totalAvailableBalance: '', totalInitialMargin: '3', coin: [{ coin: 'USDT', equity: '25.4', walletBalance: '25.4', availableToWithdraw: '', totalPositionIM: '3', totalOrderIM: '0', locked: '0' }] });
  assert.strictEqual(uta.equity, 25.4); assert.strictEqual(uta.available, 22.4); assert.match(uta.raw.availableSource, /computed/);
  assert.strictEqual(parseWallet({ totalEquity: '10', totalAvailableBalance: '9.5', coin: [{ coin: 'USDT', equity: '10', walletBalance: '10' }] }).available, 9.5);
  assert.strictEqual(parseWallet({ totalEquity: '10', totalAvailableBalance: '0', coin: [{ coin: 'USDT', equity: '10', walletBalance: '10', availableToWithdraw: '7', totalPositionIM: '3' }] }).available, 7);
  assert.strictEqual(parseWallet({ totalEquity: '8', totalInitialMargin: '8', totalAvailableBalance: '0', coin: [{ coin: 'USDT', equity: '8', walletBalance: '8', totalPositionIM: '8' }] }).available, 0, 'fully used margin is truly 0');
});

test('v6.0.2 slots: ramp off gives max slots at any capital; ramp on starts at start; unlimited = 100; validation', () => {
  const rt = require('../src/control/runtime'); const RiskEngine = require('../src/risk/engine');
  rt.setSlotConfig({ ramp: false, max: 9 });
  let r = new RiskEngine({ accountBalance: 5, scaling: true, maxOpenPositions: 0 }); r.refreshProfile({ equity: 5, peakEquity: 5 }); assert.strictEqual(r.cfg.maxOpenPositions, 9, 'tiny capital still gets the slots you set');
  rt.setSlotConfig({ ramp: true, start: 2, every: 5, minPF: 1.2, max: 9 });
  r = new RiskEngine({ accountBalance: 500, scaling: true, maxOpenPositions: 0 }); r.refreshProfile({ equity: 500, peakEquity: 500, stats: { trades: 0, profitFactor: 0, expectancy: 0 } }); assert.strictEqual(r.cfg.maxOpenPositions, 2);
  r.refreshProfile({ equity: 500, peakEquity: 500, stats: { trades: 10, profitFactor: 1.5, expectancy: 0.2 } }); assert.strictEqual(r.cfg.maxOpenPositions, 4, '2 + floor(10/5)');
  rt.setSlotConfig({ ramp: false, max: 0 }); r.refreshProfile({ equity: 500, peakEquity: 500 }); assert.strictEqual(r.cfg.maxOpenPositions, 100);
  assert.throws(() => rt.setSlotConfig({ max: -1 })); assert.throws(() => rt.setSlotConfig({ start: 1.5 }));
  journal.setState('slot_cfg', null);
});

test('v6.5: live authorisation only from .env (LIVE_AUTHORIZE), reason text, no dashboard path', () => {
  const { liveAuthStatus } = require('../src/live/authStatus');
  assert.strictEqual(liveAuthStatus({ mode: 'LIVE', isLive: true, liveEnabled: true, liveAuthorize: true }).ok, true);
  const no = liveAuthStatus({ mode: 'LIVE', isLive: false, liveEnabled: false, liveAuthorize: false });
  assert.strictEqual(no.ok, false); assert.match(no.text, /LIVE_TRADING_ENABLED/); assert.match(no.text, /LIVE_AUTHORIZE/);
  assert.match(liveAuthStatus({ mode: 'SIM', isLive: false, liveEnabled: false, liveAuthorize: true }).text, /TRADING_MODE/);
  const robot = require('fs').readFileSync(require('path').join(__dirname, '../src/robot.js'), 'utf8');
  assert.ok(!/case 'CONFIRM_LIVE'/.test(robot) && !/case 'REVOKE_LIVE'/.test(robot), 'no dashboard command can authorise');
  assert.ok(!/golive_pending'\)\s*;?\s*\n\s*if \(gl\)/.test(robot));
  const live = require('fs').readFileSync(require('path').join(__dirname, '../dashboard/public/live.js'), 'utf8');
  assert.ok(!/data-a="golive"|data-a="gopaper"|data-a="revoke"|data-a="confirmLive"/.test(live));
});
test('v6.5: robot authorises at start when .env says so, and not otherwise', () => {
  const Robot = require('../src/robot'); const config = require('../src/config');
  const saved = { m: config.mode, e: config.liveEnabled, a: config.liveAuthorize, l: config.isLive };
  try {
    config.mode = 'LIVE'; config.liveEnabled = true; config.isLive = true;
    for (const [flag, want] of [[true, 'LIVE_AUTHORIZED'], [false, 'LIVE_LOCKED']]) {
      config.liveAuthorize = flag;
      let confirmed = false; const fake = { liveExecution: { confirmLiveMode() { confirmed = true; } } };
      const au = require('../src/live/authStatus').liveAuthStatus(config); if (config.isLive && au.ok) fake.liveExecution.confirmLiveMode();
      assert.strictEqual(confirmed, flag, want);
    }
  } finally { config.mode = saved.m; config.liveEnabled = saved.e; config.liveAuthorize = saved.a; config.isLive = saved.l; }
});
