'use strict';
const test = require('node:test');
const assert = require('node:assert');
function load(env) {
  const keys = ['ACCOUNT_BALANCE','MAX_OPEN_POSITIONS','MAX_OPEN_POSITIONS_PAPER','MAX_OPEN_POSITIONS_LIVE','SCALING_MAX_SLOTS','TRADING_MODE','GOV_EMERGENCY_ACTION'];
  const saved = {}; keys.forEach(k => { saved[k] = process.env[k]; delete process.env[k]; });
  Object.assign(process.env, { TRADING_MODE: 'SIM', ROBOT_SKIP_DOTENV: '1' }, env);   // never read the real .env: defaults must be tested in isolation
  delete require.cache[require.resolve('../src/config')];
  const c = require('../src/config');
  keys.forEach(k => { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; });
  delete require.cache[require.resolve('../src/config')];
  return c;
}
test('defaults: $100 start, paper 50, live 12', () => {
  const c = load({});
  assert.strictEqual(c.accountBalance, 100);
  assert.strictEqual(c.maxOpenPositions, 50);
  assert.strictEqual(c.maxOpenPositionsLive, 12);
  assert.strictEqual(c.scaling.maxSlots, 12);
  assert.strictEqual(c.scaling.maxOpenRisk, 0.08);
  assert.strictEqual(c.sizingPreview.marginPerTrade, 5);
});
test('all limits are configurable via env', () => {
  const c = load({ ACCOUNT_BALANCE: '20', MAX_OPEN_POSITIONS_PAPER: '30', MAX_OPEN_POSITIONS_LIVE: '7' });
  assert.strictEqual(c.accountBalance, 20);
  assert.strictEqual(c.maxOpenPositions, 30);
  assert.strictEqual(c.scaling.maxSlots, 7);
  assert.strictEqual(c.sizingPreview.marginPerTrade, 1);
  assert.strictEqual(load({ SCALING_MAX_SLOTS: '5' }).scaling.maxSlots, 5);
});
test('legacy MAX_OPEN_POSITIONS still applies to paper', () => {
  assert.strictEqual(load({ MAX_OPEN_POSITIONS: '0' }).maxOpenPositions, 0);
});
test('emergency action defaults to HALT', () => {
  delete process.env.GOV_EMERGENCY_ACTION;
  delete require.cache[require.resolve('../src/protection/config')];
  const p = require('../src/protection/config');
  assert.strictEqual(p.get().govEmergencyAction, 'HALT');
});
