'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const envStore = require('../src/control/envStore');
const routes = require('../dashboard/exchangeRoutes');
const ENV_BEFORE = fs.existsSync(envStore.ENV_PATH) ? fs.readFileSync(envStore.ENV_PATH, 'utf8') : null;

const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'alr-')), '.env');

test('envStore: updates only the given keys, keeps comments and other settings, quotes risky values', () => {
  const p = tmp(); fs.writeFileSync(p, '# my settings\nWS_ENABLED=true\nEXCHANGE=bybit\nBITGET_API_KEY=old\n');
  const wrote = envStore.set({ EXCHANGE: 'bitget', BITGET_API_KEY: 'abc def#1', BITGET_API_SECRET: 's3cret', BITGET_PASSPHRASE: '' }, p);
  assert.deepStrictEqual(wrote.sort(), ['BITGET_API_KEY', 'BITGET_API_SECRET', 'EXCHANGE']);
  const txt = fs.readFileSync(p, 'utf8');
  assert.match(txt, /# my settings/); assert.match(txt, /WS_ENABLED=true/); assert.match(txt, /EXCHANGE=bitget/); assert.match(txt, /BITGET_API_KEY="abc def#1"/);
  const back = envStore.readAll(p); assert.strictEqual(back.BITGET_API_KEY, 'abc def#1'); assert.strictEqual(back.BITGET_API_SECRET, 's3cret');
  assert.strictEqual(fs.statSync(p).mode & 0o777, 0o600);
});
test('envStore: refuses unknown keys, newline injection, bad enum values', () => {
  const p = tmp(); fs.writeFileSync(p, 'A=1\n');
  assert.throws(() => envStore.set({ ADMIN_TOKEN: 'x' }, p), /cannot be changed/);
  assert.throws(() => envStore.set({ BYBIT_API_KEY: 'x\nTRADING_MODE=LIVE' }, p), /invalid characters/);
  assert.throws(() => envStore.set({ EXCHANGE: 'binance' }, p), /EXCHANGE must be/);
  assert.throws(() => envStore.set({ TRADING_MODE: 'TESTNET' }, p), /SIM or LIVE/);
  assert.strictEqual(fs.readFileSync(p, 'utf8'), 'A=1\n');
});
test('envStore: blank keeps the saved value; __CLEAR__ removes it; status never exposes secrets', () => {
  const p = tmp(); fs.writeFileSync(p, 'BYBIT_API_KEY=keykeykey1234\nBYBIT_API_SECRET=supersecretvalue\n');
  envStore.set({ BYBIT_API_KEY: '', BYBIT_API_SECRET: envStore.CLEAR }, p);
  const e = envStore.readAll(p); assert.strictEqual(e.BYBIT_API_KEY, 'keykeykey1234'); assert.strictEqual(e.BYBIT_API_SECRET, '');
  fs.writeFileSync(p, 'BITGET_API_KEY=abcdef123456\nBITGET_API_SECRET=zzzzSECRETzzzz\nBITGET_PASSPHRASE=pp\n');
  const st = JSON.stringify(envStore.keyStatus(p));
  assert.ok(!st.includes('zzzzSECRETzzzz') && !st.includes('abcdef123456') && !st.includes('"pp"'));
  assert.match(st, /3456/);   // only the masked tail of the (non-secret) key id
});

const fakeRes = () => { const r = { code: null, body: null }; r.writeHead = () => {}; r.end = (b) => { r.body = b; }; return r; };
const mk = (body) => {
  const out = [];
  const h = routes.create({ sendJson: (res, code, data) => { out.push({ code, data }); }, parseBody: async () => body || {} });
  return { h, out };
};
test('routes: writes need the dashboard header; cross-site origin refused', async () => {
  const { h, out } = mk({});
  await h.handle({ headers: {}, method: 'POST' }, fakeRes(), '/api/exchange/save', 'POST');
  assert.strictEqual(out[0].code, 403);
  await h.handle({ headers: { 'x-alpha': '1', origin: 'https://evil.example', host: 'localhost:3000' }, method: 'POST' }, fakeRes(), '/api/exchange/save', 'POST');
  assert.strictEqual(out[1].code, 403);
});
test('routes: unknown keys (incl. TRADING_MODE) are rejected before any write; GO LIVE routes are gone (v6.5)', async () => {
  let { h, out } = mk({ exchange: 'bitget', keys: { TRADING_MODE: 'LIVE' } });
  await h.handle({ headers: { 'x-alpha': '1', host: 'x' }, method: 'POST' }, fakeRes(), '/api/exchange/save', 'POST');
  assert.strictEqual(out[0].code, 400);   // TRADING_MODE is not a key field: only .env changes the mode
  ({ h, out } = mk({ confirm: 'GO LIVE' }));
  const handled = await h.handle({ headers: { 'x-alpha': '1', host: 'x' }, method: 'POST' }, fakeRes(), '/api/live/golive', 'POST');
  assert.strictEqual(handled, false, 'no GO LIVE route in this module any more');
});
test('routes: state endpoint never returns secrets', async () => {
  const { h, out } = mk({});
  await h.handle({ headers: {}, method: 'GET' }, fakeRes(), '/api/exchange/state', 'GET');
  assert.strictEqual(out[0].code, 200); const j = JSON.stringify(out[0].data);
  assert.ok(!/SECRET\"?:\s*\"[^"•]{6,}/.test(j));
  assert.ok(out[0].data.exchanges.find(e => e.id === 'bitget'));
});

test('the tests above never modified the real .env', () => {
  const now = fs.existsSync(envStore.ENV_PATH) ? fs.readFileSync(envStore.ENV_PATH, 'utf8') : null;
  assert.strictEqual(now, ENV_BEFORE);
});

test('envStore.parse: quoted value with a trailing comment, CRLF and empty values', () => {
  const e = envStore.parse('TRADING_MODE="SIM"   # paper\r\nA=\r\nB=x y # c\r\nC=\'q\'\r\n');
  assert.strictEqual(e.TRADING_MODE, 'SIM'); assert.strictEqual(e.A, ''); assert.strictEqual(e.B, 'x y'); assert.strictEqual(e.C, 'q');
});
test('a route that throws answers JSON 500 instead of killing the dashboard', async () => {
  const orig = envStore.keyStatus; envStore.keyStatus = () => { throw new Error('boom'); };
  try {
    const { h, out } = mk({});
    const handled = await h.handle({ headers: {}, method: 'GET' }, fakeRes(), '/api/exchange/state', 'GET');
    assert.strictEqual(handled, true); assert.strictEqual(out[0].code, 500); assert.match(out[0].data.error, /boom/);
  } finally { envStore.keyStatus = orig; }
});
test('state reports settings that the shell/Codespaces environment sets (they override .env)', () => {
  const { spawnSync } = require('child_process');
  const r = spawnSync(process.execPath, ['-e', "const c=require('./src/config');console.log(JSON.stringify(c.envFromShell))"], { cwd: path.resolve(__dirname, '..'), env: { PATH: process.env.PATH, ROBOT_SKIP_DOTENV: '1', BITGET_API_KEY: 'abc', EXCHANGE: 'bitget', UNRELATED: '1' }, encoding: 'utf8' });
  const list = JSON.parse(r.stdout); assert.ok(list.includes('BITGET_API_KEY') && list.includes('EXCHANGE') && !list.includes('UNRELATED'));
});
