'use strict';
const test = require('node:test');
const assert = require('node:assert');
const OrderManager = require('../src/execution/orderManager');
const RiskEngine = require('../src/risk/engine');
const config = require('../src/config');

function mem() { const m = {}; return { get: k => m[k] ?? null, set: (k, v) => { m[k] = v === null ? null : JSON.parse(JSON.stringify(v)); }, m }; }
function fake(over = {}) {
  const ex = { positions: [], stops: [], orders: {}, getPositions: async () => ex.positions, getStopOrders: async () => ex.stops,
    getOrder: async () => null, placeOrder: async () => ({}), cancelOrder: async () => ({}), ...over }; return ex;
}
const mk = (ex = fake()) => { const clock = { t: 1000000 }; const store = mem(); const events = []; const om = new OrderManager({ exchange: ex, store, now: () => clock.t, onEvent: e => events.push(e) }); return { om, store, clock, events }; };
const unprotectedRec = (om, store, clock) => { store.set('live_orders', { a1: { id: 'a1', symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98, state: 'FILLED', qty: 1, filledQty: 1, protected: false, createdAt: clock.t, updatedAt: clock.t } }); };

test('entry block: default auto-clear wait is 15s and force is off', () => {
  assert.strictEqual(config.entryBlockAutoClearSec, 15);
  assert.strictEqual(config.entryBlockForceClear, false);
});

test('entry block: not cleared before 15s, reports remaining seconds', async () => {
  const { om, clock } = mk(); om.block('test');
  clock.t += 5000;
  const r = await om.autoClear();
  assert.strictEqual(r.cleared, false); assert.ok(r.pending); assert.strictEqual(r.remainingSec, 10);
  assert.ok(om.blocked());
  assert.strictEqual(om.blockStatus().remainingSec, 10);
});

test('entry block: VERIFIED mode clears after 15s when nothing is unresolved and emits "Entry block cleared"', async () => {
  const { om, clock, events } = mk(); om.block('order X outcome unknown');
  clock.t += 15000;
  const r = await om.autoClear();
  assert.ok(r.cleared); assert.strictEqual(r.mode, 'verified'); assert.strictEqual(om.blocked(), null);
  assert.ok(events.some(e => e.title === 'Entry block cleared'));
  assert.strictEqual(om.blockStatus().lastCleared.mode, 'verified');
});

test('entry block: VERIFIED mode keeps the block while a filled position has no verified stop-loss', async () => {
  const { om, store, clock } = mk(fake({ positions: [{ symbol: 'SOLUSDT' }], stops: [] }));
  unprotectedRec(om, store, clock); om.block('SOLUSDT filled without a verified stop-loss');
  clock.t += 20000;
  const r = await om.autoClear();
  assert.strictEqual(r.cleared, false); assert.ok(om.blocked());
  assert.strictEqual(r.waitingOn[0].symbol, 'SOLUSDT');
});

test('entry block: same condition re-detected does not reset the 15s clock', async () => {
  const { om, clock } = mk(); om.block('same');
  const at = om.blocked().at; clock.t += 9000; om.block('same');
  assert.strictEqual(om.blocked().at, at);
});

test('entry block: FORCE mode clears regardless, and the same condition is not re-raised (no flip-flop)', async () => {
  const { om, store, clock } = mk(fake({ positions: [{ symbol: 'SOLUSDT' }], stops: [] }));
  om.setForceClear(true); assert.ok(om.forceClear());
  unprotectedRec(om, store, clock); om.block('SOLUSDT filled without a verified stop-loss');
  clock.t += 15000;
  const r = await om.autoClear();
  assert.ok(r.cleared); assert.strictEqual(r.mode, 'forced'); assert.strictEqual(om.blocked(), null);
  om.block('SOLUSDT filled without a verified stop-loss');          // protection loop re-detects it
  assert.strictEqual(om.blocked(), null);
  om.block('ETHUSDT filled without a verified stop-loss');          // a DIFFERENT problem still blocks
  assert.ok(om.blocked());
});

test('entry block: dashboard force setting overrides .env, auto-clear 0 disables', async () => {
  const { om, clock } = mk(); om.setForceClear(false); assert.strictEqual(om.forceClear(), false);
  const old = config.entryBlockAutoClearSec; config.entryBlockAutoClearSec = 0;
  try { om.block('x'); clock.t += 60000; const r = await om.autoClear(); assert.ok(r.disabled); assert.ok(om.blocked()); } finally { config.entryBlockAutoClearSec = old; }
});

const sig = { symbol: 'SOLUSDT', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 105, riskReward: 2.5, score: 90, strategyId: 'gps' };
test('manual take: ignoreSlots passes the slot limit but never the hard cap', () => {
  const risk = new RiskEngine({ accountBalance: 10000, riskPerTrade: 0.005, maxOpenPositions: 2, minRR: 2 });
  const open = (n) => Array.from({ length: n }, (_, i) => ({ symbol: 'C' + i + 'USDT', positionSize: 1, entry: 10 }));
  assert.match(risk.check(sig, open(2)).reason, /MAX_POSITIONS_REACHED/);                       // robot: blocked by slots
  assert.ok(risk.check(sig, open(2), { ignoreSlots: true, hardCap: 5 }).approved);              // manual: allowed
  assert.ok(risk.check(sig, open(4), { ignoreSlots: true, hardCap: 5 }).approved);
  assert.match(risk.check(sig, open(5), { ignoreSlots: true, hardCap: 5 }).reason, /HARD_CAP_REACHED/);   // never beyond 5
});

test('manual take: kill switch and daily-loss style gates still apply', () => {
  const risk = new RiskEngine({ accountBalance: 10000, riskPerTrade: 0.005, maxOpenPositions: 1, minRR: 2 });
  risk.state.killSwitch = true;
  assert.match(risk.check(sig, [], { ignoreSlots: true, hardCap: 5 }).reason, /KILL_SWITCH/);
});

test('manual take (v7.0): no fixed hard cap by default (0 = confirm instead), 15% risk-confirm level, max drift 0.5%', () => {
  assert.strictEqual(config.manualTakeHardCapLive, 0);
  assert.strictEqual(config.manualTakeHardCapPaper, 0);
  assert.strictEqual(config.manualTakeRiskConfirmPct, 15);
  assert.strictEqual(config.manualTakeMaxDriftPct, 0.5);
});

// ── robot-level manual Take (paper mode, everything external stubbed) ──────────────────────────
const TradingRobot = require('../src/robot');
const gate = require('../src/risk/gate');
const intel = require('../src/market/intel');
const journal = require('../src/journal/store');

function robotWith({ signals, price = 100 }) {
  const r = new TradingRobot(); r.paused = false;
  r.paperEngine.analyzeMarket = async (symbol) => ({ symbol, signals: signals.map(s => ({ ...s, symbol, timestamp: Date.now() })) });
  r._getTickerMap = async () => ({ SOLUSDT: { lastPrice: price } });
  r._normPositions = () => []; r._equityNow = () => 1000; r._updateState = () => {}; r._writeHeartbeat = () => {};
  r._noteOutcomeOpen = async () => {}; r.notifier = { notifySignal: async () => {} };
  return r;
}
const qual = { strategyId: 'gps', strategyName: 'GPS', direction: 'LONG', entry: 100, stopLoss: 98, takeProfit: 105, riskReward: 2.5, score: 90, tier: 'QUALIFIED', decision: 'TRADE', cluster: 'L1' };

test('manual take (paper): refuses stale, drifted, and invalidated setups; opens a valid one even when slots are full', async () => {
  const saved = { gp: gate.prepare, gc: gate.check, gn: gate.noteOpened, ir: intel.refresh, mc: config.microChecks, live: config.isLive };
  gate.prepare = async () => ({ intel: null, snap: { aggRiskPct: 0 }, gov: null, f: {} }); gate.check = async () => ({ allowed: true, sizeFactor: 1 }); gate.noteOpened = () => {};
  intel.refresh = async () => {}; config.microChecks = false; config.isLive = false;
  try {
    // 1) no longer qualified
    let r = robotWith({ signals: [{ ...qual, tier: null, decision: 'REJECT', score: 70, rejectionReason: 'low score' }] });
    await assert.rejects(() => r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps' }), /NO_LONGER_QUALIFIED/);
    // 2) price drifted > 0.5%
    r = robotWith({ signals: [qual], price: 101 });
    await assert.rejects(() => r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps' }), /PRICE_DRIFTED/);
    // failed attempts must not leave a 30s lock behind
    r._getTickerMap = async () => ({ SOLUSDT: { lastPrice: 100.1 } });
    // 3) paused
    r.paused = true; await assert.rejects(() => r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG' }), /paused/i); r.paused = false;
    // 4) slots full for the robot, manual take still opens (paper hard cap 50)
    r.riskEngine.cfg.maxOpenPositions = 1; r.riskEngine.cfg.accountBalance = 1000;
    r.paperEngine.balance = 1000;
    const pre = await r._prepareTake({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps' });
    assert.ok(pre.driftPct < 0.5);
    const out = await r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps' });
    assert.strictEqual(out.mode, 'paper'); assert.strictEqual(out.symbol, 'SOLUSDT');
    assert.strictEqual(r.paperEngine.getOpenTrades().filter(t => t.symbol === 'SOLUSDT').length, 1);
    assert.ok((journal.getState('manual_taken') || {})['SOLUSDT|LONG']);
    // 5) double-click: second take of the same symbol is refused
    await assert.rejects(() => r._takeSetup({ symbol: 'SOLUSDT', direction: 'LONG', strategyId: 'gps' }), /just submitted|SYMBOL_ALREADY_OPEN/);
  } finally { Object.assign(gate, { prepare: saved.gp, check: saved.gc, noteOpened: saved.gn }); intel.refresh = saved.ir; config.microChecks = saved.mc; config.isLive = saved.live; }
});
