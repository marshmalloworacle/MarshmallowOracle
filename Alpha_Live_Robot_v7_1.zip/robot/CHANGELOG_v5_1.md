# v5.1 — Obsidian Graphite × Sea-Glass Teal dashboard + limits

Visual redesign only. Trading engine, strategies, exchange adapters, DB schema and safety gates are unchanged.

## Dashboard
- New theme layer `dashboard/public/obsidian.css` (loaded last) + shell `obsidian.js`: left sidebar (Command Centre / Markets / Trading / Intelligence / System), glass sticky header with page title, mobile slide-over drawer, 2px black-framed cards, teal accent, DM Mono numerics, reduced-motion/transparency support.
- All existing IDs, onclick handlers, polling and API calls preserved. Old violet palette mapped to teal across index/live/v46/v5 assets.
- Command Centre: Open slots (used / allowed + limiting cap), Sizing basis (start balance, margin and position per trade), Entry pace and risk caps.
- New **Modules** page: switches for trailing, profit-giveback, partial exits, time exits, direction control, adaptive direction, correlation block, loss governor, stale-data block, regime filter, health strip, journal extras, close buttons, plus tunable limits. Uses the existing `/api/v46/features` and `/api/v46/settings`. Stop-loss/take-profit shown as ALWAYS ON (not switchable).
- Read-only endpoint `GET /api/v5/limits`.
- Scanner/opportunity/qualified lists are no longer capped (`SCANNER_DISPLAY_LIMIT=0`).

## Config
- `ACCOUNT_BALANCE` default $100 everywhere (`.env.example` shipped 10000).
- `MAX_OPEN_POSITIONS_PAPER=50`, `MAX_OPEN_POSITIONS_LIVE=12` (legacy `MAX_OPEN_POSITIONS` still honoured for paper; `SCALING_MAX_SLOTS` overrides live).
- 8% aggregate open-risk cap stays live-only (`SCALING_MAX_OPEN_RISK`); paper has no aggregate cap.
- `MAX_NEW_PER_SCAN`: 20 paper / 10 live when unset.
- `GOV_EMERGENCY_ACTION=HALT` documented as default (keep stops, no new entries).
- Startup log prints start balance, margin and position per trade, and both limits.

## Page-level redesign (Scanner, Positions, Analytics)
- `dashboard/public/obsidian-pages.js` (read-only, existing endpoints only):
  - Scanner: quick-filter chips with live counts (drive the existing status filter), score bars, long/short row accents, sticky symbol column.
  - Open Positions: live position cards from `/api/dashboard/positions` with a stop-loss to take-profit rail (entry and mark markers), unrealized P&L, current R, margin and leverage, liquidation distance, age, strategy, trailing badge. The existing table stays below.
  - Performance & Analytics: strategy performance table from `/api/dashboard/strategy-stats` with an honest empty state (no estimates).

## Controls, sentiment meter, margin display
- Unified control system in `obsidian.css`: one height (36px), radius, type and state set for `.btn`, `.lv-btn`, `.acc-btn`, `.tf-btn`, segmented controls (`.seg`, `.mode-switch`), account tabs (`.lv-tabs`), selects and inputs. Primary = teal, danger = coral, compact variant inside tables.
- Sentiment meter: zoned track (red bearish, amber neutral, green bullish; thresholds match the robot: <=40 / >=60), marker at the score, legend and verdict chip. Display only.
- Fix: "Margin used" on Command Centre was overstated (540% vs about 27%) because paper rows fell back to leverage 1. Rows now carry each trade's real margin (`src/robot.js`, display-only; not consumed by any gate).

## Bitget + multi-exchange WebSocket
- New `src/exchanges/bitget.js`: Bitget USDT-M futures (v2 API). Market data (instruments, tickers, candles, funding, open interest, order book), read-only account (balance, positions, orders, TP/SL, history) and order placement (one-way mode, isolated margin, signed with key/secret/passphrase, no auto-retry on writes, hedge mode refused). Orders are LIVE-mode only and sit behind every existing live gate; `npm run bitget:verify` is read-only.
- `EXCHANGE=bybit|bitget|mexc|sim` selects ONE active exchange (facade unchanged for strategies, scanner, risk and dashboard).
- WebSocket public streams for all three exchanges (`src/exchanges/ws/publicStreams.js`, `liveFeed.js`); REST fallback stays automatic. Private order stream remains Bybit-only.
- New `.env` keys: `BITGET_API_KEY`, `BITGET_API_SECRET`, `BITGET_PASSPHRASE`, optional `BITGET_BASE_URL`, `BITGET_WS_URL`.
- NOT verified against the live Bitget/MEXC servers (no network in the build sandbox): covered by mocked-HTTP and recorded-frame tests only.

## Test isolation fix
- `src/config.js` honours `ROBOT_SKIP_DOTENV=1` (skips reading `.env`); `npm test` sets it, so config-default tests no longer depend on a real Codespaces `.env`. Verified with a deliberately hostile `.env` (ACCOUNT_BALANCE=500, limits 7/3, EXCHANGE=bitget): 338/338 pass. Never set this flag when running the robot.
