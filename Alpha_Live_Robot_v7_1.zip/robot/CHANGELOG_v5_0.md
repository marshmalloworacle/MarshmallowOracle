# v5.0 — complete switchable protection, risk and intelligence layer

Built on v4.5 (+ v4.6 foundations). Every feature has its own switch (dashboard strip -> "features"); OFF = v4.5 behaviour.
Switches live in the DB and apply instantly. Tunable limits (strip -> "Tunable limits") are bounded and persisted; env vars give defaults.

## What's new since v4.6
- **Real ATR on every signal** (`analyzeMarket` attaches 1h ATR(14)); trailing/giveback use it. The old stop-distance/1.5 proxy is only a fallback and is labelled (`atrSource`).
- **Protection on every tick**: paper (300 ms throttle) and live/testnet (per symbol, 1 s throttle, single-flight, serialised with the cycle) via the price feed. Needs the WebSocket ticker feed; with REST polling it runs once per cycle.
- **Time exits (your policy)**: a LOSING or GOING-NOWHERE trade (<15% of target) is closed after `staleHours` (default 8, configurable 1-48; 6-12 suggested). A trade in profit that is still trailing is left alone and closed at `maxHours` (24). `whenLosing: TIGHTEN` remains available in code.
- **Partial profit-taking** (paper + exchange): default 30% at 50% of target; reduce-only market order with a deterministic client id (no duplicates), size floored to the instrument step, never leaves less than min qty; remainder keeps its stop. Paper books realised P&L/fees and final trade totals include partials.
- **Portfolio risk + correlation** (`src/risk/portfolio.js`): aggregate risk to stops, notional L/S, dominant side, margin, largest asset, nearest liquidation, rolling 1h correlation groups (same-direction only; hedges are not added). Caps: aggregate risk 8%, correlated group 5%, direction 80% (3+ positions). Entry blocked when a cap would be exceeded; risk is never raised silently.
- **Loss governor** (`src/risk/governor.js`): NORMAL / CAUTION (+5 score, max 2 new per scan) / DEFENSIVE (+10, max 1) / ENTRY HALT / EMERGENCY from daily (UTC day, incl. unrealised), weekly (UTC Monday) and from-peak drawdown. Baselines persist; separate paper/live books. EMERGENCY latches until acknowledged (daily reset cannot clear it). Emergency action default HALT (alert + no entries, stops stay); optional FLATTEN is idempotent, retried and verified against the exchange.
- **Market intelligence** (`src/market/intel.js`): sentiment gauge 0-100 with confidence, BTC/ETH trend, breadth, volatility, volume change, funding, shock detector, regime state with hysteresis, bias recommendation. Each metric carries source/scope/time; unavailable data shows UNKNOWN; buy/sell flow is UNAVAILABLE (Bybit tickers have no aggressor volume).
- **Entry gate** (`src/risk/gate.js`): stale-data block, governor, regime filter, adaptive direction (auto, OFF by default, manual direction always wins), correlation/exposure. Every block is recorded with its reason (Why trades were blocked card).
- **Journal extras** (`trade_extras` side table; existing tables/exports untouched): regime, ATR, initial risk, MFE/MAE, R-multiples, giveback, stage, partials, exit reason. **Performance intelligence**: win rate, PF, expectancy, avg R, max drawdown, fees, by strategy/direction/regime/exit, protection stats, low-sample flag (<30).
- **Dashboard**: mission-control cards with placeholders (Market Intelligence battery gauge, Portfolio Risk, Loss Governor, Protection table, Why trades were blocked, Performance) + the control strip; Graphite + Neon Teal.

## Defaults
ON: directionControl, healthStrip, journalExtras, closeButtons, staleDataBlock (blocks entries only, never exits; skipped in the offline simulator).
OFF: smartTrailing, profitGiveback, partialExits, timeExit, correlationBlock, lossGovernor, regimeFilter, adaptiveDirection.

## Honest limits
- Never run against real Bybit (sandbox has no network). 324 offline tests pass. Run TESTNET first.
- Live journal extras are keyed `live_<symbol>_<openedAt>`; they are not joined to live_trades rows, so live R-multiples in the performance card stay UNKNOWN until joined.
- Slippage and funding are not in the net-profit estimate (fees only).
- Liquidation distance needs `liquidationPrice` from the exchange; shows n/a if absent. Paper has none.
- UI was not opened in a real browser here.
- No automated parameter tuning (by design). Correlation uses 60 hourly returns; shorter history = UNKNOWN, never assumed.
