# v5.2.4
**Diagnosis (from source):** DEFENSIVE came from the account-drawdown throttle (>=10% below saved peak = 1 slot, minimum leverage, half risk) and, if enabled, the loss governor. "Live on but no trades" = entries PAUSED by design until Resume. Protection ran on EVERY exchange position incl. app-opened ones (time/giveback exits could close them). No code path closes everything just because API keys connect; check Bybit order history: robot closes are reduce-only market orders with order ID starting `cl` / `ptl`.

**New**
- **Take Live Trades** master switch: OFF at every start (TAKE_LIVE_TRADES_ON_START=false). Live authorisation stays a separate step (typed phrase); the button warns if not authorised. PAUSE/FLATTEN/KILL unchanged.
- **Live sizing:** each NEW live trade = margin x leverage. Defaults 1 USDT, 10x. Dashboard (presets + custom) or .env; saved in DB, read fresh per trade, open trades never change. Contract min qty/notional, step, max leverage (default: skip coin; LEVERAGE_OVER_MAX=cap to cap), free balance and existing risk gates still apply (stop-before-liquidation rule is unchanged: high leverage rejects more signals).
- **Drawdown guard** (DRAWDOWN_MODE=warn|enforce|off, live only): warn = banner + log, never blocks, no slot/leverage cut. Paper keeps original limits.
- **Close ALL losing / winning** buttons (live + paper), entries not paused.
- **Manual (app-opened) trades:** stops trailed (tighten only); never auto-closed unless MANUAL_TRADE_EXITS=true; warning if no stop on exchange.
- **Decision log + banners:** real reasons from gate/risk/execution/protection paths, with module state snapshot, deduplicated. **Module cards** (status dot, info, suggestion), **Insights drawer** (decision history, per-position advisor with entry/current integrity and data coverage; not a win probability).
- Module switch changes are logged. MODULES_DEFAULT_OFF=true starts all optional modules OFF (default keeps trailing + giveback ON).

**Not in this version:** module performance tracker, config presets, what-if analysis.
**Tests:** 366 pass (paper/offline only; no real orders). Changed behaviour: live start is always paused (tests updated).
**Run:** `npm run paper` then dashboard `DASHBOARD_PORT=8000 npm run dashboard` (or `npm run all`).
