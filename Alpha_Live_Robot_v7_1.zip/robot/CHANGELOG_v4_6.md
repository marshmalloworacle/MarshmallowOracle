# v4.6 — switchable protection, direction control, control strip (Graphite + Neon Teal)

All new behaviour sits behind per-feature switches (dashboard strip -> "features", or POST /api/v46/features).
State is stored in the DB (`robot_state.feature_flags`), survives restarts, needs no restart to change. OFF = v4.5 behaviour.

## Added
- `src/features/flags.js` — feature switches. Default ON: directionControl, healthStrip, journalExtras, closeButtons. Default OFF: smartTrailing, profitGiveback, timeExit, correlationBlock*, lossGovernor*, regimeFilter*  (*switch exists, logic NOT built yet - see Not done).
- `src/control/direction.js` — BOTH / LONG_ONLY / SHORT_ONLY / PAUSE, durations 1/3/6/12/24h/custom/until-changed, lazy expiry (correct after refresh/restart), blocked-entry counter with reasons. Enforced in `PaperEngine.openFromSignal` and `OrderManager.submitEntry` (every automated entry route). New entries only: never closes positions, never touches stops.
- `src/protection/stops.js` — pure protection maths. Profit basis is explicit: TP% (default) | R | PRICE | MARGIN. Stages 30/50/60/70/80, break-even + fee buffer, lock fractions, ATR trail off the PEAK, giveback guard, 24h time exit (close only if net-of-fees profit; if losing, tighten the stop - never close at a loss because of the clock), partial-exit logic (tested, not wired).
- `src/protection/live.js` — applies it to real exchange positions each live cycle: tighten-only `setTradingStop`, read-back verification, alert on failure (old exchange stop stays), idempotent close (5-min cooldown), per-position state persisted (`protection_state`). Runs independently of pause/direction.
- Paper engine: when smartTrailing/giveback/timeExit is ON it replaces the legacy fixed-distance trailing; OFF = legacy.
- Dashboard: control strip (PAPER/TESTNET/LIVE badge + separate API status, direction control + countdown + blocked count, health pills, feature switches); Graphite + Neon Teal theme (`v46.css`); paper Close shows instant "closing" state and restores on failure.
- `GET /api/v46/state`, `POST /api/v46/features`, `POST /api/v46/direction`.
- `bybit.getPositions()` now also returns markPrice, createdTime, upnl (additive).

## Not done yet (honest list)
Partial exits wiring (paper + live accounting), correlation/aggregate-risk block, daily/weekly governor states, sentiment gauge + regime filter extension, per-position protection columns in the positions table, journal extra fields/exports, startup recovery of protection state beyond persisted DB, market-data-stale entry block.
ATR for protection is a proxy (initial stop distance / 1.5) unless the signal carries `atr`.
Nothing here has been run against real Bybit (sandbox has no network). Test on TESTNET first.
