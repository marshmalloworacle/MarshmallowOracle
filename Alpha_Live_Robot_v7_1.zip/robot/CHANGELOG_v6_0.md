# v6.0
- Soft risk budget: new trades shrink smoothly as open stop-risk nears the cap; hard refusal only above a ceiling (default 150% of cap); winners go to break-even to free budget. Gate now sizes candidate risk from real margin x leverage.
- New optional modules (OFF by default, fail-open): Spread & liquidity, Volume confirmation, Higher-timeframe trend, Volatility filter.
- Presets: Conservative / Balanced / Aggressive with preview, confirm and undo. Never touch live permissions, Take Live Trades, margin, leverage, drawdown mode or stop-loss.
- Module performance tracker and what-if analysis (simulated, flagged low-confidence under 30 trades).
- Messages auto-fade (info 5s, warning 9s, critical 25s); full history in Insights.
- New black + money-green glass theme, iOS-style switches.
- Tests: 374 passing.

# v6.0.1
- Fix: Bybit Unified (UTA) accounts showed equity but 0 available. Wallet is now read without the coin filter, blank availability fields are handled, and available falls back to equity minus margin in use.
- Robot now trades when it sees equity even if the exchange reports 0/blank available (uses equity - margin; the exchange still rejects any order it cannot fund). Dashboard shows the corrected figure.
- Whole dashboard soft iPhone styling, deep charcoal black with money-green accents.
