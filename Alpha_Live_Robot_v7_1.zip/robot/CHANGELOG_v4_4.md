# v4.4: live trading (MEXC + Bybit), small-account scaling, new theme
- NEW `src/exchanges/mexc.js`: official MEXC contract API (HMAC signing, contract-size aware qty, Bybit-shaped output, `apiAllowed` check, no blind POST retries). `EXCHANGE=mexc`.
- NEW signed Bybit endpoints (balance, positions, orders, TP/SL read-back, leverage, cancel) in `bybit.js`.
- NEW `src/execution/orderManager.js`: persisted order lifecycle, duplicate-proof client ids, ambiguity handling, partial fills, stale-entry cancel, stop-loss verification, entry blocking.
- `LiveExecution.submitOrder`: safety stub replaced by the real path; all 8 gates kept.
- NEW `src/risk/scaling.js`: equity tiers (slots/leverage), performance gate, drawdown scale-down, `fitPosition` (slot margin + exchange minimums, never rounds up).
- RiskEngine: LIVE daily-loss stop forced (5%), `refreshProfile`, `check(..., { rules })`.
- Robot: `_liveCycle` (real equity, persistent daily anchor, reconcile) and `_openLive`; commands CONFIRM_LIVE / REVOKE_LIVE / UNBLOCK_ENTRIES; paper-only guards on RESET_ACCOUNT / CLOSE_ALL in LIVE.
- Dashboard: black · gold · crimson-pink theme, PAPER/LIVE ribbon, **Live Account** tab, `/api/live/*` endpoints.
- `npm run mexc:verify`, `npm run bybit:verify`, `npm run live:status`. New tests: 31 (all offline).

## v4.4b
- Slots for small accounts: 4/5/6/7/8/10/12 (was 2/3/4…); per-trade risk = min(1.5%, 6% ÷ slots); exchange-minimum size allowed when its risk ≤ 3% of equity.
- Theme: black · crimson-pink · gold with glass cards (teal removed).
- MEXC: refuses the spot host (api.mexc.com), reports HTTP/MEXC code + next step on 401/1005/406/602/70x; `getClosedTrades`; Bybit `getClosedTrades`.
- Leverage unlock now fed by exchange closed-trade PnL (`live_stats`).
- Slots configurable: SCALING_SLOTS (fixed N, 0=auto) and SCALING_MAX_SLOTS (cap).
- v4.4d ALPHA LIVE ROBOT: renamed; tiers 5/6/8/10/12/14/16 (6 at $15-40); margin sizing (5% equity as isolated margin); aggregate open risk 8%; Bybit isolated-margin gate; RESET locked in LIVE (UI+server). 264 tests.
- v4.4e: slots start at 3 and ramp +1 per 10 closed live trades while PF>=1.2 (SCALING_START_SLOTS/RAMP_EVERY/RAMP_MIN_PF); SCALING_TIERS custom table; fixed bug where unset config values overrode scaling defaults. 267 tests.
- v4.4f: live alerts (dashboard feed + Telegram): scaling up/down grouped, orders/fills/stop-confirmed/closed PnL, safety, hourly heartbeat; Telegram /status shows live info, /pause persisted across restarts (bug fixed: restore order). 272 tests.

## v4.4g: Live Control Center
- Header PAPER|LIVE switch; LIVE view = Account, Risk, Order Preview, Positions & Orders, Live Journal, Strategy, Charts, System Health (own journal/charts, separate from paper).
- Direct read-only exchange reads for the dashboard (account, positions, orders, stop verification, margin mode, latency/clock) with 5 s cache and stale fallback.
- Order Preview (`src/live/preview.js`): same sizing, liquidation and risk checks as the live path; sends nothing.
- Emergency controls: Flatten all (F), Kill switch (K), per-row Close, Pause/Resume, Clear block, Revoke; server-side confirmation words; executed only by the robot process.
- Real trades journaled to live_trades (open at fill, closed from exchange-reported PnL, fees, exit reason).
- UI: mono prices, density toggle, day-P&L sparkline, optional sound cues, green PAPER ribbon vs crimson LIVE ribbon.
