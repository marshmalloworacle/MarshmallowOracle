# v7.0

## Scrolling
Every wide table gets a mirrored scrollbar ABOVE it; long tables scroll inside the page with a sticky header; floating up/down jump buttons (bottom right); thin smooth scrollbars.

## Back arrow + Home (top-left, every page)
← goes back to the previous section you were in (works across Markets tabs and the Account view, also Alt+←); ⌂ goes to the Command Center.

## Position chart (before the Close button)
Markets > Open Positions and Account > Positions & Orders: "📈 Chart" shows 15m candles (5m / 1h switch) with Entry, Take-profit, Stop-loss, the trailing / break-even stop and its path, current price, liquidation (when known). Refreshes every 5 s and survives table refreshes.

## Manual Take
No fixed cap any more (MANUAL_TAKE_HARD_CAP_* = 0; set a number to restore one). Over your position limit: the robot requires confirmation (checkbox in the pop-up, enforced server-side). If total open stop-risk after the trade would exceed MANUAL_TAKE_RISK_CONFIRM_PCT (15% of equity) or the aggregate risk cap would block it: a second confirmation, and only the aggregate open-risk caps are bypassed for that one trade (stop-loss, daily-loss, kill switch, correlation, governor, exchange minimums and margin checks still apply).

## Paper Lab (LIVE mode)
Every qualified scanner setup also runs on a separate paper account (own balance, own risk engine, no exchange access, rows tagged LAB, kept out of every normal paper/live view, no Telegram spam). New "Paper Lab" tab: day verdict (GOOD / MIXED / POOR / WAIT), today vs 7 days, per-coin and per-strategy tables, best/worst coins, open and closed paper trades. Trades opened when your live position limit would already have been full carry "▲ OVER LIVE CAP". ON/OFF switch on the tab (PAPER_LAB_ENABLED default true). The Adaptive Engine can learn from it (learnFrom = all | live | paper | lab).

## Notifications
One iPhone-style notification centre (top right): frosted glass, spring entrance, icon tile, progress hairline, swipe/tap to dismiss. All dashboard messages (incl. live, obsidian and manual-take ones) use it.

## Positions & Orders
Strategy shown as a small coloured badge next to the symbol (also for open orders); looked up from the lifecycle record, then the live journal so it survives restarts.

## Files
New: src/intelligence/paperLab.js, dashboard/v7Routes.js, dashboard/public/{v7.js,v7.css,paperlab.js}, tests/v7_features.test.js.
Changed: src/robot.js, src/paper/engine.js, src/journal/store.js, src/risk/gate.js, src/config.js, src/live/readModel.js, src/intelligence/adaptive.js, dashboard/{server.js,liveRoutes.js}, dashboard/public/{index.html,live.js,v67.js,obsidian.js,obsidian-pages.js,adaptive.js}, .env.example.
