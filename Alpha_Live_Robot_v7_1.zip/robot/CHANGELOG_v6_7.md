# v6.7 — Entry-block auto-clear + manual Take from the scanner

## 1. Entry block clears itself after 15 seconds
- `ENTRY_BLOCK_AUTOCLEAR_SEC=15` (0 = never). The robot checks every 3 s (`robot._entryBlockTick`).
- **VERIFIED mode (default):** after 15 s the robot re-checks the exchange (reconcile). It clears only when no order is UNKNOWN and no filled position lacks an exchange stop-loss. Otherwise the block stays and the dashboard banner says why.
- **FORCE mode:** `ENTRY_BLOCK_FORCE_CLEAR=true` or the "Force-clear after wait even if unresolved" switch in the red banner (dashboard setting wins over .env). Clears after the wait regardless, and the same condition is not re-raised for 30 min (no 15 s flip-flop). The protection loop still works on any unprotected position and SYMBOL_BUSY still stops a second order on the same symbol.
- **Force clear now** button = immediate unconditional clear.
- Banner shows a live countdown and **"Entry block cleared"** (green, 12 s). The Live view "Entries" cell no longer waits for the next scan to update.
- Re-detecting the same condition no longer resets the 15 s clock or re-sends alerts.

## 2. Take any qualified setup from the Market Scanner
- A green **Take** button appears on every QUALIFIED scanner row (not already open). Rows show OPEN / TAKEN markers.
- Click → the robot **re-validates right now**: fresh 4H/1H/15M analysis must still QUALIFY (same direction/strategy), live price within `MANUAL_TAKE_MAX_DRIFT_PCT` (0.5%) of the fresh entry, stop/target not already hit, symbol not already open, portfolio gates + microstructure checks pass. Modal shows fresh entry/SL/TP, drift, risk $, slots; you confirm (paper and live).
- **Overrides only:** the slot limit, per-scan budget and the signal-repeat guard.
- **Never overrides:** hard cap (`MANUAL_TAKE_HARD_CAP_LIVE=5`, `MANUAL_TAKE_HARD_CAP_PAPER=50`), mandatory stop-loss, daily loss, aggregate risk, kill switch/emergency, Take-Live-Trades pause, balance, exchange min-qty, risk-based sizing.
- 30 s duplicate-click lock per symbol; deterministic client order id and SYMBOL_BUSY still protect against double orders.
- Scanner list now shows one row per symbol+strategy+direction (each scan used to save a fresh duplicate row).

## Files changed
src/execution/orderManager.js, src/robot.js, src/risk/engine.js, src/paper/engine.js, src/config.js, dashboard/server.js, dashboard/liveRoutes.js, dashboard/public/index.html, dashboard/public/v67.js (new), .env.example, package.json, tests/v67_entry_block_manual_take.test.js (new).
