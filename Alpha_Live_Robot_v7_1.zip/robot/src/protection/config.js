'use strict';
/**
 * Tunable protection / risk settings. Precedence: dashboard override (DB `protection_config`) > env > default.
 * All numeric, bounded. Changing a value takes effect on the next evaluation (no restart).
 */
const journal = require('../journal/store');
const E = (k, d) => (process.env[k] !== undefined && process.env[k] !== '' ? Number(process.env[k]) : d);

const SPEC = {
  staleHours:       { def: E('PROT_STALE_HOURS', 8),   min: 1,   max: 48,  label: 'Stale-trade exit (hours): close a losing or going-nowhere trade after this long' },
  flatPct:          { def: E('PROT_FLAT_PCT', 15),     min: 0,   max: 50,  label: 'Going nowhere = progress below this % of target' },
  maxHours:         { def: E('PROT_MAX_HOURS', 24),    min: 2,   max: 168, label: 'Max hold (hours): close if still in profit (winners otherwise keep trailing)' },
  atrMult:          { def: E('PROT_ATR_MULT', 1.5),    min: 0.5, max: 6,   label: 'ATR trailing multiple' },
  givebackPct:      { def: E('PROT_GIVEBACK_PCT', 35), min: 10,  max: 90,  label: 'Giveback % of peak profit that tightens the stop' },
  aggRiskPct:       { def: E('RISK_MAX_AGG_RISK_PCT', 8),  min: 1, max: 50, label: 'Max aggregate open risk (% of equity, to protective stops)' },
  taperStartPct:    { def: E('RISK_TAPER_START_PCT', 50),  min: 10, max: 95,  label: 'Soft risk budget: start shrinking new trades when open risk passes this % of the cap' },
  taperMinPct:      { def: E('RISK_TAPER_MIN_PCT', 25),    min: 5,  max: 100, label: 'Soft risk budget: smallest size a new trade shrinks to (% of normal) at the cap' },
  ceilingPct:       { def: E('RISK_HARD_CEILING_PCT', 150), min: 100, max: 500, label: 'Soft risk budget: hard ceiling (% of the cap) - the only point where new trades are refused' },
  spreadMaxBps:     { def: E('FILTER_SPREAD_MAX_BPS', 12), min: 1, max: 200, label: 'Spread filter: max bid/ask spread (basis points)' },
  volumeMinRatio:   { def: E('FILTER_VOLUME_MIN_RATIO', 0.8), min: 0.1, max: 5, label: 'Volume confirmation: min last-hour volume vs 20h average (x)' },
  volatilityMaxRatio:{ def: E('FILTER_VOLATILITY_MAX_RATIO', 2.5), min: 1.2, max: 10, label: 'Volatility filter: max volatility vs normal (x)' },
  corrRiskPct:      { def: E('RISK_MAX_CORR_RISK_PCT', 5), min: 0.5, max: 50, label: 'Max risk in one correlated same-direction group (% equity)' },
  corrThreshold:    { def: E('RISK_CORR_THRESHOLD', 0.75), min: 0.3, max: 0.99, label: 'Correlation treated as "same bet"' },
  dirNotionalPct:   { def: E('RISK_MAX_DIR_NOTIONAL_PCT', 80), min: 50, max: 100, label: 'Max share of notional in one direction (needs 3+ positions)' },
  govCautionPct:    { def: E('GOV_DAILY_CAUTION_PCT', 2),   min: 0.5, max: 50, label: 'Daily drawdown % -> CAUTION' },
  govDefensivePct:  { def: E('GOV_DAILY_DEFENSIVE_PCT', 3.5), min: 0.5, max: 50, label: 'Daily drawdown % -> DEFENSIVE' },
  govHaltPct:       { def: E('GOV_DAILY_HALT_PCT', 5),      min: 0.5, max: 50, label: 'Daily drawdown % -> ENTRY HALT' },
  govEmergencyPct:  { def: E('GOV_DAILY_EMERGENCY_PCT', 8), min: 1,   max: 90, label: 'Daily drawdown % -> EMERGENCY' },
  govWeeklyHaltPct: { def: E('GOV_WEEKLY_HALT_PCT', 10),    min: 1,   max: 90, label: 'Weekly drawdown % -> ENTRY HALT' },
  govAccountDdPct:  { def: E('GOV_ACCOUNT_DD_PCT', 20),     min: 1,   max: 95, label: 'Drawdown from equity peak % -> ENTRY HALT' },
  shockPct:         { def: E('REGIME_SHOCK_PCT', 3),        min: 0.5, max: 20, label: 'BTC 1h move % that counts as a market shock' },
  staleDataSec:     { def: E('STALE_DATA_SEC', 300),        min: 30,  max: 3600, label: 'Market data older than this blocks entries (sec)' },
};
const TEXT = { govEmergencyAction: { def: (process.env.GOV_EMERGENCY_ACTION || 'HALT').toUpperCase(), allowed: ['HALT', 'FLATTEN'], label: 'EMERGENCY action: HALT (stop entries, keep stops) or FLATTEN (close everything)' } };

function overrides() { try { return journal.getState('protection_config') || {}; } catch (_) { return {}; } }
function get() {
  const o = overrides(); const out = {};
  for (const [k, s] of Object.entries(SPEC)) out[k] = Number.isFinite(o[k]) ? o[k] : s.def;
  for (const [k, s] of Object.entries(TEXT)) out[k] = s.allowed.includes(o[k]) ? o[k] : (s.allowed.includes(s.def) ? s.def : s.allowed[0]);
  return out;
}
function set(key, value) {
  if (TEXT[key]) { const v = String(value).toUpperCase(); if (!TEXT[key].allowed.includes(v)) throw new Error(`${key} must be ${TEXT[key].allowed.join('|')}`); const o = overrides(); o[key] = v; journal.setState('protection_config', o); return get(); }
  const s = SPEC[key]; if (!s) throw new Error(`Unknown setting "${key}"`);
  const n = Number(value); if (!Number.isFinite(n) || n < s.min || n > s.max) throw new Error(`${key} must be between ${s.min} and ${s.max}`);
  const o = overrides(); o[key] = n; journal.setState('protection_config', o); return get();
}
function describe() { const cur = get(); return [...Object.entries(SPEC).map(([k, s]) => ({ key: k, label: s.label, value: cur[k], min: s.min, max: s.max, def: s.def })),
  ...Object.entries(TEXT).map(([k, s]) => ({ key: k, label: s.label, value: cur[k], options: s.allowed, def: s.def }))]; }
/** stops.js config object built from the live settings */
function stopsConfig() {
  const c = get();
  return { atrMult: c.atrMult, giveback: { pct: c.givebackPct / 100 }, timeExit: { staleHours: c.staleHours, flatPct: c.flatPct, maxHours: c.maxHours } };
}
module.exports = { get, set, describe, stopsConfig, SPEC };
