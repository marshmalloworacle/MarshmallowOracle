'use strict';
/**
 * Applies protection decisions to REAL exchange positions (testnet + live). Exchange state is authoritative.
 * Runs every live cycle AND on every price tick (per-symbol, throttled, single-flight - see robot._onLiveTicker).
 * Safety rules: stops only ever tighten; the existing exchange stop is never removed; after a change the stop is read
 * back from the exchange (mismatch -> alert, old stop remains); closes/partials are idempotent (client ids + cooldown);
 * runs independently of pause / direction / governor (those only gate NEW entries).
 */
const crypto = require('crypto');
const journal = require('../journal/store');
const flags = require('../features/flags');
const pcfg = require('./config');
const extras = require('../journal/extras');
const { evaluate, isTighter } = require('./stops');
const logger = require('../utils/logger');
const decisions = require('../decisions/log');
const cfgRt = require('../config');

const KEY = 'protection_state', VIEW = 'protection_view';
const CLOSE_COOLDOWN_MS = 5 * 60 * 1000;
const floorTo = (v, step) => (step > 0 ? Math.floor(v / step + 1e-9) * step : v);

function viewRow(pos, st, ev, mark, now) {
  const long = pos.side === 'LONG', stop = ev.stop;
  const peakMove = ev.peakProgress, cur = ev.progress;
  return { mode: 'live', symbol: pos.symbol, side: pos.side, entry: pos.entry, mark, qty: pos.qty, initialStop: st.initialStop, stop, stopReason: ev.reason || st.lastReason || null,
    stage: ev.stage, peakProgress: Number(peakMove.toFixed(1)), progress: Number(cur.toFixed(1)), givebackPct: peakMove > 0 ? Number(Math.max(0, (peakMove - cur) / peakMove * 100).toFixed(1)) : 0,
    distToStopPct: stop ? Number(((long ? mark - stop : stop - mark) / mark * 100).toFixed(2)) : null,
    liqDistPct: pos.liquidationPrice ? Number((Math.abs(mark - pos.liquidationPrice) / mark * 100).toFixed(2)) : null,
    upnl: pos.upnl ?? null, manual: !!st.manual, protectedStop: !!pos.stopLoss, hoursOpen: Number(((now - st.openedAt) / 3600e3).toFixed(1)), atr: st.atr || null, atrSource: st.atrSource || null };
}

async function _run({ exchange, orders, positions, tickers = {}, alert = () => {}, now = Date.now(), prune = true }) {
  const f = flags.all();
  if (!(f.smartTrailing || f.profitGiveback || f.timeExit || f.partialExits || f.riskTaper)) return { skipped: 'features off', actions: [] };
  const all = journal.getState(KEY) || {};
  const view = prune ? [] : (journal.getState(VIEW) || []).filter(r => r.mode === 'live' && !positions.some(p => p.symbol === r.symbol));
  const live = new Set(), actions = [];
  const cfg = pcfg.stopsConfig();
  for (const pos of positions) {
    const key = `${pos.symbol}:${pos.side}`; live.add(key);
    const mark = pos.markPrice || tickers[pos.symbol]?.markPrice || tickers[pos.symbol]?.lastPrice;
    const rec = orders.list(true).find(r => r.symbol === pos.symbol && r.direction === pos.side);
    const manual = !rec;   // v5.2.4: opened in the exchange app (or otherwise not by this robot)
    if (manual && !cfgRt.protectManualTrades) { actions.push({ symbol: pos.symbol, skipped: 'MANUAL_TRADE_NOT_PROTECTED (PROTECT_MANUAL_TRADES=false)' }); continue; }
    if (!(mark > 0) || !pos.stopLoss) {
      actions.push({ symbol: pos.symbol, skipped: !pos.stopLoss ? 'NO_STOP_ON_EXCHANGE' : 'NO_MARK' });
      if (!pos.stopLoss && manual) decisions.record({ type: 'TRADE_WARNING', severity: 'WARNING', symbol: pos.symbol, direction: pos.side, module: 'manualProtection', reason: `${pos.symbol} (opened outside the robot) has NO stop-loss on the exchange, so the robot cannot guard it.`,
        action: 'Not protected', recommend: 'Set a stop-loss on this position in the exchange app; the robot will then trail it (tighten only).', key: `manual_nostop_${pos.symbol}`, cooldownMs: 60 * 60 * 1000 });
      continue;
    }
    const st = all[key] || { openedAt: pos.createdTime || now, initialStop: pos.stopLoss, partialsDone: [], partials: [],
      atr: (rec && rec.atr) || null, atrSource: rec && rec.atr ? 'SIGNAL_ATR' : 'STOP_DISTANCE_PROXY', regime: (rec && rec.regime) || null };
    if (!st.atr) st.atr = Math.abs(pos.entry - st.initialStop) / 1.5;
    // the tightest stop we know of: a previous successful update must not be undone by a stale exchange read
    const known = st.lastStop && isTighter(pos.side, pos.stopLoss, st.lastStop) ? st.lastStop : pos.stopLoss;
    const ev = evaluate({ side: pos.side, entry: pos.entry, stop: known, initialStop: st.initialStop,
      target: pos.takeProfit || (rec && rec.takeProfit) || pos.entry + (pos.side === 'LONG' ? 1 : -1) * Math.abs(pos.entry - st.initialStop) * 2,
      mark, atr: st.atr, openedAt: st.openedAt, leverage: pos.leverage }, st, f, cfg, now);
    all[key] = { ...st, ...ev.state, manual, stage: ev.stage, peakPrice: ev.peakPrice, lastReason: ev.reason || st.lastReason };
    const cur = all[key];

    if (manual && !cfgRt.manualTradeExits && (ev.exit || ev.partial)) {   // trail-only for manual trades: never auto-close or split them unless MANUAL_TRADE_EXITS=true
      if (ev.exit) actions.push({ symbol: pos.symbol, skipped: `MANUAL_TRADE_EXIT_SUPPRESSED (${ev.exit.reason})` });
      ev.exit = null; ev.partial = null;
    }
    if (ev.exit) {
      decisions.record({ type: 'TRADE_CLOSED', severity: 'WARNING', symbol: pos.symbol, direction: pos.side, module: /GIVEBACK/.test(ev.exit.reason) ? 'profitGiveback' : 'timeExit', reason: `Robot closed ${pos.symbol}: ${ev.exit.reason}`,
        measured: { progressR: Number(ev.progress.toFixed(2)), peakProgressR: Number(ev.peakProgress.toFixed(2)), hoursOpen: Number(((now - st.openedAt) / 3600e3).toFixed(1)) }, action: 'Reduce-only market close', mode: 'live', key: `close_${pos.symbol}_${ev.exit.reason}`, cooldownMs: CLOSE_COOLDOWN_MS });
      if (st.closingAt && now - st.closingAt < CLOSE_COOLDOWN_MS) { actions.push({ symbol: pos.symbol, skipped: 'CLOSE_ALREADY_SENT' }); }
      else {
        cur.closingAt = now; cur.exitReason = ev.exit.reason;
        const r = await orders.closePosition(pos.symbol, ev.exit.reason);
        actions.push({ symbol: pos.symbol, close: ev.exit.reason, ok: !!r.ok });
        if (!r.ok) alert({ category: 'safety', severity: 'WARNING', title: `Protection exit failed: ${pos.symbol}`, message: r.reason });
      }
      view.push(viewRow(pos, cur, ev, mark, now)); continue;
    }

    if (ev.partial && !cur.partialsDone.includes(ev.partial.stage)) {
      const rules = require('../exchanges/rules').getRules(pos.symbol) || {};
      const qty = floorTo(pos.qty * ev.partial.fraction, rules.qtyStep || 0);
      if (qty > 0 && qty >= (rules.minQty || 0) && pos.qty - qty >= (rules.minQty || 0)) {
        const cid = 'ptl' + crypto.createHash('sha1').update(`${pos.symbol}|${st.openedAt}|${ev.partial.stage}`).digest('hex').slice(0, 24);
        try {
          await exchange.placeOrder({ symbol: pos.symbol, side: pos.side === 'LONG' ? 'Sell' : 'Buy', qty, orderType: 'Market', reduceOnly: true, clientOrderId: cid });
          cur.partialsDone.push(ev.partial.stage); cur.partials.push({ at: now, stage: ev.partial.stage, qty, price: mark });
          actions.push({ symbol: pos.symbol, partial: qty, stage: ev.partial.stage });
          alert({ category: 'orders', severity: 'INFO', title: `Partial profit: ${pos.symbol}`, message: `closed ${qty} at stage ${ev.partial.stage} - remainder keeps its stop` });
        } catch (e) {
          if (/duplicate|exist|link/i.test(e.message)) cur.partialsDone.push(ev.partial.stage);        // same client id already accepted
          else { actions.push({ symbol: pos.symbol, partialError: e.message }); alert({ category: 'safety', severity: 'WARNING', title: `Partial exit failed: ${pos.symbol}`, message: e.message, key: `ptl_${pos.symbol}`, cooldownMs: 600000 }); }
        }
      } else cur.partialsDone.push(ev.partial.stage);   // too small to split: do not retry every tick
    }

    if (f.riskTaper && ev.progress >= 30) {   // v6.0 soft risk budget: when the budget is getting used up, free it by moving WINNERS to break-even (plus fees). Tighten only.
      const pr = journal.getState('portfolio_risk') || {}, capNow = pcfg.get();
      if (pr.aggRiskPct != null && pr.aggRiskPct >= capNow.aggRiskPct * capNow.taperStartPct / 100) {
        const be = pos.entry * (1 + (pos.side === 'LONG' ? 1 : -1) * 0.0008);
        if (isTighter(pos.side, ev.stop || pos.stopLoss, be) && (pos.side === 'LONG' ? mark > be * 1.001 : mark < be * 0.999)) { ev.stop = be; ev.reason = 'BUDGET_BREAKEVEN'; }
      }
    }
    if (isTighter(pos.side, pos.stopLoss, ev.stop)) {
      try {
        await exchange.setTradingStop({ symbol: pos.symbol, stopLoss: ev.stop });
        const back = (await exchange.getStopOrders(pos.symbol)).find(s => s.long === (pos.side === 'LONG'));
        const ok = back && Math.abs(back.stopLoss - ev.stop) <= Math.max(ev.stop * 0.0005, 1e-9);
        if (ok) { cur.lastStop = ev.stop; pos.stopLoss = ev.stop; cur.moves = [...(cur.moves || []), { ts: now, stop: ev.stop, reason: ev.reason || 'trailing' }].slice(-25);
          decisions.record({ type: 'TRADE_MODIFIED', severity: 'INFO', symbol: pos.symbol, direction: pos.side, module: 'smartTrailing', reason: `Stop moved closer to ${ev.stop} (${ev.reason || 'trailing'})${manual ? ' on a trade you opened yourself' : ''}`,
            measured: { stop: ev.stop, stage: ev.stage }, action: 'Stop tightened and verified on the exchange', mode: 'live', key: `trail_${pos.symbol}`, cooldownMs: 15 * 60 * 1000 }); }
        actions.push({ symbol: pos.symbol, stop: ev.stop, reason: ev.reason, verified: !!ok });
        if (!ok) alert({ category: 'safety', severity: 'WARNING', title: `Stop update NOT verified: ${pos.symbol}`, message: `wanted ${ev.stop}, exchange shows ${back ? back.stopLoss : 'none'}`, key: `stopverify_${pos.symbol}`, cooldownMs: 600000 });
      } catch (e) {
        logger.warn(`protection: stop update failed for ${pos.symbol}: ${e.message} (existing exchange stop remains)`);
        actions.push({ symbol: pos.symbol, error: e.message });
        alert({ category: 'safety', severity: 'WARNING', title: `Stop update failed: ${pos.symbol}`, message: `${e.message} - previous exchange stop is still active`, key: `stopfail_${pos.symbol}`, cooldownMs: 600000 });
      }
    }
    view.push(viewRow(pos, cur, ev, mark, now));
  }
  if (prune) for (const k of Object.keys(all)) if (!live.has(k)) {          // position gone: write its journal extras, drop state
    const s = all[k], [sym, side] = k.split(':'), long = side === 'LONG';
    try {
      const entry = s.entryPrice; void entry;
      extras.merge(`live_${sym}_${s.openedAt}`, { symbol: sym, direction: side, openedAt: s.openedAt, closedAt: now, exitReason: s.exitReason || 'EXCHANGE_STOP_TP_OR_MANUAL', stageReached: s.stage || null, partials: s.partials || [],
        peakPrice: s.peakPrice, troughPrice: s.troughPrice, atr: s.atr, atrSource: s.atrSource, initialStop: s.initialStop, finalStop: s.lastStop || null, regime: s.regime || null, protectionBehaved: s.lastStop ? 'STOP_MOVED' : 'STOP_UNCHANGED' });
    } catch (_) { /* best effort */ }
    delete all[k];
  }
  journal.setState(KEY, all);
  journal.setState(VIEW, [...view, ...(prune ? [] : [])]);
  return { actions };
}
// Serialise all runs (cycle + per-tick) so state read-modify-write never interleaves.
let chain = Promise.resolve();
function run(opts) { const p = chain.then(() => _run(opts)); chain = p.catch(() => {}); return p; }
module.exports = { run, KEY, VIEW };
