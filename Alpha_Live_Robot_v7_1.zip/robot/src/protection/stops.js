'use strict';
/**
 * Position protection maths (pure, no I/O). One evaluate() call returns what should change for ONE position.
 *
 * PROFIT BASIS (explicit and configurable, never mixed):
 *   TP     = % of the distance entry -> take-profit already travelled   (default)
 *   R      = multiples of initial risk (|entry - initial stop|); stage N% means N/100 R
 *   PRICE  = % price move from entry
 *   MARGIN = % return on margin (price move % x leverage)
 *
 * Invariants: a LONG stop only moves up, a SHORT stop only down; a stop is never placed on the wrong side of the
 * market (must stay `minGap` behind mark); all outputs are suggestions - the caller applies and verifies them.
 */
// v5.2: the trailing ladder starts EARLY (first lock at 15% of the way to take-profit) and the ATR trail is armed from the
// moment a trade opens (armAtOpen). Ladder is configurable: PROT_STAGES="15,30,50,60,70,80" PROT_LOCKS="0,0.1,0.2,0.35,0.5,0.65"
// (stages = % of the way to TP, ascending; locks = fraction of PEAK profit protected at that stage, same length).
function envList(k, fb, lo, hi) {
  const raw = process.env[k]; if (!raw) return fb;
  const v = raw.split(',').map(x => Number(x.trim()));
  return v.length && v.every(n => Number.isFinite(n) && n >= lo && n <= hi) ? v : fb;
}
const STAGES = envList('PROT_STAGES', [15, 30, 50, 60, 70, 80], 1, 100);
const LOCKS = envList('PROT_LOCKS', [0.0, 0.1, 0.2, 0.35, 0.5, 0.65], 0, 0.95);
const LADDER_OK = STAGES.length === LOCKS.length && STAGES.every((x, i) => i === 0 || x > STAGES[i - 1]);
const DEFAULTS = {
  stageBasis: 'TP',
  stages: LADDER_OK ? STAGES : [15, 30, 50, 60, 70, 80],
  // fraction of the PEAK profit (in price distance) locked in once each stage is reached; stage 1 = break-even + fees
  lockFractions: LADDER_OK ? LOCKS : [0.0, 0.1, 0.2, 0.35, 0.5, 0.65],
  armAtOpen: process.env.PROT_ARM_AT_OPEN !== 'false',   // ATR trail follows the peak from the first favourable tick (never looser than the initial stop)
  atrMult: 1.5, minGapAtr: 0.25, minGapPct: 0.0005,
  feeBps: 11,                         // round-trip taker estimate (2 x 5.5 bps); used for "net profit" tests
  breakEvenBufferBps: 6,              // break-even stop sits this far beyond entry so fees are covered
  giveback: { enabled: true, minPeakStage: 2, pct: 0.35, action: 'TIGHTEN' }, // TIGHTEN | EXIT
  partial: { enabled: true, steps: [{ stage: 50, fraction: 0.3 }] },
  // staleHours: a LOSING or GOING-NOWHERE trade is closed after this long (frees the slot for better setups).
  // maxHours: a trade that is in profit at this age is closed; winners that are still trailing between stale and max are left alone.
  // whenLosing: 'CLOSE' (default, user choice) | 'TIGHTEN' (old behaviour: tighten stop instead of closing).
  timeExit: { staleHours: 8, flatPct: 15, maxHours: 24, graceHours: 0, whenLosing: 'CLOSE', retightenMin: 60, tightenFraction: 0.5 },
};

const dirSign = (side) => (side === 'LONG' ? 1 : -1);
function isTighter(side, oldStop, newStop) { return oldStop == null ? true : (side === 'LONG' ? newStop > oldStop : newStop < oldStop); }

/** Progress of the trade in the chosen basis, in percent (R basis: 100 = 1R so stages read 30/50/... as 0.3R...). */
function progress(p, basis, price) {
  const s = dirSign(p.side);
  const move = (price - p.entry) * s;
  if (basis === 'R') { const r = Math.abs(p.entry - p.initialStop); return r > 0 ? (move / r) * 100 : 0; }
  if (basis === 'PRICE') return (move / p.entry) * 100;
  if (basis === 'MARGIN') return (move / p.entry) * 100 * (p.leverage || 1);
  const full = Math.abs(p.target - p.entry);                  // TP
  return full > 0 ? (move / full) * 100 : 0;
}

/** Net profit estimate in price units after round-trip fees (slippage/funding: not modelled, said so in docs). */
function netMove(p, price, cfg) { return (price - p.entry) * dirSign(p.side) - p.entry * (cfg.feeBps / 1e4); }

/**
 * p: { side, entry, stop, initialStop, target, mark, qty, leverage, openedAt, atr }
 * st (persisted per position): { peakPrice, stageIdx, partialsDone[], lastTightenAt }
 * features: { smartTrailing, profitGiveback, partialExits, timeExit } booleans
 * Returns { stop, stageIdx, stage, peakPrice, peakProgress, progress, reason, partial, exit, state }
 */
function evaluate(p, st, features, userCfg = {}, now = Date.now()) {
  const cfg = { ...DEFAULTS, ...userCfg, giveback: { ...DEFAULTS.giveback, ...(userCfg.giveback || {}) },
    partial: { ...DEFAULTS.partial, ...(userCfg.partial || {}) }, timeExit: { ...DEFAULTS.timeExit, ...(userCfg.timeExit || {}) } };
  const s = dirSign(p.side);
  const state = { peakPrice: p.entry, troughPrice: p.entry, stageIdx: -1, partialsDone: [], lastTightenAt: 0, ...(st || {}) };
  // peak is the most favourable price ever seen (monotonic)
  if ((p.mark - state.peakPrice) * s > 0) state.peakPrice = p.mark;
  const prog = progress(p, cfg.stageBasis, p.mark);
  const peakProg = progress(p, cfg.stageBasis, state.peakPrice);
  let stageIdx = state.stageIdx;
  cfg.stages.forEach((th, i) => { if (peakProg >= th && i > stageIdx) stageIdx = i; });
  state.stageIdx = stageIdx;

  const out = { stop: p.stop, stageIdx, stage: stageIdx >= 0 ? cfg.stages[stageIdx] : null, peakPrice: state.peakPrice,
    progress: prog, peakProgress: peakProg, reason: null, partial: null, exit: null, state };
  const gap = Math.max(p.mark * cfg.minGapPct, (p.atr || 0) * cfg.minGapAtr);
  const limit = p.mark - s * gap;                               // stop may not be closer to market than this
  const consider = (cand, why) => {
    if (!Number.isFinite(cand)) return;
    const capped = s > 0 ? Math.min(cand, limit) : Math.max(cand, limit);
    if (isTighter(p.side, out.stop, capped)) { out.stop = capped; out.reason = why; }
  };

  if (features.smartTrailing && (stageIdx >= 0 || cfg.armAtOpen)) {
    const peakMove = (state.peakPrice - p.entry) * s;
    if (stageIdx >= 0) {
      const be = p.entry + s * p.entry * (cfg.breakEvenBufferBps / 1e4);
      const lockFrac = cfg.lockFractions[Math.min(stageIdx, cfg.lockFractions.length - 1)] || 0;
      consider(stageIdx === 0 || lockFrac === 0 ? be : p.entry + s * Math.max(peakMove * lockFrac, p.entry * cfg.breakEvenBufferBps / 1e4), `STAGE_${out.stage}_LOCK`);
    }
    // armed from the open: once the trade has moved in our favour, the stop trails the PEAK by the ATR multiple (only ever tightens)
    if (p.atr > 0 && peakMove > 0) consider(state.peakPrice - s * cfg.atrMult * p.atr, stageIdx >= 0 ? `ATR_TRAIL_${stageIdx + 1}` : 'ATR_TRAIL_OPEN');
  }

  if (features.profitGiveback && cfg.giveback.enabled && stageIdx + 1 >= cfg.giveback.minPeakStage) {
    const peakMove = (state.peakPrice - p.entry) * s, curMove = (p.mark - p.entry) * s;
    if (peakMove > 0 && curMove <= peakMove * (1 - cfg.giveback.pct)) {
      if (cfg.giveback.action === 'EXIT' && netMove(p, p.mark, cfg) > 0) out.exit = { reason: 'GIVEBACK_EXIT' };
      else consider(p.entry + s * Math.max(curMove * 0.5, 0), 'GIVEBACK_TIGHTEN');
    }
  }

  if (features.partialExits && cfg.partial.enabled !== false) {
    for (const step of cfg.partial.steps) {
      if (peakProg >= step.stage && !state.partialsDone.includes(step.stage) && prog >= step.stage * 0.9) { out.partial = { stage: step.stage, fraction: step.fraction }; break; }
    }
  }

  if (features.timeExit && p.openedAt) {
    const te = cfg.timeExit, hrs = (now - p.openedAt) / 3600e3;
    const net = netMove(p, p.mark, cfg) > 0;
    const goingNowhere = Math.abs(prog) < te.flatPct && !(prog > 0 && net && stageIdx >= 0);
    if (hrs >= te.staleHours && (!net || goingNowhere) && !out.exit) {
      if (te.whenLosing === 'CLOSE') out.exit = { reason: net ? 'STALE_EXIT_FLAT' : 'STALE_EXIT_LOSING' };
      else if ((now - (state.lastTightenAt || 0)) / 60e3 >= te.retightenMin) {
        const before = out.stop; consider(out.stop + (p.mark - out.stop) * te.tightenFraction, 'TIME_EXIT_TIGHTEN');
        if (out.stop !== before) state.lastTightenAt = now;
      }
    } else if (hrs >= te.maxHours + te.graceHours && net && !out.exit) out.exit = { reason: 'TIME_EXIT_MAX_HOLD_PROFIT' };
  }
  // excursions for the journal (price terms): MFE = peak favourable, MAE = worst adverse
  if (state.troughPrice == null || (p.mark - state.troughPrice) * s < 0) state.troughPrice = p.mark;
  return out;
}

module.exports = { DEFAULTS, evaluate, progress, netMove, isTighter };
