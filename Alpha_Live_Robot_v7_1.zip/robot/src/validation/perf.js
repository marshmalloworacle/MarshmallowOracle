'use strict';
/**
 * Performance intelligence from the journal (paper_trades + live_trades) joined with trade_extras.
 * Pure read-side. Small samples are flagged (n < 30 => "low sample"), never presented as proof.
 */
const journal = require('../journal/store');
const extras = require('../journal/extras');

function stats(rows) {
  const n = rows.length; if (!n) return { n: 0 };
  const wins = rows.filter(r => r.pnl > 0), losses = rows.filter(r => r.pnl <= 0);
  const gw = wins.reduce((s, r) => s + r.pnl, 0), gl = Math.abs(losses.reduce((s, r) => s + r.pnl, 0));
  let eq = 0, peak = 0, mdd = 0; for (const r of [...rows].sort((a, b) => a.close_time - b.close_time)) { eq += r.pnl; peak = Math.max(peak, eq); mdd = Math.max(mdd, peak - eq); }
  const R = rows.filter(r => r.R != null);
  return { n, winRate: wins.length / n * 100, avgWin: wins.length ? gw / wins.length : 0, avgLoss: losses.length ? -gl / losses.length : 0, profitFactor: gl > 0 ? gw / gl : (gw > 0 ? null : 0),
    expectancy: rows.reduce((s, r) => s + r.pnl, 0) / n, total: rows.reduce((s, r) => s + r.pnl, 0), fees: rows.reduce((s, r) => s + (r.fee || 0), 0), maxDrawdown: mdd,
    avgR: R.length ? R.reduce((s, r) => s + r.R, 0) / R.length : null, lowSample: n < 30 };
}
const by = (rows, f) => { const m = {}; for (const r of rows) (m[f(r) || 'unknown'] ||= []).push(r); return Object.fromEntries(Object.entries(m).map(([k, v]) => [k, stats(v)])); };

function build(limit = 1000) {
  const d = journal.getDb(); const ex = Object.fromEntries(extras.all(5000).map(e => [e.id, e]));
  const q = (t) => { try { return d.prepare(`SELECT id, strategy_name, direction, regime, pnl, fee, initial_risk, exit_reason, close_time, '${t}' AS src FROM ${t} WHERE close_time IS NOT NULL AND pnl IS NOT NULL ORDER BY close_time DESC LIMIT ?`).all(limit); } catch (_) { return []; } };
  const rows = [...q('paper_trades'), ...q('live_trades')].map(r => ({ ...r, R: r.initial_risk > 0 && ex[r.id] && ex[r.id].resultR != null ? ex[r.id].resultR : null, x: ex[r.id] || null }));
  const out = { overall: stats(rows), paper: stats(rows.filter(r => r.src === 'paper_trades')), live: stats(rows.filter(r => r.src === 'live_trades')),
    byStrategy: by(rows, r => r.strategy_name), byDirection: by(rows, r => r.direction), byRegime: by(rows, r => r.regime), byExit: by(rows, r => r.exit_reason) };
  const withX = rows.filter(r => r.x && r.x.givebackFromPeak != null);
  out.protection = { n: withX.length, avgGivebackPct: withX.length ? withX.reduce((s, r) => s + r.x.givebackFromPeak * 100, 0) / withX.length : null,
    avgPeakR: withX.length ? withX.reduce((s, r) => s + (r.x.peakR || 0), 0) / withX.length : null, trailedExits: rows.filter(r => /TRAIL|STAGE|GIVEBACK/.test(r.exit_reason || '')).length,
    staleExits: rows.filter(r => /STALE|TIME_EXIT/.test(r.exit_reason || '')).length };
  return out;
}
module.exports = { build, stats };
