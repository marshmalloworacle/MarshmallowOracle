'use strict';
/**
 * ADAPTIVE WINNING STRATEGY ENGINE (v6.8)
 *
 * Learns from the robot's own CLOSED trades (paper_trades + live_trades) and gives proven strategies a bounded advantage when
 * qualified setups compete for slots / the per-scan budget. It ONLY re-orders (and, in STRONG mode, skips proven losers):
 *  - never changes sig.score, sizing, leverage, margin, stops or any risk limit; the risk engine / gate keep final authority
 *  - never adds a signal that did not already qualify (no qualified setup = NO TRADE)
 *  - OFF = the original order, byte for byte (history keeps being collected; "shadow" notes what it would have favoured)
 * Settings live in robot_state key `adaptive_cfg` (dashboard wins over .env after first save), shared by robot + dashboard.
 */
const config = require('../config');       // loads .env before the defaults below are read
const journal = require('../journal/store');

const CFG_KEY = 'adaptive_cfg', APPLIED_KEY = 'adaptive_applied', STATE_KEY = 'adaptive_state', SHADOW_KEY = 'adaptive_shadow';
const MODES = ['OFF', 'ON', 'STRONG'], LEARN = ['all', 'live', 'paper', 'lab'];   // paper = plain paper journal, lab = Paper Lab (separate paper account used while LIVE)
const CACHE_MS = 30000, RECENT_N = 15, MIN_RECENT = 8, HYST_MARGIN = 6, CONC_PEN = 2, CONC_CAP = 6;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const r2 = (v) => (v == null || !Number.isFinite(v) ? null : Number(v.toFixed(2)));

// ── settings ─────────────────────────────────────────────────────────────────────────────────────
function envDefaults() {
  const e = process.env, num = (k, d) => { const v = Number(e[k]); return e[k] !== undefined && e[k] !== '' && Number.isFinite(v) ? v : d; };
  const enabled = String(e.ADAPTIVE_STRATEGY_ENABLED || 'false').toLowerCase() === 'true';
  const m = String(e.ADAPTIVE_STRATEGY_MODE || 'ON').toUpperCase(), on = MODES.includes(m) && m !== 'OFF' ? m : 'ON';
  let rw = clamp(num('ADAPTIVE_STRATEGY_RECENT_WEIGHT', 0.6), 0, 1), lw = clamp(num('ADAPTIVE_STRATEGY_LONG_TERM_WEIGHT', 0.4), 0, 1);
  if (rw + lw <= 0) { rw = 0.6; lw = 0.4; } const s = rw + lw; rw /= s; lw /= s;
  const learn = String(e.ADAPTIVE_STRATEGY_LEARN_FROM || 'all').toLowerCase();
  return { mode: enabled ? on : 'OFF', lastOnMode: on, minTrades: clamp(Math.round(num('ADAPTIVE_STRATEGY_MIN_TRADES', 30)), 5, 500),
    minRegimeTrades: clamp(Math.round(num('ADAPTIVE_STRATEGY_MIN_REGIME_TRADES', 15)), 3, 200), recentWeight: rw, longTermWeight: lw,
    bonusOn: clamp(num('ADAPTIVE_STRATEGY_BONUS_ON', 8), 0, 20), bonusStrong: clamp(num('ADAPTIVE_STRATEGY_BONUS_STRONG', 15), 0, 30),
    skipMinTrades: clamp(Math.round(num('ADAPTIVE_STRATEGY_SKIP_MIN_TRADES', 50)), 20, 1000), learnFrom: LEARN.includes(learn) ? learn : 'all',
    recentWindow: 20, halfLife: 25 };
}
function savedCfg() { try { return journal.getState(CFG_KEY) || {}; } catch (_) { return {}; } }
function cfg() {
  const c = { ...envDefaults(), ...savedCfg() };
  if (!MODES.includes(c.mode)) c.mode = 'OFF';
  if (!LEARN.includes(c.learnFrom)) c.learnFrom = 'all';
  c.enabled = c.mode !== 'OFF';
  return c;
}
/** Validate a patch ({mode|enabled, minTrades, minRegimeTrades, recentWeight, longTermWeight, bonusOn, bonusStrong, skipMinTrades, learnFrom}); throws a readable Error. */
function validate(p = {}) {
  const out = {}, cur = cfg();
  const int = (k, lo, hi) => { if (p[k] === undefined || p[k] === '') return; const n = Number(p[k]); if (!Number.isInteger(n) || n < lo || n > hi) throw new Error(`${k} must be a whole number from ${lo} to ${hi}`); out[k] = n; };
  const flt = (k, lo, hi) => { if (p[k] === undefined || p[k] === '') return; const n = Number(p[k]); if (!Number.isFinite(n) || n < lo || n > hi) throw new Error(`${k} must be a number from ${lo} to ${hi}`); out[k] = n; };
  if (p.mode !== undefined) { const m = String(p.mode).toUpperCase(); if (!MODES.includes(m)) throw new Error(`mode must be one of ${MODES.join(', ')}`); out.mode = m; if (m !== 'OFF') out.lastOnMode = m; }
  if (p.enabled !== undefined) {
    if (typeof p.enabled !== 'boolean') throw new Error('enabled must be true or false');
    if (p.mode === undefined) { out.mode = p.enabled ? (cur.lastOnMode && cur.lastOnMode !== 'OFF' ? cur.lastOnMode : 'ON') : 'OFF'; if (p.enabled) out.lastOnMode = out.mode; }
  }
  int('minTrades', 5, 500); int('minRegimeTrades', 3, 200); int('skipMinTrades', 20, 1000);
  flt('bonusOn', 0, 20); flt('bonusStrong', 0, 30);
  if (p.recentWeight !== undefined || p.longTermWeight !== undefined) {
    const rw = Number(p.recentWeight !== undefined ? p.recentWeight : cur.recentWeight), lw = Number(p.longTermWeight !== undefined ? p.longTermWeight : cur.longTermWeight);
    if (!Number.isFinite(rw) || !Number.isFinite(lw) || rw < 0 || lw < 0 || rw + lw <= 0) throw new Error('recentWeight and longTermWeight must be numbers >= 0 and not both 0');
    out.recentWeight = rw / (rw + lw); out.longTermWeight = lw / (rw + lw);
  }
  if (p.learnFrom !== undefined) { const l = String(p.learnFrom).toLowerCase(); if (!LEARN.includes(l)) throw new Error(`learnFrom must be one of ${LEARN.join(', ')}`); out.learnFrom = l; }
  const bo = out.bonusOn !== undefined ? out.bonusOn : cur.bonusOn, bs = out.bonusStrong !== undefined ? out.bonusStrong : cur.bonusStrong;
  if (bs < bo) throw new Error('bonusStrong must be at least bonusOn');
  return out;
}
function setCfg(patch) {
  const clean = validate(patch), before = cfg();
  journal.setState(CFG_KEY, { ...savedCfg(), ...clean });
  const after = cfg();
  if (before.mode !== after.mode) addEvent('MODE', `Adaptive engine ${before.mode} → ${after.mode} (set from the dashboard/API)`);
  cache = { at: 0, key: null, rank: null };
  return after;
}

// ── storage (own tables; trade tables are never altered) ─────────────────────────────────────────
let tablesOk = false;
function db() {
  const d = journal.getDb();
  if (!tablesOk) {
    d.exec(`CREATE TABLE IF NOT EXISTS adaptive_decisions (id TEXT PRIMARY KEY, ts INTEGER, run_mode TEXT, trade_id TEXT, symbol TEXT, direction TEXT, strategy_id TEXT,
      strategy_rank INTEGER, win_rate REAL, net_pnl REAL, profit_factor REAL, confidence REAL, regime TEXT, adaptive_mode TEXT, preference_score REAL, base_score REAL, competing TEXT, reason TEXT);
      CREATE TABLE IF NOT EXISTS adaptive_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, type TEXT, detail TEXT);
      CREATE TABLE IF NOT EXISTS adaptive_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, closed_count INTEGER, favourite TEXT, ranking TEXT);`);
    tablesOk = true;
  }
  return d;
}
function addEvent(type, detail) {
  try {
    const d = db(), last = d.prepare('SELECT type, detail FROM adaptive_events ORDER BY id DESC LIMIT 1').get();
    if (last && last.type === type && last.detail === detail) return;
    d.prepare('INSERT INTO adaptive_events (ts, type, detail) VALUES (?,?,?)').run(Date.now(), type, detail);
    try { require('../decisions/log').record({ type: 'SYSTEM', severity: 'INFO', module: 'adaptiveStrategy', reason: detail, key: `adp_${type}_${Date.now()}`, cooldownMs: 0 }); } catch (_) { /* optional */ }
  } catch (_) { /* never throw into trading code */ }
}

// ── history -> statistics ────────────────────────────────────────────────────────────────────────
function normRegime(r) {
  if (r == null || r === '') return null;
  let v = r;
  if (typeof v === 'string') { const t = v.trim(); if (t[0] !== '{') return t.toUpperCase() || null; try { v = JSON.parse(t); } catch (_) { return t.toUpperCase(); } }
  return v && typeof v === 'object' ? (String(v.canonicalRegime || v.regime || '').toUpperCase() || null) : null;
}
/** CLOSED trades only (close_time and outcome set), real recorded pnl, duplicate ids dropped, unknown strategy ignored. */
function loadTrades(learnFrom = 'all') {
  const out = [], seen = new Set(); let ignored = 0;
  const push = (rows, srcMode) => {
    for (const r of rows || []) {
      if (!r || r.close_time == null || r.outcome == null) continue;
      const mode = srcMode === 'paper' && r.mode === 'LAB' ? 'lab' : srcMode;     // tag Paper Lab rows separately
      if (learnFrom !== 'all' && learnFrom !== mode) continue;
      const pnl = Number(r.pnl), key = `${mode}:${r.id}`;
      if (!Number.isFinite(pnl) || !r.strategy_id || seen.has(key)) { if (!seen.has(key)) ignored++; continue; }
      seen.add(key);
      out.push({ key, id: r.id, mode, strategyId: r.strategy_id, strategyName: r.strategy_name || r.strategy_id, symbol: r.symbol, direction: r.direction, pnl, fee: Number(r.fee) || 0,
        regime: normRegime(r.regime), closeTime: Number(r.close_time), openTime: Number(r.open_time) || null });
    }
  };
  try {
    push(journal.getClosedPaperTrades(100000, 'all'), 'paper');
    push(journal.getClosedLiveTrades(100000), 'live');
  } catch (_) { /* DB not ready */ }
  out.sort((a, b) => a.closeTime - b.closeTime);
  out.ignored = ignored;
  return out;
}
function stats(rows) {
  const n = rows.length;
  const z = { n: 0, wins: 0, losses: 0, winRate: null, netPnl: 0, grossWin: 0, grossLoss: 0, profitFactor: null, avgWin: null, avgLoss: null, payoff: null, expectancy: null, maxDrawdown: 0, maxWinStreak: 0, maxLossStreak: 0, consistency: null, sharpe: null };
  if (!n) return z;
  let wins = 0, losses = 0, gw = 0, gl = 0, eq = 0, peak = 0, dd = 0, ws = 0, ls = 0, mws = 0, mls = 0;
  for (const r of rows) {
    const p = r.pnl; eq += p; if (eq > peak) peak = eq; dd = Math.max(dd, peak - eq);
    if (p > 0) { wins++; gw += p; ws++; ls = 0; mws = Math.max(mws, ws); } else if (p < 0) { losses++; gl -= p; ls++; ws = 0; mls = Math.max(mls, ls); } else { ws = 0; ls = 0; }
  }
  const mean = eq / n; let sd = null;
  if (n > 1) sd = Math.sqrt(rows.reduce((s, r) => s + (r.pnl - mean) ** 2, 0) / (n - 1));
  let cons = null;
  if (n >= 20) { const chunks = Math.floor(n / 10); let pos = 0; for (let i = 0; i < chunks; i++) if (rows.slice(i * 10, i * 10 + 10).reduce((s, r) => s + r.pnl, 0) > 0) pos++; cons = pos / chunks; }
  return { n, wins, losses, winRate: wins / n, netPnl: eq, grossWin: gw, grossLoss: gl, profitFactor: gl > 0 ? gw / gl : (gw > 0 ? 99 : null), avgWin: wins ? gw / wins : null, avgLoss: losses ? gl / losses : null,
    payoff: wins && losses ? (gw / wins) / (gl / losses) : null, expectancy: mean, maxDrawdown: dd, maxWinStreak: mws, maxLossStreak: mls, consistency: cons, sharpe: sd ? mean / sd : null };
}
function decayedExp(rows, halfLife) {
  let sw = 0, s = 0; const n = rows.length;
  for (let i = 0; i < n; i++) { const w = Math.pow(0.5, (n - 1 - i) / halfLife); sw += w; s += w * rows[i].pnl; }
  return sw ? s / sw : 0;
}
const unitOf = (rows, s) => s.avgLoss || (rows.length ? rows.reduce((a, r) => a + Math.abs(r.pnl), 0) / rows.length : 0) || 1;
/** 0..100 edge score: decayed recent + long-term expectancy (in "average loss" units), profit factor, drawdown, consistency. Shrunk toward 50 until minTrades is reached. */
function edge(rows, c, unit) {
  const s = stats(rows);
  if (!s.n) return { s, score: 50, shrunk: 50, confidence: 0 };
  const u = unit || unitOf(rows, s), recent = rows.slice(-c.recentWindow);
  const blendR = c.recentWeight * (decayedExp(recent, c.halfLife) / u) + c.longTermWeight * (s.expectancy / u);
  const expC = Math.tanh(blendR / 0.4), pfC = Math.tanh((Math.min(s.profitFactor == null ? 1 : s.profitFactor, 4) - 1) / 1.5);
  const ddPen = s.grossWin > 0 ? Math.min(1, s.maxDrawdown / s.grossWin) : (s.maxDrawdown > 0 ? 1 : 0);
  const raw = 0.45 * (expC + 1) / 2 + 0.25 * (pfC + 1) / 2 + 0.15 * (1 - ddPen) + 0.15 * (s.consistency == null ? 0.5 : s.consistency);
  const confidence = Math.min(1, s.n / c.minTrades), score = 100 * raw;
  return { s, score, shrunk: 50 + (score - 50) * confidence, confidence };
}

// ── ranking ──────────────────────────────────────────────────────────────────────────────────────
let cache = { at: 0, key: null, rank: null }, known = null;
function knownStrategies() {
  if (known) return known;
  try { known = require('../strategy/registry').createDefaultRegistry().getAll().map(s => ({ id: s.id, name: s.name })); } catch (_) { known = []; }
  return known;
}
function subStats(rows, c, unit) { const e = edge(rows, c, unit); return { n: e.s.n, netPnl: r2(e.s.netPnl), winRate: r2(e.s.winRate), profitFactor: r2(e.s.profitFactor), expectancy: r2(e.s.expectancy), score: r2(e.shrunk), evidence: e.s.n >= c.minRegimeTrades }; }

function compute(c = cfg(), opts = {}) {
  const trades = loadTrades(c.learnFrom), by = new Map();
  for (const t of trades) { if (!by.has(t.strategyId)) by.set(t.strategyId, []); by.get(t.strategyId).push(t); }
  const names = new Map(knownStrategies().map(s => [s.id, s.name]));
  for (const id of names.keys()) if (!by.has(id)) by.set(id, []);
  const entries = [];
  for (const [id, rows] of by) {
    const e = edge(rows, c), s = e.s, unit = unitOf(rows, s);
    const recent = stats(rows.slice(-RECENT_N)), prior = stats(rows.slice(-2 * RECENT_N, -RECENT_N));
    const deteriorating = recent.n >= MIN_RECENT && recent.expectancy < 0 && recent.expectancy < s.expectancy && (recent.profitFactor == null ? 0 : recent.profitFactor) < 0.9;
    const recovering = !deteriorating && prior.n >= MIN_RECENT && prior.expectancy < 0 && recent.n >= MIN_RECENT && recent.expectancy > 0;
    const regimes = {}, dirs = {}, syms = {};
    for (const r of rows) { const g = r.regime || 'UNKNOWN'; (regimes[g] = regimes[g] || []).push(r); (syms[r.symbol] = syms[r.symbol] || []).push(r); }
    const byRegime = {}; for (const [g, rs] of Object.entries(regimes)) byRegime[g] = subStats(rs, c, unit);
    for (const d of ['LONG', 'SHORT']) dirs[d] = subStats(rows.filter(r => r.direction === d), c, unit);
    const bySymbol = Object.entries(syms).map(([sym, rs]) => ({ symbol: sym, n: rs.length, netPnl: r2(rs.reduce((a, r) => a + r.pnl, 0)), winRate: r2(rs.filter(r => r.pnl > 0).length / rs.length) })).sort((a, b) => b.n - a.n).slice(0, 8);
    const improvement = recent.n >= MIN_RECENT && s.n >= c.minTrades ? (recent.expectancy - s.expectancy) / unit : null;
    entries.push({ strategyId: id, name: (rows[0] && rows[0].strategyName) || names.get(id) || id, n: s.n, wins: s.wins, losses: s.losses, winRate: r2(s.winRate), netPnl: r2(s.netPnl), profitFactor: r2(s.profitFactor),
      expectancy: r2(s.expectancy), avgWin: r2(s.avgWin), avgLoss: r2(s.avgLoss), payoff: r2(s.payoff), maxDrawdown: r2(s.maxDrawdown), maxWinStreak: s.maxWinStreak, maxLossStreak: s.maxLossStreak,
      consistency: r2(s.consistency), sharpe: r2(s.sharpe), score: r2(e.score), shrunk: r2(e.shrunk), confidence: r2(e.confidence), eligible: s.n >= c.minTrades,
      recent: { n: recent.n, netPnl: r2(recent.netPnl), expectancy: r2(recent.expectancy), profitFactor: r2(recent.profitFactor) }, improvement: r2(improvement),
      trend: deteriorating ? 'DETERIORATING' : recovering ? 'RECOVERING' : 'STEADY', long: dirs.LONG, short: dirs.SHORT, byRegime, bySymbol });
  }
  entries.sort((a, b) => (b.eligible - a.eligible) || (b.shrunk - a.shrunk) || (b.n - a.n));
  entries.forEach((e, i) => { e.rank = i + 1; });
  // recent same-setup losses (repetition guard)
  const rep = {}, since = Date.now() - 24 * 3600 * 1000;
  for (const t of trades) if (t.closeTime >= since) { const k = `${t.symbol}|${t.strategyId}|${t.direction}`; const o = rep[k] = rep[k] || { n: 0, losses: 0, lastTs: 0, lastLoss: false }; o.n++; if (t.pnl < 0) o.losses++; if (t.closeTime >= o.lastTs) { o.lastTs = t.closeTime; o.lastLoss = t.pnl < 0; } }
  const sources = { paper: 0, lab: 0, live: 0 }; for (const t of trades) sources[t.mode] = (sources[t.mode] || 0) + 1;
  return { at: Date.now(), cfg: c, entries, rep, sources, closedCount: trades.length, ignored: trades.ignored || 0, lastClose: trades.length ? trades[trades.length - 1].closeTime : null };
}

/** favourite with hysteresis: a challenger must beat the current favourite by HYST_MARGIN points (0 when the favourite is deteriorating or no longer profitable). */
function decideFavourite(entries, prevId) {
  const good = entries.filter(e => e.eligible && e.netPnl > 0 && e.shrunk >= 55);
  const best = good.slice().sort((a, b) => b.shrunk - a.shrunk)[0] || null, cur = entries.find(e => e.strategyId === prevId) || null;
  if (!best) return { id: null, replaced: !!prevId, why: prevId ? 'no strategy has proven net profit with enough trades' : null };
  if (!cur || !cur.eligible || cur.netPnl <= 0) return { id: best.strategyId, replaced: !!prevId && prevId !== best.strategyId, why: cur ? `${cur.name} is no longer a proven winner` : 'first proven favourite' };
  if (best.strategyId === cur.strategyId) return { id: cur.strategyId, replaced: false };
  const margin = cur.trend === 'DETERIORATING' ? 0 : HYST_MARGIN;
  if (best.shrunk >= cur.shrunk + margin) return { id: best.strategyId, replaced: true, why: `${best.name} (${best.shrunk}) now beats ${cur.name} (${cur.shrunk})${margin ? ` by more than ${margin} points` : ' which is deteriorating'}` };
  return { id: cur.strategyId, replaced: false };
}

function getRanking(opts = {}) {
  const c = opts.cfg || cfg(), key = JSON.stringify([c.learnFrom, c.minTrades, c.minRegimeTrades, c.recentWeight, c.longTermWeight, c.recentWindow, c.halfLife]);
  if (!opts.force && cache.rank && cache.key === key && Date.now() - cache.at < CACHE_MS) return cache.rank;
  const rank = compute(c);
  let st = {}; try { st = journal.getState(STATE_KEY) || {}; } catch (_) { /* none */ }
  const fav = decideFavourite(rank.entries, st.favourite || null);
  rank.favourite = fav.id;
  for (const e of rank.entries) e.status = !e.eligible ? 'LEARNING' : e.strategyId === fav.id ? 'FAVOURITE' : e.trend === 'DETERIORATING' ? 'DETERIORATING' : e.trend === 'RECOVERING' ? 'RECOVERING' : (e.netPnl <= 0 || e.shrunk < 45) ? 'WEAK' : 'ACTIVE';
  if (opts.persist) {
    try {
      const nm = (id) => { const e = rank.entries.find(x => x.strategyId === id); return e ? e.name : id; };
      if (fav.id !== (st.favourite || null)) addEvent('FAVOURITE', fav.id ? (st.favourite ? `Favourite changed: ${nm(st.favourite)} → ${nm(fav.id)}${fav.why ? ' — ' + fav.why : ''}` : `First favourite: ${nm(fav.id)} (${fav.why || 'proven net profit'})`) : `Favourite ${nm(st.favourite)} removed — ${fav.why || 'no proven winner'}`);
      const prev = st.status || {}, next = {};
      for (const e of rank.entries) { next[e.strategyId] = e.status; if (prev[e.strategyId] && prev[e.strategyId] !== e.status && ['DETERIORATING', 'RECOVERING'].includes(e.status)) addEvent(e.status, `${e.name} is now ${e.status} (recent expectancy ${e.recent.expectancy} vs long-term ${e.expectancy})`); }
      if (st.lastCount !== rank.closedCount) {
        const d = db(); d.prepare('INSERT INTO adaptive_snapshots (ts, closed_count, favourite, ranking) VALUES (?,?,?,?)').run(Date.now(), rank.closedCount, fav.id, JSON.stringify(rank.entries.map(e => ({ id: e.strategyId, rank: e.rank, n: e.n, netPnl: e.netPnl, score: e.shrunk, status: e.status }))));
        d.prepare('DELETE FROM adaptive_snapshots WHERE id NOT IN (SELECT id FROM adaptive_snapshots ORDER BY id DESC LIMIT 200)').run();
      }
      journal.setState(STATE_KEY, { favourite: fav.id, since: fav.id === st.favourite ? (st.since || Date.now()) : Date.now(), status: next, lastCount: rank.closedCount });
    } catch (_) { /* best effort */ }
  }
  cache = { at: Date.now(), key, rank };
  return rank;
}

// ── preference for one signal ────────────────────────────────────────────────────────────────────
function modalRegime(signals) {
  const n = {}; for (const s of signals || []) { const g = normRegime(s && s.regime); if (g) n[g] = (n[g] || 0) + 1; }
  return Object.entries(n).sort((a, b) => b[1] - a[1]).map(x => x[0])[0] || null;
}
function prefFor(sig, rank, c, eff) {
  const e = rank.entries.find(x => x.strategyId === sig.strategyId), regime = normRegime(sig.regime);
  const none = (why) => ({ bonus: 0, rank: e ? e.rank : null, e, regime, regimeUsed: false, why });
  if (!e) return none('strategy not in history yet');
  if (!e.eligible) return none(`balanced: only ${e.n}/${c.minTrades} completed trades`);
  let fs = e.shrunk, regimeUsed = false, dirUsed = false;
  const rg = regime && e.byRegime[regime];
  const gates = adiGates();   // v7.1: ADI strategy switches map onto this engine
  if (gates.regime && rg && rg.evidence) { fs = 0.4 * e.shrunk + 0.6 * rg.score; regimeUsed = true; }
  const dr = sig.direction && (sig.direction === 'LONG' ? e.long : e.short);
  if (gates.direction && dr && dr.evidence) { fs = 0.85 * fs + 0.15 * dr.score; dirUsed = true; }
  const maxB = eff === 'STRONG' ? c.bonusStrong : c.bonusOn;
  let b = maxB * clamp((fs - 50) / 40, -1, 1);
  if (e.trend === 'DETERIORATING' && b > 0) b *= 0.25;
  if (e.strategyId === rank.favourite && b > 0 && eff === 'STRONG') b = Math.min(maxB * 1.25, b * 1.25);
  return { bonus: b, rank: e.rank, e, regime, regimeUsed, dirUsed, fs, rg, why: null };
}
function explain(sig, p, eff) {
  const e = p.e, nm = String(sig.strategyName || (e && e.name) || sig.strategyId || '?').toUpperCase();
  if (!e || p.why) return `${nm} NEUTRAL — ${p.why || 'no history'}`;
  const bits = [];
  if (e.netPnl > 0) bits.push(`profitable history (net ${e.netPnl}, PF ${e.profitFactor}, ${e.n} trades)`); else bits.push(`losing history (net ${e.netPnl}, PF ${e.profitFactor})`);
  if (e.recent.expectancy != null) bits.push(e.recent.expectancy > 0 ? 'positive recent expectancy' : 'negative recent expectancy');
  if (p.regimeUsed) bits.push(p.rg.netPnl > 0 ? `strong results in the current ${p.regime} regime` : `weak results in the current ${p.regime} regime`);
  if (e.trend === 'DETERIORATING') bits.push('deteriorating — preference cut');
  if (e.trend === 'RECOVERING') bits.push('recovering');
  return `${nm} ${p.bonus > 0.05 ? 'FAVOURED' : p.bonus < -0.05 ? 'DEMOTED' : 'NEUTRAL'} (${eff}) — ${bits.join(', ')}.`;
}

/**
 * Order the qualified (then fill) setups. Returns { queue, skipped, mode }. OFF returns the original order untouched.
 * Never mutates sig.score; never adds a signal; STRONG may skip proven losers (>= skipMinTrades, negative expectancy, PF < 1).
 */
function adiGates() { try { return require('./adi').strategyGates(); } catch (_) { return { ordering: true, direction: true, regime: true }; } }
function order(qualified, fills = [], ctx = {}) {
  const c0 = cfg(), c = adiGates().ordering ? c0 : { ...c0, mode: 'OFF' }, plain = [...qualified, ...fills];
  if (!plain.length) return { queue: plain, skipped: [], mode: c.mode };
  const shadow = c.mode === 'OFF', eff = shadow ? 'ON' : c.mode;
  const rank = getRanking({ cfg: c }), regime = modalRegime(ctx.signals || plain);
  const skipped = [];
  const annotate = (group) => group.filter((sig) => {
    const p = prefFor(sig, rank, c, eff), e = p.e;
    const rep = rank.rep[`${sig.symbol}|${sig.strategyId}|${sig.direction}`];
    let pen = 0; if (rep) { if (rep.losses >= 2) pen = 5; else if (rep.lastLoss && Date.now() - rep.lastTs < 2 * 3600 * 1000) pen = 2; }
    sig._adaptive = { mode: c.mode, effective: eff, bonus: r2(p.bonus), repetitionPenalty: pen, base: sig.score || 0, rank: p.rank, regime: p.regime, regimeUsed: p.regimeUsed, strategyScore: e ? e.shrunk : null, confidence: e ? e.confidence : 0,
      winRate: e ? e.winRate : null, netPnl: e ? e.netPnl : null, profitFactor: e ? e.profitFactor : null, reason: explain(sig, p, eff), adjusted: (sig.score || 0) + p.bonus - pen, shadow };
    if (c.mode === 'STRONG' && e) {
      const rg = p.regime && e.byRegime[p.regime], useReg = rg && rg.n >= c.skipMinTrades, n = useReg ? rg.n : e.n, ex = useReg ? rg.expectancy : e.expectancy, pf = useReg ? rg.profitFactor : e.profitFactor;
      if (n >= c.skipMinTrades && ex < 0 && (pf == null || pf < 1)) { sig._adaptive.skip = `${String(e.name).toUpperCase()} SKIPPED (STRONG) — proven losing ${useReg ? 'in the ' + p.regime + ' regime' : 'overall'}: ${n} trades, expectancy ${ex}, PF ${pf}.`; skipped.push(sig); return false; }
    }
    return true;
  });
  const arrange = (group) => {
    const rest = annotate(group).map((s, i) => ({ s, i })), picked = [], cnt = {};
    while (rest.length) {
      let bi = 0, bv = -Infinity;
      for (let k = 0; k < rest.length; k++) { const s = rest[k].s, v = s._adaptive.adjusted - Math.min(CONC_CAP, CONC_PEN * (cnt[s.strategyId] || 0)); if (v > bv + 1e-9 || (Math.abs(v - bv) <= 1e-9 && (rest[k].s.score || 0) > (rest[bi].s.score || 0))) { bv = v; bi = k; } }
      const [x] = rest.splice(bi, 1); cnt[x.s.strategyId] = (cnt[x.s.strategyId] || 0) + 1; x.s._adaptive.finalValue = r2(bv); picked.push(x.s);
    }
    return picked;
  };
  const arranged = [...arrange(qualified), ...arrange(fills)];
  const label = (s) => ({ symbol: s.symbol, strategy: s.strategyName || s.strategyId, direction: s.direction, score: s.score, adjusted: s._adaptive ? r2(s._adaptive.adjusted) : null });
  arranged.forEach((s, i) => { s._adaptive.competing = arranged.filter(o => o !== s).slice(0, 4).map(label); });
  if (shadow) {
    if (ctx.persist && arranged[0] && plain[0] && arranged[0] !== plain[0]) {
      try { const l = journal.getState(SHADOW_KEY) || []; l.unshift({ ts: Date.now(), original: label(plain[0]), wouldPick: label(arranged[0]), reason: arranged[0]._adaptive.reason }); journal.setState(SHADOW_KEY, l.slice(0, 20)); } catch (_) { /* optional */ }
    }
    return { queue: plain, skipped: [], mode: 'OFF', regime };
  }
  return { queue: arranged, skipped, mode: c.mode, regime, favourite: rank.favourite };
}

/** Called by the robot each scan: refresh ranking (persists favourite/snapshots/events) and tell the dashboard what mode the robot is applying. */
function refresh(ctx = {}) {
  const c = cfg(), rank = getRanking({ cfg: c, persist: true, force: true });
  heartbeat({ regime: modalRegime(ctx.signals), scanCount: ctx.scanCount || null });
  return rank;
}
function heartbeat(extra = {}) {
  try { const c = cfg(), prev = journal.getState(APPLIED_KEY) || {}; journal.setState(APPLIED_KEY, { ...prev, ...extra, mode: c.mode, ts: Date.now(), pid: process.pid }); } catch (_) { /* optional */ }
}

// ── journal of adaptive decisions ────────────────────────────────────────────────────────────────
function noteSelected(sig, { tradeId = null, runMode = 'paper' } = {}) {
  try {
    const a = sig && sig._adaptive; if (!a) return false;
    const d = db(), ts = Date.now(), id = `${runMode}|${sig.symbol}|${sig.strategyId}|${sig.direction}|${Math.floor(ts / 60000)}`;
    if (tradeId && d.prepare('SELECT 1 FROM adaptive_decisions WHERE trade_id=?').get(String(tradeId))) return false;
    const r = d.prepare('INSERT OR IGNORE INTO adaptive_decisions (id, ts, run_mode, trade_id, symbol, direction, strategy_id, strategy_rank, win_rate, net_pnl, profit_factor, confidence, regime, adaptive_mode, preference_score, base_score, competing, reason) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(id, ts, runMode, tradeId ? String(tradeId) : null, sig.symbol, sig.direction, sig.strategyId, a.rank, a.winRate, a.netPnl, a.profitFactor, a.confidence, a.regime, a.mode, a.bonus, a.base, JSON.stringify(a.competing || []), a.reason);
    return r.changes > 0;
  } catch (_) { return false; }
}
function recentDecisions(limit = 25) {
  try {
    const d = db(), rows = d.prepare('SELECT * FROM adaptive_decisions ORDER BY ts DESC LIMIT ?').all(limit);
    return rows.map((r) => {
      let t = null;
      try {
        if (r.trade_id) t = d.prepare('SELECT pnl, outcome FROM paper_trades WHERE id=? AND close_time IS NOT NULL').get(r.trade_id) || d.prepare('SELECT pnl, outcome FROM live_trades WHERE id=? AND close_time IS NOT NULL').get(r.trade_id);
        if (!t) { const tb = r.run_mode === 'live' ? 'live_trades' : 'paper_trades'; t = d.prepare(`SELECT pnl, outcome FROM ${tb} WHERE symbol=? AND strategy_id=? AND direction=? AND open_time>=? AND close_time IS NOT NULL ORDER BY open_time ASC LIMIT 1`).get(r.symbol, r.strategy_id, r.direction, r.ts - 120000); }
      } catch (_) { /* outcome pending */ }
      let comp = []; try { comp = JSON.parse(r.competing || '[]'); } catch (_) { /* ignore */ }
      return { ...r, competing: comp, finalPnl: t ? t.pnl : null, finalOutcome: t ? t.outcome : 'OPEN' };
    });
  } catch (_) { return []; }
}
function recentEvents(limit = 30) { try { return db().prepare('SELECT ts, type, detail FROM adaptive_events ORDER BY id DESC LIMIT ?').all(limit); } catch (_) { return []; } }
function snapshotCount() { try { return db().prepare('SELECT COUNT(*) n FROM adaptive_snapshots').get().n; } catch (_) { return 0; } }

/** Everything the dashboard shows, straight from the backend state. */
function status() {
  const c = cfg(), rank = getRanking({ cfg: c }), ap = (() => { try { return journal.getState(APPLIED_KEY) || null; } catch (_) { return null; } })();
  const st = (() => { try { return journal.getState(STATE_KEY) || {}; } catch (_) { return {}; } })();
  const regime = (ap && ap.regime) || null, el = rank.entries.filter(e => e.eligible);
  const fav = rank.entries.find(e => e.strategyId === (st.favourite || rank.favourite)) || null;
  const regRank = regime ? el.filter(e => e.byRegime[regime] && e.byRegime[regime].evidence).sort((a, b) => (0.4 * b.shrunk + 0.6 * b.byRegime[regime].score) - (0.4 * a.shrunk + 0.6 * a.byRegime[regime].score)) : [];
  const improved = el.filter(e => e.improvement != null && e.improvement > 0).sort((a, b) => b.improvement - a.improvement)[0] || null;
  const worse = rank.entries.filter(e => e.status === 'DETERIORATING').sort((a, b) => a.recent.expectancy - b.recent.expectancy)[0] || null;
  const pick = (e) => (e ? { strategyId: e.strategyId, name: e.name, score: e.shrunk } : null);
  const preferred = regRank[0] || fav;
  const why = preferred ? `${preferred.name}: net ${preferred.netPnl}, PF ${preferred.profitFactor}, expectancy ${preferred.expectancy} over ${preferred.n} trades${regRank[0] ? `, best evidence in the current ${regime} regime` : ''}${preferred.trend === 'DETERIORATING' ? ' (but deteriorating)' : ''}.` : (el.length ? 'No strategy has proven net profit yet — selection stays balanced.' : `Learning: no strategy has ${c.minTrades} completed trades yet — selection stays balanced.`);
  const fresh = ap && Date.now() - ap.ts < 20000;
  return { ok: true, cfg: c, enabled: c.mode !== 'OFF', applied: { mode: ap ? ap.mode : null, ts: ap ? ap.ts : null, confirmed: !!(fresh && ap.mode === c.mode), robotSeen: !!fresh },
    intel: { overall: pick(el.filter(e => e.netPnl > 0)[0] || null), regimeBest: pick(regRank[0] || null), second: pick(el[1] || null), third: pick(el[2] || null), mostImproved: pick(improved), deteriorating: pick(worse), totalEvaluated: rank.entries.length,
      regime, preferred: pick(preferred), favourite: pick(fav), favouriteSince: st.since || null, why },
    ranking: rank.entries, sources: rank.sources, closedTrades: rank.closedCount, ignoredRows: rank.ignored, lastRankingUpdate: rank.at, snapshots: snapshotCount(), events: recentEvents(30), decisions: recentDecisions(25),
    shadow: (() => { try { return journal.getState(SHADOW_KEY) || []; } catch (_) { return []; } })(),
    note: 'Learns from CLOSED trades only (paper + live/testnet journals). It re-orders qualified setups; the risk engine keeps final authority. History is not a promise of future profit.' };
}
function _reset() { cache = { at: 0, key: null, rank: null }; tablesOk = false; known = null; }

module.exports = { cfg, setCfg, validate, envDefaults, loadTrades, stats, edge, compute, getRanking, decideFavourite, prefFor, order, refresh, heartbeat, noteSelected, recentDecisions, recentEvents, status, modalRegime, normRegime, _reset, MODES };
