'use strict';
/**
 * v7.0 PAPER LAB (LIVE mode). Every qualified scanner setup also runs on a SEPARATE paper account (rows tagged mode='LAB' in paper_trades,
 * own balance, own risk engine, no exchange access) so you can see which coins/strategies perform and whether today is a good day to trade.
 * It reads/writes nothing that live trading uses. Results are information only - they never change a live decision.
 */
const config = require('../config');
const journal = require('../journal/store');
const KEY = 'paper_lab_cfg';
const r2 = (v) => (v == null || !Number.isFinite(v) ? null : Number(v.toFixed(2)));

function enabled() { try { const c = journal.getState(KEY); if (c && typeof c.enabled === 'boolean') return c.enabled; } catch (_) { /* default */ } return !!config.paperLabEnabled; }
function setEnabled(b) { if (typeof b !== 'boolean') throw new Error('enabled must be true or false'); journal.setState(KEY, { enabled: b }); return b; }
/** remember that this lab trade was opened while the LIVE position limit would already have been full */
function markOpened(trade, { openBefore = 0, liveCap = 0 } = {}) {
  try { require('../journal/extras').merge(trade.id, { lab: true, overLiveCap: liveCap > 0 && openBefore >= liveCap, liveCap, openBefore }); } catch (_) { /* best effort */ }
}
function loadClosed() {
  try { return journal.getDb().prepare("SELECT * FROM paper_trades WHERE mode='LAB' AND close_time IS NOT NULL AND outcome IS NOT NULL AND pnl IS NOT NULL ORDER BY close_time ASC").all(); } catch (_) { return []; }
}
function agg(rows) {
  const n = rows.length; if (!n) return { n: 0, wins: 0, losses: 0, winRate: null, net: 0, pf: null, avg: null, best: null, worst: null };
  let w = 0, gw = 0, gl = 0, net = 0, best = -Infinity, worst = Infinity;
  for (const r of rows) { const p = Number(r.pnl) || 0; net += p; if (p > 0) { w++; gw += p; } else if (p < 0) gl -= p; best = Math.max(best, p); worst = Math.min(worst, p); }
  return { n, wins: w, losses: rows.filter(r => r.pnl < 0).length, winRate: r2(w / n), net: r2(net), pf: gl > 0 ? r2(gw / gl) : (gw > 0 ? 99 : null), avg: r2(net / n), best: r2(best), worst: r2(worst) };
}
/** start of the viewer's local day as epoch ms. tzOffsetMin = new Date().getTimezoneOffset() from the browser (minutes WEST of UTC). */
function dayStart(now, tzOffsetMin = 0) { const local = now - tzOffsetMin * 60000; return Math.floor(local / 86400000) * 86400000 + tzOffsetMin * 60000; }
const MIN_DAY_TRADES = 5;
function verdict(today, week) {
  if (!today || today.n < MIN_DAY_TRADES) return { level: 'WAIT', text: `Not enough closed paper trades today yet (${today ? today.n : 0}/${MIN_DAY_TRADES}).` };
  const bits = `${today.n} closed, win rate ${Math.round((today.winRate || 0) * 100)}%, net ${today.net}${today.pf != null ? `, PF ${today.pf}` : ''}`;
  const base = week && week.n >= 15 ? ` Last 7 days: win rate ${Math.round((week.winRate || 0) * 100)}%, net ${week.net}.` : '';
  if (today.net > 0 && today.winRate >= 0.5 && (today.pf == null || today.pf >= 1.2)) return { level: 'GOOD', text: `Good day so far for the scanned setups — ${bits}.${base}` };
  if (today.net < 0 && (today.winRate < 0.4 || (today.pf != null && today.pf < 0.8))) return { level: 'POOR', text: `Poor day so far for the scanned setups — ${bits}.${base}` };
  return { level: 'NEUTRAL', text: `Mixed day — ${bits}.${base}` };
}
function group(rows, keyFn) {
  const m = new Map(); for (const r of rows) { const k = keyFn(r); if (!m.has(k)) m.set(k, []); m.get(k).push(r); }
  return [...m.entries()].map(([k, rs]) => ({ key: k, ...agg(rs) })).sort((a, b) => (b.net - a.net) || (b.n - a.n));
}
function summarize(rows, now = Date.now(), tzOffsetMin = 0) {
  const ds = dayStart(now, tzOffsetMin), td = rows.filter(r => r.close_time >= ds), wk = rows.filter(r => r.close_time >= now - 7 * 86400000);
  const today = agg(td), week = agg(wk), byCoin = group(rows, r => r.symbol), byCoinToday = group(td, r => r.symbol);
  const ranked = byCoin.filter(c => c.n >= 3);
  return { totals: agg(rows), today, week, verdict: verdict(today, week), byCoin, byCoinToday, byStrategy: group(rows, r => r.strategy_name || r.strategy_id),
    bestCoins: ranked.slice(0, 3), worstCoins: ranked.slice(-3).reverse().filter(c => c.net < 0), dayStart: ds };
}
function status({ tzOffsetMin = 0 } = {}) {
  const rows = loadClosed(), s = summarize(rows, Date.now(), tzOffsetMin);
  let open = []; try { open = (journal.getState('protection_view_paper') || []); } catch (_) { /* none */ }
  const ex = require('../journal/extras'); let flagged = 0;
  open = open.map(o => { const e = ex.get(o.id) || {}; if (e.overLiveCap) flagged++; return { id: o.id, symbol: o.symbol, side: o.side, entry: o.entry, mark: o.mark, stop: o.stop, tp: o.tp, upnl: o.upnl, progress: o.progress, hoursOpen: o.hoursOpen, overLiveCap: !!e.overLiveCap, liveCap: e.liveCap || null }; });
  const unreal = open.reduce((a, o) => a + (Number(o.upnl) || 0), 0), start = config.accountBalance;
  const overRows = rows.filter(r => { try { return (ex.get(r.id) || {}).overLiveCap; } catch (_) { return false; } });
  return { ok: true, live: !!config.isLive, enabled: enabled(), startBalance: start, balance: r2(start + s.totals.net + unreal), realized: s.totals.net, unrealized: r2(unreal), ...s,
    open: open.sort((a, b) => (b.upnl || 0) - (a.upnl || 0)), openOverCap: flagged, closedOverCap: agg(overRows), liveCap: config.maxOpenPositionsLive,
    recent: rows.slice(-40).reverse().map(r => ({ symbol: r.symbol, side: r.direction, strategy: r.strategy_name || r.strategy_id, pnl: r2(r.pnl), outcome: r.outcome, exit: r.exit_reason, closed: r.close_time, overLiveCap: !!(ex.get(r.id) || {}).overLiveCap })),
    note: 'Separate paper account. Nothing here is sent to the exchange or counted in your live limits, balance or journal.' };
}
module.exports = { enabled, setEnabled, markOpened, loadClosed, agg, summarize, verdict, dayStart, status, MIN_DAY_TRADES };
