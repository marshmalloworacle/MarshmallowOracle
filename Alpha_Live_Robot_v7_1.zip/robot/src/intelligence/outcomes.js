'use strict';
/**
 * Trade outcomes -> module performance tracker + what-if analysis (v6.0).
 * At entry the robot notes which modules were ON and what the market looked like (measured values). At close the realised PnL is
 * attached. Nothing is credited to a module unless the sample is large enough, and every simulated figure is labelled SIMULATED.
 */
const journal = require('../journal/store');
const flags = require('../features/flags');
const dl = require('../decisions/log');
const OPEN = 'outcome_open', DONE = 'outcome_done', MAXN = 500, MIN_SAMPLE = 30;

const get = (k, d) => { try { return journal.getState(k) || d; } catch (_) { return d; } };

function noteOpen({ symbol, direction, mode, measured = {}, regime = null, aggRiskPct = null }) {
  try { const o = get(OPEN, {}); o[`${mode}:${symbol}`] = { symbol, direction, mode, at: Date.now(), modules: flags.all(), measured, regime, aggRiskPct }; journal.setState(OPEN, o); } catch (_) { /* best effort */ }
}
function noteClose({ symbol, mode, pnl }) {
  try {
    if (!Number.isFinite(pnl)) return;
    const o = get(OPEN, {}); const k = `${mode}:${symbol}`, snap = o[k]; if (snap) { delete o[k]; journal.setState(OPEN, o); }
    const d = get(DONE, []); d.unshift({ symbol, mode, pnl, closedAt: Date.now(), openedAt: snap ? snap.at : null, modules: snap ? snap.modules : null, measured: snap ? snap.measured : null, regime: snap ? snap.regime : null, aggRiskPct: snap ? snap.aggRiskPct : null });
    journal.setState(DONE, d.slice(0, MAXN));
  } catch (_) { /* best effort */ }
}

const conf = (n) => (n >= 100 ? 'reasonable' : n >= MIN_SAMPLE ? 'low' : 'not enough data');
function agg(rows) { const n = rows.length, w = rows.filter(r => r.pnl > 0).length, pnl = rows.reduce((s, r) => s + r.pnl, 0); return { trades: n, wins: w, winRate: n ? w / n : null, netPnl: Number(pnl.toFixed(4)) }; }

function performance() {
  const done = get(DONE, []).filter(r => r.modules), ev = dl.list({ limit: 300 });
  const keys = Object.keys(flags.all());
  const rows = keys.map(k => {
    const on = done.filter(r => r.modules[k]), off = done.filter(r => !r.modules[k]);
    const blocks = ev.filter(e => e.module === k && /BLOCKED|REJECTED/.test(e.type)).reduce((s, e) => s + (e.count || 1), 0);
    return { key: k, label: (flags.describe().find(d => d.key === k) || {}).label || k, whenOn: agg(on), whenOff: agg(off), blocks, confidence: conf(Math.min(on.length || 0, off.length || 0)),
      note: Math.min(on.length, off.length) < MIN_SAMPLE ? `Not enough trades with the module both ON and OFF (need ${MIN_SAMPLE}+ each) - no conclusion should be drawn.` : 'Associations only: other things changed at the same time.' };
  });
  return { ok: true, totalClosed: done.length, rows, note: 'Counts "blocks" are events the robot blocked while the module was ON. False-rejection estimates need replay data and are not shown.' };
}

const RULES = {
  spreadFilter: (r, c) => r.measured && r.measured.spreadBps != null ? r.measured.spreadBps > c.spreadMaxBps : null,
  volumeConfirm: (r, c) => r.measured && r.measured.volRatio != null ? r.measured.volRatio < c.volumeMinRatio : null,
  htfTrend: (r) => r.measured && r.measured.htfTrend ? ((r.measured.htfTrend === 'DOWN' && r.dir === 'LONG') || (r.measured.htfTrend === 'UP' && r.dir === 'SHORT')) : null,
  volatilityFilter: (r, c) => r.measured && r.measured.atrRatio != null ? r.measured.atrRatio > c.volatilityMaxRatio : null,
  regimeFilter: (r) => r.regime ? (r.regime === 'MARKET_SHOCK' || r.regime === 'HIGH_VOLATILITY') : null,
  riskTaper: (r, c) => r.aggRiskPct != null ? r.aggRiskPct > c.aggRiskPct : null,
  correlationBlock: (r, c) => r.aggRiskPct != null ? r.aggRiskPct > c.aggRiskPct : null,
};
function whatIf(module) {
  const rule = RULES[module]; const caps = require('../protection/config').get();
  if (!rule) return { ok: false, error: `No what-if rule for "${module}"` };
  const done = get(DONE, []);
  const ev = done.map(r => ({ ...r, hit: rule(r, caps) })).filter(r => r.hit !== null);
  const hit = ev.filter(r => r.hit), kept = ev.filter(r => !r.hit);
  const a = agg(hit), k = agg(kept);
  return { ok: true, simulated: true, module, evaluable: ev.length, ofClosed: done.length, wouldHaveBlocked: hit.length, blockedTradesPnl: a.netPnl, blockedWinRate: a.winRate, keptTradesPnl: k.netPnl, keptWinRate: k.winRate,
    verdict: ev.length < MIN_SAMPLE ? 'NOT ENOUGH DATA' : (a.netPnl < 0 ? 'Would likely have helped (blocked trades lost money)' : 'Would likely have hurt (blocked trades made money)'), confidence: conf(ev.length),
    note: 'SIMULATED from your own recorded trades and the market values saved at entry. It ignores that other trades could have taken the blocked slots. Trades recorded before v6.0 carry no measurements.' };
}
module.exports = { noteOpen, noteClose, performance, whatIf, RULES };
