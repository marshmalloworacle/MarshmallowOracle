'use strict';
/**
 * ADAPTIVE DIRECTIONAL INTELLIGENCE engine (v7.1) - extends, never duplicates, the existing pieces:
 *   - trade history + statistics come from the Adaptive Winning Strategy Engine (adaptive.loadTrades / adaptive.stats)
 *   - the direction decision is applied through the existing direction control (control/direction.js: AUTO mode)
 *   - Manual Take keeps overriding the direction MODE (with a confirmation); ALLOW_LONG/SHORT stay hard permissions
 *
 * What it does: scores LONG vs SHORT from CLOSED trades (paper / Paper Lab / live, weighted and normalised), produces a
 * recommendation { BOTH | LONG_ONLY | SHORT_ONLY, confidence, reasons } and a small ordering bias. It NEVER:
 *   - closes, reverses, cancels or edits an open position (direction changes govern NEW entries only)
 *   - changes score, size, leverage, margin, stop-loss or any risk limit
 *   - restricts a direction without evidence (insufficient data = BOTH) or, in LIVE, without your approval
 */
const journal = require('../journal/store');
const adiCfg = require('../control/adiConfig');

const REC_KEY = 'adi_recommendation', HIST_KEY = 'adi_history', APPROVAL_KEY = 'adi_approval';
const APPROVAL_TTL_MS = 24 * 3600 * 1000, MAX_BIAS = 6, HIST_MAX = 200;
const HALF_LIFE = { LOW: 60, MEDIUM: 30, HIGH: 15 };
const r2 = (v) => (v == null || !Number.isFinite(v) ? null : Number(v.toFixed(2)));
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const adaptive = () => require('./adaptive');

// ── scoring ──────────────────────────────────────────────────────────────────────────────────────
/** rows: chronological {pnl}. Returns { n, expectancy, score(0-100), winRate, profitFactor, netPnl } for the (decay-weighted) rows. */
function scoreRows(rows, c) {
  const n = rows.length;
  if (!n) return { n: 0, score: null, expectancy: null, winRate: null, profitFactor: null, netPnl: 0 };
  const hl = HALF_LIFE[c.ADI_PERFORMANCE_DECAY_SENSITIVITY] || 30;
  let sw = 0, sp = 0, lossW = 0, lossN = 0, gw = 0, gl = 0, wins = 0, eq = 0, peak = 0, dd = 0, abs = 0, net = 0;
  rows.forEach((r, i) => {
    const w = c.ADI_PERFORMANCE_DECAY_ENABLED ? Math.pow(0.5, (n - 1 - i) / hl) : 1;
    sw += w; sp += w * r.pnl;
    if (r.pnl < 0) { lossW += w * -r.pnl; lossN += w; gl += -r.pnl; } else if (r.pnl > 0) { gw += r.pnl; wins++; }
    eq += r.pnl; net += r.pnl; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); abs += Math.abs(r.pnl);
  });
  const expectancy = sp / sw;
  const unit = lossN > 0 ? lossW / lossN : (abs / n) || 1;                 // average (weighted) loss, fallback average |pnl|
  let ratio = expectancy / (unit || 1);
  if (c.ADI_RISK_ADJUSTED_SCORING) ratio *= clamp(1 - dd / (abs || 1), 0.5, 1);   // drawdown penalty, at most halves a positive edge
  const score = 50 + 50 * Math.tanh(1.5 * ratio);
  return { n, score, expectancy, winRate: wins / n, profitFactor: gl > 0 ? gw / gl : (gw > 0 ? null : 0), netPnl: net };
}
function windowScore(rows, c) {
  const rec = scoreRows(rows.slice(-c.ADI_RECENT_WINDOW_TRADES), c), lng = scoreRows(rows.slice(-c.ADI_LONG_TERM_WINDOW_TRADES), c);
  const m = c.ADI_PERFORMANCE_WINDOW_MODE;
  if (m === 'RECENT') return { ...rec, recent: rec, longTerm: lng };
  if (m === 'LONG_TERM') return { ...lng, recent: rec, longTerm: lng };
  if (rec.score == null || lng.score == null) return { ...(lng.score != null ? lng : rec), recent: rec, longTerm: lng };
  return { n: lng.n, score: 0.6 * rec.score + 0.4 * lng.score, expectancy: 0.6 * rec.expectancy + 0.4 * lng.expectancy, winRate: lng.winRate, profitFactor: lng.profitFactor, netPnl: lng.netPnl, recent: rec, longTerm: lng };
}

/** One direction: combine paper and live fairly. Paper can never hide poor live results. */
function directionScore(trades, dir, c) {
  const mine = trades.filter(t => t.direction === dir);
  const live = mine.filter(t => t.mode === 'live'), paper = mine.filter(t => t.mode !== 'live');
  const L = windowScore(live, c), P = windowScore(paper, c), min = c.ADI_MIN_COMPLETED_TRADES;
  const lOk = L.n >= min && L.score != null, pOk = P.n >= min && P.score != null;
  let score = null, basis = 'insufficient', wl = 0, wp = 0, note = null, guarded = false, expectancy = null;
  if (lOk && pOk) {
    const tot = c.ADI_LIVE_WEIGHT + c.ADI_PAPER_WEIGHT || 1; wl = c.ADI_LIVE_WEIGHT / tot; wp = c.ADI_PAPER_WEIGHT / tot;
    score = wl * L.score + wp * P.score; expectancy = wl * L.expectancy + wp * P.expectancy; basis = 'live+paper';
    if (L.score < 45 && score > L.score + 10) { score = L.score + 10; guarded = true; note = 'poor live results are not hidden by paper results'; }
  } else if (lOk) { score = L.score; expectancy = L.expectancy; wl = 1; basis = 'live only'; }
  else if (pOk) { score = P.score; expectancy = P.expectancy; wp = 1; basis = 'paper only'; }
  const nEff = (lOk ? L.n : 0) + (pOk ? P.n : 0);
  return { direction: dir, score: r2(score), expectancy: r2(expectancy), basis, weights: { live: r2(wl), paper: r2(wp) }, guarded, note,
    trades: { live: L.n, paper: P.n, effective: nEff, needed: min }, live: { n: L.n, score: r2(L.score), expectancy: r2(L.expectancy), winRate: r2(L.winRate), netPnl: r2(L.netPnl) },
    paper: { n: P.n, score: r2(P.score), expectancy: r2(P.expectancy), winRate: r2(P.winRate), netPnl: r2(P.netPnl) }, credibility: clamp(nEff / (min * 3), 0, 1) };
}

/** Closed trades usable for ADI, honouring the learning switches and the fee setting. */
function usableTrades(c) {
  const all = adaptive().loadTrades('all'), out = [];
  for (const t of all) {
    const isLive = t.mode === 'live';
    if (isLive && !c.ADI_LIVE_LEARNING) continue;
    if (!isLive && !c.ADI_PAPER_LEARNING) continue;
    out.push({ ...t, pnl: c.ADI_INCLUDE_FEES ? t.pnl : t.pnl + (t.fee || 0) });     // recorded pnl is net of fees; OFF = add them back
  }
  return out;
}

function analyse(now = Date.now()) {
  const c = adiCfg.cfg(), trades = usableTrades(c);
  const L = directionScore(trades, 'LONG', c), S = directionScore(trades, 'SHORT', c);
  const reasons = [];
  let direction = 'BOTH', confidence = 0, bias = { LONG: 0, SHORT: 0 };
  if (L.score == null || S.score == null) {
    reasons.push(`Not enough evidence: need ${c.ADI_MIN_COMPLETED_TRADES}+ completed trades for BOTH directions (LONG ${L.trades.effective}, SHORT ${S.trades.effective}). Staying on BOTH.`);
  } else {
    const diff = L.score - S.score, strong = diff >= 0 ? L : S, weak = diff >= 0 ? S : L;
    confidence = Math.round(clamp(Math.abs(diff) * 2, 0, 100) * Math.min(L.credibility, S.credibility));
    bias[strong.direction] = r2(clamp(Math.abs(diff) / 50 * MAX_BIAS, 0, MAX_BIAS) * Math.min(L.credibility, S.credibility));
    bias[weak.direction] = -bias[strong.direction];
    reasons.push(`${strong.direction} scores ${strong.score} vs ${weak.direction} ${weak.score} (${strong.basis}; expectancy ${strong.expectancy} vs ${weak.expectancy}).`);
    if (confidence >= c.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD && weak.expectancy != null && weak.expectancy <= 0) {
      direction = `${strong.direction}_ONLY`; reasons.push(`${weak.direction} loses money on average and confidence ${confidence} >= ${c.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD}: recommend ${direction.replace('_', ' ')}.`);
    } else if (confidence >= c.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD) reasons.push(`${weak.direction} is weaker but still profitable, so both directions stay open (ordering favours ${strong.direction}).`);
    else reasons.push(`Confidence ${confidence} is below the ${c.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD} needed to restrict a direction.`);
  }
  for (const d of [L, S]) if (d.guarded) reasons.push(`${d.direction}: ${d.note}.`);
  if (c.ADI_INCLUDE_FUNDING) reasons.push('Funding is not recorded per trade yet, so results are not funding-adjusted.');
  return { ts: now, direction, confidence, bias, reasons, long: L, short: S, settings: { window: c.ADI_PERFORMANCE_WINDOW_MODE, threshold: c.ADI_ADAPTIVE_CONFIDENCE_THRESHOLD, minTrades: c.ADI_MIN_COMPLETED_TRADES },
    sources: { paper: trades.filter(t => t.mode !== 'live').length, live: trades.filter(t => t.mode === 'live').length } };
}

// ── recommendation lifecycle ─────────────────────────────────────────────────────────────────────
function _get(k, d) { try { const v = journal.getState(k); return v == null ? d : v; } catch (_) { return d; } }
function _bucket(r) { return `${r.direction}|${Math.floor(r.confidence / 10)}`; }

/** Returns the saved recommendation, recomputing when stale (or force). Honours ADI on/off, generate and auto-learning switches. */
function recommendation({ force = false, now = Date.now() } = {}) {
  const c = adiCfg.cfg(), prev = _get(REC_KEY, null);
  if (!c.ADI_ENABLED || !c.ADI_GENERATE_RECOMMENDATIONS) return prev ? { ...prev, stale: true, inactive: true } : null;
  const due = !prev || (now - prev.ts) >= c.ADI_RECOMMENDATION_REFRESH_MINUTES * 60000;
  if (!force && !(due && c.ADI_AUTO_LEARNING)) return prev;
  const rec = analyse(now);
  try {
    journal.setState(REC_KEY, rec);
    if (c.ADI_SAVE_RECOMMENDATION_HISTORY && (!prev || _bucket(prev) !== _bucket(rec) || force)) {
      const h = _get(HIST_KEY, []); h.unshift({ ts: rec.ts, direction: rec.direction, confidence: rec.confidence, longScore: rec.long.score, shortScore: rec.short.score, trades: { long: rec.long.trades.effective, short: rec.short.trades.effective }, reasons: rec.reasons.slice(0, 2), forced: !!force });
      journal.setState(HIST_KEY, h.slice(0, HIST_MAX));
    }
  } catch (_) { /* persistence is best effort; the recommendation is still returned */ }
  return rec;
}

function approval(now = Date.now()) {
  const a = _get(APPROVAL_KEY, null), rec = _get(REC_KEY, null);
  if (!a) return { valid: false };
  const fresh = now - a.ts < APPROVAL_TTL_MS, same = rec && rec.direction === a.direction;
  return { ...a, valid: !!(fresh && same), expired: !fresh, outdated: !same };
}
function approve({ by = 'dashboard', now = Date.now() } = {}) {
  const rec = recommendation({ force: true, now });
  if (!rec || rec.inactive) throw new Error('ADI is off or not generating recommendations');
  journal.setState(APPROVAL_KEY, { direction: rec.direction, confidence: rec.confidence, ts: now, by });
  return approval(now);
}
function revoke() { journal.setState(APPROVAL_KEY, null); return { valid: false }; }

/** May ADI-initiated changes apply right now? Encodes the paper/live/approval rules in one place. */
function authority(isLive, now = Date.now()) {
  const c = adiCfg.cfg(), a = approval(now);
  if (!c.ADI_ENABLED) return { applies: false, why: 'ADI is OFF' };
  if (a.valid) return { applies: true, why: 'approved by you' };
  if (!isLive) return c.ADI_PAPER_AUTO_ADAPT ? { applies: true, why: 'paper auto-adapt' } : { applies: false, why: 'waiting for your approval (ADI_PAPER_AUTO_ADAPT=false)' };
  if (c.liveNeedsApproval) return { applies: false, why: 'LIVE: waiting for your approval' };
  return { applies: !!(c.ADI_LIVE_AUTO_DIRECTION_SWITCH || c.ADI_LIVE_AUTO_APPLY), why: 'live auto-apply enabled in .env' };
}

/** AUTO-mode restriction for new entries: 'LONG_ONLY' | 'SHORT_ONLY' | null. */
function autoRestriction(isLive, now = Date.now()) {
  const rec = recommendation({ now });
  if (!rec || rec.inactive || rec.direction === 'BOTH') return null;
  return authority(isLive, now).applies ? rec.direction : null;
}

/** Ordering nudge for a direction (points added to the adjusted score); 0 unless bias is on and ADI may apply. */
function biasFor(direction, isLive, now = Date.now()) {
  const c = adiCfg.cfg();
  if (!c.ADI_ENABLED || !c.ADI_DIRECTIONAL_BIAS_ENABLED) return 0;
  const rec = _get(REC_KEY, null); if (!rec) return 0;
  const a = approval(now);
  const ok = a.valid || (!isLive ? c.ADI_PAPER_AUTO_ADAPT : (!c.ADI_REQUIRE_LIVE_APPROVAL && !c.ADI_DIRECTION_SWITCH_APPROVAL_REQUIRED && c.ADI_LIVE_AUTO_APPLY));
  return ok ? Number(rec.bias[direction]) || 0 : 0;
}

/** Stable re-sort of a queue by (adaptive-adjusted score + ADI bias). No-op when no bias is active. Never adds or removes setups. */
function applyBias(queue, isLive) {
  if (!Array.isArray(queue) || queue.length < 2) return queue;
  const b = { LONG: biasFor('LONG', isLive), SHORT: biasFor('SHORT', isLive) };
  if (!b.LONG && !b.SHORT) return queue;
  const val = (s) => (s._adaptive && Number.isFinite(s._adaptive.adjusted) ? s._adaptive.adjusted : (s.score || 0)) + (b[s.direction] || 0);
  const out = queue.map((s, i) => ({ s, i, v: val(s) })).sort((x, y) => (y.v - x.v) || (x.i - y.i)).map(x => { x.s._adi = { bias: b[x.s.direction] || 0 }; return x.s; });
  return out;
}

// ── strategy-engine gates (map ADI strategy switches onto the existing Adaptive Winning Strategy Engine) ──
function strategyGates() {
  const c = adiCfg.cfg();
  if (!c.ADI_ENABLED) return { ordering: true, direction: true, regime: true };      // ADI off = v7.0 behaviour unchanged
  return { ordering: !!(c.ADI_STRATEGY_LEARNING_ENABLED && c.ADI_STRATEGY_AUTO_PRIORITY), direction: !!c.ADI_STRATEGY_DIRECTION_ANALYSIS, regime: !!c.ADI_MARKET_REGIME_ANALYSIS };
}

function status(isLive, now = Date.now()) {
  const c = adiCfg.cfg(), rec = _get(REC_KEY, null), a = approval(now), auth = authority(isLive, now);
  return { enabled: c.ADI_ENABLED, runMode: isLive ? 'LIVE' : 'PAPER', recommendation: rec, approval: a, authority: auth,
    pendingApproval: !!(c.ADI_ENABLED && rec && rec.direction !== 'BOTH' && !auth.applies && !a.valid),
    autoRestriction: autoRestriction(isLive, now), history: _get(HIST_KEY, []).slice(0, 25), gates: strategyGates(), now };
}

module.exports = { analyse, scoreRows, directionScore, recommendation, approve, revoke, approval, authority, autoRestriction, biasFor, applyBias, strategyGates, status };
