'use strict';
/**
 * Configuration presets (v6.0): CONSERVATIVE / BALANCED / AGGRESSIVE.
 * A preset only changes optional module switches and risk-budget numbers listed below. It NEVER touches: stop-loss protection (always on),
 * Take Live Trades, live authorisation, margin, leverage, drawdown mode, kill/flatten. Applying always saves the previous values so it can be undone.
 */
const journal = require('../journal/store');
const flags = require('../features/flags');
const pcfg = require('../protection/config');
const dl = require('../decisions/log');

const PRESETS = {
  conservative: { label: 'Conservative', blurb: 'More confirmation and a tighter risk budget. Fewer trades, more protection.',
    flags: { smartTrailing: true, profitGiveback: true, riskTaper: true, correlationBlock: true, staleDataBlock: true, regimeFilter: true, spreadFilter: true, volumeConfirm: true, htfTrend: true, volatilityFilter: true, timeExit: false, partialExits: false, adaptiveDirection: false },
    settings: { aggRiskPct: 6, taperStartPct: 40, taperMinPct: 20, ceilingPct: 130 } },
  balanced: { label: 'Balanced', blurb: 'Trailing protection, soft risk budget and basic liquidity / data checks. A middle path.',
    flags: { smartTrailing: true, profitGiveback: true, riskTaper: true, staleDataBlock: true, regimeFilter: true, spreadFilter: true, correlationBlock: false, volumeConfirm: false, htfTrend: false, volatilityFilter: false, timeExit: false, partialExits: false, adaptiveDirection: false },
    settings: { aggRiskPct: 8, taperStartPct: 50, taperMinPct: 25, ceilingPct: 150 } },
  aggressive: { label: 'Aggressive', blurb: 'Few entry filters, wider risk budget. More trades and more exposure; stop-loss on every trade stays.',
    flags: { smartTrailing: true, riskTaper: true, staleDataBlock: true, profitGiveback: false, regimeFilter: false, spreadFilter: false, correlationBlock: false, volumeConfirm: false, htfTrend: false, volatilityFilter: false, timeExit: false, partialExits: false, adaptiveDirection: false },
    settings: { aggRiskPct: 12, taperStartPct: 60, taperMinPct: 35, ceilingPct: 200 } },
};

function preview(name) {
  const p = PRESETS[name]; if (!p) throw new Error(`Unknown preset "${name}"`);
  const curF = flags.all(), curS = pcfg.get(), desc = Object.fromEntries(flags.describe().map(d => [d.key, d.label])), sdesc = Object.fromEntries(pcfg.describe().map(d => [d.key, d.label]));
  const changes = [];
  for (const [k, v] of Object.entries(p.flags)) if (curF[k] !== v) changes.push({ kind: 'module', key: k, label: desc[k] || k, from: curF[k] ? 'ON' : 'OFF', to: v ? 'ON' : 'OFF' });
  for (const [k, v] of Object.entries(p.settings)) if (curS[k] !== v) changes.push({ kind: 'setting', key: k, label: sdesc[k] || k, from: curS[k], to: v });
  return { name, label: p.label, blurb: p.blurb, changes, unchanged: 'Stop-loss protection, Take Live Trades, live authorisation, margin, leverage and drawdown mode are never changed by a preset.' };
}
function applyPreset(name) {
  const p = PRESETS[name]; if (!p) throw new Error(`Unknown preset "${name}"`);
  const curF = flags.all(), curS = pcfg.get();
  journal.setState('preset_prev', { at: Date.now(), applied: name, flags: Object.fromEntries(Object.keys(p.flags).map(k => [k, curF[k]])), settings: Object.fromEntries(Object.keys(p.settings).map(k => [k, curS[k]])) });
  for (const [k, v] of Object.entries(p.flags)) flags.set(k, v);
  for (const [k, v] of Object.entries(p.settings)) pcfg.set(k, v);
  journal.setState('preset_active', { name, at: Date.now() });
  dl.record({ type: 'SYSTEM', severity: 'INFO', module: 'presets', reason: `Preset ${p.label} applied by you (can be undone)`, key: 'preset_' + Date.now(), cooldownMs: 0 });
  return preview(name);
}
function revert() {
  const prev = journal.getState('preset_prev'); if (!prev) throw new Error('Nothing to undo');
  for (const [k, v] of Object.entries(prev.flags)) flags.set(k, v);
  for (const [k, v] of Object.entries(prev.settings)) pcfg.set(k, v);
  journal.setState('preset_prev', null); journal.setState('preset_active', null);
  dl.record({ type: 'SYSTEM', severity: 'INFO', module: 'presets', reason: `Preset ${prev.applied} undone: previous module switches and limits restored`, key: 'preset_undo_' + Date.now(), cooldownMs: 0 });
  return { ok: true, restoredFrom: prev.applied };
}
function list() { return { presets: Object.keys(PRESETS).map(preview), active: journal.getState('preset_active') || null, canUndo: !!journal.getState('preset_prev') }; }
module.exports = { PRESETS, preview, applyPreset, revert, list };
