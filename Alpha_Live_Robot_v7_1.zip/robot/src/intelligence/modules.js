'use strict';
/**
 * Module Control Centre data (v5.2.4): one card per module with a plain-language explanation, a status dot that tells the
 * truth (enabled is not the same as operational), and a market-aware recommendation. Never switches anything by itself.
 * dot: green = enabled and operational, grey = disabled, amber = enabled but waiting / degraded, red = error.
 */
const journal = require('../journal/store');
const flags = require('../features/flags');
const runtime = require('../control/runtime');
const config = require('../config');

const INFO = {
  smartTrailing: { analyses: 'How far each open trade has moved toward its target and its ATR (normal price swing).', when: 'From the moment a trade is open and in profit.', influence: 'Moves the stop-loss closer in small steps. It never loosens a stop.', benefits: 'Locks in profit automatically; most useful on small accounts.', risks: 'A normal pullback can stop a good trade early.', deps: ['A stop-loss must exist on the exchange'] },
  profitGiveback: { analyses: 'The best profit a trade reached versus how much it has given back.', when: 'After a trade has reached an early profit stage.', influence: 'Tightens the stop when too much of the peak profit is lost (exit option available in settings).', benefits: 'Protects open profit from turning into a loss.', risks: 'Can leave a trade that would have recovered.', deps: ['Smart trailing stop gives the best results'] },
  partialExits: { analyses: 'Profit milestones on each trade.', when: 'When a trade reaches a milestone.', influence: 'Closes a fraction of the position and lets the rest run with its stop.', benefits: 'Banks profit while keeping upside.', risks: 'Smaller winners; extra fees; tiny positions cannot be split.', deps: [] },
  timeExit: { analyses: 'How long a trade has been open and whether it is going anywhere.', when: 'After the stale-hours limit (default 8h) for losing / flat trades, or max-hold for winners.', influence: 'Closes stale trades or tightens their stop. CLOSES POSITIONS.', benefits: 'Frees margin from dead trades.', risks: 'May close a trade just before it moves. Trades you open in the exchange app are never closed by it unless MANUAL_TRADE_EXITS=true.', deps: [] },
  directionControl: { analyses: 'Your LONG ONLY / SHORT ONLY / BOTH / PAUSE choice.', when: 'On every new entry.', influence: 'Blocks entries in a direction you switched off.', benefits: 'Lets you keep the robot aligned with your own market view.', risks: 'Misses trades in the blocked direction.', deps: [] },
  adaptiveDirection: { analyses: 'Market-wide bias (BTC trend, breadth, sentiment).', when: 'When the market bias is strong and confirmed.', influence: 'Blocks NEW entries that go against the bias.', benefits: 'Fewer counter-trend trades.', risks: 'Fewer opportunities; the bias is an estimate.', deps: ['Fresh market intelligence'] },
  correlationBlock: { analyses: 'How much risk your open positions share (same direction / same cluster).', when: 'On every new entry.', influence: 'Blocks new entries when combined risk is above the caps.', benefits: 'Stops you piling risk onto one idea.', risks: 'May block good setups.', deps: [] },
  lossGovernor: { analyses: 'Daily, weekly and account drawdown.', when: 'When drawdown passes its levels.', influence: 'In WARN mode (default) it only warns. In ENFORCE mode it raises score requirements, slows entries or halts them.', benefits: 'Early warning that the day is going badly.', risks: 'In enforce mode it can stop you trading when conditions recover.', deps: ['Account equity readable'] },
  staleDataBlock: { analyses: 'Age of the market data.', when: 'On every new entry.', influence: 'Blocks entries if data is older than the limit. Never blocks stops or exits.', benefits: 'Avoids trading on old prices.', risks: 'A data outage pauses entries.', deps: [] },
  regimeFilter: { analyses: 'BTC market regime (trend, range, high volatility, shock).', when: 'During market shock / high volatility.', influence: 'Blocks NEW entries in dangerous regimes.', benefits: 'Avoids fresh trades in chaos.', risks: 'Misses fast opportunities.', deps: ['Fresh market intelligence'] },
  healthStrip: { analyses: 'Scanner, data, exchange, database and reconciliation status.', when: 'Always.', influence: 'Display only.', benefits: 'Shows what is broken.', risks: 'None.', deps: [] },
  journalExtras: { analyses: 'Peak profit, giveback and exit reasons per trade.', when: 'Always.', influence: 'Record keeping only.', benefits: 'Better review of why trades ended.', risks: 'None.', deps: [] },
  closeButtons: { analyses: 'Nothing: it adds a Close button to each position.', when: 'Always.', influence: 'Manual control only.', benefits: 'Quick manual closing.', risks: 'Accidental clicks (a confirmation is shown).', deps: [] },
};
Object.assign(INFO, {
  riskTaper: { analyses: 'Your total stop-loss risk across all open positions (the "aggregate stop risk") versus its cap (default 8% of equity).', when: 'When open risk passes the start point (default 50% of the cap).', influence: 'Instead of stopping new trades at the cap, each new trade is sized smaller and smaller (down to 25% by default). Winners are moved to break-even to free budget. New trades are refused only above the hard ceiling (150% of the cap).', benefits: 'Keeps trading while holding total risk down.', risks: 'Smaller trades earn less; break-even stops can end a winner that would have run. The ceiling still blocks entries when risk is very high.', deps: ['Live margin x leverage sizing (live only)'] },
  spreadFilter: { analyses: 'The bid/ask spread and the depth of the order book for the coin.', when: 'On every new entry.', influence: 'Skips the coin if the spread is wider than your limit or the book is too thin. If data is missing it does NOT block.', benefits: 'Cheaper entries, less slippage.', risks: 'Skips thin coins that may still move well.', deps: ['Exchange order-book data'] },
  volumeConfirm: { analyses: 'Last closed 1-hour volume versus its 20-hour average.', when: 'On every new entry.', influence: 'Blocks the entry when volume is below your ratio (default 0.8x).', benefits: 'Avoids moves with no participation.', risks: 'Misses early breakouts that start quietly.', deps: ['1h candles'] },
  htfTrend: { analyses: 'The coin 4-hour trend: EMA20 versus EMA50 and price.', when: 'On every new entry.', influence: 'Blocks LONGs in a 4h downtrend and SHORTs in a 4h uptrend.', benefits: 'Fewer trades against the bigger trend.', risks: 'Misses reversals; trend can lag.', deps: ['4h candles'] },
  volatilityFilter: { analyses: 'Current 1-hour volatility (ATR) versus its normal level.', when: 'On every new entry.', influence: 'Blocks entries when volatility is above your limit (default 2.5x normal).', benefits: 'Avoids chaotic spikes.', risks: 'Misses fast news-driven moves.', deps: ['1h candles'] },
});
const EXTRA = [
  { key: 'positionSlots', label: 'Position slots', desc: 'How many trades can be open at once (any capital, no equity tier)', control: 'slots', info: { analyses: 'Your closed live trades (profit factor) when the ramp is ON.', when: 'Before every scan; changes apply to the next trade with no restart.', influence: 'Ramp OFF: you get the Max slots straight away. Ramp ON: start at the Start number, +1 slot for every N closed live trades while profit factor stays at or above your minimum. Max 0 = no limit (counted as 100).', benefits: 'Fill as many positions as you want with any capital.', risks: 'More positions means more total risk. Free margin must still cover each trade, and the soft risk budget shrinks new trades as total risk rises.', deps: ['Free margin on the exchange'] } },
  { key: 'drawdownGuard', label: 'Drawdown guard', desc: 'What happens when drawdown or the daily-loss limit is reached', control: 'drawdownMode', info: { analyses: 'Account drawdown from peak, daily loss and loss streaks.', when: 'When a limit is passed.', influence: 'WARN (default): banner + log, trading continues. ENFORCE: old behaviour - fewer slots / lower leverage / entries blocked. OFF: nothing. Live only; paper keeps the original limits.', benefits: 'You choose: be warned, or be stopped.', risks: 'WARN and OFF let you keep trading through a bad streak. Stop-loss on every trade is never switched off.', deps: [] } },
  { key: 'takeLiveTrades', label: 'Take Live Trades', desc: 'Master permission for the robot to open new trades', control: 'take', info: { analyses: 'Nothing: it is your permission switch.', when: 'OFF at every start (TAKE_LIVE_TRADES_ON_START=false). You switch it ON when you want trades.', influence: 'OFF = no new entries. Open trades keep their stops and trailing.', benefits: 'The robot never trades before you say so.', risks: 'If you forget to switch it ON, nothing is opened - a banner tells you when setups are waiting.', deps: ['Live authorisation'] } },
  { key: 'manualProtection', label: 'Protect manual trades', desc: 'Guard trades you opened in the Bybit / Bitget / MEXC app', control: 'env', info: { analyses: 'Every position on the exchange that the robot did not open.', when: 'Each cycle, if the position has a stop-loss.', influence: 'Trails the stop closer (tighten only). Never closes or splits them unless MANUAL_TRADE_EXITS=true.', benefits: 'App trades get the same stop protection.', risks: 'A tighter stop can end the trade earlier than you planned. Trades without a stop cannot be guarded - you get a warning.', deps: ['PROTECT_MANUAL_TRADES in .env (on by default)'] } },
];

function robotAlive() { try { const hb = journal.getState('robot_heartbeat'); return hb && hb.ts ? (hb.alive !== false && Date.now() - hb.ts < 60000) : null; } catch (_) { return null; } }

function status(key, enabled, ctx) {
  if (!enabled) return { dot: 'grey', label: 'Disabled' };
  if (ctx.alive === false) return { dot: 'amber', label: 'Enabled, but the robot is not running - nothing applies it yet' };
  if (['adaptiveDirection', 'regimeFilter'].includes(key)) {
    const age = ctx.intel ? Date.now() - ctx.intel.ts : null;
    if (age == null) return { dot: 'amber', label: 'Enabled, waiting for market intelligence' };
    if (age > 10 * 60 * 1000) return { dot: 'amber', label: `Market intelligence is ${Math.round(age / 60000)} min old` };
  }
  if (key === 'lossGovernor' && !journal.getState('governor_state')) return { dot: 'amber', label: 'Enabled, no equity baseline yet' };
  return { dot: 'green', label: 'Enabled and operational' };
}

function advice(key, ctx) {
  const rg = ctx.intel && ctx.intel.regime && ctx.intel.regime.state, open = ctx.openCount;
  switch (key) {
    case 'riskTaper': return open >= 2 ? { text: 'Replaces the hard risk wall with smooth shrinking. Recommended.', level: 'recommend' } : null;
    case 'spreadFilter': return { text: 'Cheap, reliable filter for small accounts: consider enabling.', level: 'consider' };
    case 'volatilityFilter': return (rg === 'HIGH_VOLATILITY' || rg === 'MARKET_SHOCK') ? { text: 'Market volatility is high: consider enabling.', level: 'recommend' } : null;
    case 'htfTrend': return (rg === 'BULL_TREND' || rg === 'BEAR_TREND') ? { text: 'Clear trend: consider enabling to avoid fighting it.', level: 'consider' } : null;
    case 'smartTrailing': return open ? { text: 'Recommended while trades are open: protects gains.', level: 'recommend' } : null;
    case 'profitGiveback': return open ? { text: 'Consider with trailing: guards peak profit.', level: 'consider' } : null;
    case 'regimeFilter': return (rg === 'HIGH_VOLATILITY' || rg === 'MARKET_SHOCK') ? { text: `Market is in ${rg.replace('_', ' ').toLowerCase()}: consider enabling.`, level: 'recommend' } : null;
    case 'adaptiveDirection': return (rg === 'BULL_TREND' || rg === 'BEAR_TREND') ? { text: 'Clear market trend: consider enabling to avoid counter-trend entries.', level: 'consider' } : null;
    case 'correlationBlock': return open >= 3 ? { text: `${open} positions open: consider limiting shared risk.`, level: 'consider' } : null;
    case 'timeExit': return rg === 'RANGE' ? { text: 'Sideways market: dead trades are common; consider enabling (it closes positions).', level: 'consider' } : null;
    default: return null;
  }
}

function build() {
  const cur = flags.all(), desc = Object.fromEntries(flags.describe().map(d => [d.key, d]));
  const intel = journal.getState('market_intel') || null, alive = robotAlive();
  const mode = config.runMode !== 'SIM' ? 'advisor_live' : 'advisor_paper';
  const open = ((journal.getState(mode) || {}).rows || []).length;
  const ctx = { intel, alive, openCount: open };
  const cards = Object.keys(INFO).filter(k => desc[k]).map(k => ({ key: k, kind: 'switch', label: desc[k].label, desc: desc[k].desc, enabled: cur[k], default: desc[k].default,
    status: status(k, cur[k], ctx), info: INFO[k], advice: cur[k] ? null : advice(k, ctx) }));
  const ls = journal.getState('live_status') || {};
  const dd = runtime.drawdownMode(), lev = runtime.leverageChoice(), paused = !!journal.getState('live_paused');
  const extras = EXTRA.map(e => {
    let enabled = true, st = { dot: 'green', label: 'Operational' }, value = null;
    if (e.key === 'drawdownGuard') { value = dd; enabled = dd !== 'off'; st = dd === 'off' ? { dot: 'grey', label: 'OFF: limits ignored' } : dd === 'warn' ? { dot: 'green', label: 'WARN: limits warn, never block' } : { dot: 'amber', label: 'ENFORCE: limits can block trades' }; }
    if (e.key === 'takeLiveTrades') { value = config.runMode === 'SIM' ? null : !paused; enabled = !paused; st = config.runMode === 'SIM' ? { dot: 'grey', label: 'Paper mode: applies to LIVE only' } : paused ? { dot: 'amber', label: 'OFF: no new live trades will open' } : { dot: 'green', label: 'ON: robot may open live trades' }; if (ls.error) st = { dot: 'red', label: `Live cycle error: ${ls.error}` }; }
    if (e.key === 'positionSlots') { const sc = require('../control/runtime').slotConfig(); value = sc; st = { dot: 'green', label: sc.ramp ? `Ramp ON: start ${sc.start}, +1 per ${sc.every} trades at PF ${sc.minPF}, max ${sc.max || 'unlimited'}` : `Ramp OFF: ${sc.max || 'unlimited'} slots available now` }; }
    if (e.key === 'manualProtection') { enabled = config.protectManualTrades; st = enabled ? { dot: 'green', label: config.manualTradeExits ? 'ON: trail + exits' : 'ON: trail only' } : { dot: 'grey', label: 'OFF (PROTECT_MANUAL_TRADES=false)' }; }
    return { key: e.key, kind: e.control, label: e.label, desc: e.desc, enabled, value, status: st, info: e.info, advice: null };
  });
  return { cards: [...extras, ...cards], leverage: lev || 'auto', drawdownMode: dd, intelAgeSec: intel ? Math.round((Date.now() - intel.ts) / 1000) : null, robotAlive: alive,
    note: 'Green = enabled AND operational. Amber = enabled but waiting or degraded. Grey = disabled. Red = error. A recommendation is a suggestion, not a promise of better results; nothing is switched on automatically.' };
}
module.exports = { build, INFO };
