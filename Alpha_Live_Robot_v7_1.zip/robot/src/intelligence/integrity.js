'use strict';
/**
 * Trade Integrity (v5.2.4). An explainable 0-100 QUALITY score for an open position. It is NOT a win probability:
 * "80" means 80% of the weighted checks that could be measured were satisfied.
 * Three separate numbers are kept:
 *   entry    - frozen the first time the robot sees the position (never rewritten)
 *   current  - recalculated on every refresh (adds live momentum / give-back)
 *   coverage - how much of the scoring weight could actually be measured. Unmeasurable factors are "unknown",
 *              they are NOT counted as passed (and not as failed): they just lower coverage.
 */
const journal = require('../journal/store');
const KEY = 'integrity_entry';

const BANDS = [[90, 'Excellent'], [70, 'Strong'], [50, 'Moderate'], [30, 'Weak'], [0, 'Very weak']];
const band = (s) => (s == null ? 'Not enough data' : BANDS.find(([min]) => s >= min)[1]);
const VAL = { pass: 1, partial: 0.5, fail: 0, unknown: null };

function factors(p, ctx) {
  const long = p.side === 'LONG', s = long ? 1 : -1, intel = ctx.intel || null, out = [];
  const add = (key, label, weight, status, detail, currentOnly = false) => out.push({ key, label, weight, status, detail, currentOnly });

  add('stop', 'Stop-loss on the exchange', 25, p.stop > 0 ? 'pass' : 'fail', p.stop > 0 ? `Stop set at ${p.stop}` : 'No stop-loss found - the trade is unprotected');

  const risk = Math.abs(p.entry - (p.initialStop || p.stop || 0)), reward = p.tp ? Math.abs(p.tp - p.entry) : null;
  if (reward && risk > 0) { const rr = reward / risk; add('rr', 'Risk / reward', 15, rr >= 2 ? 'pass' : rr >= 1.2 ? 'partial' : 'fail', `Target is ${rr.toFixed(2)}x the risk`); }
  else add('rr', 'Risk / reward', 15, 'unknown', 'No take-profit / initial stop on record');

  const bias = intel && intel.bias && intel.bias.recommendation;
  if (bias) {
    const agree = (bias === 'LONG_BIAS' && long) || (bias === 'SHORT_BIAS' && !long), against = (bias === 'LONG_BIAS' && !long) || (bias === 'SHORT_BIAS' && long);
    add('trend', 'Market trend agreement', 15, agree ? 'pass' : against ? 'fail' : 'partial', `Market bias is ${bias.replace('_', ' ').toLowerCase()} (BTC-led estimate)`);
  } else add('trend', 'Market trend agreement', 15, 'unknown', 'Market intelligence not available yet');

  const sc = intel && intel.sentiment && intel.sentiment.score;
  if (sc != null) { const f = long ? sc : 100 - sc; add('sentiment', 'Market sentiment', 10, f >= 55 ? 'pass' : f >= 45 ? 'partial' : 'fail', `Sentiment ${sc}/100 (${intel.sentiment.label || 'n/a'})`); }
  else add('sentiment', 'Market sentiment', 10, 'unknown', 'Sentiment not available');

  const rg = intel && intel.regime && intel.regime.state;
  if (rg) add('regime', 'Market regime', 10, (rg === 'MARKET_SHOCK' || rg === 'HIGH_VOLATILITY') ? 'fail' : rg === 'UNCERTAIN' ? 'partial' : 'pass', `Regime: ${rg.replace('_', ' ').toLowerCase()}`);
  else add('regime', 'Market regime', 10, 'unknown', 'Regime not available');

  const stopDist = p.stop > 0 && p.mark > 0 ? Math.abs(p.mark - p.stop) / p.mark * 100 : null;
  if (p.liqDistPct != null && stopDist) { const x = p.liqDistPct / Math.max(stopDist, 0.01); add('liq', 'Distance to liquidation', 15, x >= 3 ? 'pass' : x >= 1.5 ? 'partial' : 'fail', `Liquidation is ${p.liqDistPct}% away; stop is ${stopDist.toFixed(2)}% away`); }
  else add('liq', 'Distance to liquidation', 15, 'unknown', 'No liquidation price (paper trade or not reported)');

  if (p.progress != null) {
    const gb = p.peakProgress >= 40 && p.progress <= p.peakProgress * 0.5;
    add('momentum', 'Trade momentum', 20, gb ? 'fail' : p.progress >= 0 ? 'pass' : p.progress > -40 ? 'partial' : 'fail',
      gb ? `Gave back more than half of its peak (${p.peakProgress}% -> ${p.progress}% of the way to target)` : `${p.progress}% of the way to target`, true);
  } else add('momentum', 'Trade momentum', 20, 'unknown', 'No target to measure progress against', true);
  return out;
}

function score(list, includeCurrent) {
  const use = list.filter(f => includeCurrent || !f.currentOnly);
  const total = use.reduce((a, f) => a + f.weight, 0), known = use.filter(f => VAL[f.status] != null);
  const kw = known.reduce((a, f) => a + f.weight, 0);
  const pts = known.reduce((a, f) => a + f.weight * VAL[f.status], 0);
  return { score: kw > 0 && kw / total >= 0.4 ? Math.round(pts / kw * 100) : null, coverage: Math.round(total ? kw / total * 100 : 0) };
}

function assess(p, ctx = {}) {
  const f = factors(p, ctx), cur = score(f, true), ent = score(f, false);
  return { factors: f, current: cur.score, coverage: cur.coverage, entryNow: ent.score, band: band(cur.score),
    method: 'Weighted checklist of measurable conditions. It is NOT the probability of winning. Unmeasurable factors lower "data coverage" instead of counting as passed.' };
}

/** rows: protection-view style rows. Freezes entry integrity at first sight; returns rows with .integrity */
function annotate(mode, rows, ctx = {}) {
  let store = {}; try { store = journal.getState(KEY) || {}; } catch (_) { /* ignore */ }
  const live = new Set(); let dirty = false;
  const out = rows.map(r => {
    const key = `${mode}:${r.symbol}:${r.side}:${Math.round((r.entry || 0) * 1e6)}`; live.add(key);
    const a = assess(r, ctx);
    if (!store[key]) { store[key] = { score: a.entryNow, coverage: a.coverage, at: Date.now(), peak: r.peakProgress || 0 }; dirty = true; }
    return { ...r, integrity: { entry: store[key].score, entryAt: store[key].at, current: a.current, coverage: a.coverage, band: a.band, factors: a.factors, method: a.method } };
  });
  for (const k of Object.keys(store)) if (k.startsWith(mode + ':') && !live.has(k)) { delete store[k]; dirty = true; }
  if (dirty) { try { journal.setState(KEY, store); } catch (_) { /* ignore */ } }
  return out;
}

/** Recommendations for one annotated row, given current module switches. Never auto-applies anything. */
function recommend(row, flags, rows = []) {
  const rec = [], fl = flags || {}, up = row.progress != null && row.progress > 0;
  const add = (module, label, why, benefit, risk, note) => rec.push({ module, label, enabled: !!fl[module], why, benefit, risk, note: note || 'Module switches apply to ALL positions. Safe to change while trades are open: it only tightens stops or exits earlier.' });
  if (!row.protectedStop && row.stop == null) rec.push({ module: null, label: 'Set a stop-loss', enabled: false, why: 'This position has no stop-loss on the exchange.', benefit: 'The robot can only protect trades that have a stop.', risk: 'None.', note: 'Set it in your exchange app.' });
  if (up && !fl.smartTrailing) add('smartTrailing', 'Smart trailing stop', `Trade is ${row.progress}% of the way to target with no trailing protection.`, 'Locks in part of the gain by moving the stop closer as price moves your way.', 'A normal pullback can stop you out before the target.');
  if (up && row.peakProgress >= 40 && !fl.profitGiveback) add('profitGiveback', 'Profit giveback guard', `Peak was ${row.peakProgress}% of the way to target.`, 'Tightens the stop if too much of the peak profit is given back.', 'Can exit a trade that would have recovered.');
  if (row.hoursOpen >= 8 && Math.abs(row.progress || 0) < 15 && !fl.timeExit) add('timeExit', 'Time exits', `Open ${row.hoursOpen}h without real progress.`, 'Frees margin from trades that are going nowhere.', 'May close a trade just before it moves. Applies to robot trades; app-opened trades only if MANUAL_TRADE_EXITS=true.', 'Closes positions - check before enabling.');
  const f = (row.integrity && row.integrity.factors) || [];
  if (f.some(x => x.key === 'trend' && x.status === 'fail') && !fl.adaptiveDirection) add('adaptiveDirection', 'Adaptive direction', 'Market bias is against this position.', 'Blocks NEW entries against a confirmed strong bias.', 'Fewer opportunities. Does not touch this open trade.', 'Affects new entries only.');
  const same = rows.filter(r => r.side === row.side).length;
  if (same >= 3 && !fl.correlationBlock) add('correlationBlock', 'Correlation / exposure block', `${same} open positions are all ${row.side}.`, 'Stops piling more risk onto the same direction.', 'May block good setups.', 'Affects new entries only.');
  return rec;
}
module.exports = { assess, annotate, recommend, band, KEY };
