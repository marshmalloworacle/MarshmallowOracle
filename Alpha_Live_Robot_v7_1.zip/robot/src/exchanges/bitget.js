'use strict';

/**
 * Bitget USDT-M futures adapter (official v2 mix API, https://api.bitget.com).
 * Normalised to the same Bybit-shaped objects the rest of the robot consumes. Internal symbols are BTCUSDT
 * (identical to Bitget's own), quantities are BASE units (Bitget USDT-futures sizes are already base coin).
 *
 * SAFETY (mirrors the MEXC adapter):
 *  - Orders are only reachable through the existing execution layer, which stays behind TRADING_MODE=LIVE +
 *    LIVE_TRADING_ENABLED + keys + dashboard confirmation. TESTNET is Bybit-only, so Bitget orders are LIVE-only.
 *  - POST requests are NEVER auto-retried: a timeout is AMBIGUOUS (err.ambiguous = true) -> reconcile by clientOid.
 *  - One-way position mode only. In hedge mode classicPlaceOrder refuses (never silently changes your account mode).
 *  - Isolated margin only (marginMode:'isolated' on every order).
 *  - NOT verified against the live Bitget servers by the author (no network in the build sandbox): run
 *    `npm run bitget:verify` (read-only, sends no order) before relying on it.
 */
const crypto = require('node:crypto');
const config = require('../config');
const logger = require('../utils/logger');

const TIMEOUT_MS = 15000;
const RETRIES = 3;
const MIN_GAP_MS = 80;               // ~12 req/s, under Bitget's 20 req/s market-data limit
const DETAIL_TTL_MS = 5 * 60 * 1000;
const PT = 'USDT-FUTURES';

const GRAN = { '1': '1m', '3': '3m', '5': '5m', '15': '15m', '30': '30m', '60': '1H', '240': '4H', '360': '6H', '720': '12H', D: '1D', W: '1W', M: '1M' };
const MINUTES = { '1': 1, '3': 3, '5': 5, '15': 15, '30': 30, '60': 60, '240': 240, '360': 360, '720': 720, D: 1440, W: 10080, M: 43200 };

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };

class BitgetError extends Error {
  constructor(message, { code = null, status = null, ambiguous = false, path = '' } = {}) {
    super(message); this.name = 'BitgetError'; this.code = code; this.status = status; this.ambiguous = ambiguous; this.path = path;
  }
}

let lastCall = 0;
async function throttle() {
  const wait = lastCall + MIN_GAP_MS - Date.now();
  lastCall = Math.max(Date.now(), lastCall + MIN_GAP_MS);
  if (wait > 0) await sleep(wait);
}

function queryString(params) {
  const keys = Object.keys(params || {}).filter(k => params[k] !== undefined && params[k] !== null && params[k] !== '').sort();
  return keys.map(k => `${k}=${encodeURIComponent(String(params[k]))}`).join('&');
}
/** base64(HMAC_SHA256(secret, timestamp + METHOD + requestPath[?query] + body)) */
function sign(secret, timestamp, method, requestPath, query, body) {
  const pre = `${timestamp}${method.toUpperCase()}${requestPath}${query ? `?${query}` : ''}${body || ''}`;
  return crypto.createHmac('sha256', secret).update(pre).digest('base64');
}

async function request(method, path, params = {}, { auth = false, retries } = {}) {
  const maxTries = retries ?? (method === 'GET' ? RETRIES : 1);   // never auto-retry writes
  for (let attempt = 1; attempt <= maxTries; attempt++) {
    try {
      await throttle();
      const { apiKey, apiSecret, passphrase, baseUrl } = config.bitget;
      const headers = { 'Content-Type': 'application/json', locale: 'en-US' };
      const qs = method === 'GET' ? queryString(params) : '';
      const body = method === 'POST' ? JSON.stringify(params || {}) : '';
      if (auth) {
        if (!apiKey || !apiSecret || !passphrase) throw new BitgetError('Bitget credentials missing (BITGET_API_KEY / BITGET_API_SECRET / BITGET_PASSPHRASE)', { path });
        const ts = String(Date.now());
        headers['ACCESS-KEY'] = apiKey; headers['ACCESS-TIMESTAMP'] = ts; headers['ACCESS-PASSPHRASE'] = passphrase;
        headers['ACCESS-SIGN'] = sign(apiSecret, ts, method, path, qs, body);
      }
      const opts = { method, headers, signal: AbortSignal.timeout(TIMEOUT_MS) };
      if (method === 'POST') opts.body = body;
      let res;
      try { res = await fetch(`${baseUrl}${path}${qs ? `?${qs}` : ''}`, opts); }
      catch (e) { throw new BitgetError(`network/timeout on ${method} ${path}: ${e.message}`, { path, ambiguous: method !== 'GET' }); }
      let data = null;
      try { data = await res.json(); } catch (_) { /* non-JSON */ }
      if (!res.ok) {
        const detail = data && data.msg ? ` - Bitget says: ${String(data.msg).slice(0, 160)}` : '';
        throw new BitgetError(`HTTP ${res.status}${data?.code ? ` (code ${data.code})` : ''} on ${method} ${path}${detail}`, { status: res.status, path, code: data?.code ?? null, ambiguous: method !== 'GET' && res.status >= 500 });
      }
      if (data && data.code !== undefined && String(data.code) !== '00000') throw new BitgetError(`Bitget error ${data.code}: ${data.msg || 'unknown'} (${path})`, { code: String(data.code), path });
      return data && 'data' in data ? data.data : data;
    } catch (err) {
      const retryable = method === 'GET' && attempt < maxTries && (err.status >= 500 || err.code === '429' || err.status === 429 || /network|timeout/.test(err.message));
      if (!retryable) { logger.warn(`Bitget ${method} ${path} failed: ${err.message}`); throw err; }
      await sleep(500 * 2 ** (attempt - 1));
    }
  }
}
const pub = (path, params) => request('GET', path, { ...params });
const priv = (method, path, params) => request(method, path, params, { auth: true });

// ── contract cache (price/size precision drives every order) ──
let detail = { at: 0, map: new Map(), raw: [] };
async function loadDetail(force = false) {
  if (!force && detail.map.size && Date.now() - detail.at < DETAIL_TTL_MS) return detail;
  const list = await pub('/api/v2/mix/market/contracts', { productType: PT });
  const map = new Map();
  for (const c of Array.isArray(list) ? list : []) map.set(c.symbol, c);
  if (map.size) detail = { at: Date.now(), map, raw: list };
  return detail;
}
async function contractOf(symbol) {
  const d = await loadDetail(); const c = d.map.get(symbol);
  if (!c) throw new BitgetError(`unknown Bitget contract ${symbol}`);
  return c;
}
const tickOf = (c) => num(c.priceEndStep || 1) * Math.pow(10, -num(c.pricePlace));
const stepOf = (c) => num(c.sizeMultiplier) || Math.pow(10, -num(c.volumePlace));
const decimals = (x) => { const s = String(x); const i = s.indexOf('.'); return i < 0 ? 0 : Math.min(12, s.length - i - 1); };
const floorTo = (v, step) => { const n = Math.floor(v / step + 1e-9) * step; return Number(n.toFixed(Math.max(decimals(step), 0))); };
const fmt = (v, step) => Number(v).toFixed(decimals(step));

async function getInstruments() {
  const d = await loadDetail();
  return d.raw
    .filter(c => c.quoteCoin === 'USDT' && c.symbolType === 'perpetual' && (!c.symbolStatus || c.symbolStatus === 'normal'))
    .map(c => ({
      symbol: c.symbol, baseCoin: c.baseCoin, quoteCoin: 'USDT', contractType: 'LinearPerpetual', status: 'Trading',
      lotSizeFilter: { minOrderQty: String(num(c.minTradeNum)), maxOrderQty: String(num(c.maxOrderQty) || 1e12), qtyStep: String(stepOf(c)), minNotionalValue: String(num(c.minTradeUSDT) || 5) },
      priceFilter: { tickSize: String(Number(tickOf(c).toFixed(12))) },
      leverageFilter: { maxLeverage: String(c.maxLever || 1) },
      takerFeeRate: num(c.takerFeeRate), makerFeeRate: num(c.makerFeeRate), maintenanceMarginRate: null, apiAllowed: true,
    }));
}

function mapTicker(t) {
  return {
    symbol: t.symbol, lastPrice: String(t.lastPr), markPrice: String(t.markPrice || t.lastPr), indexPrice: String(t.indexPrice || t.lastPr),
    bid1Price: String(t.bidPr), ask1Price: String(t.askPr),
    turnover24h: String(num(t.usdtVolume || t.quoteVolume)), volume24h: String(num(t.baseVolume)),
    price24hPcnt: String(num(t.change24h)), fundingRate: String(num(t.fundingRate)),
    openInterest: String(num(t.holdingAmount)), openInterestValue: String(num(t.holdingAmount) * num(t.lastPr)),
    highPrice24h: String(num(t.high24h)), lowPrice24h: String(num(t.low24h)),
  };
}
async function getTickers(symbol) {
  if (symbol) { const d = await pub('/api/v2/mix/market/ticker', { symbol, productType: PT }); return (Array.isArray(d) ? d : d ? [d] : []).map(mapTicker); }
  const d = await pub('/api/v2/mix/market/tickers', { productType: PT });
  return (d || []).filter(t => String(t.symbol).endsWith('USDT')).map(mapTicker);
}

const toCandle = (k) => ({ time: Number(k[0]), open: num(k[1]), high: num(k[2]), low: num(k[3]), close: num(k[4]), volume: num(k[5]), turnover: num(k[6]) });
async function getKlines(symbol, interval, limit = 200, start, end) {
  const g = GRAN[String(interval)]; if (!g) throw new BitgetError(`unsupported interval ${interval}`);
  const d = await pub('/api/v2/mix/market/candles', { symbol, productType: PT, granularity: g, limit: Math.min(1000, limit), startTime: start, endTime: end });
  return (d || []).map(toCandle).sort((a, b) => a.time - b.time).slice(-limit);
}
async function getKlineHistory(symbol, interval, maxCandles = 1000) {
  const g = GRAN[String(interval)]; if (!g) throw new BitgetError(`unsupported interval ${interval}`);
  const stepMs = MINUTES[String(interval)] * 60000; let end = Date.now(); let all = [];
  while (all.length < maxCandles) {
    const win = Math.min(1000, maxCandles - all.length + 5);
    let d; try { d = await pub('/api/v2/mix/market/candles', { symbol, productType: PT, granularity: g, limit: win, startTime: end - win * stepMs, endTime: end }); } catch (_) { break; }
    const cs = (d || []).map(toCandle).sort((a, b) => a.time - b.time); if (!cs.length) break;
    all = [...cs, ...all]; end = cs[0].time - 1;
    if (cs.length < win - 5) break;
  }
  const seen = new Set();
  return all.filter(k => !seen.has(k.time) && seen.add(k.time)).sort((a, b) => a.time - b.time).slice(-maxCandles);
}

async function getFundingRate(symbol) {
  const d = await pub('/api/v2/mix/market/current-fund-rate', { symbol, productType: PT });
  const r = Array.isArray(d) ? d[0] : d;
  return r ? { symbol, fundingRate: num(r.fundingRate), fundingTime: Number(r.nextUpdate) || null } : null;
}
async function getFundingHistory(symbol, limit = 8) {
  const d = await pub('/api/v2/mix/market/history-fund-rate', { symbol, productType: PT, pageSize: limit });
  return (d || []).map(r => ({ fundingRate: String(r.fundingRate), fundingRateTimestamp: String(r.fundingTime) }));
}
async function getOpenInterest(symbol) {
  const d = await pub('/api/v2/mix/market/open-interest', { symbol, productType: PT });
  const row = d?.openInterestList?.[0];
  return row ? { symbol, openInterest: num(row.size), time: Number(d.ts) || Date.now() } : null;
}
/** Bitget exposes only the current open interest; no history endpoint. */
async function getOpenInterestHistory() { return []; }
async function getOrderBook(symbol, limit = 50) {
  const d = await pub('/api/v2/mix/market/merge-depth', { symbol, productType: PT, limit });
  return { symbol, ts: Number(d?.ts) || Date.now(), bids: (d?.bids || []).map(([p, s]) => [String(p), String(s)]), asks: (d?.asks || []).map(([p, s]) => [String(p), String(s)]) };
}

// ── private ──
async function classicGetPositionMode() {
  const a = await priv('GET', '/api/v2/mix/account/accounts', { productType: PT });
  const row = (a || []).find(x => x.marginCoin === 'USDT') || (a || [])[0] || {};
  return { posMode: row.posMode || null, raw: row };
}
async function classicGetPositions() {
  const list = await priv('GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
  return (list || []).filter(p => num(p.total) > 0).map(p => ({
    positionId: `${p.symbol}:${p.holdSide}`, symbol: p.symbol, side: p.holdSide === 'long' ? 'LONG' : 'SHORT', qty: num(p.total), vol: num(p.total),
    entry: num(p.openPriceAvg), liquidationPrice: num(p.liquidationPrice), leverage: num(p.leverage), margin: num(p.marginSize),
    realised: num(p.achievedProfits), unrealized: num(p.unrealizedPL), isolated: p.marginMode === 'isolated',
  }));
}
async function classicGetAccountBalance() {
  const a = await priv('GET', '/api/v2/mix/account/accounts', { productType: PT });
  const row = (a || []).find(x => x.marginCoin === 'USDT') || (a || [])[0];
  if (!row) throw new BitgetError('Bitget returned no USDT-futures account');
  let margin = 0; try { margin = (await classicGetPositions()).reduce((s, p) => s + p.margin, 0); } catch (_) { /* leave 0 */ }
  return { currency: 'USDT', equity: num(row.accountEquity || row.usdtEquity), available: num(row.available), margin, unrealized: num(row.unrealizedPL), raw: row };
}

const STATE = { live: 'New', new: 'New', partially_filled: 'PartiallyFilled', filled: 'Filled', canceled: 'Cancelled', cancelled: 'Cancelled' };
function mapOrder(o) {
  return { orderId: String(o.orderId), clientOrderId: o.clientOid || null, symbol: o.symbol, status: STATE[o.state || o.status] || 'Unknown',
    side: o.side === 'buy' ? 'Buy' : 'Sell', reduceOnly: o.reduceOnly === 'YES' || o.tradeSide === 'close',
    price: num(o.price), qty: num(o.size), filledQty: num(o.baseVolume), avgPrice: num(o.priceAvg), fee: Math.abs(num(o.fee)),
    stopLoss: num(o.presetStopLossPrice) || null, takeProfit: num(o.presetStopSurplusPrice) || null, errorCode: 0, raw: o };
}
async function classicGetOpenOrders(symbol) {
  const d = await priv('GET', '/api/v2/mix/order/orders-pending', { productType: PT, symbol });
  return (d?.entrustedList || []).map(mapOrder);
}
/** Is this TP/SL order protecting a LONG? posSide when given; otherwise a closing SELL protects a long (one-way mode). */
const protectsLong = (s) => { const ps = String(s.posSide || s.holdSide || '').toLowerCase(); return ps === 'long' || ps === 'buy' ? true : ps === 'short' || ps === 'sell' ? false : String(s.side || '').toLowerCase() === 'sell'; };
async function classicRawStops(symbol) {
  const d = await priv('GET', '/api/v2/mix/order/orders-plan-pending', { productType: PT, planType: 'profit_loss', symbol });
  return d?.entrustedList || [];
}
/** Exchange-side TP/SL (plan) orders still active - used to VERIFY a position is protected. Handles pos_loss/pos_profit (set in the app) and loss_plan/profit_plan (preset on the order). */
async function classicGetStopOrders(symbol) {
  const grouped = new Map();
  for (const s of await classicRawStops(symbol)) {
    const long = protectsLong(s); const key = `${s.symbol}:${long ? 'long' : 'short'}`;
    const cur = grouped.get(key) || { id: String(s.orderId), symbol: s.symbol, positionId: key, stopLoss: null, takeProfit: null, long, slOrderId: null, tpOrderId: null };
    const px = num(s.triggerPrice) || null; const pt = String(s.planType || '');
    if (/loss/.test(pt)) { cur.stopLoss = px; cur.slOrderId = String(s.orderId); } else if (/profit|surplus/.test(pt)) { cur.takeProfit = px; cur.tpOrderId = String(s.orderId); }
    if (num(s.stopLossTriggerPrice)) cur.stopLoss = num(s.stopLossTriggerPrice);
    if (num(s.stopSurplusTriggerPrice)) cur.takeProfit = num(s.stopSurplusTriggerPrice);
    grouped.set(key, cur);
  }
  return [...grouped.values()];
}
/** Move the stop-loss (and/or take-profit) of an OPEN position on the exchange. Modifies the existing plan order when there is one, else places a position-level one.
 *  Used by the live trailing stop. The caller reads the stop back afterwards and alerts if it did not take, so a rejected update leaves the previous stop in force. */
async function classicSetTradingStop({ symbol, stopLoss, takeProfit }) {
  const c = await contractOf(symbol); const tick = tickOf(c); const step = stepOf(c);
  const pos = (await classicGetPositions()).find(p => p.symbol === symbol);
  if (!pos) throw new BitgetError(`no open Bitget position for ${symbol}`);
  const cur = (await classicGetStopOrders(symbol)).find(x => x.long === (pos.side === 'LONG'));
  const holdSide = pos.side === 'LONG' ? 'buy' : 'sell';   // one-way mode naming
  const apply = async (kind, price, existingId) => {
    const triggerPrice = fmt(price, tick);
    if (existingId) return priv('POST', '/api/v2/mix/order/modify-tpsl-order', { orderId: existingId, marginCoin: 'USDT', productType: PT, symbol, triggerPrice, triggerType: 'mark_price', executePrice: '0', size: fmt(pos.qty, step) });
    return priv('POST', '/api/v2/mix/order/place-tpsl-order', { marginCoin: 'USDT', productType: PT, symbol, planType: kind === 'sl' ? 'pos_loss' : 'pos_profit', triggerPrice, triggerType: 'mark_price', executePrice: '0', holdSide });
  };
  if (stopLoss) await apply('sl', stopLoss, cur && cur.slOrderId);
  if (takeProfit) await apply('tp', takeProfit, cur && cur.tpOrderId);
  return { ok: true };
}
async function classicGetOrder(symbol, { orderId, clientOrderId } = {}) {
  const d = await priv('GET', '/api/v2/mix/order/detail', { symbol, productType: PT, orderId, clientOid: orderId ? undefined : clientOrderId });
  return d && d.orderId ? mapOrder(d) : null;
}

/**
 * Place an order. qty is in BASE units, floored to Bitget's size step. One-way mode + isolated margin only.
 * params: { symbol, side:'Buy'|'Sell', qty, orderType:'Limit'|'Market', price, leverage, reduceOnly, clientOrderId, stopLoss, takeProfit }
 * Throws BitgetError; err.ambiguous === true means the outcome is UNKNOWN -> reconcile by clientOrderId.
 */
async function classicPlaceOrder(p) {
  if (!p || !p.symbol || !p.side || !(p.qty > 0)) throw new BitgetError('classicPlaceOrder: symbol, side and qty are required');
  const c = await contractOf(p.symbol); const step = stepOf(c); const tick = tickOf(c);
  const size = floorTo(p.qty, step);
  if (size < num(c.minTradeNum)) throw new BitgetError(`qty below Bitget minimum (${num(c.minTradeNum)})`, { code: 'BELOW_MIN' });
  const { posMode } = await getPositionMode();
  if (posMode && posMode !== 'one_way_mode') throw new BitgetError(`Bitget account is in ${posMode}; this robot needs one_way_mode (switch it in Bitget > Futures > Preferences with no open positions, then retry)`, { code: 'HEDGE_MODE' });
  if (!p.reduceOnly && p.leverage) {
    await priv('POST', '/api/v2/mix/account/set-leverage', { symbol: p.symbol, productType: PT, marginCoin: 'USDT', leverage: String(Math.round(p.leverage)) });
  }
  const body = { symbol: p.symbol, productType: PT, marginMode: 'isolated', marginCoin: 'USDT', size: fmt(size, step), side: p.side === 'Buy' ? 'buy' : 'sell',
    orderType: p.orderType === 'Market' ? 'market' : 'limit', force: 'gtc', reduceOnly: p.reduceOnly ? 'YES' : 'NO' };
  if (body.orderType === 'limit') body.price = fmt(p.price, tick);
  if (p.clientOrderId) { if (p.clientOrderId.length > 50) throw new BitgetError('clientOid max 50 chars'); body.clientOid = p.clientOrderId; }
  if (!p.reduceOnly && p.stopLoss) body.presetStopLossPrice = fmt(p.stopLoss, tick);
  if (!p.reduceOnly && p.takeProfit) body.presetStopSurplusPrice = fmt(p.takeProfit, tick);
  const data = await priv('POST', '/api/v2/mix/order/place-order', body);
  const orderId = String(data?.orderId ?? '');
  logger.live(`Bitget order sent: ${p.side} ${p.symbol} size=${body.size} ${body.orderType} id=${orderId} coid=${p.clientOrderId || '-'}`);
  return { orderId, clientOrderId: p.clientOrderId || null, vol: size, qty: size };
}
async function classicCancelOrder(symbol, orderId) {
  return priv('POST', '/api/v2/mix/order/cancel-order', { symbol, productType: PT, marginCoin: 'USDT', orderId: String(orderId) });
}
/** Every order is sent with marginMode:'isolated', so the mode is isolated by construction. */
async function getMarginMode() { return 'ISOLATED_MARGIN'; }

async function classicGetClosedTrades(limit = 50) {
  const d = await priv('GET', '/api/v2/mix/position/history-position', { productType: PT, limit: Math.min(100, limit) });
  return (d?.list || []).map(p => ({ symbol: p.symbol, direction: p.holdSide === 'long' ? 'LONG' : 'SHORT', qty: num(p.closeTotalPos || p.openTotalPos),
    entry: num(p.openAvgPrice), exit: num(p.closeAvgPrice), pnl: num(p.netProfit ?? p.pnl), fee: Math.abs(num(p.openFee)) + Math.abs(num(p.closeFee)),
    openedAt: Number(p.ctime) || null, closedAt: Number(p.utime) || Date.now(), orderId: p.positionId }));
}
async function ping() {
  const t0 = Date.now(); const d = await pub('/api/v2/public/time'); const t1 = Date.now();
  const serverTime = Number(d?.serverTime) || t1;
  return { latencyMs: t1 - t0, serverTime, driftMs: Math.abs(t1 - serverTime) };
}

function explain(err) {
  const c = String(err && err.code); const st = err && err.status;
  if (c === '40012' || c === '40009' || c === '40006') return 'Signature/key rejected: re-copy BITGET_API_KEY, BITGET_API_SECRET and BITGET_PASSPHRASE exactly (no quotes/spaces); the passphrase is the one you typed when creating the key.';
  if (c === '40014') return 'Key lacks permission: edit the key on Bitget and tick Futures read (and Futures trade for live).';
  if (c === '40018' || c === '40037') return 'IP not whitelisted / key invalid. Codespaces IPs change: remove the IP restriction (keep withdrawals OFF) or whitelist the current IP.';
  if (c === '40008') return 'Clock problem: request timestamp outside Bitget\'s window; check the clock drift above.';
  if (c === '429' || st === 429) return 'Rate limited: wait a minute and retry.';
  if (/network|timeout/i.test(err && err.message)) return 'Network problem from this machine to Bitget.';
  return 'See the Bitget v2 error-code table in the API docs.';
}

/** Read-only checks for `npm run bitget:verify`: never places an order. */
async function verify() {
  const out = { checks: [] };
  const add = (name, ok, detail) => out.checks.push({ name, ok, detail });
  try { const p = await ping(); add('public API + clock', p.driftMs < 5000, `latency ${p.latencyMs} ms, clock drift ${p.driftMs} ms`); }
  catch (e) { add('public API + clock', false, e.message); }
  try { const ins = await getInstruments(); add('contracts', ins.length > 0, `${ins.length} USDT perpetuals`); } catch (e) { add('contracts', false, e.message); }
  try { const t = await getTickers(); add('tickers', t.length > 0, `${t.length} tickers`); } catch (e) { add('tickers', false, e.message); }
  if (!config.bitget.apiKey || !config.bitget.apiSecret || !config.bitget.passphrase) { add('credentials', false, 'BITGET_API_KEY / BITGET_API_SECRET / BITGET_PASSPHRASE not set'); return out; }
  try { add('account type', true, `${await accountType()} (BITGET_ACCOUNT_TYPE=${config.bitget.accountType})`); } catch (e) { add('account type', false, e.message); }
  try { const b = await getAccountBalance(); add('account read', true, `equity ${b.equity} USDT, available ${b.available}`); out.balance = b; }
  catch (e) { add('account read', false, `${e.message}  -> ${explain(e)}`); }
  try { const m = await getPositionMode(); add('position mode', m.posMode === 'one_way_mode' ? true : m.posMode ? false : null, `${m.posMode || 'unknown'} (robot requires one_way_mode)`); } catch (e) { add('position mode', false, e.message); }
  try { await getPositions(); await getOpenOrders(); add('positions/orders read', true, 'ok'); } catch (e) { add('positions/orders read', false, `${e.message}  -> ${explain(e)}`); }
  add('order placement', null, 'NOT TESTED (verify never sends orders). Test with the smallest size first.');
  return out;
}


// ── Classic (v2) vs Unified Trading Account (v3): BITGET_ACCOUNT_TYPE=auto|classic|uta ──
let modeCache = { at: 0, uta: null };
async function isUta() {
  const t = config.bitget.accountType;
  if (t === 'uta') return true; if (t === 'classic') return false;
  if (modeCache.at && Date.now() - modeCache.at < 10 * 60 * 1000) return modeCache.uta;
  try { await priv('GET', '/api/v3/account/settings', {}); modeCache = { at: Date.now(), uta: true }; }
  catch (e) { if (e && e.code) modeCache = { at: Date.now(), uta: false }; else return false; }   // only cache a definitive answer from Bitget
  return modeCache.uta;
}
const uta = require('./bitgetUta').create({ priv, contractOf, stepOf, tickOf, floorTo, fmt, BitgetError, logger });
const classic = { setTradingStop: classicSetTradingStop, rawStops: classicRawStops, getPositionMode: classicGetPositionMode, getPositions: classicGetPositions, getAccountBalance: classicGetAccountBalance, getOpenOrders: classicGetOpenOrders, getStopOrders: classicGetStopOrders, getOrder: classicGetOrder, placeOrder: classicPlaceOrder, cancelOrder: classicCancelOrder, getClosedTrades: classicGetClosedTrades };
const route = (n) => async (...a) => ((await isUta()) ? uta : classic)[n](...a);
const setTradingStop = route('setTradingStop'), rawStops = route('rawStops'), getPositionMode = route('getPositionMode'), getPositions = route('getPositions'), getAccountBalance = route('getAccountBalance'), getOpenOrders = route('getOpenOrders'),
  getStopOrders = route('getStopOrders'), getOrder = route('getOrder'), placeOrder = route('placeOrder'), cancelOrder = route('cancelOrder'), getClosedTrades = route('getClosedTrades');
async function accountType() { return (await isUta()) ? 'uta' : 'classic'; }

module.exports = {
  getInstruments, getTickers, getKlines, getKlineHistory, getFundingRate, getFundingHistory, getOpenInterest, getOpenInterestHistory, getOrderBook,
  getAccountBalance, getPositions, getMarginMode, getClosedTrades, ping, getOpenOrders, getStopOrders, getOrder, placeOrder, cancelOrder, setTradingStop, rawStops, getPositionMode, verify,
  explain, accountType, _internals: { sign, queryString, mapOrder, mapTicker, floorTo, tickOf, stepOf, BitgetError, resetCache: () => { detail = { at: 0, map: new Map(), raw: [] }; lastCall = 0; modeCache = { at: 0, uta: null }; } },
};
