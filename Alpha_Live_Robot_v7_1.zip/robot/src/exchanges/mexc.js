'use strict';

/**
 * MEXC USDT-M futures adapter (official contract API, https://contract.mexc.com).
 * Output is normalised to the same Bybit-shaped objects the rest of the robot consumes, so strategies,
 * scanner, risk and dashboard need no changes. Internal symbols are BTCUSDT; MEXC's BTC_USDT only
 * exists at this boundary (toMexc / fromMexc).
 *
 * IMPORTANT LIMITS (verified against the official docs, see LIVE_MEXC.md):
 *  - MEXC enables futures ORDER placement via API for some accounts only (contract/detail has apiAllowed per
 *    contract; the docs mark submit/cancel endpoints as restricted). This adapter uses ONLY the official signed
 *    endpoints. It never uses browser-session ("WEB") tokens or any bypass. If MEXC refuses, placeOrder throws
 *    and the robot stays safe.
 *  - POST requests (orders) are NEVER auto-retried: a timeout is an AMBIGUOUS outcome (err.ambiguous = true)
 *    and the caller must reconcile by clientOrderId before doing anything else.
 *  - No futures WebSocket yet: the feed falls back to REST polling (WS support is a documented TODO).
 */
const crypto = require('node:crypto');
const config = require('../config');
const logger = require('../utils/logger');

const TIMEOUT_MS = 15000;
const RETRIES = 3;
const DETAIL_TTL_MS = 5 * 60 * 1000;   // contract/detail is limited to 1 call / 5 s
const MIN_GAP_MS = 110;                // ~9 req/s, well under the 20 req / 2 s limit

const INTERVALS = { '1': 'Min1', '5': 'Min5', '15': 'Min15', '30': 'Min30', '60': 'Min60', '240': 'Hour4', '480': 'Hour8', D: 'Day1', W: 'Week1', M: 'Month1' };
const MINUTES = { '1': 1, '5': 5, '15': 15, '30': 30, '60': 60, '240': 240, '480': 480, D: 1440, W: 10080, M: 43200 };

const toMexc = (s) => { const b = String(s).toUpperCase().replace(/_?USDT$/, ''); return `${b}_USDT`; };
const fromMexc = (s) => String(s).replace('_', '');
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };

class MexcError extends Error {
  constructor(message, { code = null, status = null, ambiguous = false, path = '' } = {}) {
    super(message); this.name = 'MexcError'; this.code = code; this.status = status; this.ambiguous = ambiguous; this.path = path;
  }
}

let lastCall = 0;
async function throttle() {
  const wait = lastCall + MIN_GAP_MS - Date.now();
  lastCall = Math.max(Date.now(), lastCall + MIN_GAP_MS);
  if (wait > 0) await sleep(wait);
}

/** accessKey + reqTime + paramString -> hex HMAC-SHA256. GET/DELETE: params sorted, values URL-encoded; POST: exact JSON body. */
function paramString(method, params) {
  if (method === 'POST') return params && Object.keys(params).length || Array.isArray(params) ? JSON.stringify(params) : '';
  const keys = Object.keys(params || {}).filter(k => params[k] !== undefined && params[k] !== null).sort();
  return keys.map(k => `${k}=${encodeURIComponent(String(params[k])).replace(/\+/g, '%20')}`).join('&');
}
function sign(secret, accessKey, reqTime, pstr) {
  return crypto.createHmac('sha256', secret).update(`${accessKey}${reqTime}${pstr}`).digest('hex');
}

async function request(method, path, params = {}, { auth = false, retries } = {}) {
  const maxTries = retries ?? (method === 'GET' ? RETRIES : 1);   // never auto-retry writes
  for (let attempt = 1; attempt <= maxTries; attempt++) {
    try {
      await throttle();
      const { apiKey, apiSecret, baseUrl } = config.mexc;
      if (/\/\/(api|www)\.mexc\.com/i.test(baseUrl)) throw new MexcError(`MEXC_BASE_URL (${baseUrl}) is the SPOT host. Futures REST lives only on https://contract.mexc.com - remove the MEXC_BASE_URL line from .env`, { code: 'WRONG_HOST', path });
      const headers = { 'Content-Type': 'application/json' };
      let url = `${baseUrl}${path}`;
      const pstr = paramString(method, params);
      if (auth) {
        if (!apiKey || !apiSecret) throw new MexcError('MEXC credentials missing (MEXC_API_KEY / MEXC_API_SECRET)', { path });
        const reqTime = String(Date.now());
        headers.ApiKey = apiKey; headers['Request-Time'] = reqTime; headers.Signature = sign(apiSecret, apiKey, reqTime, pstr);
      }
      const opts = { method, headers, signal: AbortSignal.timeout(TIMEOUT_MS) };
      if (method === 'POST') opts.body = pstr || '{}';
      else if (pstr) url += `?${pstr}`;

      let res;
      try { res = await fetch(url, opts); }
      catch (e) { throw new MexcError(`network/timeout on ${method} ${path}: ${e.message}`, { path, ambiguous: method !== 'GET' }); }
      let body = null;
      try { body = await res.json(); } catch (_) { /* non-JSON */ }
      if (!res.ok) {
        const detail = body && (body.message || body.msg) ? ` - MEXC says: ${String(body.message || body.msg).slice(0, 160)}` : '';
        throw new MexcError(`HTTP ${res.status}${body?.code != null ? ` (code ${body.code})` : ''} on ${method} ${path}${detail}`, { status: res.status, path, code: body?.code ?? null, ambiguous: method !== 'GET' && res.status >= 500 });
      }
      if (body && body.success === false) throw new MexcError(`MEXC error ${body.code}: ${body.message || 'unknown'} (${path})`, { code: body.code, path });
      return body && 'data' in body ? body.data : body;
    } catch (err) {
      const retryable = method === 'GET' && attempt < maxTries && (err.code === 510 || err.code === 501 || err.status >= 500 || /network|timeout/.test(err.message));
      if (!retryable) { logger.warn(`MEXC ${method} ${path} failed: ${err.message}`); throw err; }
      await sleep(500 * 2 ** (attempt - 1));
    }
  }
}
const pub = (path, params) => request('GET', path, params);
const priv = (method, path, params) => request(method, path, params, { auth: true });

// ── contract cache (contract size drives every qty conversion) ───────────────────────────────────────
let detail = { at: 0, map: new Map(), raw: [] };
async function loadDetail(force = false) {
  if (!force && detail.map.size && Date.now() - detail.at < DETAIL_TTL_MS) return detail;
  const list = await pub('/api/v1/contract/detail');
  const map = new Map();
  for (const c of Array.isArray(list) ? list : []) map.set(c.symbol, c);
  if (map.size) detail = { at: Date.now(), map, raw: list };
  return detail;
}
async function contractOf(mexcSymbol) {
  const d = await loadDetail();
  const c = d.map.get(mexcSymbol);
  if (!c) throw new MexcError(`unknown MEXC contract ${mexcSymbol}`);
  return c;
}

async function getInstruments() {
  const d = await loadDetail();
  return d.raw
    .filter(c => c.quoteCoin === 'USDT' && c.settleCoin === 'USDT' && c.state === 0 && !c.isHidden)
    .map(c => {
      const cs = num(c.contractSize) || 1;
      return {
        symbol: fromMexc(c.symbol), baseCoin: c.baseCoin, quoteCoin: 'USDT', contractType: 'LinearPerpetual', status: 'Trading',
        lotSizeFilter: { minOrderQty: String(num(c.minVol) * cs), maxOrderQty: String(num(c.maxVol) * cs), qtyStep: String(num(c.volUnit || 1) * cs), minNotionalValue: '0.01' },
        priceFilter: { tickSize: String(c.priceUnit) },
        leverageFilter: { maxLeverage: String(c.maxLeverage) },
        contractSize: cs, apiAllowed: c.apiAllowed === true,
        takerFeeRate: num(c.takerFeeRate), makerFeeRate: num(c.makerFeeRate), maintenanceMarginRate: num(c.maintenanceMarginRate),
      };
    });
}

function mapTicker(t, cs) {
  return {
    symbol: fromMexc(t.symbol), lastPrice: String(t.lastPrice), markPrice: String(t.fairPrice ?? t.lastPrice), indexPrice: String(t.indexPrice ?? t.lastPrice),
    bid1Price: String(t.bid1), ask1Price: String(t.ask1),
    turnover24h: String(num(t.amount24)), volume24h: String(num(t.volume24) * cs),
    price24hPcnt: String(num(t.riseFallRate)), fundingRate: String(num(t.fundingRate)),
    openInterest: String(num(t.holdVol) * cs), openInterestValue: String(num(t.holdVol) * cs * num(t.lastPrice)),
    highPrice24h: String(num(t.high24Price)), lowPrice24h: String(num(t.lower24Price)),
  };
}
async function getTickers(symbol) {
  const d = await loadDetail();
  const data = await pub('/api/v1/contract/ticker', symbol ? { symbol: toMexc(symbol) } : {});
  const arr = Array.isArray(data) ? data : data ? [data] : [];
  return arr.filter(t => String(t.symbol).endsWith('_USDT')).map(t => mapTicker(t, num(d.map.get(t.symbol)?.contractSize) || 1));
}

const toCandles = (data, cs) => {
  const t = data?.time || [];
  return t.map((_, i) => ({
    time: t[i] * 1000, open: num(data.open[i]), high: num(data.high[i]), low: num(data.low[i]), close: num(data.close[i]),
    volume: num(data.vol[i]) * cs, turnover: num(data.amount?.[i]),
  }));
};
async function getKlines(symbol, interval, limit = 200, start, end) {
  const iv = INTERVALS[String(interval)]; if (!iv) throw new MexcError(`unsupported interval ${interval}`);
  const ms = symbol && toMexc(symbol); const c = await contractOf(ms);
  const endSec = end ? Math.floor(end / 1000) : Math.floor(Date.now() / 1000);
  const startSec = start ? Math.floor(start / 1000) : endSec - limit * MINUTES[String(interval)] * 60;
  const data = await pub(`/api/v1/contract/kline/${ms}`, { interval: iv, start: startSec, end: endSec });
  return toCandles(data, num(c.contractSize) || 1).slice(-limit);
}
async function getKlineHistory(symbol, interval, maxCandles = 1000) {
  const iv = INTERVALS[String(interval)]; if (!iv) throw new MexcError(`unsupported interval ${interval}`);
  const ms = toMexc(symbol); const c = await contractOf(ms); const cs = num(c.contractSize) || 1;
  const step = MINUTES[String(interval)] * 60;
  let endSec = Math.floor(Date.now() / 1000); let all = [];
  while (all.length < maxCandles) {
    const win = Math.min(2000, maxCandles - all.length + 5);
    let data; try { data = await pub(`/api/v1/contract/kline/${ms}`, { interval: iv, start: endSec - win * step, end: endSec }); } catch (_) { break; }
    const candles = toCandles(data, cs); if (!candles.length) break;
    all = [...candles, ...all]; endSec = Math.floor(candles[0].time / 1000) - 1;
    if (candles.length < win - 5) break;
  }
  const seen = new Set();
  return all.filter(k => !seen.has(k.time) && seen.add(k.time)).sort((a, b) => a.time - b.time).slice(-maxCandles);
}

async function getFundingRate(symbol) {
  const d = await pub(`/api/v1/contract/funding_rate/${toMexc(symbol)}`);
  return d ? { symbol, fundingRate: num(d.fundingRate), fundingTime: d.nextSettleTime || d.timestamp } : null;
}
async function getFundingHistory(symbol, limit = 8) {
  const d = await pub('/api/v1/contract/funding_rate/history', { symbol: toMexc(symbol), page_num: 1, page_size: limit });
  return (d?.resultList || []).map(r => ({ fundingRate: String(r.fundingRate), fundingRateTimestamp: String(r.settleTime) }));
}
/** MEXC exposes only the current open interest (ticker holdVol); no OI history endpoint exists. */
async function getOpenInterest(symbol) {
  const t = (await getTickers(symbol))[0];
  return t ? { symbol, openInterest: num(t.openInterest), time: Date.now() } : null;
}
async function getOpenInterestHistory() { return []; }

async function getOrderBook(symbol, limit = 50) {
  const ms = toMexc(symbol); const c = await contractOf(ms); const cs = num(c.contractSize) || 1;
  const raw = await pub(`/api/v1/contract/depth/${ms}`, { limit });
  const r = raw?.asks ? raw : raw?.data || {};
  const lv = (a) => (a || []).map(([p, v]) => [String(p), String(num(v) * cs)]);
  return { symbol, ts: r.timestamp || Date.now(), bids: lv(r.bids), asks: lv(r.asks) };
}

// ── private ──────────────────────────────────────────────────────────────────────────────────────────
async function getAccountBalance() {
  const a = await priv('GET', '/api/v1/private/account/asset/USDT');
  return { currency: 'USDT', equity: num(a.equity), available: num(a.availableBalance), margin: num(a.positionMargin), unrealized: num(a.unrealized), raw: a };
}
async function getPositions() {
  const d = await loadDetail();
  const list = await priv('GET', '/api/v1/private/position/open_positions', {});
  return (list || []).filter(p => num(p.holdVol) > 0).map(p => {
    const cs = num(d.map.get(p.symbol)?.contractSize) || 1;
    return { positionId: p.positionId, symbol: fromMexc(p.symbol), side: p.positionType === 1 ? 'LONG' : 'SHORT', qty: num(p.holdVol) * cs, vol: num(p.holdVol),
      entry: num(p.holdAvgPrice), liquidationPrice: num(p.liquidatePrice), leverage: num(p.leverage), margin: num(p.im), realised: num(p.realised), isolated: p.openType === 1 };
  });
}

const STATE = { 1: 'Created', 2: 'New', 3: 'Filled', 4: 'Cancelled', 5: 'Rejected' };
function mapOrder(o, cs = 1) {
  const filled = num(o.dealVol) * cs;
  let status = STATE[o.state] || 'Unknown';
  if (o.state === 2 && filled > 0) status = 'PartiallyFilled';
  return { orderId: String(o.orderId), clientOrderId: o.externalOid || null, symbol: fromMexc(o.symbol), status,
    side: o.side === 1 || o.side === 4 ? 'Buy' : 'Sell', reduceOnly: o.side === 2 || o.side === 4,
    price: num(o.price), qty: num(o.vol) * cs, filledQty: filled, avgPrice: num(o.dealAvgPrice),
    fee: num(o.takerFee) + num(o.makerFee), stopLoss: num(o.stopLossPrice) || null, takeProfit: num(o.takeProfitPrice) || null, errorCode: o.errorCode || 0, raw: o };
}
async function getOpenOrders(symbol) {
  const d = await loadDetail();
  const path = symbol ? `/api/v1/private/order/list/open_orders/${toMexc(symbol)}` : '/api/v1/private/order/list/open_orders';
  const list = await priv('GET', path, { page_num: 1, page_size: 100 });
  return (list || []).map(o => mapOrder(o, num(d.map.get(o.symbol)?.contractSize) || 1));
}
/** Exchange-side TP/SL (plan) orders that are still active - used to VERIFY a position is protected. */
async function getStopOrders(symbol) {
  const list = await priv('GET', '/api/v1/private/stoporder/open_orders', symbol ? { symbol: toMexc(symbol) } : {});
  return (list || []).filter(s => s.isFinished !== 1).map(s => ({ id: String(s.id), symbol: fromMexc(s.symbol), positionId: s.positionId,
    stopLoss: num(s.stopLossPrice) || null, takeProfit: num(s.takeProfitPrice) || null, long: s.positionType === 1 }));
}
async function getOrder(symbol, { orderId, clientOrderId } = {}) {
  const ms = toMexc(symbol); const c = await contractOf(ms);
  const o = clientOrderId
    ? await priv('GET', `/api/v1/private/order/external/${ms}/${encodeURIComponent(clientOrderId)}`, {})
    : await priv('GET', `/api/v1/private/order/get/${orderId}`, {});
  return o ? mapOrder(o, num(c.contractSize) || 1) : null;
}

/**
 * Place an order. qty is in BASE units (same as the rest of the robot) and is floored to whole contracts.
 * params: { symbol, side:'Buy'|'Sell', qty, orderType:'Limit'|'Market', price, leverage, reduceOnly, clientOrderId, stopLoss, takeProfit }
 * Isolated margin. Throws MexcError; err.ambiguous === true means the outcome is UNKNOWN -> reconcile by clientOrderId.
 */
async function placeOrder(p) {
  if (!p || !p.symbol || !p.side || !(p.qty > 0)) throw new MexcError('placeOrder: symbol, side and qty are required');
  const ms = toMexc(p.symbol); const c = await contractOf(ms);
  if (c.apiAllowed === false) throw new MexcError(`MEXC reports apiAllowed=false for ${ms}: API order placement is not enabled for this contract/account`, { code: 'API_NOT_ALLOWED' });
  const cs = num(c.contractSize) || 1; const unit = num(c.volUnit) || 1;
  const vol = Math.floor(p.qty / cs / unit + 1e-9) * unit;
  if (vol < num(c.minVol)) throw new MexcError(`qty below MEXC minimum (${num(c.minVol)} contracts)`, { code: 'BELOW_MIN' });
  const open = !p.reduceOnly; const buy = p.side === 'Buy';
  const side = open ? (buy ? 1 : 3) : (buy ? 2 : 4);   // 1 open long, 3 open short, 2 close short, 4 close long
  const body = { symbol: ms, vol, side, type: p.orderType === 'Market' ? 5 : 1, openType: 1, leverage: Math.round(p.leverage || 1) };
  if (body.type === 1) body.price = p.price;
  if (p.clientOrderId) { if (p.clientOrderId.length > 32) throw new MexcError('clientOrderId max 32 chars'); body.externalOid = p.clientOrderId; }
  if (open && p.stopLoss) body.stopLossPrice = p.stopLoss;
  if (open && p.takeProfit) body.takeProfitPrice = p.takeProfit;
  const data = await priv('POST', '/api/v1/private/order/submit', body);
  const orderId = String(data?.orderId ?? data ?? '');
  logger.live(`MEXC order sent: ${p.side} ${p.symbol} vol=${vol} (${p.qty} base requested) ${p.orderType || 'Limit'} id=${orderId} coid=${p.clientOrderId || '-'}`);
  return { orderId, clientOrderId: p.clientOrderId || null, vol, qty: vol * cs };
}
async function cancelOrder(symbol, orderId) {
  return priv('POST', '/api/v1/private/order/cancel', [Number(orderId)]);
}
/** Every MEXC order is sent with openType=1 (isolated), so the mode is isolated by construction. */
async function getMarginMode() { return 'ISOLATED_MARGIN'; }

/** Closed positions (realised PnL) for live stats: [{ symbol, pnl, closedAt }] newest first. */
async function getClosedTrades(limit = 50) {
  const d = await loadDetail();
  const list = await priv('GET', '/api/v1/private/position/list/history_positions', { page_num: 1, page_size: Math.min(100, limit) });
  return (list || []).filter(p => p.state === 3).map(p => {
    const cs = num(d.map.get(p.symbol)?.contractSize) || 1;
    return { symbol: fromMexc(p.symbol), direction: p.positionType === 1 ? 'LONG' : 'SHORT', qty: num(p.closeVol || p.holdVol) * cs,
      entry: num(p.openAvgPrice || p.holdAvgPrice), exit: num(p.closeAvgPrice), pnl: num(p.realised), fee: num(p.totalFee ?? p.fee),
      openedAt: Number(p.createTime) || null, closedAt: Number(p.updateTime) || Date.now(), orderId: p.positionId };
  });
}
async function ping() {
  const t0 = Date.now();
  const t = await pub('/api/v1/contract/ping'); const t1 = Date.now();
  const serverTime = Number(t) || t1;
  return { latencyMs: t1 - t0, serverTime, driftMs: Math.abs(t1 - serverTime) };
}

/** Plain-English next step for an auth/permission failure (never includes credentials). */
function explain(err) {
  const c = err && err.code; const st = err && err.status;
  if (c === 'WRONG_HOST') return 'Remove MEXC_BASE_URL from .env (default https://contract.mexc.com is the futures host; api.mexc.com is SPOT only).';
  if (c === 406) return 'IP not in the key\'s whitelist. Codespaces IPs change: either remove the IP restriction on the key (keep withdrawals OFF) or whitelist the current IP.';
  if (c === 402) return 'API key expired: create a new one.';
  if (c === 602) return 'Signature rejected: key/secret mismatch (re-copy the secret exactly, no spaces/quotes) or the key was created for another product.';
  if (c === 513) return 'Clock/time-window problem: check clock drift above.';
  if (c === 701 || c === 703 || c === 702 || c === 704) return 'Key lacks a Futures permission: edit the key on MEXC and tick Futures read (and trade, for live).';
  if (c === 510 || c === 501) return 'Rate limited / busy: wait a minute and retry.';
  if (c === 1005 || st === 401 || c === 401) return 'MEXC rejected the key for futures (1005/401). Most common causes: the key has no FUTURES permission (spot-only key), futures trading was never activated on the account, an IP whitelist excludes this Codespace, or MEXC restricts API access for the account/region. Check the key on MEXC > API Management; create a key with Futures read enabled and NO IP restriction first, then retry.';
  if (/network|timeout/i.test(err && err.message)) return 'Network problem from this machine to MEXC.';
  return 'See the MEXC error code table in the contract API docs.';
}

/** Read-only checks for `npm run mexc:verify`: never places an order. */
async function verify() {
  const out = { checks: [] };
  const add = (name, ok, detail) => out.checks.push({ name, ok, detail });
  try { const t = await pub('/api/v1/contract/ping'); const drift = Math.abs(Date.now() - Number(t)); add('public API + clock', drift < 5000, `clock drift ${drift} ms (limit 10 000)`); }
  catch (e) { add('public API + clock', false, e.message); }
  try { const ins = await getInstruments(); const allowed = ins.filter(i => i.apiAllowed).length; add('contracts', ins.length > 0, `${ins.length} USDT perps, apiAllowed=true on ${allowed}`); out.apiAllowedCount = allowed; }
  catch (e) { add('contracts', false, e.message); }
  add('REST host', !/\/\/(api|www)\.mexc\.com/i.test(config.mexc.baseUrl), config.mexc.baseUrl);
  if (!config.mexc.apiKey || !config.mexc.apiSecret) { add('credentials', false, 'MEXC_API_KEY / MEXC_API_SECRET not set'); return out; }
  try { const b = await getAccountBalance(); add('account read', true, `equity ${b.equity} USDT, available ${b.available}`); out.balance = b; }
  catch (e) { add('account read', false, `${e.message}  -> ${explain(e)}`); }
  try { await getPositions(); await getOpenOrders(); add('positions/orders read', true, 'ok'); } catch (e) { add('positions/orders read', false, `${e.message}  -> ${explain(e)}`); }
  add('order placement', null, 'NOT TESTED (no order is ever sent by verify). Real permission is only proven by the first live order; see LIVE_MEXC.md');
  return out;
}

/** Synchronous contract-size lookup from the cached contract/detail (1 until the cache is warm). Used by the WS stream. */
function contractSizeSync(symbol) { const c = detail.map.get(toMexc(symbol)); return (c && num(c.contractSize)) || 1; }

/** MEXC cannot move exchange-side stops yet: fail loudly so the live trailing stop reports it and the ORIGINAL exchange stop stays in force. */
async function setTradingStop() { throw new Error('MEXC adapter cannot move exchange stop orders yet; the original exchange stop-loss stays in force'); }

module.exports = {
  setTradingStop, contractSizeSync, getInstruments, getTickers, getKlines, getKlineHistory, getFundingRate, getFundingHistory, getOpenInterest, getOpenInterestHistory, getOrderBook,
  getAccountBalance, getPositions, getMarginMode, getClosedTrades, ping, getOpenOrders, getStopOrders, getOrder, placeOrder, cancelOrder, verify,
  // exported for tests
  explain, _internals: { toMexc, fromMexc, sign, paramString, MexcError, mapOrder, resetCache: () => { detail = { at: 0, map: new Map(), raw: [] }; lastCall = 0; } },
};
