'use strict';

/**
 * Bitget UNIFIED TRADING ACCOUNT (UTA) private/trading layer: /api/v3, category=USDT-FUTURES.
 * Public market data stays on the v2 public endpoints (identical for both account types), see bitget.js.
 * Endpoint/field names follow Bitget's UTA docs (order management, positions, account assets/settings) and the v2->v3 upgrade guide:
 *   one-way mode: open long = side buy; close long = side sell + reduceOnly yes; hedge mode needs posSide (REFUSED here);
 *   place-order accepts marginMode isolated|crossed (default crossed -> we always send isolated), takeProfit/stopLoss presets,
 *   clientOid must match ^[.A-Za-z0-9:/_-]{1,32}$.
 * Response shapes are parsed DEFENSIVELY (several candidate field names). NOT verified against a live UTA account by the author:
 * `npm run bitget:verify` shows what your account returns; start with the smallest size.
 */
const CAT = 'USDT-FUTURES';
const COID = /^[.A-Za-z0-9:/_-]{1,32}$/;
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };
const rows = (d) => (Array.isArray(d) ? d : Array.isArray(d && d.list) ? d.list : Array.isArray(d && d.entrustedList) ? d.entrustedList : d && typeof d === 'object' && d.orderId ? [d] : []);

function create({ priv, contractOf, stepOf, tickOf, floorTo, fmt, BitgetError, logger }) {
  const STATUS = { live: 'New', new: 'New', partially_filled: 'PartiallyFilled', filled: 'Filled', cancelled: 'Cancelled', canceled: 'Cancelled' };

  async function getPositionMode() {
    const s = await priv('GET', '/api/v3/account/settings', {});
    const raw = String(s && (s.holdMode ?? s.posMode ?? s.positionMode ?? s.hold_mode) || '').toLowerCase();
    const posMode = !raw ? null : raw.includes('hedge') ? 'hedge_mode' : (raw.includes('one') || raw.includes('net')) ? 'one_way_mode' : raw;
    return { posMode, raw: s };
  }
  async function getPositions() {
    const d = await priv('GET', '/api/v3/position/current-position', { category: CAT });
    return rows(d).filter(p => num(p.total ?? p.size ?? p.qty) > 0).map((p) => {
      const ps = String(p.posSide || p.positionSide || p.side || '').toLowerCase();
      const avg = num(p.avgPrice), mark = num(p.markPrice), pnl = num(p.unrealisedPnl);
      let side = ps === 'long' || ps === 'buy' ? 'LONG' : ps === 'short' || ps === 'sell' ? 'SHORT' : null;
      if (!side && avg && mark && pnl) side = (mark - avg) * pnl > 0 ? 'LONG' : 'SHORT';   // last resort: infer from the sign of unrealised PnL
      return { positionId: `${p.symbol}:${side || 'net'}`, symbol: p.symbol, side: side || 'LONG', sideUnknown: !side, qty: num(p.total ?? p.size ?? p.qty), vol: num(p.total ?? p.size ?? p.qty),
        entry: avg, liquidationPrice: num(p.liqPrice ?? p.liquidationPrice), leverage: num(p.leverage), margin: num(p.positionBalance ?? p.margin), realised: num(p.curRealisedPnl ?? p.cumRealisedPnl), unrealized: pnl, isolated: String(p.marginMode || 'isolated') === 'isolated' };
    });
  }
  async function getAccountBalance() {
    const a = await priv('GET', '/api/v3/account/assets', {});
    if (!a) throw new BitgetError('Bitget returned no UTA account assets');
    const usdt = (Array.isArray(a.assets) ? a.assets : []).find(x => (x.coin || x.asset) === 'USDT') || {};
    let margin = 0; try { margin = (await getPositions()).reduce((s, p) => s + p.margin, 0); } catch (_) { /* leave 0 */ }
    const equity = num(a.accountEquity || a.usdtEquity || usdt.equity);
    const available = usdt.available !== undefined ? num(usdt.available) : Math.max(0, num(a.effEquity || equity) - margin);
    return { currency: 'USDT', equity, available, margin, unrealized: num(a.usdtUnrealisedPnl ?? a.unrealisedPnl), raw: a };
  }
  function mapOrder(o) {
    return { orderId: String(o.orderId), clientOrderId: o.clientOid || null, symbol: o.symbol, status: STATUS[String(o.orderStatus || o.status || '').toLowerCase()] || 'Unknown',
      side: String(o.side).toLowerCase() === 'buy' ? 'Buy' : 'Sell', reduceOnly: String(o.reduceOnly).toLowerCase() === 'yes',
      price: num(o.price), qty: num(o.qty), filledQty: num(o.cumExecQty ?? o.baseVolume), avgPrice: num(o.avgPrice ?? o.priceAvg), fee: Math.abs(num(o.fee ?? o.totalFee)),
      stopLoss: num(o.stopLoss) || null, takeProfit: num(o.takeProfit) || null, errorCode: 0, raw: o };
  }
  async function getOpenOrders(symbol) { return rows(await priv('GET', '/api/v3/trade/unfilled-orders', { category: CAT, symbol })).map(mapOrder); }
  async function getOrder(symbol, { orderId, clientOrderId } = {}) {
    const d = await priv('GET', '/api/v3/trade/order-info', { category: CAT, symbol, orderId, clientOid: orderId ? undefined : clientOrderId });
    const r = rows(d)[0] || (d && d.orderId ? d : null); return r ? mapOrder(r) : null;
  }
  let warnedStops = false;
  const protectsLong = (s) => { const ps = String(s.posSide || s.holdSide || '').toLowerCase(); return ps === 'long' ? true : ps === 'short' ? false : String(s.side || '').toLowerCase() === 'sell'; };
  /** Raw open TP/SL strategy orders (type=tpsl). Only pending ones count. */
  async function rawStops(symbol) {
    const list = rows(await priv('GET', '/api/v3/trade/unfilled-strategy-orders', { category: CAT, symbol, type: 'tpsl' }));
    return list.filter(s => !s.status || /pending|live|submitting/i.test(String(s.status)));
  }
  /** Exchange-side TP/SL orders, grouped per symbol + direction. A shape the parser cannot read returns [] and is logged once (the robot then treats the position as UNPROTECTED and reacts). */
  async function getStopOrders(symbol) {
    let list = [];
    try { list = await rawStops(symbol); }
    catch (e) { if (!warnedStops) { warnedStops = true; logger.warn(`Bitget UTA: could not read TP/SL strategy orders (${e.message}); positions will be reported as unprotected until this works. Run: npm run bitget:stops`); } return []; }
    const grouped = new Map();
    for (const s of list) {
      const long = protectsLong(s); const key = `${s.symbol}:${long ? 'long' : 'short'}`;
      const cur = grouped.get(key) || { id: String(s.orderId || s.strategyId || key), symbol: s.symbol, positionId: key, stopLoss: null, takeProfit: null, long, slOrderId: null, tpOrderId: null };
      if (num(s.stopLoss)) { cur.stopLoss = num(s.stopLoss); cur.slOrderId = String(s.orderId); }
      if (num(s.takeProfit)) { cur.takeProfit = num(s.takeProfit); cur.tpOrderId = String(s.orderId); }
      const kind = String(s.strategyType || s.planType || s.type || '').toLowerCase(); const trig = num(s.triggerPrice) || null;
      if (trig && !num(s.stopLoss) && !num(s.takeProfit)) { if (/loss|(^|_)sl/.test(kind)) { cur.stopLoss = trig; cur.slOrderId = String(s.orderId); } else if (/profit|(^|_)tp/.test(kind)) { cur.takeProfit = trig; cur.tpOrderId = String(s.orderId); } }
      grouped.set(key, cur);
    }
    return [...grouped.values()];
  }
  /** Move the stop-loss / take-profit of an open position: modify the existing tpsl strategy order, else place a full-position one. */
  async function setTradingStop({ symbol, stopLoss, takeProfit }) {
    const c = await contractOf(symbol); const tick = tickOf(c);
    const pos = (await getPositions()).find(p => p.symbol === symbol);
    if (!pos) throw new BitgetError(`no open Bitget position for ${symbol}`);
    const cur = (await getStopOrders(symbol)).find(x => x.long === (pos.side === 'LONG'));
    const existing = cur && (cur.slOrderId || cur.tpOrderId);
    if (existing) {
      const body = { category: CAT, orderId: String(existing) };
      if (stopLoss) { body.stopLoss = fmt(stopLoss, tick); body.slTriggerBy = 'mark'; body.slOrderType = 'market'; }
      if (takeProfit) { body.takeProfit = fmt(takeProfit, tick); body.tpTriggerBy = 'mark'; body.tpOrderType = 'market'; }
      return priv('POST', '/api/v3/trade/modify-strategy-order', body);
    }
    const body = { category: CAT, symbol, type: 'tpsl', tpslMode: 'full' };
    if (stopLoss) { body.stopLoss = fmt(stopLoss, tick); body.slTriggerBy = 'mark'; body.slOrderType = 'market'; }
    if (takeProfit) { body.takeProfit = fmt(takeProfit, tick); body.tpTriggerBy = 'mark'; body.tpOrderType = 'market'; }
    return priv('POST', '/api/v3/trade/place-strategy-order', body);
  }
  async function placeOrder(p) {
    if (!p || !p.symbol || !p.side || !(p.qty > 0)) throw new BitgetError('placeOrder: symbol, side and qty are required');
    const c = await contractOf(p.symbol); const step = stepOf(c); const tick = tickOf(c);
    const size = floorTo(p.qty, step);
    if (size < num(c.minTradeNum)) throw new BitgetError(`qty below Bitget minimum (${num(c.minTradeNum)})`, { code: 'BELOW_MIN' });
    const { posMode, raw } = await getPositionMode();
    if (posMode !== 'one_way_mode') throw new BitgetError(posMode ? `Bitget UTA account is in ${posMode}; this robot needs one-way mode (switch it in Bitget futures preferences with no open positions, then retry)` : `Cannot confirm one-way position mode from /account/settings (fields seen: ${Object.keys(raw || {}).join(', ') || 'none'}); refusing to trade`, { code: 'HOLD_MODE' });
    if (p.clientOrderId && !COID.test(p.clientOrderId)) throw new BitgetError('clientOid must match ^[.A-Za-z0-9:/_-]{1,32}$');
    if (!p.reduceOnly && p.leverage) await priv('POST', '/api/v3/account/set-leverage', { category: CAT, symbol: p.symbol, leverage: String(Math.round(p.leverage)) });
    const body = { category: CAT, symbol: p.symbol, qty: fmt(size, step), side: p.side === 'Buy' ? 'buy' : 'sell', orderType: p.orderType === 'Market' ? 'market' : 'limit', timeInForce: 'gtc', reduceOnly: p.reduceOnly ? 'yes' : 'no', marginMode: 'isolated' };
    if (body.orderType === 'limit') body.price = fmt(p.price, tick);
    if (p.clientOrderId) body.clientOid = p.clientOrderId;
    if (!p.reduceOnly && p.stopLoss) { body.stopLoss = fmt(p.stopLoss, tick); body.slTriggerBy = 'mark'; body.slOrderType = 'market'; }
    if (!p.reduceOnly && p.takeProfit) { body.takeProfit = fmt(p.takeProfit, tick); body.tpTriggerBy = 'mark'; body.tpOrderType = 'market'; }
    const data = await priv('POST', '/api/v3/trade/place-order', body);
    const orderId = String((data && data.orderId) ?? '');
    logger.live(`Bitget UTA order sent: ${p.side} ${p.symbol} qty=${body.qty} ${body.orderType} id=${orderId} coid=${p.clientOrderId || '-'}`);
    return { orderId, clientOrderId: p.clientOrderId || null, vol: size, qty: size };
  }
  async function cancelOrder(symbol, orderId) { return priv('POST', '/api/v3/trade/cancel-order', { category: CAT, symbol, orderId: String(orderId) }); }
  async function getClosedTrades(limit = 50) {
    const d = await priv('GET', '/api/v3/position/history-position', { category: CAT, limit: Math.min(100, limit) });
    return rows(d).map(p => ({ symbol: p.symbol, direction: String(p.posSide || '').toLowerCase() === 'short' ? 'SHORT' : 'LONG', qty: num(p.closeTotalPos ?? p.closeQty ?? p.openTotalPos),
      entry: num(p.openAvgPrice ?? p.avgPrice), exit: num(p.closeAvgPrice), pnl: num(p.netProfit ?? p.pnl ?? p.realisedPnl), fee: Math.abs(num(p.openFee)) + Math.abs(num(p.closeFee)),
      openedAt: Number(p.createdTime ?? p.ctime) || null, closedAt: Number(p.updatedTime ?? p.utime) || Date.now(), orderId: p.positionId }));
  }
  return { setTradingStop, rawStops, getPositionMode, getPositions, getAccountBalance, getOpenOrders, getStopOrders, getOrder, placeOrder, cancelOrder, getClosedTrades, mapOrder };
}
module.exports = { create };
