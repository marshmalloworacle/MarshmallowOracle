'use strict';

const config = require('../config');
const logger = require('../utils/logger');

const BASE_URL = config.bybit.baseUrl;
const DEFAULT_TIMEOUT = 15000;
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ── Connectivity guard ──────────────────────────────────────────────────────────────────────────
// HTTP 403/451 from Bybit means the server's IP or country is blocked (very common for cloud/datacenter IPs).
// Retrying cannot fix that, so fail at once, remember it, and short-circuit for a while instead of flooding the log.
const BLOCK_CODES = new Set([403, 451]);
const BLOCK_COOLDOWN_MS = 30000;
const conn = { blocked: false, since: null, lastError: null, lastOkAt: null, host: BASE_URL };
class RegionBlockedError extends Error {
  constructor(status) {
    super(`Bybit refused this server (HTTP ${status}) on ${BASE_URL}. The IP/region is blocked. Run the robot from an allowed region (e.g. a VPS in Singapore/Europe or your own PC) or set BYBIT_BASE_URL.`);
    this.name = 'RegionBlockedError'; this.status = status; this.regionBlocked = true;
  }
}
function connectivity() { return { ...conn, cooldownMs: BLOCK_COOLDOWN_MS }; }
function noteOk() { conn.blocked = false; conn.lastOkAt = Date.now(); conn.lastError = null; }
function noteBlocked(status) { if (!conn.blocked) logger.error(`Bybit BLOCKED this server (HTTP ${status}) at ${BASE_URL}: retries paused for ${BLOCK_COOLDOWN_MS / 1000}s`); conn.blocked = true; conn.since = conn.since || Date.now(); conn.lastError = `HTTP ${status}`; conn.retryAt = Date.now() + BLOCK_COOLDOWN_MS; }

async function request(method, path, params = {}, retries = MAX_RETRIES) {
  if (conn.blocked && Date.now() < conn.retryAt) throw new RegionBlockedError(conn.lastError.replace('HTTP ', ''));
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      let url = `${BASE_URL}${path}`;
      const options = {
        method,
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(DEFAULT_TIMEOUT),
      };

      if (method === 'GET') {
        const query = new URLSearchParams();
        for (const [k, v] of Object.entries(params)) {
          if (v !== undefined && v !== null) {
            query.append(k, String(v));
          }
        }
        const qs = query.toString();
        if (qs) url += `?${qs}`;
      } else {
        options.body = JSON.stringify(params);
      }

      const response = await fetch(url, options);
      if (BLOCK_CODES.has(response.status)) { noteBlocked(response.status); throw new RegionBlockedError(response.status); }
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      noteOk();

      const data = await response.json();
      const { retCode, retMsg, result } = data;
      if (retCode !== 0) {
        throw new Error(`Bybit API error ${retCode}: ${retMsg}`);
      }
      return result;
    } catch (err) {
      const isLast = attempt === retries || err.regionBlocked;
      if (isLast) {
        logger.error(`Bybit request failed: ${method} ${path}`, err.message);
        throw err;
      }
      const delay = RETRY_DELAY_MS * Math.pow(2, attempt - 1);
      logger.warn(`Bybit request retry ${attempt}/${retries} after ${delay}ms: ${err.message}`);
      await sleep(delay);
    }
  }
}

// Public API methods

/** Get all linear USDT perpetual instruments */
async function getInstruments() {
  const result = await request('GET', '/v5/market/instruments-info', {
    category: 'linear',
    status: 'Trading',
    limit: 1000,
  });
  return result.list || [];
}

/** Get tickers for linear category */
async function getTickers(symbol) {
  const params = { category: 'linear' };
  if (symbol) params.symbol = symbol;
  const result = await request('GET', '/v5/market/tickers', params);
  return result.list || [];
}

/**
 * Get OHLCV candles
 * @param {string} symbol
 * @param {string} interval  '15','60','240','D'
 * @param {number} limit     max 200
 * @param {number} start     epoch ms start (optional)
 * @param {number} end       epoch ms end (optional)
 */
async function getKlines(symbol, interval, limit = 200, start, end) {
  const params = { category: 'linear', symbol, interval, limit };
  if (start) params.start = start;
  if (end) params.end = end;
  const result = await request('GET', '/v5/market/kline', params);
  // Bybit returns newest first — reverse to chronological
  const raw = result.list || [];
  return raw.reverse().map(c => ({
    time:   parseInt(c[0], 10),
    open:   parseFloat(c[1]),
    high:   parseFloat(c[2]),
    low:    parseFloat(c[3]),
    close:  parseFloat(c[4]),
    volume: parseFloat(c[5]),
    turnover: parseFloat(c[6]),
  }));
}

/**
 * Fetch full history by paginating backwards
 * Returns chronological candles
 */
async function getKlineHistory(symbol, interval, maxCandles = 1000) {
  const limit = 200;
  let allCandles = [];
  let end = undefined;

  while (allCandles.length < maxCandles) {
    const params = { category: 'linear', symbol, interval, limit };
    if (end) params.end = end;

    let result;
    try {
      result = await request('GET', '/v5/market/kline', params);
    } catch (e) {
      break;
    }

    const raw = (result.list || []);
    if (raw.length === 0) break;

    const candles = raw.reverse().map(c => ({
      time:   parseInt(c[0], 10),
      open:   parseFloat(c[1]),
      high:   parseFloat(c[2]),
      low:    parseFloat(c[3]),
      close:  parseFloat(c[4]),
      volume: parseFloat(c[5]),
      turnover: parseFloat(c[6]),
    }));

    // Prepend — oldest first
    allCandles = [...candles, ...allCandles];

    if (raw.length < limit) break; // no more data

    // Move end window back
    end = candles[0].time - 1;
    await sleep(200); // rate limit courtesy pause
  }

  // Deduplicate by time, keep chronological order
  const seen = new Set();
  const deduped = allCandles.filter(c => {
    if (seen.has(c.time)) return false;
    seen.add(c.time);
    return true;
  });
  deduped.sort((a, b) => a.time - b.time);

  return deduped.slice(-maxCandles);
}

/** Get funding rate history */
async function getFundingRate(symbol, limit = 1) {
  const result = await request('GET', '/v5/market/funding/history', {
    category: 'linear',
    symbol,
    limit,
  });
  const list = result.list || [];
  if (list.length === 0) return null;
  return {
    symbol,
    fundingRate: parseFloat(list[0].fundingRate),
    fundingTime: parseInt(list[0].fundingRateTimestamp, 10),
  };
}

/** Get open interest */
async function getOpenInterest(symbol, intervalTime = '4h', limit = 1) {
  const result = await request('GET', '/v5/market/open-interest', {
    category: 'linear',
    symbol,
    intervalTime,
    limit,
  });
  const list = result.list || [];
  if (list.length === 0) return null;
  return {
    symbol,
    openInterest: parseFloat(list[0].openInterest),
    time: parseInt(list[0].timestamp, 10),
  };
}

/** Order book (top `limit` levels per side), normalised to { bids:[[p,s]], asks:[[p,s]], ts } */
async function getOrderBook(symbol, limit = 50) {
  const r = await request('GET', '/v5/market/orderbook', { category: 'linear', symbol, limit });
  return { symbol, ts: Number(r.ts) || Date.now(), bids: r.b || [], asks: r.a || [] };
}

/** Funding history, newest first: [{ fundingRate, fundingRateTimestamp }] */
async function getFundingHistory(symbol, limit = 8) {
  const r = await request('GET', '/v5/market/funding/history', { category: 'linear', symbol, limit });
  return r.list || [];
}

/** Open-interest history, newest first: [{ openInterest, timestamp }] */
async function getOpenInterestHistory(symbol, intervalTime = '1h', limit = 6) {
  const r = await request('GET', '/v5/market/open-interest', { category: 'linear', symbol, intervalTime, limit });
  return r.list || [];
}


// ── Private (signed) endpoints: account, positions, orders ─────────────────────────────────────────
const crypto = require('node:crypto');
const RECV = '5000';
class BybitError extends Error {
  constructor(m, { code = null, ambiguous = false } = {}) { super(m); this.name = 'BybitError'; this.code = code; this.ambiguous = ambiguous; }
}
function bybitSign(secret, ts, key, recv, payload) {
  return crypto.createHmac('sha256', secret).update(`${ts}${key}${recv}${payload}`).digest('hex');
}
/** Writes (POST) are never auto-retried; a timeout/5xx is AMBIGUOUS -> caller reconciles by orderLinkId. */
async function privateRequest(method, path, params = {}) {
  const { apiKey, apiSecret } = config.bybit;
  if (!apiKey || !apiSecret) throw new BybitError('Bybit credentials missing (BYBIT_API_KEY / BYBIT_API_SECRET)');
  const ts = String(Date.now());
  let url = `${BASE_URL}${path}`; let payload = '';
  const opts = { method, headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(DEFAULT_TIMEOUT) };
  if (method === 'GET') {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null) q.append(k, String(v));
    payload = q.toString(); if (payload) url += `?${payload}`;
  } else { payload = JSON.stringify(params); opts.body = payload; }
  opts.headers['X-BAPI-API-KEY'] = apiKey; opts.headers['X-BAPI-TIMESTAMP'] = ts; opts.headers['X-BAPI-RECV-WINDOW'] = RECV;
  opts.headers['X-BAPI-SIGN'] = bybitSign(apiSecret, ts, apiKey, RECV, payload);
  let res;
  try { res = await fetch(url, opts); }
  catch (e) { throw new BybitError(`network/timeout on ${method} ${path}: ${e.message}`, { ambiguous: method !== 'GET' }); }
  if (BLOCK_CODES.has(res.status)) { noteBlocked(res.status); throw new RegionBlockedError(res.status); }
  if (!res.ok) throw new BybitError(`HTTP ${res.status} on ${method} ${path}`, { ambiguous: method !== 'GET' && res.status >= 500 });
  const data = await res.json();
  if (data.retCode !== 0) throw new BybitError(`Bybit API error ${data.retCode}: ${data.retMsg} (${path})`, { code: data.retCode });
  return data.result;
}
const f = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };

/** Pure parser (exported for tests). Bybit returns different fields per account type; blank strings are common (availableToWithdraw is
 *  empty on Unified accounts, totalAvailableBalance can be empty on Classic/other types). Never let a blank field read as "0 available". */
function parseWallet(acc, coinName = 'USDT') {
  acc = acc || {}; const coin = (acc.coin || []).find(c => c.coin === coinName) || {};
  const has = (v) => v !== undefined && v !== null && v !== '' && Number.isFinite(parseFloat(v));
  const equity = f(has(coin.equity) ? coin.equity : acc.totalEquity);
  const margin = f(has(acc.totalInitialMargin) ? acc.totalInitialMargin : (f(coin.totalPositionIM) + f(coin.totalOrderIM)));
  let available, source;
  if (has(acc.totalAvailableBalance) && (f(acc.totalAvailableBalance) > 0 || !has(coin.walletBalance))) { available = f(acc.totalAvailableBalance); source = 'totalAvailableBalance'; }
  else if (has(coin.availableToWithdraw) && f(coin.availableToWithdraw) > 0) { available = f(coin.availableToWithdraw); source = 'availableToWithdraw'; }
  else if (has(coin.walletBalance) || has(coin.equity)) { available = Math.max(0, f(has(coin.equity) ? coin.equity : coin.walletBalance) - f(coin.totalPositionIM) - f(coin.totalOrderIM) - f(coin.locked)); source = 'computed: coin equity - margin'; }
  else { available = Math.max(0, equity - margin); source = 'computed: equity - margin'; }
  return { currency: coinName, equity, available, margin, unrealized: f(coin.unrealisedPnl), raw: { accountType: acc.accountType, availableSource: source, totalAvailableBalance: acc.totalAvailableBalance, availableToWithdraw: coin.availableToWithdraw, walletBalance: coin.walletBalance, coinEquity: coin.equity, totalEquity: acc.totalEquity, totalInitialMargin: acc.totalInitialMargin } };
}
async function getAccountBalance() {
  let r = await privateRequest('GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED' });   // no coin filter: account-level totals stay populated
  let out = parseWallet((r.list || [])[0]);
  if (!(out.equity > 0)) {   // not a Unified account: try the classic derivatives wallet
    try { r = await privateRequest('GET', '/v5/account/wallet-balance', { accountType: 'CONTRACT', coin: 'USDT' }); const o2 = parseWallet((r.list || [])[0]); if (o2.equity > 0) out = o2; } catch (_) { /* keep unified result */ }
  }
  return out;
}
async function getPositions() {
  const r = await privateRequest('GET', '/v5/position/list', { category: 'linear', settleCoin: 'USDT', limit: 200 });
  return (r.list || []).filter(p => f(p.size) > 0).map(p => ({ symbol: p.symbol, side: p.side === 'Buy' ? 'LONG' : 'SHORT', qty: f(p.size),
    entry: f(p.avgPrice), liquidationPrice: f(p.liqPrice), leverage: f(p.leverage), margin: f(p.positionIM), realised: f(p.cumRealisedPnl),
    stopLoss: f(p.stopLoss) || null, takeProfit: f(p.takeProfit) || null,
    markPrice: f(p.markPrice) || null, createdTime: f(p.createdTime) || null, upnl: f(p.unrealisedPnl) }));
}
const OSTATUS = { Created: 'Created', New: 'New', PartiallyFilled: 'PartiallyFilled', Filled: 'Filled', Cancelled: 'Cancelled', PartiallyFilledCanceled: 'Cancelled', Rejected: 'Rejected', Deactivated: 'Cancelled' };
const mapBybitOrder = (o) => ({ orderId: o.orderId, clientOrderId: o.orderLinkId || null, symbol: o.symbol, status: OSTATUS[o.orderStatus] || 'Unknown',
  side: o.side, reduceOnly: o.reduceOnly === true, price: f(o.price), qty: f(o.qty), filledQty: f(o.cumExecQty), avgPrice: f(o.avgPrice),
  fee: f(o.cumExecFee), stopLoss: f(o.stopLoss) || null, takeProfit: f(o.takeProfit) || null });
async function getOpenOrders(symbol) {
  const p = { category: 'linear', limit: 50 }; if (symbol) p.symbol = symbol; else p.settleCoin = 'USDT';
  return ((await privateRequest('GET', '/v5/order/realtime', p)).list || []).map(mapBybitOrder);
}
async function getOrder(symbol, { orderId, clientOrderId } = {}) {
  const p = { category: 'linear', symbol, limit: 1 }; if (orderId) p.orderId = orderId; else p.orderLinkId = clientOrderId;
  const live = (await privateRequest('GET', '/v5/order/realtime', { ...p, openOnly: 0 })).list || [];
  const hist = live.length ? live : ((await privateRequest('GET', '/v5/order/history', p)).list || []);
  return hist[0] ? mapBybitOrder(hist[0]) : null;
}
/** Stop protection is attached to the position on Bybit; read it back from the position. */
async function getStopOrders(symbol) {
  return (await getPositions()).filter(p => !symbol || p.symbol === symbol).map(p => ({ id: p.symbol, symbol: p.symbol, stopLoss: p.stopLoss, takeProfit: p.takeProfit, long: p.side === 'LONG' }));
}
/** Account margin mode: ISOLATED_MARGIN | REGULAR_MARGIN (cross) | PORTFOLIO_MARGIN. The robot refuses live entries unless ISOLATED. */
async function getMarginMode() {
  const r = await privateRequest('GET', '/v5/account/info', {});
  return r.marginMode || 'UNKNOWN';
}
/** Closed positions with exchange-reported realised PnL (net of fees) for journal + live stats. */
async function getClosedTrades(limit = 50) {
  const r = await privateRequest('GET', '/v5/position/closed-pnl', { category: 'linear', limit: Math.min(100, limit) });
  return (r.list || []).map(t => ({ symbol: t.symbol, direction: t.side === 'Sell' ? 'LONG' : 'SHORT', qty: f(t.qty), entry: f(t.avgEntryPrice), exit: f(t.avgExitPrice),
    pnl: f(t.closedPnl), fee: f(t.openFee) + f(t.closeFee), openedAt: Number(t.createdTime) || null, closedAt: Number(t.updatedTime) || Date.now(), orderId: t.orderId }));
}
/** Public round-trip: latency, server time and clock drift (no credentials). */
async function ping() {
  const t0 = Date.now();
  const res = await fetch(`${BASE_URL}/v5/market/time`, { signal: AbortSignal.timeout(8000) });
  if (BLOCK_CODES.has(res.status)) { noteBlocked(res.status); throw new RegionBlockedError(res.status); }
  noteOk();
  const j = await res.json(); const t1 = Date.now();
  const serverTime = Number(j.time) || Number(j.result?.timeNano) / 1e6 || t1;
  return { latencyMs: t1 - t0, serverTime, driftMs: Math.abs(t1 - serverTime) };
}
async function setLeverage(symbol, leverage) {
  try { await privateRequest('POST', '/v5/position/set-leverage', { category: 'linear', symbol, buyLeverage: String(leverage), sellLeverage: String(leverage) }); }
  catch (e) { if (e.code !== 110043) throw e; /* 110043 = leverage not modified */ }
}
const numStr = (n) => { const s = Number(n).toFixed(10).replace(/0+$/, '').replace(/\.$/, ''); return s || '0'; };
/** params: { symbol, side:'Buy'|'Sell', qty, orderType:'Limit'|'Market', price, leverage, reduceOnly, clientOrderId, stopLoss, takeProfit } */
async function placeOrder(p) {
  if (!p || !p.symbol || !p.side || !(p.qty > 0)) throw new BybitError('placeOrder: symbol, side and qty are required');
  if (p.leverage && !p.reduceOnly) await setLeverage(p.symbol, p.leverage);
  const body = { category: 'linear', symbol: p.symbol, side: p.side, orderType: p.orderType === 'Market' ? 'Market' : 'Limit', qty: numStr(p.qty), positionIdx: 0 };
  if (body.orderType === 'Limit') { body.price = numStr(p.price); body.timeInForce = 'GTC'; }
  if (p.reduceOnly) body.reduceOnly = true;
  if (p.clientOrderId) body.orderLinkId = p.clientOrderId;
  if (!p.reduceOnly && (p.stopLoss || p.takeProfit)) {
    body.tpslMode = 'Full'; body.slTriggerBy = 'MarkPrice'; body.tpTriggerBy = 'MarkPrice';
    if (p.stopLoss) body.stopLoss = numStr(p.stopLoss);
    if (p.takeProfit) body.takeProfit = numStr(p.takeProfit);
  }
  const r = await privateRequest('POST', '/v5/order/create', body);
  logger.live(`Bybit order sent: ${p.side} ${p.symbol} qty=${body.qty} ${body.orderType} id=${r.orderId} link=${p.clientOrderId || '-'}`);
  return { orderId: r.orderId, clientOrderId: r.orderLinkId || p.clientOrderId || null, qty: p.qty };
}
/** Attach / change SL, TP or a trailing stop on an open position (Bybit trading-stop). Pass '0' to clear a value. */
async function setTradingStop({ symbol, stopLoss, takeProfit, trailingStop, activePrice }) {
  const b = { category: 'linear', symbol, tpslMode: 'Full', positionIdx: 0, slTriggerBy: 'MarkPrice', tpTriggerBy: 'MarkPrice' };
  if (stopLoss !== undefined) b.stopLoss = numStr(stopLoss);
  if (takeProfit !== undefined) b.takeProfit = numStr(takeProfit);
  if (trailingStop !== undefined) { b.trailingStop = numStr(trailingStop); if (activePrice) b.activePrice = numStr(activePrice); }
  return privateRequest('POST', '/v5/position/trading-stop', b);
}
async function cancelOrder(symbol, orderId) {
  return privateRequest('POST', '/v5/order/cancel', { category: 'linear', symbol, orderId });
}
async function verify() {
  const out = { checks: [] }; const add = (n, ok, d) => out.checks.push({ name: n, ok, detail: d });
  try { const t = await (await fetch(`${BASE_URL}/v5/market/time`)).json(); const drift = Math.abs(Date.now() - Number(t.time)); add('public API + clock', drift < 4000, `clock drift ${drift} ms (limit 5 000)`); } catch (e) { add('public API + clock', false, e.message); }
  if (!config.bybit.apiKey) { add('credentials', false, 'BYBIT_API_KEY / BYBIT_API_SECRET not set'); return out; }
  try { const m = await getMarginMode(); add('margin mode', m === 'ISOLATED_MARGIN', m === 'ISOLATED_MARGIN' ? 'ISOLATED (required)' : `${m}: switch the account to ISOLATED margin in Bybit (Trade > Margin mode / account settings) before live trading`); } catch (e) { add('margin mode', false, e.message); }
  try { const b = await getAccountBalance(); add('account read', true, `equity ${b.equity} USDT, available ${b.available}`); out.balance = b; } catch (e) { add('account read', false, e.message); }
  try { await getPositions(); await getOpenOrders(); add('positions/orders read', true, 'ok'); } catch (e) { add('positions/orders read', false, e.message); }
  add('order placement', null, `NOT TESTED (verify never sends orders)${config.bybit.testnet ? ' - testnet' : ''}`);
  return out;
}

module.exports = {
  parseWallet,
  getAccountBalance, getPositions, getMarginMode, getClosedTrades, ping, getOpenOrders, getOrder, getStopOrders, placeOrder, cancelOrder, setTradingStop, setLeverage, connectivity, RegionBlockedError, verify, _internals: { bybitSign, numStr, mapBybitOrder },
  getOrderBook,
  getFundingHistory,
  getOpenInterestHistory,
  getInstruments,
  getTickers,
  getKlines,
  getKlineHistory,
  getFundingRate,
  getOpenInterest,
};
