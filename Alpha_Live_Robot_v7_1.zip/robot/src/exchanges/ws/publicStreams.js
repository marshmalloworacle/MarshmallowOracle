'use strict';

/**
 * Public WebSocket streams for Bitget (v2) and MEXC futures. Same interface as BybitPublicStream so liveFeed can use
 * any of the three: start/stop, subscribe/unsubscribe(['tickers.SYM','orderbook.50.SYM','kline.15.SYM']), emits 'ticker'/'kline',
 * getTickerMap/getBook/getKline/status. Internal topics keep the Bybit naming; each class translates them to its venue's protocol.
 * Public market data only (REST remains the automatic fallback; private order streams exist for Bybit only).
 * Frame formats follow each venue's public docs; they are unit-tested with recorded-shape frames but NOT yet
 * confirmed against the live servers (no network in the build sandbox) - liveFeed falls back to REST if a stream stays silent.
 */
const { EventEmitter } = require('events');
const ManagedSocket = require('./managed');
const logger = require('../../utils/logger');

const BITGET_G = { '1': '1m', '3': '3m', '5': '5m', '15': '15m', '30': '30m', '60': '1H', '240': '4H', '360': '6H', '720': '12H', D: '1D', W: '1W', M: '1M' };
const BITGET_REV = Object.fromEntries(Object.entries(BITGET_G).map(([k, v]) => [v, k]));
const MEXC_IV = { '1': 'Min1', '5': 'Min5', '15': 'Min15', '30': 'Min30', '60': 'Min60', '240': 'Hour4', '480': 'Hour8', D: 'Day1', W: 'Week1', M: 'Month1' };
const MEXC_REV = Object.fromEntries(Object.entries(MEXC_IV).map(([k, v]) => [v, k]));
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };

class BasePublicStream extends EventEmitter {
  constructor({ url, Impl, staleMs = 30000, name, pingMsg }) {
    super();
    this.sock = new ManagedSocket({ url, name, Impl, staleMs, pingMsg });
    this.topics = new Set(); this.tickers = new Map(); this.books = new Map(); this.klines = new Map();
    this.latencyMs = null; this._rate = [];
    this.sock.on('open', () => { this._resubscribeAll(); this.emit('open'); });
    this.sock.on('close', () => this.emit('close'));
    this.sock.on('message', (m) => { this._rate.push(Date.now()); if (this._rate.length > 2000) this._rate.splice(0, this._rate.length - 2000); this._onMessage(m); });
  }
  start() { this.sock.start(); }
  stop() { this.sock.stop(); }
  subscribe(topics) { const add = topics.filter(t => !this.topics.has(t)); add.forEach(t => this.topics.add(t)); if (add.length) this._sub('subscribe', add); }
  unsubscribe(topics) {
    const rm = topics.filter(t => this.topics.has(t)); rm.forEach(t => this.topics.delete(t));
    if (rm.length) this._sub('unsubscribe', rm);
    for (const t of rm) {
      const [kind, ...rest] = t.split('.'); const sym = rest[rest.length - 1];
      if (kind === 'orderbook') this.books.delete(sym); if (kind === 'tickers') this.tickers.delete(sym); if (kind === 'kline') this.klines.delete(`${sym}|${rest[0]}`);
    }
  }
  _resubscribeAll() { if (this.topics.size) this._sub('subscribe', [...this.topics]); }
  _setTicker(sym, patch) {
    const cur = this.tickers.get(sym) || {}; Object.assign(cur, patch); cur.symbol = sym; cur.ts = Date.now(); this.tickers.set(sym, cur);
    const lastPrice = parseFloat(cur.lastPrice), markPrice = parseFloat(cur.markPrice || cur.lastPrice);
    if (lastPrice > 0) this.emit('ticker', { symbol: sym, lastPrice, markPrice, fundingRate: parseFloat(cur.fundingRate), ts: cur.ts });
  }
  _setKline(sym, interval, c) { this.klines.set(`${sym}|${interval}`, c); this.emit('kline', { symbol: sym, interval, candle: c }); }
  _setBook(sym, bids, asks) {
    const toMap = (lv) => new Map((lv || []).map(([p, s]) => [String(p), String(s)]));
    this.books.set(sym, { bids: toMap(bids), asks: toMap(asks), ts: Date.now() });
  }
  getTicker(symbol, maxAgeMs = 5000) { const t = this.tickers.get(symbol); return t && Date.now() - t.ts <= maxAgeMs ? t : null; }
  getTickerMap(maxAgeMs = 5000) {
    const out = {}; const now = Date.now();
    for (const [s, t] of this.tickers) if (now - t.ts <= maxAgeMs) out[s] = { lastPrice: parseFloat(t.lastPrice) || 0, markPrice: parseFloat(t.markPrice || t.lastPrice) || 0, fundingRate: parseFloat(t.fundingRate), ts: t.ts };
    return out;
  }
  getBook(symbol, maxAgeMs = 10000) {
    const b = this.books.get(symbol); if (!b || Date.now() - b.ts > maxAgeMs) return null;
    const top = (map, dir) => [...map.entries()].sort((x, y) => dir * (parseFloat(x[0]) - parseFloat(y[0]))).slice(0, 50);
    return { bids: top(b.bids, -1), asks: top(b.asks, 1), ts: b.ts };
  }
  getKline(symbol, interval) { return this.klines.get(`${symbol}|${interval}`) || null; }
  status() {
    const now = Date.now(); const recent = this._rate.filter(t => now - t < 10000).length;
    return { ...this.sock.status(), topics: this.topics.size, tickers: this.tickers.size, books: this.books.size, klines: this.klines.size, msgPerSec: +(recent / 10).toFixed(1), latencyMs: this.latencyMs == null ? null : Math.round(this.latencyMs) };
  }
}

class BitgetPublicStream extends BasePublicStream {
  constructor(o) { super({ ...o, name: 'bitget-public', pingMsg: () => 'ping' }); }
  _arg(topic) {
    const [kind, ...rest] = topic.split('.'); const sym = rest[rest.length - 1];
    if (kind === 'tickers') return { instType: 'USDT-FUTURES', channel: 'ticker', instId: sym };
    if (kind === 'kline') return BITGET_G[rest[0]] ? { instType: 'USDT-FUTURES', channel: `candle${BITGET_G[rest[0]]}`, instId: sym } : null;
    if (kind === 'orderbook') return { instType: 'USDT-FUTURES', channel: 'books15', instId: sym };
    return null;
  }
  _sub(op, topics) { const args = topics.map(t => this._arg(t)).filter(Boolean); for (let i = 0; i < args.length; i += 20) this.sock.send({ op, args: args.slice(i, i + 20) }); }
  _onMessage(str) {
    if (str === 'pong') return;
    let m; try { m = JSON.parse(str); } catch (_) { return; }
    if (m.event === 'error') { logger.warn(`Bitget WS error: ${m.code} ${m.msg}`); this.sock.lastError = `${m.code} ${m.msg}`; return; }
    if (!m.arg || !m.data) return;
    if (m.ts) { const lat = Math.max(0, Date.now() - Number(m.ts)); this.latencyMs = this.latencyMs == null ? lat : this.latencyMs * 0.9 + lat * 0.1; }
    const ch = m.arg.channel, sym = m.arg.instId;
    if (ch === 'ticker') { for (const d of m.data) this._setTicker(d.instId || sym, { lastPrice: d.lastPr, markPrice: d.markPrice, fundingRate: d.fundingRate, bid1Price: d.bidPr, ask1Price: d.askPr }); }
    else if (ch.startsWith('candle')) {
      const iv = BITGET_REV[ch.slice(6)]; if (!iv) return;
      for (const k of m.data) this._setKline(sym, iv, { time: Number(k[0]), open: num(k[1]), high: num(k[2]), low: num(k[3]), close: num(k[4]), volume: num(k[5]), turnover: num(k[6]), confirm: false });
    } else if (ch.startsWith('books')) { const d = m.data[0]; if (d) this._setBook(sym, d.bids, d.asks); }
  }
}

class MexcPublicStream extends BasePublicStream {
  constructor({ csOf, ...o }) { super({ ...o, name: 'mexc-public', pingMsg: () => JSON.stringify({ method: 'ping' }) }); this.csOf = csOf || (() => 1); }
  _msgs(op, topic) {
    const [kind, ...rest] = topic.split('.'); const sym = rest[rest.length - 1]; const s = `${sym.replace(/USDT$/, '')}_USDT`; const m = op === 'subscribe' ? 'sub' : 'unsub';
    if (kind === 'tickers') return [{ method: `${m}.ticker`, param: { symbol: s } }];
    if (kind === 'kline') return MEXC_IV[rest[0]] ? [{ method: `${m}.kline`, param: { symbol: s, interval: MEXC_IV[rest[0]] } }] : [];
    if (kind === 'orderbook') return [{ method: `${m}.depth.full`, param: { symbol: s, limit: 20 } }];
    return [];
  }
  _sub(op, topics) { for (const t of topics) for (const msg of this._msgs(op, t)) this.sock.send(msg); }
  _onMessage(str) {
    let m; try { m = JSON.parse(str); } catch (_) { return; }
    if (m.channel === 'pong') return;
    if (m.channel === 'rs.error') { this.sock.lastError = String(m.data || 'subscription error'); logger.warn(`MEXC WS error: ${m.data}`); return; }
    if (!m.channel || !m.channel.startsWith('push.') || m.data == null) return;
    if (m.ts) { const lat = Math.max(0, Date.now() - Number(m.ts)); this.latencyMs = this.latencyMs == null ? lat : this.latencyMs * 0.9 + lat * 0.1; }
    const sym = String(m.symbol || m.data.symbol || '').replace('_', '');
    if (m.channel === 'push.ticker') {
      const d = m.data; this._setTicker(String(d.symbol || m.symbol).replace('_', ''), { lastPrice: d.lastPrice, markPrice: d.fairPrice ?? d.lastPrice, fundingRate: d.fundingRate });
    } else if (m.channel === 'push.kline') {
      const d = m.data, iv = MEXC_REV[d.interval]; if (!iv) return; const cs = num(this.csOf(sym)) || 1;
      this._setKline(sym, iv, { time: Number(d.t) * 1000, open: num(d.o), high: num(d.h), low: num(d.l), close: num(d.c), volume: num(d.q) * cs, turnover: num(d.a), confirm: false });
    } else if (m.channel === 'push.depth.full') {
      const cs = num(this.csOf(sym)) || 1; const lv = (a) => (a || []).map(([p, v]) => [p, num(v) * cs]);
      this._setBook(sym, lv(m.data.bids), lv(m.data.asks));
    }
  }
}

module.exports = { BitgetPublicStream, MexcPublicStream, BasePublicStream };
