'use strict';
const indicators = require('../indicators');

const dataFeed = require('../market/dataFeed');
const { createDefaultRegistry, StrategyRouter } = require('../strategy/registry');
const { scoreSignal } = require('../scoring/engine');
const RiskEngine = require('../risk/engine');
const { getAssetCluster } = RiskEngine;
const config = require('../config');
const journal = require('../journal/store');
const { eventBus } = require('../events/bus');
const { autopsyEngine } = require('../learning/autopsy');
const logger = require('../utils/logger');

const FEE_RATE = config.takerFeeRate; // taker fee of the ACTIVE exchange (TAKER_FEE_RATE overrides)
const DEFAULT_SLIPPAGE_RATE = 0.0005; // 0.05% slippage simulation

/**
 * Paper Trading Engine
 * Realistic execution simulator with Bybit live data, fees, slippage,
 * correlation tracking, and regime awareness.
 */
class PaperEngine {
  constructor(strategyConfig = {}, riskConfig = {}) {
    this.registry = createDefaultRegistry(strategyConfig);
    this.router = new StrategyRouter(this.registry);
    this.riskEngine = new RiskEngine(riskConfig);
    this.openTrades = new Map();   // key → trade
    this.closedTrades = [];
    this.balance = this.riskEngine.cfg.accountBalance;
    this.startBalance = this.balance;
    this.slippageRate = riskConfig.slippageRate ?? DEFAULT_SLIPPAGE_RATE;
    this.trailingConfig = riskConfig.trailingStop ?? config.trailingStop ?? { enabled: true, activationRR: 1.0, distancePct: 0.015 };
    this._processedSignals = new Set();
    this._outbox = new Map();      // id -> trade awaiting a successful DB write
    this._lastPrice = new Map();   // symbol -> last price seen by updateTrades
  }

  // ── Persistence (never silent) ─────────────────────────────────────────

  /**
   * Save a trade to the journal. A failure is LOGGED, alerted and queued for retry
   * instead of being swallowed, so the dashboard can never silently miss a trade.
   */
  _persist(trade) {
    try {
      journal.savePaperTrade(trade);
      this._outbox.delete(trade.id);
      return true;
    } catch (err) {
      this._outbox.set(trade.id, trade);
      logger.error(`JOURNAL WRITE FAILED for ${trade.symbol} (${trade.id}): ${err.message} — queued for retry (${this._outbox.size} pending)`);
      try { journal.logAlert('DB_WRITE_FAILED', `Trade ${trade.id}: ${err.message}`, 'system', false); } catch (_) { /* DB itself is down */ }
      return false;
    }
  }

  /** Retry queued writes; returns number still pending */
  flushOutbox() {
    for (const trade of Array.from(this._outbox.values())) {
      try {
        journal.savePaperTrade(trade);
        this._outbox.delete(trade.id);
        logger.info(`Journal write recovered for ${trade.symbol} (${trade.id})`);
      } catch (_) { /* still failing — try again next tick */ }
    }
    return this._outbox.size;
  }

  getPendingWrites() {
    return this._outbox.size;
  }

  /**
   * Rebuild in-memory open positions from the journal after a restart so that
   * SL/TP/trailing keep being managed (otherwise they show on the dashboard
   * as "open" forever while nothing is watching them).
   * Opt-in: only the robot daemon calls this.
   */
  restoreFromJournal() {
    let restored = 0;
    let realized = 0;
    try {
      const epoch = (journal.getState('account_epoch') || {}).ts || 0;
      realized = journal.getClosedPaperTrades(100000, config.isLive ? 'lab' : undefined).filter(t => (t.close_time || 0) >= epoch).reduce((sum, t) => sum + (t.pnl || 0), 0);
    } catch (_) { /* ignore */ }

    for (const r of journal.getOpenPaperTrades(config.isLive ? 'lab' : undefined)) {
      if (this.adoptOpenRow(r)) restored++;
    }

    if (realized) {
      this.balance = this.startBalance + realized;
    }
    if (restored) logger.info(`Restored ${restored} open paper position(s) from journal`);
    return restored;
  }

  /**
   * Re-attach one open journal row to the engine. Used on restart AND as a fallback when the dashboard
   * asks to close a position the robot's memory no longer holds (the cause of "<strategy> not found").
   * Returns the in-memory trade, or null if it was already attached.
   */
  adoptOpenRow(r) {
    if ((r.mode === 'LAB') !== !!config.isLive) return null;   // v7.0: Paper Lab rows (LIVE mode) and plain paper rows never mix
    for (const t of this.openTrades.values()) if (t.id === r.id) return null;
    let key = `${r.symbol}_${r.strategy_id}`;
    if (this.openTrades.has(key)) key = r.id;   // same symbol+strategy already held: never skip a row
    const entry = r.entry;
    const initialStop = r.initial_stop_loss ?? r.stop_loss;
    const trade = {
      id: r.id, symbol: r.symbol, strategyId: r.strategy_id, strategyName: r.strategy_name,
      strategyVersion: r.strategy_version, direction: r.direction, entry, targetEntry: entry,
      stopLoss: r.stop_loss, takeProfit: r.take_profit, riskReward: r.risk_reward, score: r.score,
      positionSize: r.position_size, regime: r.regime || null, cluster: r.cluster || 'ALT_GENERAL',
      slippage: r.slippage || 0, openTime: r.open_time, mode: 'PAPER', dbMode: r.mode === 'LAB' ? 'LAB' : 'PAPER',
      initialStopLoss: initialStop, initialRisk: r.initial_risk ?? Math.abs(entry - initialStop),
      trailingActive: !!r.trailing_active, trailingStopPrice: r.trailing_stop ?? null,
    };
    this.openTrades.set(key, trade);
    try { this.riskEngine.onPositionOpened(trade.positionSize * trade.entry, trade.symbol); } catch (_) { /* ignore */ }
    return trade;
  }

  /**
   * Analyse one market with every active strategy. Never opens anything — returns scored signals so the
   * robot can rank ALL markets first and fill position slots best-first.
   * Each signal gets tier: 'QUALIFIED' (score >= minScore) | 'FILL' (>= fillMinScore, valid levels) | null
   */
  async analyzeMarket(symbol) {
    try {
      const [mtf, meta] = await Promise.all([
        dataFeed.getMultiTimeframe(symbol, ['4h', '1h', '15m'], 200),
        dataFeed.getMarketMeta(symbol),
      ]);
      const marketData = {
        symbol, candles4H: mtf['4h'], candles1H: mtf['1h'], candles15M: mtf['15m'],
        meta: { symbol, ...meta },
      };
      const raw = this.router
        ? await this.router.routeAndEvaluate(marketData)
        : await this.registry.evaluateAll(marketData);
      let atr1h = null;
      try { const a = indicators.atr(marketData.candles1H || [], 14); const v = a[a.length - 1]; atr1h = Number.isFinite(v) && v > 0 ? v : null; } catch (_) { /* no ATR: protection falls back to a stop-distance proxy */ }
      const signals = raw.map(sig => this.classify(scoreSignal({ ...sig, atr: sig.atr || atr1h })));
      return { symbol, signals };
    } catch (err) {
      logger.error(`Paper analyze failed for ${symbol}: ${err.message}`);
      return { symbol, signals: [], error: err.message };
    }
  }

  /** Attach tier + cluster. FILL = below minScore but still a structurally valid, risk-reward-compliant setup */
  classify(scored) {
    const out = { ...scored, cluster: scored.cluster || getAssetCluster(scored.symbol), tier: null };
    const validLevels = out.entry > 0 && out.stopLoss > 0 && out.takeProfit > 0;
    if (out.decision === 'TRADE') out.tier = 'QUALIFIED';
    else if (config.fillToTarget && !out.criticalFail && out.direction && validLevels
      && (out.score || 0) >= config.fillMinScore && (out.riskReward || 0) >= config.minRR) {
      out.tier = 'FILL';
      out.decision = 'FILL';
      out.rejectionReason = `Below ${config.minScore} (score ${out.score}) — eligible as fill setup`;
    }
    return out;
  }

  /** Try to open ONE paper trade from a scored signal. Returns { action: 'OPENED'|'SKIPPED', ... } */
  openFromSignal(signal, opts = {}) {
    const symbol = signal.symbol;
    const sigKey = `${symbol}_${signal.strategyId}_${signal.direction}_${Math.floor(signal.timestamp / 60000)}`;
    if (!opts.manual && this._processedSignals.has(sigKey)) return { action: 'SKIPPED', reason: 'DUPLICATE_SIGNAL' };

    const existingKey = `${symbol}_${signal.strategyId}`;
    if (this.openTrades.has(existingKey)) return { action: 'SKIPPED', reason: 'ALREADY_IN_TRADE' };
    if (config.onePositionPerSymbol && Array.from(this.openTrades.values()).some(t => t.symbol === symbol)) {
      return { action: 'SKIPPED', reason: 'SYMBOL_ALREADY_OPEN' };
    }

    const dirGate = require('../control/direction').check(signal.direction, { manual: !!opts.manual });   // v7.1: Manual Take overrides the direction MODE (ALLOW_* still apply)
    if (!dirGate.allowed) return { action: 'SKIPPED', reason: dirGate.reason };

    const openList = Array.from(this.openTrades.values());
    if (config.sizeOnEquity) this.riskEngine.cfg.accountBalance = Math.max(0, this.balance);
    const riskCheck = this.riskEngine.check(signal, openList, opts.manual ? { ignoreSlots: true, hardCap: config.manualTakeHardCapPaper } : {});
    if (!riskCheck.approved) {
      logger.paper(`Risk rejected paper trade ${symbol}: ${riskCheck.reason}`);
      return { action: 'SKIPPED', reason: riskCheck.reason };
    }

    const slippageMultiplier = signal.direction === 'LONG' ? (1 + this.slippageRate) : (1 - this.slippageRate);
    const actualEntry = parseFloat((signal.entry * slippageMultiplier).toFixed(4));
    const entrySlippage = Math.abs(actualEntry - signal.entry) * riskCheck.positionSize;
    const initialRisk = Math.abs(actualEntry - signal.stopLoss);
    const openTime = Date.now();
    const trade = {
      // Unique per open (symbol_strategy was reused and overwrote earlier closed trades in the journal)
      id: `${existingKey}_${openTime}`,
      symbol, strategyId: signal.strategyId, strategyName: signal.strategyName,
      strategyVersion: signal.strategyVersion, direction: signal.direction,
      entry: actualEntry, targetEntry: signal.entry, stopLoss: signal.stopLoss, takeProfit: signal.takeProfit,
      riskReward: signal.riskReward, score: signal.score, positionSize: riskCheck.positionSize,
      regime: signal.regime || null, cluster: riskCheck.cluster || 'ALT_GENERAL',
      slippage: parseFloat(entrySlippage.toFixed(4)), openTime, mode: 'PAPER', dbMode: config.isLive ? 'LAB' : 'PAPER',
      initialStopLoss: signal.stopLoss, initialRisk, trailingActive: false, trailingStopPrice: null,
      tier: signal.tier || 'QUALIFIED',
      atr: signal.atr || (initialRisk > 0 ? initialRisk / 1.5 : null),   // real 1h ATR from the signal; proxy only if unavailable
      atrSource: signal.atr ? 'SIGNAL_ATR' : 'STOP_DISTANCE_PROXY',
    };

    this.openTrades.set(existingKey, trade);
    this._processedSignals.add(sigKey);
    this.riskEngine.onPositionOpened(trade.positionSize * trade.entry, symbol);
    this._persist(trade);
    try { require('../journal/extras').merge(trade.id, { strategy: trade.strategyId, direction: trade.direction, regime: trade.regime, atr: trade.atr, atrSource: trade.atrSource, initialStop: trade.initialStopLoss, target: trade.takeProfit, initialRisk: trade.initialRisk, openedAt: trade.openTime, context: this.entryContext || null }); } catch (_) { /* extras are best effort */ }
    eventBus.emitEvent('position.opened', { trade, signal, mode: 'PAPER' });
    logger.paper(`OPENED [${trade.cluster}] (${trade.tier}): ${symbol} ${signal.direction} @ ${trade.entry} | SL: ${signal.stopLoss} | TP: ${signal.takeProfit}`);
    return { action: 'OPENED', trade, signal };
  }

  /**
   * Backwards-compatible single-market flow: analyse, then open the best qualified signal.
   * (The robot daemon uses analyzeMarket + openFromSignal to rank the whole universe first.)
   */
  async evaluateMarket(symbol) {
    try {
      const { signals, error } = await this.analyzeMarket(symbol);
      if (error) return { action: 'ERROR', error };
      const candidates = signals.filter(s => s.decision === 'TRADE').sort((a, b) => b.score - a.score);
      for (const sig of candidates) {
        const r = this.openFromSignal(sig);
        if (r.action === 'OPENED') return r;
      }
      return { action: 'NONE' };
    } catch (err) {
      logger.error(`Paper eval failed for ${symbol}: ${err.message}`);
      return { action: 'ERROR', error: err.message };
    }
  }

  /**
   * Update open paper trades against current price
   * @param {string} symbol
   * @param {number} currentPrice
   */
  updateTrades(symbol, currentPrice) {
    const closed = [];
    if (Number.isFinite(currentPrice) && currentPrice > 0) this._lastPrice.set(symbol, currentPrice);
    for (const [key, trade] of this.openTrades) {
      if (trade.symbol !== symbol) continue;

      // v4.6 smart protection (switchable). When any of these is ON it replaces the legacy fixed-distance trailing below.
      const prot = require('../features/flags').all();
      const smart = prot.smartTrailing || prot.profitGiveback || prot.timeExit || prot.partialExits;
      if (smart && trade.initialRisk > 0) {
        const ev = require('../protection/stops').evaluate({ side: trade.direction, entry: trade.entry, stop: trade.stopLoss,
          initialStop: trade.initialStopLoss, target: trade.takeProfit, mark: currentPrice, atr: trade.atr, openedAt: trade.openTime,
          leverage: this.leverage || config.leverage }, trade.prot, prot, require('../protection/config').stopsConfig());
        trade.prot = ev.state; trade.peakPrice = ev.peakPrice; trade.stage = ev.stage;
        if (ev.stop !== trade.stopLoss) {
          trade.stopLoss = ev.stop; trade.trailingStopPrice = ev.stop; trade.trailingActive = true; trade.stopReason = ev.reason;
          this._persist(trade);
          eventBus.emitEvent('position.trailing_updated', { tradeId: trade.id, symbol: trade.symbol, stopLoss: trade.stopLoss, reason: ev.reason });
        }
        if (ev.partial && trade.positionSize > 0) {
          const pc = this.partialClose(trade.id, ev.partial.fraction, currentPrice, ev.partial.stage);
          if (pc) { trade.prot.partialsDone = [...(trade.prot.partialsDone || []), ev.partial.stage]; }
        }
        if (ev.exit) {
          const c = this.closeTrade(trade.id, ev.exit.reason, currentPrice);
          if (c) closed.push(c);
          continue;
        }
      }
      // Trailing stop ratchet logic (legacy v4.5 behaviour, used when smart protection is OFF)
      if (!smart && this.trailingConfig?.enabled && trade.initialRisk > 0) {
        const activationRR = this.trailingConfig.activationRR || 1.0;
        const distancePct = this.trailingConfig.distancePct || 0.015;

        if (trade.direction === 'LONG') {
          const profit = currentPrice - trade.entry;
          if (profit >= trade.initialRisk * activationRR) {
            trade.trailingActive = true;
            const proposedStop = parseFloat((currentPrice * (1 - distancePct)).toFixed(4));
            if (!trade.trailingStopPrice || proposedStop > trade.trailingStopPrice) {
              trade.trailingStopPrice = proposedStop;
            }
            if (trade.trailingStopPrice > trade.stopLoss) {
              trade.stopLoss = trade.trailingStopPrice;
              this._persist(trade);
              eventBus.emitEvent('position.trailing_updated', { tradeId: trade.id, symbol: trade.symbol, stopLoss: trade.stopLoss });
            }
          }
        } else if (trade.direction === 'SHORT') {
          const profit = trade.entry - currentPrice;
          if (profit >= trade.initialRisk * activationRR) {
            trade.trailingActive = true;
            const proposedStop = parseFloat((currentPrice * (1 + distancePct)).toFixed(4));
            if (!trade.trailingStopPrice || proposedStop < trade.trailingStopPrice) {
              trade.trailingStopPrice = proposedStop;
            }
            if (trade.trailingStopPrice < trade.stopLoss) {
              trade.stopLoss = trade.trailingStopPrice;
              this._persist(trade);
              eventBus.emitEvent('position.trailing_updated', { tradeId: trade.id, symbol: trade.symbol, stopLoss: trade.stopLoss });
            }
          }
        }
      }

      let outcome = null;
      let exitReason = null;
      if (trade.direction === 'LONG') {
        if (currentPrice <= trade.stopLoss) {
          outcome = (trade.trailingActive && currentPrice > trade.entry) ? 'WIN' : 'LOSS';
          exitReason = trade.trailingActive ? 'TRAILING_STOP_HIT' : 'STOP_LOSS_HIT';
        } else if (currentPrice >= trade.takeProfit) {
          outcome = 'WIN';
          exitReason = 'TAKE_PROFIT_HIT';
        }
      } else {
        if (currentPrice >= trade.stopLoss) {
          outcome = (trade.trailingActive && currentPrice < trade.entry) ? 'WIN' : 'LOSS';
          exitReason = trade.trailingActive ? 'TRAILING_STOP_HIT' : 'STOP_LOSS_HIT';
        } else if (currentPrice <= trade.takeProfit) {
          outcome = 'WIN';
          exitReason = 'TAKE_PROFIT_HIT';
        }
      }

      if (outcome) {
        // Apply exit slippage
        const nominalExit = outcome === 'WIN' ? trade.takeProfit : trade.stopLoss;
        const exitSlippageMultiplier = trade.direction === 'LONG'
          ? (outcome === 'WIN' ? (1 - this.slippageRate) : (1 - this.slippageRate))
          : (outcome === 'WIN' ? (1 + this.slippageRate) : (1 + this.slippageRate));

        const actualExit = parseFloat((nominalExit * exitSlippageMultiplier).toFixed(4));
        const exitSlippage = Math.abs(actualExit - nominalExit) * trade.positionSize;
        const totalSlippage = (trade.slippage || 0) + exitSlippage;

        const rawPnl = trade.direction === 'LONG'
          ? (actualExit - trade.entry) * trade.positionSize
          : (trade.entry - actualExit) * trade.positionSize;

        const totalFees = (trade.positionSize * trade.entry * FEE_RATE) + (trade.positionSize * actualExit * FEE_RATE);
        const netPnl = rawPnl - totalFees;

        this.balance += netPnl;
        this.riskEngine.onTradeClosed(netPnl);
        this.riskEngine.onPositionClosed(trade.positionSize * trade.entry, symbol);

        const closedTrade = {
          ...trade,
          exitPrice: actualExit,
          closeTime: Date.now(),
          outcome,
          exitReason,
          pnl: parseFloat((netPnl + (trade.realizedPartial || 0)).toFixed(4)),
          fee: parseFloat((totalFees + (trade.partialFees || 0)).toFixed(4)),
          slippage: parseFloat(totalSlippage.toFixed(4)),
          durationMs: Date.now() - trade.openTime,
        };

        this.closedTrades.push(closedTrade);
        this.openTrades.delete(key);
        closed.push(closedTrade);

        this._persist(closedTrade);
        this._extrasClose(closedTrade);

        eventBus.emitEvent('position.closed', { trade: closedTrade, mode: 'PAPER' });
        try {
          autopsyEngine.diagnoseTrade(closedTrade);
        } catch (err) {
          logger.warn(`Autopsy failed for ${closedTrade.id}: ${err.message}`);
        }

        logger.paper(`CLOSED [${trade.cluster}]: ${symbol} ${trade.direction} ${outcome} (${exitReason}) | Net P&L: ${netPnl >= 0 ? '+' : ''}${netPnl.toFixed(4)} | Fees: ${totalFees.toFixed(4)}`);
      }
    }
    return closed;
  }

  /** Journal extras for a finished trade: excursions, stage, giveback, partials, exit reason. Never throws. */
  _extrasClose(t) {
    try {
      const long = t.direction === 'LONG', pr = t.prot || {};
      const mfe = long ? (pr.peakPrice || t.entry) - t.entry : t.entry - (pr.peakPrice || t.entry);
      const mae = long ? t.entry - (pr.troughPrice || t.entry) : (pr.troughPrice || t.entry) - t.entry;
      const exitMove = long ? t.exitPrice - t.entry : t.entry - t.exitPrice;
      const R = t.initialRisk > 0 ? t.initialRisk : null;
      require('../journal/extras').merge(t.id, { exitReason: t.exitReason, closedAt: t.closeTime, peakFavourable: mfe, peakAdverse: mae,
        peakR: R ? mfe / R : null, adverseR: R ? mae / R : null, resultR: R ? exitMove / R : null, givebackFromPeak: mfe > 0 ? Math.max(0, (mfe - exitMove) / mfe) : null,
        stageReached: t.stage || null, stopReason: t.stopReason || null, partials: t.partials || [], realizedPartial: t.realizedPartial || 0, fees: t.fee });
    } catch (_) { /* best effort */ }
  }

  /**
   * Close a fraction of an open paper trade at `price`. Books realised P&L + fees for that slice, shrinks the position,
   * keeps the (already tightened) stop on the remainder. Returns the partial record or null.
   */
  partialClose(idOrKey, fraction, price, stage = null) {
    const trade = this.openTrades.get(idOrKey) || Array.from(this.openTrades.values()).find(t => t.id === idOrKey);
    if (!trade || !(fraction > 0 && fraction < 1) || !(price > 0)) return null;
    const qty = parseFloat((trade.positionSize * fraction).toFixed(8));
    if (!(qty > 0) || qty >= trade.positionSize) return null;
    const raw = trade.direction === 'LONG' ? (price - trade.entry) * qty : (trade.entry - price) * qty;
    const fees = (qty * trade.entry * FEE_RATE) + (qty * price * FEE_RATE);
    const net = raw - fees;
    this.balance += net;
    this.riskEngine.onTradeClosed(net);
    this.riskEngine.state.totalExposure = Math.max(0, this.riskEngine.state.totalExposure - this.riskEngine._expo(qty * trade.entry));
    trade.positionSize = parseFloat((trade.positionSize - qty).toFixed(8));
    trade.realizedPartial = parseFloat(((trade.realizedPartial || 0) + net).toFixed(4));
    trade.partialFees = parseFloat(((trade.partialFees || 0) + fees).toFixed(4));
    const rec = { at: Date.now(), stage, fraction, qty, price, net: parseFloat(net.toFixed(4)), remaining: trade.positionSize };
    trade.partials = [...(trade.partials || []), rec];
    this._persist(trade);
    eventBus.emitEvent('position.partial_close', { tradeId: trade.id, symbol: trade.symbol, ...rec });
    logger.paper(`PARTIAL ${trade.symbol} ${trade.direction}: closed ${qty} @ ${price} (stage ${stage}) net ${net.toFixed(4)} · remaining ${trade.positionSize}`);
    return rec;
  }

  /**
   * Manually close a trade by ID or symbol
   */
  closeTrade(idOrSymbol, reason = 'MANUAL_CLOSE', exitPrice = null) {
    let keyToClose = null;
    let trade = null;

    if (this.openTrades.has(idOrSymbol)) {
      keyToClose = idOrSymbol;
      trade = this.openTrades.get(idOrSymbol);
    } else {
      for (const [k, t] of this.openTrades) {
        if (t.symbol === idOrSymbol || t.id === idOrSymbol) {
          keyToClose = k;
          trade = t;
          break;
        }
      }
    }

    if (!trade) return null;

    // A manual close MUST use a real market price. The old fallback (exit at entry) booked
    // every manual close as a ~0 PnL trade and corrupted balance/win-rate statistics.
    const actualExit = parseFloat(exitPrice);
    if (!Number.isFinite(actualExit) || actualExit <= 0) {
      throw new Error(`closeTrade(${trade.symbol}): a valid exitPrice is required`);
    }
    const rawPnl = trade.direction === 'LONG'
      ? (actualExit - trade.entry) * trade.positionSize
      : (trade.entry - actualExit) * trade.positionSize;

    const totalFees = (trade.positionSize * trade.entry * FEE_RATE) + (trade.positionSize * actualExit * FEE_RATE);
    const netPnl = rawPnl - totalFees;
    const outcome = (netPnl + (trade.realizedPartial || 0)) >= 0 ? 'WIN' : 'LOSS';

    this.balance += netPnl;
    this.riskEngine.onTradeClosed(netPnl);
    this.riskEngine.onPositionClosed(trade.positionSize * trade.entry, trade.symbol);

    const closedTrade = {
      ...trade,
      exitPrice: parseFloat(actualExit.toFixed(4)),
      closeTime: Date.now(),
      outcome,
      exitReason: reason,
      pnl: parseFloat((netPnl + (trade.realizedPartial || 0)).toFixed(4)),
      fee: parseFloat((totalFees + (trade.partialFees || 0)).toFixed(4)),
      slippage: trade.slippage || 0,
      durationMs: Date.now() - trade.openTime,
    };

    this.closedTrades.push(closedTrade);
    this.openTrades.delete(keyToClose);

    this._persist(closedTrade);
    this._extrasClose(closedTrade);

    eventBus.emitEvent('position.closed', { trade: closedTrade, mode: 'PAPER', manual: true });
    try {
      autopsyEngine.diagnoseTrade(closedTrade);
    } catch (err) {
      logger.warn(`Autopsy failed for ${closedTrade.id}: ${err.message}`);
    }

    logger.paper(`MANUAL CLOSE: ${trade.symbol} ${trade.direction} (${reason}) | Net P&L: ${netPnl >= 0 ? '+' : ''}${netPnl.toFixed(4)}`);
    return closedTrade;
  }

  /**
   * Close all open trades
   */
  closeAllTrades(reason = 'MANUAL_CLOSE_ALL', priceFor = null, opts = {}) {
    const closed = [];
    const failed = [];
    const keys = Array.from(this.openTrades.keys());
    for (const k of keys) {
      const t = this.openTrades.get(k);
      try {
        let price = typeof priceFor === 'function' ? priceFor(t.symbol) : null;
        if (!(price > 0)) price = this._lastPrice.get(t.symbol) || null;
        if (!(price > 0)) {
          if (opts.strict) throw new Error(`no market price available for ${t.symbol}`);
          logger.warn(`closeAllTrades: no market price for ${t.symbol} — closing at entry (legacy behaviour)`);
          price = t.entry;
        }
        const res = this.closeTrade(k, reason, price);
        if (res) closed.push(res);
      } catch (err) {
        failed.push({ id: t.id, symbol: t.symbol, error: err.message });
      }
    }
    closed.failed = failed;
    return closed;
  }

  /** Performance summary */
  getPerformance() {
    const trades = this.closedTrades;
    const wins = trades.filter(t => t.outcome === 'WIN');
    const losses = trades.filter(t => t.outcome === 'LOSS');
    const netPnl = trades.reduce((s, t) => s + t.pnl, 0);

    return {
      mode: 'PAPER',
      totalTrades: trades.length,
      openTrades: this.openTrades.size,
      wins: wins.length,
      losses: losses.length,
      winRate: trades.length ? parseFloat((wins.length / trades.length * 100).toFixed(2)) : 0,
      netPnl: parseFloat(netPnl.toFixed(4)),
      returnPct: parseFloat((netPnl / this.startBalance * 100).toFixed(2)),
      currentBalance: parseFloat(this.balance.toFixed(4)),
      riskStatus: this.riskEngine.getStatus(),
    };
  }

  hasOpen(symbol) {
    for (const t of this.openTrades.values()) if (t.symbol === symbol) return true;
    return false;
  }

  /**
   * Start a fresh paper account. Closes open trades at live prices (never at entry), then resets balance and
   * the risk state. Journal history is kept; account_epoch marks where the new account begins.
   */
  resetAccount(balance, priceFor = null) {
    if (!(balance > 0)) throw new Error('Balance must be greater than 0');
    const closed = this.closeAllTrades('ACCOUNT_RESET', priceFor, { strict: false });
    for (const k of Array.from(this.openTrades.keys())) this.openTrades.delete(k);
    this.balance = balance;
    this.startBalance = balance;
    this.closedTrades = [];
    this.riskEngine.cfg.accountBalance = balance;
    Object.assign(this.riskEngine.state, { openPositions: 0, dailyPnL: 0, consecutiveLosses: 0, totalExposure: 0, clusterExposures: {} });
    this._processedSignals.clear();
    return closed;
  }

  getOpenTrades() {
    return Array.from(this.openTrades.values());
  }

  getClosedTrades() {
    return this.closedTrades;
  }
}

module.exports = PaperEngine;
