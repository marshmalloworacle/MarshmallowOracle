'use strict';

const config = require('../config');
const logger = require('../utils/logger');
const journal = require('../journal/store');
const OrderManager = require('./orderManager');

/**
 * Live Execution Safety Layer
 *
 * Operational States:
 * - PAPER: Standard paper simulation mode (safe default)
 * - LIVE_LOCKED: Live mode declared in config, but operator authorization missing
 * - LIVE_AUTHORIZED: All environment and operator gates explicitly confirmed
 * - EMERGENCY_STOP: Trading frozen by emergency kill switch or reconciliation failure
 *
 * LIVE TRADING IS LOCKED BY DEFAULT.
 * No order will be placed unless ALL gates pass.
 */
class LiveExecution {
  constructor(options = {}) {
    this._runtimeConfirmed = false;   // v5.2: no testnet; LIVE always needs explicit operator authorisation
    this.reconciliationEngine = options.reconciliationEngine || null;
    this.riskEngine = options.riskEngine || null;
    this.orders = options.orderManager || new OrderManager({ exchange: options.exchange });
  }

  setReconciliationEngine(reconciliationEngine) {
    this.reconciliationEngine = reconciliationEngine;
  }

  setRiskEngine(riskEngine) {
    this.riskEngine = riskEngine;
  }

  /**
   * Determine current high-level operational state
   */
  getOperationalState() {
    const isEmergency = journal.getState('emergency_stop') === true ||
      (this.riskEngine && this.riskEngine.state.killSwitch);
    if (isEmergency) return 'EMERGENCY_STOP';

    if (config.mode === 'LIVE') {
      if (config.liveEnabled && this._runtimeConfirmed) {
        return 'LIVE_AUTHORIZED';
      }
      return 'LIVE_LOCKED';
    }

    return 'PAPER';
  }

  /**
   * Verify all live gates — returns { ok, reason, failedGate: string | null }
   */
  verifyGates(signal, riskResult) {
    const checks = [
      { name: 'EMERGENCY_STOP_GATE', fn: () => this._checkEmergencyStop() },
      { name: 'MODE_GATE', fn: () => this._checkMode() },
      { name: 'LIVE_FLAG_GATE', fn: () => this._checkLiveFlag() },
      { name: 'CREDENTIALS_GATE', fn: () => this._checkAPICredentials() },
      { name: 'RUNTIME_CONFIRM_GATE', fn: () => this._checkRuntimeConfirm() },
      { name: 'RECONCILIATION_GATE', fn: () => this._checkReconciliation() },
      { name: 'SIGNAL_INTEGRITY_GATE', fn: () => this._checkSignal(signal) },
      { name: 'RISK_APPROVAL_GATE', fn: () => this._checkRiskApproval(riskResult) },
    ];

    for (const check of checks) {
      const res = check.fn();
      if (!res.ok) {
        logger.live(`BLOCKED by ${check.name}: ${res.reason}`);
        return { ok: false, reason: res.reason, failedGate: check.name };
      }
    }

    return { ok: true, reason: 'ALL_GATES_PASSED', failedGate: null };
  }

  _checkEmergencyStop() {
    const isEmergency = journal.getState('emergency_stop') === true ||
      (this.riskEngine && this.riskEngine.state.killSwitch);
    if (isEmergency) {
      return { ok: false, reason: 'EMERGENCY_STOP_ACTIVE: Trading is frozen' };
    }
    return { ok: true };
  }

  _checkMode() {
    if (config.mode !== 'LIVE') {
      return { ok: false, reason: `MODE=${config.mode} (Must be explicitly set to LIVE)` };
    }
    return { ok: true };
  }

  _checkLiveFlag() {
    if (!config.liveEnabled) {
      return { ok: false, reason: 'LIVE_TRADING_ENABLED=false (Must be explicitly set to true)' };
    }
    return { ok: true };
  }

  _checkAPICredentials() {
    const ex = config.exchange;
    if (ex !== 'bybit' && ex !== 'mexc' && ex !== 'bitget') {
      return { ok: false, reason: `EXCHANGE=${ex} cannot place real orders (use bybit, bitget or mexc)` };
    }
    const c = ex === 'mexc' ? config.mexc : ex === 'bitget' ? config.bitget : config.bybit;
    if (ex === 'bitget' && !c.passphrase) return { ok: false, reason: 'Missing BITGET_PASSPHRASE (Bitget API keys need key, secret and passphrase)' };
    if (!c.apiKey || !c.apiSecret) {
      return { ok: false, reason: `Missing ${ex.toUpperCase()} API credentials (${ex.toUpperCase()}_API_KEY / ${ex.toUpperCase()}_API_SECRET)` };
    }
    return { ok: true };
  }

  _checkRuntimeConfirm() {
    if (!this._runtimeConfirmed) {
      return { ok: false, reason: 'Runtime live authorization not set. Operator must call confirmLiveMode()' };
    }
    return { ok: true };
  }

  _checkReconciliation() {
    if (this.reconciliationEngine) {
      const reconStatus = this.reconciliationEngine.getStatus();
      if (reconStatus.status === 'RECONCILIATION_FAILURE') {
        return { ok: false, reason: 'RECONCILIATION_FAILURE: Exchange state does not match local state' };
      }
    }
    return { ok: true };
  }

  _checkSignal(signal) {
    if (!signal || !signal.direction || !signal.entry || !signal.stopLoss || !signal.takeProfit) {
      return { ok: false, reason: 'Invalid or incomplete signal parameters' };
    }
    if (signal.criticalFail) {
      return { ok: false, reason: `Signal failed critical filter: ${signal.criticalFail}` };
    }
    return { ok: true };
  }

  _checkRiskApproval(riskResult) {
    if (!riskResult || !riskResult.approved) {
      return { ok: false, reason: `Risk Engine rejected trade: ${riskResult?.reason}` };
    }
    return { ok: true };
  }

  /** Confirm runtime live mode (must be called explicitly by authorized operator) */
  confirmLiveMode() {
    if (config.mode !== 'LIVE' || !config.liveEnabled) {
      throw new Error('Cannot confirm live mode — TRADING_MODE=LIVE and LIVE_TRADING_ENABLED=true are required');
    }
    this._runtimeConfirmed = true;
    logger.live('⚠ LIVE TRADING AUTHORIZED: Runtime operator confirmation confirmed');
  }

  /** Revoke runtime live mode */
  revokeLiveMode() {
    this._runtimeConfirmed = false;
    logger.live('Live trading authorization revoked');
  }

  /**
   * Submit a live order. All gates must pass first, then the order goes through the OrderManager
   * (persist-before-send, duplicate-proof client id, ambiguity handling, protection verification).
   * @param {object} signal        approved signal (entry / stopLoss / takeProfit / direction / symbol)
   * @param {number} positionSize  quantity in base units, already fitted by the risk engine
   * @param {object} riskResult    risk engine verdict ({ approved, leverage? })
   */
  async submitOrder(signal, positionSize, riskResult = { approved: true }, opts = {}) {
    const gates = this.verifyGates(signal, riskResult);
    if (!gates.ok) {
      return { success: false, reason: gates.reason, failedGate: gates.failedGate };
    }
    const leverage = opts.leverage || riskResult.leverage || (this.riskEngine && this.riskEngine.cfg.leverage) || config.defaultLeverage;
    logger.live(`LIVE ORDER: gates passed -> ${signal.direction} ${signal.symbol} qty=${positionSize} lev=${leverage}x SL=${signal.stopLoss} TP=${signal.takeProfit}`);
    const res = await this.orders.submitEntry(signal, positionSize, { leverage, ...opts });
    if (!res.success) logger.live(`LIVE ORDER NOT PLACED: ${res.reason}`);
    return { ...res, state: res.state, operationalState: this.getOperationalState() };
  }
}

module.exports = LiveExecution;
