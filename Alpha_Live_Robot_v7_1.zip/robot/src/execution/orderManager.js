'use strict';

/**
 * Live order lifecycle manager (exchange-agnostic: Bybit or MEXC through the exchange facade).
 *
 * Every order is persisted BEFORE it is sent and moves through explicit states:
 *   INTENT -> SUBMITTING -> ACCEPTED -> PARTIAL -> FILLED -> CLOSED
 *                       \-> REJECTED | CANCEL_PENDING -> CANCELLED | UNKNOWN (must be reconciled)
 * Rules this class enforces:
 *  - clientOrderId is derived from the signal, so a retry / restart / duplicate event can never open a 2nd order.
 *  - An ambiguous outcome (timeout, 5xx) is never retried blind: we query the exchange by clientOrderId first.
 *    If it still cannot be resolved, state=UNKNOWN and NEW ENTRIES ARE BLOCKED until reconcile() resolves it.
 *  - HTTP success != filled. Fills and protection are confirmed by querying the exchange.
 *  - A filled position without a verified exchange-side stop-loss raises an incident: entries are blocked and an
 *    urgent alert goes out. LIVE_UNPROTECTED_POLICY=alert (default) leaves the position alone;
 *    =close sends a reduce-only market close.
 */
const crypto = require('node:crypto');
const config = require('../config');
const logger = require('../utils/logger');

const ACTIVE = new Set(['INTENT', 'SUBMITTING', 'ACCEPTED', 'PARTIAL', 'FILLED', 'CANCEL_PENDING', 'UNKNOWN']);
const KEY = 'live_orders';
const BLOCK_KEY = 'live_entries_blocked';

function defaultStore() {
  const j = require('../journal/store');
  return { get: (k) => j.getState(k), set: (k, v) => j.setState(k, v) };
}

class OrderManager {
  constructor({ exchange, store, notifier, now, onEvent } = {}) {
    this.onEvent = onEvent || null;          // (event) => void, wired to the alert centre by the robot
    this.exchange = exchange || require('../exchanges/index');
    this.store = store || defaultStore();
    this.notifier = notifier || null;
    this.now = now || (() => Date.now());
  }

  // ── persistence ───────────────────────────────────────────────────────────────────────────────────
  _all() { return this.store.get(KEY) || {}; }
  _save(rec) { const all = this._all(); all[rec.id] = rec; this.store.set(KEY, all); return rec; }
  _move(rec, state, note) {
    rec.state = state; rec.updatedAt = this.now();
    (rec.history = rec.history || []).push({ at: rec.updatedAt, state, note: note || '' });
    if (rec.history.length > 30) rec.history.shift();
    this._save(rec);
    this._emit(rec, state, note);
    return rec;
  }
  _emit(rec, state, note) {
    if (!this.onEvent) return;
    const sym = rec.symbol, side = rec.direction;
    const text = {
      ACCEPTED: [`Order placed: ${side} ${sym}`, `qty ${rec.qty} @ ${rec.price || 'market'} · ${rec.leverage}x isolated · SL ${rec.stopLoss} · TP ${rec.takeProfit}`, 'INFO'],
      PARTIAL: [`Partly filled: ${side} ${sym}`, `${rec.filledQty}/${rec.qty} @ ${rec.avgPrice || '-'}`, 'INFO'],
      FILLED: [`Filled: ${side} ${sym}`, `${rec.filledQty || rec.qty} @ ${rec.avgPrice || '-'}`, 'INFO'],
      CANCELLED: [`Entry cancelled: ${sym}`, note || '', 'INFO'],
      REJECTED: [`Order rejected: ${sym}`, note || '', 'WARNING'],
      UNKNOWN: [`Order outcome unknown: ${sym}`, `${note || ''} - entries blocked until resolved`, 'CRITICAL'],
      CLOSED: [`Position closed: ${sym}`, note || '', 'INFO'],
    }[state];
    if (!text) return;
    try { this.onEvent({ category: state === 'UNKNOWN' || state === 'REJECTED' ? 'safety' : 'orders', severity: text[2], title: text[0], message: text[1] }); } catch (_) { /* never break trading on alert failure */ }
  }
  list(onlyActive = false) { return Object.values(this._all()).filter(r => !onlyActive || ACTIVE.has(r.state)); }
  get(id) { return this._all()[id] || null; }

  // ── entry blocking ────────────────────────────────────────────────────────────────────────────────
  blocked() { return this.store.get(BLOCK_KEY); }
  block(reason) {
    // v6.7: with force-clear ON, a condition that was already force-cleared is not re-raised for 30 min (no 15s flip-flop).
    const fc = this._forced && this._forced.get(reason);
    if (this.forceClear() && fc && this.now() - fc < 30 * 60 * 1000) { logger.live(`ENTRY BLOCK suppressed (force-clear ON, already cleared): ${reason}`); return; }
    const prior = this.blocked();
    if (prior && prior.reason === reason) return;      // v6.7: same condition re-detected - keep the original timestamp so the 15s clock is not reset
    this.store.set(BLOCK_KEY, { reason, at: this.now() });
    logger.live(`ENTRIES BLOCKED: ${reason}`);
    if (this.onEvent) this.onEvent({ category: 'safety', severity: 'CRITICAL', title: 'LIVE ENTRIES BLOCKED', message: reason });
    if (this.notifier?.notifyWatchdogWarning) this.notifier.notifyWatchdogWarning([`LIVE ENTRIES BLOCKED: ${reason}`]).catch(() => {});
  }
  unblock() { this.store.set(BLOCK_KEY, null); }

  /** v6.7: true when the operator chose "clear entry block after the wait even if unresolved" (dashboard setting wins over .env). */
  forceClear() {
    let v = null; try { v = this.store.get('entry_block_force_clear'); } catch (_) { /* ignore */ }
    return v === null || v === undefined ? !!config.entryBlockForceClear : v === true;
  }
  setForceClear(on) { this.store.set('entry_block_force_clear', !!on); return !!on; }

  /** v6.7: what the dashboard shows - never invented: reads the persisted block + last clear. */
  blockStatus() {
    const b = this.blocked(); const wait = config.entryBlockAutoClearSec;
    let last = null; try { last = this.store.get('entry_block_last_cleared') || null; } catch (_) { /* ignore */ }
    return {
      blocked: !!b, reason: b ? b.reason : null, since: b ? b.at : null,
      remainingSec: b && wait > 0 ? Math.max(0, Math.ceil((wait * 1000 - (this.now() - b.at)) / 1000)) : null,
      autoClearSec: wait, mode: this.forceClear() ? 'FORCE' : 'VERIFIED', lastCleared: last,
    };
  }

  /**
   * v6.7: auto-clear the entry block ENTRIES_BLOCKED after ENTRY_BLOCK_AUTOCLEAR_SEC (default 15).
   * VERIFIED (default): re-check the exchange (reconcile) first; clear only when no UNKNOWN order and no filled position
   *   without a verified exchange stop-loss remains. Otherwise the block stays and the reason is reported.
   * FORCE: clear after the wait regardless. The position-protection loop keeps working on any unprotected position
   *   and SYMBOL_BUSY still prevents a second order on the same symbol.
   */
  async autoClear() {
    const b = this.blocked(); if (!b) return { cleared: false, blocked: false };
    const wait = config.entryBlockAutoClearSec;
    if (!(wait > 0)) return { cleared: false, pending: false, disabled: true };
    const age = this.now() - b.at;
    if (age < wait * 1000) return { cleared: false, pending: true, remainingSec: Math.ceil((wait * 1000 - age) / 1000) };
    const forced = this.forceClear();
    if (this._lastAutoReconcile === undefined || this.now() - this._lastAutoReconcile >= wait * 1000) {
      this._lastAutoReconcile = this.now();
      try { await this.reconcile(); } catch (e) { logger.warn(`entry-block verify: reconcile failed (${e.message})`); }
    }
    const cur = this.blocked();
    if (!cur) return this._cleared(b, 'verified', 'resolved by exchange reconciliation');
    const open = this.list(true).filter(r => r.state === 'UNKNOWN' || ((r.state === 'FILLED' || r.state === 'PARTIAL') && r.protected !== true));
    if (!open.length) { this.unblock(); return this._cleared(b, 'verified', 'no unresolved order or unprotected position on the exchange'); }
    if (forced) {
      (this._forced = this._forced || new Map()).set(cur.reason, this.now());
      this.unblock();
      return this._cleared(b, 'forced', `force-clear: ${open.map(r => `${r.symbol}:${r.state}${r.protected === false ? '/no-stop' : ''}`).join(', ')} still unresolved`);
    }
    return { cleared: false, pending: false, waitingOn: open.map(r => ({ symbol: r.symbol, state: r.state, protected: r.protected === true })) };
  }
  _cleared(b, mode, note) {
    const rec = { at: this.now(), mode, prevReason: b.reason, note };
    try { this.store.set('entry_block_last_cleared', rec); } catch (_) { /* ignore */ }
    logger.live(`ENTRY BLOCK CLEARED (${mode}): ${note}`);
    if (this.onEvent) this.onEvent({ category: 'safety', severity: 'INFO', title: 'Entry block cleared', message: `${mode === 'forced' ? 'Force-cleared' : 'Verified'}: ${note}` });
    return { cleared: true, ...rec };
  }

  /** Deterministic id (<= 32 chars: MEXC limit) so duplicates collapse to the same order. */
  static clientId(signal) {
    const seed = `${signal.id || ''}|${signal.symbol}|${signal.direction}|${signal.strategy || ''}|${signal.timestamp || signal.createdAt || ''}|${signal.entry}`;
    return `gps${crypto.createHash('sha1').update(seed).digest('hex').slice(0, 24)}`;
  }

  /**
   * Submit an entry. `fit` = { qty } already sized/rounded by the risk engine.
   * Returns { success, state, order?, reason?, duplicate? }
   */
  async submitEntry(signal, qty, { leverage, orderType = config.liveOrderType, offsetBps = config.liveEntryOffsetBps, manual = false } = {}) {
    const blocked = this.blocked();
    if (blocked) return { success: false, reason: `ENTRIES_BLOCKED: ${blocked.reason}`, state: 'BLOCKED' };
    const dirGate = require('../control/direction').check(signal.direction, { manual: !!manual, isLive: true });   // v7.1: Manual Take overrides the direction MODE (ALLOW_* still apply)
    if (!dirGate.allowed) return { success: false, reason: dirGate.reason, state: 'BLOCKED' };
    if (!(qty > 0)) return { success: false, reason: 'INVALID_QTY', state: 'REJECTED' };

    const id = OrderManager.clientId(signal);
    const existing = this.get(id);
    if (existing && ACTIVE.has(existing.state)) return { success: true, duplicate: true, state: existing.state, order: existing };
    // one position per symbol: block if another active order / exchange position exists
    const clash = this.list(true).find(r => r.symbol === signal.symbol);
    if (clash) return { success: false, reason: `SYMBOL_BUSY: active order ${clash.id} (${clash.state})`, state: 'REJECTED' };
    try {
      const pos = await this.exchange.getPositions();
      if (pos.some(p => p.symbol === signal.symbol)) return { success: false, reason: 'SYMBOL_BUSY: open exchange position', state: 'REJECTED' };
    } catch (e) { return { success: false, reason: `POSITION_CHECK_FAILED: ${e.message}`, state: 'REJECTED' }; }   // fail closed

    const long = signal.direction === 'LONG';
    const price = orderType === 'Limit' ? Number((signal.entry * (1 + (long ? 1 : -1) * (offsetBps / 10000))).toPrecision(8)) : undefined;
    const rec = { id, symbol: signal.symbol, direction: signal.direction, side: long ? 'Buy' : 'Sell', qty, price, orderType, leverage,
      stopLoss: signal.stopLoss, takeProfit: signal.takeProfit, strategy: signal.strategy || null, entry: signal.entry, atr: signal.atr || null, regime: signal.regime || null,
      state: 'INTENT', createdAt: this.now(), updatedAt: this.now(), filledQty: 0, orderId: null, protected: null, history: [] };
    this._move(rec, 'INTENT', 'persisted before submit');          // persisted first: survives a crash mid-submit
    this._move(rec, 'SUBMITTING');

    try {
      const r = await this.exchange.placeOrder({ symbol: signal.symbol, side: rec.side, qty, orderType, price, leverage,
        clientOrderId: id, stopLoss: signal.stopLoss, takeProfit: signal.takeProfit });
      rec.orderId = r.orderId;
      this._move(rec, 'ACCEPTED', `exchange id ${r.orderId}`);
      return { success: true, state: 'ACCEPTED', order: rec };
    } catch (err) {
      if (!err.ambiguous) { this._move(rec, 'REJECTED', err.message); return { success: false, reason: err.message, state: 'REJECTED', order: rec }; }
      // Ambiguous: ask the exchange before anything else. Never resubmit blindly.
      this._move(rec, 'UNKNOWN', `ambiguous: ${err.message}`);
      const found = await this._lookup(rec);
      if (found) { this._apply(rec, found); return { success: true, state: rec.state, order: rec, recovered: true }; }
      this.block(`order ${id} (${signal.symbol}) outcome unknown - reconcile before trading`);
      return { success: false, reason: 'AMBIGUOUS_SUBMISSION', state: 'UNKNOWN', order: rec };
    }
  }

  async _lookup(rec) {
    try { return await this.exchange.getOrder(rec.symbol, { clientOrderId: rec.id }); } catch (_) { return null; }
  }

  _apply(rec, ex) {
    rec.orderId = ex.orderId || rec.orderId;
    rec.filledQty = ex.filledQty || 0; rec.avgPrice = ex.avgPrice || rec.avgPrice; rec.fee = ex.fee || rec.fee;
    const map = { New: 'ACCEPTED', Created: 'ACCEPTED', PartiallyFilled: 'PARTIAL', Filled: 'FILLED', Cancelled: 'CANCELLED', Rejected: 'REJECTED' };
    const next = map[ex.status];
    if (next && next !== rec.state) this._move(rec, next, `exchange status ${ex.status}`);
    return rec;
  }

  /**
   * Periodic pass (call from the robot loop): sync every active order with the exchange, cancel stale unfilled
   * entries, verify protection on fills, resolve UNKNOWN orders, detect closed positions.
   */
  async reconcile() {
    const summary = { checked: 0, cancelled: 0, protectedOk: 0, incidents: 0, closed: 0 };
    let positions = null;
    try { positions = await this.exchange.getPositions(); } catch (e) { logger.warn(`reconcile: positions unavailable (${e.message})`); }
    for (const rec of this.list(true)) {
      summary.checked++;
      try {
        if (rec.state !== 'FILLED') {
          const ex = await this._lookup(rec);
          if (ex) this._apply(rec, ex);
          else if (rec.state === 'UNKNOWN' && this.now() - rec.updatedAt > 60000) {
            this._move(rec, 'REJECTED', 'not found on exchange after 60s - treated as never placed');
            if (!this.list(true).some(r => r.state === 'UNKNOWN')) this.unblock();
          }
        }
        // stale unfilled entry -> cancel (never leave a resting entry far from market)
        if ((rec.state === 'ACCEPTED') && this.now() - rec.createdAt > config.liveEntryTtlSec * 1000) {
          this._move(rec, 'CANCEL_PENDING', 'entry TTL expired');
          try { await this.exchange.cancelOrder(rec.symbol, rec.orderId); summary.cancelled++; } catch (e) { logger.warn(`cancel failed ${rec.id}: ${e.message}`); }
        }
        if (rec.state === 'CANCEL_PENDING') { const ex = await this._lookup(rec); if (ex?.status === 'Cancelled') this._move(rec, 'CANCELLED'); else if (ex) this._apply(rec, ex); }
        if (rec.state === 'PARTIAL' || rec.state === 'FILLED') {
          const ok = await this.verifyProtection(rec);
          if (ok) summary.protectedOk++; else summary.incidents++;
        }
        if (rec.state === 'FILLED' && positions && !positions.some(p => p.symbol === rec.symbol)) { this._move(rec, 'CLOSED', 'position no longer open'); summary.closed++; }
      } catch (e) { logger.warn(`reconcile ${rec.id}: ${e.message}`); }
    }
    return summary;
  }

  // ── manual close / flatten (reduce-only market orders; never opens or increases a position) ───────
  async cancelAllEntries() {
    const out = { cancelled: [], failed: [] };
    let open = [];
    try { open = await this.exchange.getOpenOrders(); } catch (e) { out.failed.push({ error: `open orders unreadable: ${e.message}` }); return out; }
    for (const o of open.filter(o => !o.reduceOnly)) {
      try { await this.exchange.cancelOrder(o.symbol, o.orderId); out.cancelled.push(o.symbol); }
      catch (e) { out.failed.push({ symbol: o.symbol, error: e.message }); }
    }
    for (const r of this.list(true).filter(r => r.state === 'ACCEPTED' || r.state === 'CANCEL_PENDING' || r.state === 'INTENT')) this._move(r, 'CANCELLED', 'cancelled by operator');
    return out;
  }

  async closePosition(symbol, reason = 'manual') {
    let pos;
    try { pos = (await this.exchange.getPositions()).find(p => p.symbol === symbol); }
    catch (e) { return { ok: false, symbol, reason: `positions unreadable: ${e.message}` }; }
    if (!pos) return { ok: false, symbol, reason: 'NO_OPEN_POSITION' };
    const side = pos.side === 'LONG' ? 'Sell' : 'Buy';
    const clientOrderId = `cl${crypto.createHash('sha1').update(`${symbol}|${this.now()}|${Math.random()}`).digest('hex').slice(0, 24)}`;
    try {
      const r = await this.exchange.placeOrder({ symbol, side, qty: pos.qty, orderType: 'Market', reduceOnly: true, clientOrderId });
      logger.live(`CLOSE ${symbol} (${reason}): reduce-only market ${side} ${pos.qty} id=${r.orderId}`);
      if (this.onEvent) this.onEvent({ category: 'orders', severity: 'WARNING', title: `Closing ${symbol}`, message: `${reason}: reduce-only market ${side} ${pos.qty}` });
      return { ok: true, symbol, orderId: r.orderId, qty: pos.qty, reason };
    } catch (e) {
      // outcome may be unknown: re-read before reporting failure
      try { const still = (await this.exchange.getPositions()).find(p => p.symbol === symbol); if (!still) return { ok: true, symbol, reason: 'position is gone', verified: true }; } catch (_) { /* fall through */ }
      return { ok: false, symbol, reason: e.message, ambiguous: !!e.ambiguous };
    }
  }

  async flatten(reason = 'flatten all') {
    const res = { closed: [], failed: [] };
    let positions = [];
    try { positions = await this.exchange.getPositions(); } catch (e) { return { ...res, failed: [{ symbol: '*', reason: `positions unreadable: ${e.message}` }] }; }
    for (const p of positions) { const r = await this.closePosition(p.symbol, reason); (r.ok ? res.closed : res.failed).push(r); }
    try { res.remaining = (await this.exchange.getPositions()).map(p => p.symbol); } catch (_) { res.remaining = null; }
    return res;
  }

  /** True only when the exchange REPORTS a stop-loss on this position. Never assumes it exists. */
  async verifyProtection(rec) {
    let stops = [];
    try { stops = await this.exchange.getStopOrders(rec.symbol); } catch (e) { logger.warn(`protection check failed: ${e.message}`); }
    const long = rec.direction === 'LONG';
    const sl = stops.find(s => s.stopLoss && (s.long === undefined || s.long === long));
    const tol = Math.abs(rec.entry - rec.stopLoss) * 0.25;   // within a quarter of the stop distance
    // v6.5.1: a stop that trailing / break-even has TIGHTENED (moved closer to or past entry on the protective side) is still a verified stop.
    // Only a stop that is missing, or LOOSER than the original, counts as unprotected. Previously any moved stop looked "missing" and blocked all new entries.
    const same = !!sl && Math.abs(sl.stopLoss - rec.stopLoss) <= Math.max(tol, rec.stopLoss * 0.001);
    const tighter = !!sl && sl.stopLoss > 0 && (long ? sl.stopLoss > rec.stopLoss : sl.stopLoss < rec.stopLoss);
    const ok = same || tighter;
    const first = rec.protected !== true;
    rec.protected = ok; rec.protectionCheckedAt = this.now(); this._save(rec);
    if (ok) { if (first && this.onEvent) this.onEvent({ category: 'orders', severity: 'INFO', title: `Stop-loss confirmed: ${rec.symbol}`, message: `exchange-side SL ${rec.stopLoss} verified` }); return true; }
    logger.live(`UNPROTECTED POSITION: ${rec.symbol} has no verified exchange stop-loss`);
    this.block(`${rec.symbol} filled without a verified stop-loss`);
    if (config.liveUnprotectedPolicy === 'close') {
      try {
        await this.exchange.placeOrder({ symbol: rec.symbol, side: long ? 'Sell' : 'Buy', qty: rec.filledQty || rec.qty, orderType: 'Market', reduceOnly: true, clientOrderId: `${rec.id.slice(0, 26)}_cl` });
        this._move(rec, 'CLOSED', 'closed by LIVE_UNPROTECTED_POLICY=close');
      } catch (e) { logger.live(`EMERGENCY CLOSE FAILED for ${rec.symbol}: ${e.message}`); }
    }
    return false;
  }
}

module.exports = OrderManager;
module.exports.ACTIVE = ACTIVE;
