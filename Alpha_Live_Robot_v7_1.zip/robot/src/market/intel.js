'use strict';
/**
 * Market Intelligence. Every metric carries source + scope + timestamp; anything we cannot measure is UNKNOWN, never invented.
 *  - MARKET-WIDE: breadth / median 24h move / funding come from Bybit linear tickers (top-N by turnover, exchange-wide, 24h rolling)
 *  - BTC/ETH trend + volatility come from candles (existing detectRegime)
 *  - Buy/sell pressure: UNAVAILABLE (tickers carry no aggressor-side volume; long/short account ratios are NOT volume)
 * Regime state has hysteresis (2 consecutive reads + 10 min minimum, except SHOCK which enters immediately and exits after 30 min).
 */
const journal = require('../journal/store');
const { detectRegime } = require('./regime');
const pcfg = require('../protection/config');
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
const med = (a) => { const s = a.filter(Number.isFinite).sort((x, y) => x - y); return s.length ? (s[Math.floor((s.length - 1) / 2)] + s[Math.ceil((s.length - 1) / 2)]) / 2 : null; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const MIN_HOLD_MS = 10 * 60e3, SHOCK_HOLD_MS = 30 * 60e3;

function btcMove(candles, bars) { if (!candles || candles.length <= bars) return null; const a = candles[candles.length - 1 - bars].close, b = candles[candles.length - 1].close; return a > 0 ? (b - a) / a * 100 : null; }

/** tickers: raw Bybit list; candles: { BTCUSDT:{4h,1h,15m}, ETHUSDT:{...} } */
function compute({ tickers, candles, topN = 100, now = Date.now(), prevRegime = null, turnoverSnaps = [] }) {
  const c = pcfg.get();
  const usdt = (tickers || []).filter(t => /USDT$/.test(t.symbol) && num(t.turnover24h) > 0).sort((a, b) => num(b.turnover24h) - num(a.turnover24h)).slice(0, topN);
  const ch = usdt.map(t => num(t.price24hPcnt) * 100).filter(Number.isFinite);
  const breadth = ch.length >= 20 ? ch.filter(v => v > 0).length / ch.length * 100 : null;
  const median24h = med(ch);
  const funding = med(usdt.map(t => num(t.fundingRate)).filter(Number.isFinite));
  const turnover = usdt.reduce((s, t) => s + (num(t.turnover24h) || 0), 0);
  const snaps = [...turnoverSnaps]; if (!snaps.length || now - snaps[snaps.length - 1].ts >= 10 * 60e3) snaps.push({ ts: now, v: turnover });
  const old = snaps.filter(s => now - s.ts >= 50 * 60e3).pop();
  const volChange = old && old.v > 0 ? (turnover - old.v) / old.v * 100 : null;

  const per = {};
  for (const sym of ['BTCUSDT', 'ETHUSDT']) {
    const k = candles && candles[sym]; const t = (tickers || []).find(x => x.symbol === sym);
    const r = k && k['4h'] ? detectRegime(k['4h'], k['1h'], k['15m']) : null;
    per[sym] = { trend: r ? r.trend : 'UNKNOWN', regime: r ? r.canonicalRegime : 'UNKNOWN', confidence: r ? r.confidence : null, volatility: r ? r.volatility : 'UNKNOWN', atrRatio: r ? r.atrRatio : null,
      ch24: t ? num(t.price24hPcnt) * 100 : null, ch1h: k ? btcMove(k['1h'], 1) : null };
  }
  const btc = per.BTCUSDT, eth = per.ETHUSDT;

  // sentiment 0-100 (transparent weights; null parts are skipped and lower confidence, never faked)
  const parts = []; let score = 50;
  if (breadth != null) { score += (breadth - 50) * 0.5; parts.push(breadth > 52 ? 1 : breadth < 48 ? -1 : 0); }
  if (btc.ch24 != null) { score += clamp(btc.ch24, -5, 5) * 3; parts.push(btc.ch24 > 0.3 ? 1 : btc.ch24 < -0.3 ? -1 : 0); }
  if (btc.trend !== 'UNKNOWN') { score += btc.trend === 'BULLISH' ? 8 : btc.trend === 'BEARISH' ? -8 : 0; parts.push(btc.trend === 'BULLISH' ? 1 : btc.trend === 'BEARISH' ? -1 : 0); }
  if (eth.trend !== 'UNKNOWN') { score += eth.trend === 'BULLISH' ? 4 : eth.trend === 'BEARISH' ? -4 : 0; }
  if (median24h != null) { score += clamp(median24h, -4, 4) * 2; parts.push(median24h > 0.2 ? 1 : median24h < -0.2 ? -1 : 0); }
  score = Math.round(clamp(score, 0, 100));
  const pos = parts.filter(p => p > 0).length, neg = parts.filter(p => p < 0).length;
  const confidence = parts.length >= 3 ? Math.round(Math.max(pos, neg) / parts.length * 100 * Math.min(1, parts.length / 4)) : null;
  const label = parts.length < 3 ? 'UNKNOWN' : score >= 60 ? 'BULLISH' : score <= 40 ? 'BEARISH' : 'NEUTRAL';

  // regime (market-wide, from BTC) with hysteresis
  const shock = btc.ch1h != null && Math.abs(btc.ch1h) >= c.shockPct;
  let raw = 'UNCERTAIN';
  if (btc.regime === 'UNKNOWN') raw = 'UNCERTAIN';
  else if (shock) raw = 'MARKET_SHOCK';
  else if (btc.volatility === 'HIGH' || (btc.atrRatio != null && btc.atrRatio >= 1.8)) raw = 'HIGH_VOLATILITY';
  else if ((btc.confidence || 0) < 50) raw = 'UNCERTAIN';
  else if (btc.trend === 'BULLISH') raw = 'BULL_TREND'; else if (btc.trend === 'BEARISH') raw = 'BEAR_TREND'; else raw = 'RANGE';
  const rg = { ...(prevRegime || { state: raw, since: now, pending: null, pendingCount: 0 }) };
  if (raw === rg.state) { rg.pending = null; rg.pendingCount = 0; }
  else {
    if (rg.pending === raw) rg.pendingCount++; else { rg.pending = raw; rg.pendingCount = 1; }
    const held = now - rg.since;
    const enterShock = raw === 'MARKET_SHOCK';
    const leaveShock = rg.state === 'MARKET_SHOCK' ? held >= SHOCK_HOLD_MS : true;
    if ((enterShock || (rg.pendingCount >= 2 && held >= MIN_HOLD_MS)) && leaveShock) { rg.state = raw; rg.since = now; rg.pending = null; rg.pendingCount = 0; }
  }
  const bias = rg.state === 'MARKET_SHOCK' || rg.state === 'HIGH_VOLATILITY' ? 'DEFENSIVE' : rg.state === 'BULL_TREND' && score >= 60 ? 'LONG_BIAS' : rg.state === 'BEAR_TREND' && score <= 40 ? 'SHORT_BIAS' : 'NEUTRAL';
  const out = { ts: now, sentiment: { score: parts.length >= 3 ? score : null, label, confidence, scope: 'market-wide estimate', method: 'breadth + BTC/ETH trend + BTC 24h + median 24h move' },
    btc, eth, breadth: { upPct: breadth, n: ch.length, scope: `${require('../config').exchangeLabel} USDT perps, top ${ch.length} by 24h turnover`, source: `${require('../config').exchangeLabel} tickers` },
    median24hPct: median24h, funding: { median: funding, scope: 'exchange-wide median, top-N perps', source: `${require('../config').exchangeLabel} tickers` },
    volume: { turnover24h: turnover || null, changePct: volChange, note: volChange == null ? 'UNKNOWN until ~1h of snapshots' : 'change of rolling 24h turnover vs ~1h ago', source: 'Bybit tickers' },
    flow: { status: 'UNAVAILABLE', note: 'Exchange tickers expose no buy/sell aggressor volume; account long/short ratio is not trade volume' },
    shock: { active: rg.state === 'MARKET_SHOCK', btc1hPct: btc.ch1h, thresholdPct: c.shockPct },
    regime: { state: rg.state, rawNow: raw, since: rg.since, pending: rg.pending, why: `BTC ${btc.regime} / vol ${btc.volatility} / conf ${btc.confidence ?? '?'}%` },
    bias: { recommendation: bias, confidence, note: 'recommendation only unless "Adaptive direction" is switched on; manual direction control always wins' } };
  return { intel: out, regimeState: rg, turnoverSnaps: snaps.slice(-30) };
}

/** robot-side: fetch + compute + persist (<= once per minute) */
async function refresh({ bybit, dataFeed, now = Date.now(), minGapMs = 60e3 }) {
  const prev = journal.getState('market_intel');
  if (prev && now - prev.ts < minGapMs) return prev;
  const tickers = await bybit.getTickers();
  const candles = {};
  for (const sym of ['BTCUSDT', 'ETHUSDT']) { try { candles[sym] = await dataFeed.getMultiTimeframe(sym, ['4h', '1h', '15m'], 200); } catch (_) { /* leaves that asset UNKNOWN */ } }
  const r = compute({ tickers, candles, now, prevRegime: journal.getState('market_regime'), turnoverSnaps: journal.getState('intel_turnover') || [] });
  journal.setState('market_intel', r.intel); journal.setState('market_regime', r.regimeState); journal.setState('intel_turnover', r.turnoverSnaps);
  const b = journal.getState('bias_track') || {};
  if (b.rec !== r.intel.bias.recommendation) journal.setState('bias_track', { rec: r.intel.bias.recommendation, since: now }); 
  return r.intel;
}
module.exports = { compute, refresh };
