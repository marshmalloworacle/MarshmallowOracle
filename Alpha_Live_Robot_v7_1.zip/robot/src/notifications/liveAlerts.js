'use strict';

/**
 * Live alert centre. Every event goes to (1) the dashboard feed (persisted, last 100) and (2) Telegram through the
 * existing notifier. Categories can be switched off in .env (LIVE_ALERT_EVENTS=slots,orders,safety,heartbeat).
 * Spam control: a per-key cooldown, and related changes are grouped into ONE message by the caller.
 * Alerts never contain credentials: callers pass only market/account figures.
 */
const config = require('../config');
const logger = require('../utils/logger');

const FEED_KEY = 'live_alerts';
const FEED_MAX = 100;
const ICON = { INFO: 'ℹ️', WARNING: '⚠️', CRITICAL: '🚨' };

class AlertCenter {
  constructor({ notifier, store, now, categories } = {}) {
    this.notifier = notifier || null;
    this.store = store || (() => { const j = require('../journal/store'); return { get: (k) => j.getState(k), set: (k, v) => j.setState(k, v) }; })();
    this.now = now || (() => Date.now());
    this.categories = categories || config.liveAlertEvents || ['slots', 'orders', 'safety', 'heartbeat'];
    this.lastByKey = new Map();
  }

  enabled(cat) { return this.categories.includes(cat); }
  feed() { return this.store.get(FEED_KEY) || []; }

  /** @returns {Promise<boolean>} true when the alert was recorded */
  async emit({ category, severity = 'INFO', title, message = '', key = null, cooldownMs = 0 }) {
    if (!this.enabled(category)) return false;
    const now = this.now();
    if (key && cooldownMs > 0) {
      const last = this.lastByKey.get(key);
      if (last && now - last < cooldownMs) return false;
      this.lastByKey.set(key, now);
    }
    try {
      const feed = this.feed(); feed.push({ ts: now, category, severity, title, message });
      this.store.set(FEED_KEY, feed.slice(-FEED_MAX));
    } catch (e) { logger.warn(`alert feed write failed: ${e.message}`); }
    logger.live(`ALERT [${category}/${severity}] ${title}${message ? ' - ' + message.replace(/\n/g, ' | ') : ''}`);
    if (this.notifier && this.notifier.dispatch) {
      try {
        await this.notifier.dispatch({ type: `LIVE_${category.toUpperCase()}`, severity: severity === 'CRITICAL' ? 'CRITICAL' : severity, title: `${ICON[severity] || ''} ${title}`.trim(), message, force: true });
      } catch (e) { logger.warn(`telegram alert failed: ${e.message}`); }
    }
    return true;
  }
}

module.exports = AlertCenter;
