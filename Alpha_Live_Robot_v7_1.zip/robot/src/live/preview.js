'use strict';
/**
 * Order preview: what WOULD the robot do with this idea? Pure computation (no exchange writes, no order is ever sent).
 * Uses the same sizing function, scaling profile and liquidation maths as the live path, so the preview matches reality.
 */
const config = require('../config');
const scaling = require('../risk/scaling');
const { liquidationPrice } = require('../risk/engine');

const TAKER_FEE_FALLBACK = 0.00055;   // Bybit USDT-perp taker fee (assumption, shown as such); MEXC reports its own per contract

function previewOrder({ input, account, profile, positions = [], rules, takerFee, flags = {}, riskState = {} }) {
  const checks = []; const add = (name, ok, detail) => checks.push({ name, ok, detail });
  const out = { checks, sizing: null, fees: null, liquidation: null, wouldAccept: false };
  const symbol = String(input.symbol || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const dir = String(input.direction || '').toUpperCase();
  const entry = Number(input.entry), sl = Number(input.stopLoss), tp = Number(input.takeProfit);

  const valid = symbol && (dir === 'LONG' || dir === 'SHORT') && entry > 0 && sl > 0 && tp > 0;
  add('inputs', !!valid, valid ? `${dir} ${symbol} @ ${entry}` : 'need symbol, direction, entry, stop-loss and take-profit');
  if (!valid) return out;
  const long = dir === 'LONG';
  const slOk = long ? sl < entry : sl > entry; const tpOk = long ? tp > entry : tp < entry;
  add('stop-loss on the right side', slOk, slOk ? 'ok' : `a ${dir} stop must be ${long ? 'below' : 'above'} entry`);
  add('take-profit on the right side', tpOk, tpOk ? 'ok' : `a ${dir} target must be ${long ? 'above' : 'below'} entry`);
  if (!slOk || !tpOk) return out;

  const dist = Math.abs(entry - sl), rr = Math.abs(tp - entry) / dist;
  add(`reward:risk >= ${config.minRR}`, rr >= config.minRR, `R:R ${rr.toFixed(2)}`);
  if (!account || !(account.equity > 0)) { add('exchange account', false, 'account equity not available (check System Health)'); return out; }
  if (!rules) { add('exchange rules', false, `no contract rules for ${symbol} (not a tradable USDT perp, or rules not loaded)`); return out; }
  add('exchange rules', true, `step ${rules.qtyStep}, min qty ${rules.minQty}, min notional $${rules.minNotional}`);

  const p = profile || scaling.computeProfile({ equity: account.equity, config: config.scaling });
  const fit = scaling.fitPosition({ entry, stopLoss: sl, equity: account.equity, riskPerTrade: p.riskPerTrade, leverage: p.leverage, marginPerSlot: p.marginPerSlot,
    rules, minSizeRiskCap: config.scaling.minSizeRiskCap, sizing: config.scaling.sizing, marginPct: config.scaling.marginPct });
  add('position size fits rules and risk budget', fit.ok, fit.ok ? `${fit.qty} units${fit.bumped ? ' (exchange minimum size)' : fit.shrunk ? ' (cut to margin/risk budget)' : ''}` : fit.reason);
  if (!fit.ok) return out;
  out.sizing = { qty: fit.qty, notional: fit.notional, margin: fit.margin, riskUsd: fit.riskUsd, riskPctEquity: fit.riskUsd / account.equity, leverage: p.leverage,
    rewardUsd: fit.qty * Math.abs(tp - entry), rr, mode: config.scaling.sizing };

  const fee = Number.isFinite(takerFee) && takerFee > 0 ? takerFee : TAKER_FEE_FALLBACK;
  const feeUsd = fit.notional * fee * 2;
  out.fees = { takerFeeRate: fee, roundTripUsd: feeUsd, assumed: !(Number.isFinite(takerFee) && takerFee > 0), breakevenMovePct: fee * 2 * 100,
    netRewardUsd: out.sizing.rewardUsd - feeUsd, netRiskUsd: fit.riskUsd + feeUsd };
  add('fees leave a positive net reward', out.fees.netRewardUsd > 0, `round-trip fees ~$${feeUsd.toFixed(3)}${out.fees.assumed ? ' (assumed rate)' : ''}; net R:R ${(out.fees.netRewardUsd / out.fees.netRiskUsd).toFixed(2)}`);

  const liq = liquidationPrice(dir, entry, p.leverage, config.mmr || 0.005);
  const liqDist = Math.abs(entry - liq); const safe = dist <= liqDist * (config.liqSafety || 0.8);
  out.liquidation = { price: liq, distancePct: (liqDist / entry) * 100, stopDistancePct: (dist / entry) * 100 };
  add('stop-loss sits inside liquidation distance', safe, `stop ${(dist / entry * 100).toFixed(2)}% vs liquidation ${(liqDist / entry * 100).toFixed(2)}% away (isolated ${p.leverage}x)`);

  add('slot available', positions.length < p.slots, `${positions.length}/${p.slots} slots in use`);
  add('no open position on this symbol', !positions.some(x => x.symbol === symbol), positions.some(x => x.symbol === symbol) ? 'already open' : 'ok');
  add('enough free margin', account.available >= fit.margin * 1.1, `needs $${fit.margin.toFixed(2)}, available $${(account.available ?? 0).toFixed(2)}`);
  const usedMargin = positions.reduce((a, x) => a + (x.margin || 0), 0) + fit.margin;
  add(`total margin <= ${(config.scaling.maxMarginPct * 100).toFixed(0)}% of equity`, usedMargin <= account.equity * config.scaling.maxMarginPct + 1e-9, `${(usedMargin / account.equity * 100).toFixed(1)}% after this trade`);
  const openRisk = positions.reduce((a, x) => a + (x.riskUsd || 0), 0) + fit.riskUsd;
  add(`open risk <= ${(config.scaling.maxOpenRisk * 100).toFixed(0)}% of equity`, openRisk <= account.equity * config.scaling.maxOpenRisk + 1e-9, `${(openRisk / account.equity * 100).toFixed(2)}% after this trade`);
  if (riskState.dailyLimitUsd != null) add('daily loss limit not reached', riskState.dayPnl > -riskState.dailyLimitUsd, `day P&L ${riskState.dayPnl.toFixed(2)} (limit -${riskState.dailyLimitUsd.toFixed(2)})`);

  // Robot gates (informational: they decide whether the robot itself would place an order right now)
  const gate = (n, ok, d) => add(`gate: ${n}`, ok, d);
  gate('live mode on', !!flags.isLive, flags.isLive ? 'LIVE' : 'PAPER: nothing would be sent');
  gate('live authorised', !!flags.authorised, flags.authorised ? 'yes' : 'not authorised');
  gate('entries not paused/blocked/stopped', !flags.paused && !flags.blocked && !flags.emergency, flags.emergency ? 'EMERGENCY STOP' : flags.blocked ? `blocked: ${flags.blocked}` : flags.paused ? 'paused' : 'open');

  out.wouldAccept = checks.filter(c => !c.name.startsWith('gate:')).every(c => c.ok);
  out.wouldSendNow = out.wouldAccept && checks.filter(c => c.name.startsWith('gate:')).every(c => c.ok);
  return out;
}

module.exports = { previewOrder };
