'use strict';
/** v6.5: live trading is authorised ONLY from .env (TRADING_MODE=LIVE, LIVE_TRADING_ENABLED=true, LIVE_AUTHORIZE=true). Returns the exact reason when it is not. */
function liveAuthStatus(cfg) {
  const missing = [];
  if (cfg.mode !== 'LIVE' && !cfg.isLive) missing.push('TRADING_MODE is not LIVE in .env');
  if (!cfg.liveEnabled) missing.push('LIVE_TRADING_ENABLED is not true in .env');
  if (!cfg.liveAuthorize) missing.push('LIVE_AUTHORIZE is not true in .env');
  return { ok: missing.length === 0, missing, text: missing.length ? 'NOT authorised: ' + missing.join('; ') : 'AUTHORISED via .env' };
}
module.exports = { liveAuthStatus };
