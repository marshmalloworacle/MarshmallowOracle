'use strict';
/**
 * Read-only view of the REAL exchange account for the dashboard. Strictly reads: this module never calls
 * placeOrder / cancelOrder. Results are cached for a few seconds (rate limits) and fall back to the last good
 * snapshot, flagged `stale`, if the exchange stops answering.
 */
const config = require('../config');
const scaling = require('../risk/scaling');
const instrumentRules = require('../exchanges/rules');
const { previewOrder } = require('./preview');

const WRITE_METHODS = ['placeOrder', 'cancelOrder'];

class LiveReadModel {
  constructor({ exchange, journal, ttlMs = 5000, now } = {}) {
    this.exchange = exchange || require('../exchanges');
    this.journal = journal || require('../journal/store');
    this.ttlMs = ttlMs; this.now = now || (() => Date.now());
    this.cache = null; this.lastGood = null;
  }

  hasKeys() { const c = config.exchange === 'mexc' ? config.mexc : config.exchange === 'bitget' ? config.bitget : config.bybit; return !!(c.apiKey && c.apiSecret && (config.exchange !== 'bitget' || c.passphrase)); }
  supported() { return config.exchange === 'bybit' || config.exchange === 'mexc' || config.exchange === 'bitget'; }

  async _guard(name, fn) { try { return { ok: true, data: await fn() }; } catch (e) { return { ok: false, error: String(e.message || e).slice(0, 300) }; } }

  async snapshot(force = false) {
    if (!this.supported()) return { ok: false, reason: `EXCHANGE=${config.exchange} has no live account` };
    if (!this.hasKeys()) return { ok: false, reason: `${config.exchange.toUpperCase()} API keys are not set in .env` };
    if (!force && this.cache && this.now() - this.cache.ts < this.ttlMs) return this.cache;
    const ex = this.exchange;
    const [account, positions, orders, stops, marginMode] = await Promise.all([
      this._guard('account', () => ex.getAccountBalance()), this._guard('positions', () => ex.getPositions()), this._guard('orders', () => ex.getOpenOrders()),
      this._guard('stops', () => ex.getStopOrders()), this._guard('marginMode', () => ex.getMarginMode())]);
    // mark prices for open positions
    const marks = {};
    if (positions.ok) await Promise.all(positions.data.map(async p => { const t = await this._guard('ticker', () => ex.getTickers(p.symbol)); if (t.ok && t.data[0]) marks[p.symbol] = Number(t.data[0].markPrice || t.data[0].lastPrice); }));
    const snap = { ok: account.ok, ts: this.now(), account, positions, orders, stops, marginMode, marks, exchange: config.exchange, testnet: !!(config.bybit && config.bybit.testnet && config.exchange === 'bybit') };
    if (account.ok) { this.cache = snap; this.lastGood = snap; return snap; }
    if (this.lastGood) return { ...this.lastGood, stale: true, error: account.error, staleSinceMs: this.now() - this.lastGood.ts };
    return snap;
  }

  _recs() { return Object.values(this.journal.getState('live_orders') || {}); }
  _status() { return this.journal.getState('live_status') || {}; }
  _statsLive() { return this.journal.getState('live_stats') || null; }

  _profile(equity, peak) { return scaling.computeProfile({ equity, peakEquity: peak, stats: this._statsLive(), config: config.scaling }); }

  /** v7.0: strategy for a symbol: lifecycle record first, then the live journal (open trade, else the latest trade) so it still shows after a restart */
  _stratFor(symbol) {
    try {
      const rec = this._recs().filter(r => r.symbol === symbol && r.strategy).sort((a, b) => b.createdAt - a.createdAt)[0]; if (rec) return rec.strategy;
      const open = this.journal.getOpenLiveTrades().find(t => t.symbol === symbol); if (open) return open.strategy_name || open.strategy_id || null;
      const last = this.journal.getClosedLiveTrades(300).find(t => t.symbol === symbol); return last ? (last.strategy_name || last.strategy_id || null) : null;
    } catch (_) { return null; }
  }

  _positions(snap) {
    if (!snap.positions || !snap.positions.ok) return [];
    const stops = snap.stops && snap.stops.ok ? snap.stops.data : [];
    return snap.positions.data.map(p => {
      const mark = snap.marks[p.symbol] || p.entry; const long = p.side === 'LONG';
      const st = stops.find(s => s.symbol === p.symbol && (s.long === undefined || s.long === long));
      const sl = p.stopLoss || (st && st.stopLoss) || null; const tp = p.takeProfit || (st && st.takeProfit) || null;
      const rec = this._recs().filter(r => r.symbol === p.symbol).sort((a, b) => b.createdAt - a.createdAt)[0];
      const upnl = (mark - p.entry) * p.qty * (long ? 1 : -1);
      return { ...p, mark, upnl, upnlPctOnMargin: p.margin > 0 ? (upnl / p.margin) * 100 : null, stopLoss: sl, takeProfit: tp, protected: !!sl,
        riskUsd: sl ? Math.abs(p.entry - sl) * p.qty : null, liqDistancePct: p.liquidationPrice ? Math.abs(mark - p.liquidationPrice) / mark * 100 : null,
        strategy: (rec && rec.strategy) || this._stratFor(p.symbol), orderState: rec ? rec.state : null };
    });
  }

  async account() {
    const snap = await this.snapshot();
    if (!snap.account) return { ok: false, reason: snap.reason };
    if (!snap.account.ok) return { ok: false, reason: snap.account.error, exchange: snap.exchange };
    const a = snap.account.data; const st = this._status(); const day = this.journal.getState('live_day');
    const peak = Math.max(this.journal.getState('live_peak_equity') || 0, a.equity);
    const profile = this._profile(a.equity, peak);
    const dayPnl = day ? a.equity - day.startEquity : null;
    return { ok: true, source: 'exchange', exchange: snap.exchange, testnet: snap.testnet, fetchedAt: snap.ts, stale: !!snap.stale, error: snap.error || null,
      equity: a.equity, available: a.available, marginUsed: a.margin, unrealized: a.unrealized, startEquity: day ? day.startEquity : null, dayPnl,
      dayPnlPct: day && day.startEquity ? (dayPnl / day.startEquity) * 100 : null, peakEquity: peak, drawdown: peak > 0 ? (peak - a.equity) / peak : 0,
      marginMode: snap.marginMode && snap.marginMode.ok ? snap.marginMode.data : null, profile, stats: this._statsLive(),
      equitySeries: (this.journal.getState('live_equity_series') || []).slice(-200), robotLastCycle: st.ts || null };
  }

  async positions() {
    const snap = await this.snapshot();
    if (!snap.positions) return { ok: false, reason: snap.reason };
    return { ok: snap.positions.ok, error: snap.positions.error, stale: !!snap.stale, fetchedAt: snap.ts, positions: this._positions(snap),
      openOrders: snap.orders && snap.orders.ok ? snap.orders.data.map(({ raw, ...o }) => ({ ...o, strategy: this._stratFor(o.symbol) })) : [], ordersError: snap.orders && snap.orders.error,
      records: this._recs().sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 40).map(r => ({ id: r.id, symbol: r.symbol, direction: r.direction, state: r.state, qty: r.qty, filledQty: r.filledQty, entry: r.entry, stopLoss: r.stopLoss, takeProfit: r.takeProfit, protected: r.protected, strategy: r.strategy, updatedAt: r.updatedAt })) };
  }

  async risk() {
    const acc = await this.account(); if (!acc.ok) return acc;
    const snap = await this.snapshot(); const pos = this._positions(snap); const p = acc.profile;
    const limit = this.journal.getState('live_status')?.dailyLossLimit || config.liveMaxDailyLoss;
    const limitUsd = acc.startEquity ? acc.startEquity * limit : null;
    const openRisk = pos.reduce((a, x) => a + (x.riskUsd || 0), 0);
    const unprotected = pos.filter(x => !x.protected).map(x => x.symbol);
    const flags = this.flags();
    return { ok: true, fetchedAt: acc.fetchedAt, slots: { used: pos.length, allowed: p.slots, cap: p.slotsCap }, tier: p.tier, state: p.state, reasons: p.reasons, leverage: p.leverage,
      riskPerTrade: p.riskPerTrade, daily: { limitPct: limit, limitUsd, dayPnl: acc.dayPnl, usedPct: limitUsd && acc.dayPnl < 0 ? Math.min(100, (-acc.dayPnl / limitUsd) * 100) : 0, anchored: acc.startEquity != null },
      openRisk: { usd: openRisk, pctEquity: (openRisk / acc.equity) * 100, capPct: config.scaling.maxOpenRisk * 100 },
      margin: { usedPct: (pos.reduce((s, x) => s + (x.margin || 0), 0) / acc.equity) * 100, capPct: config.scaling.maxMarginPct * 100 },
      drawdown: { pct: acc.drawdown * 100, peak: acc.peakEquity, reduceAt: config.scaling.ddReduce * 100, defendAt: config.scaling.ddDefend * 100 },
      unprotected, positions: pos.map(x => ({ symbol: x.symbol, side: x.side, riskUsd: x.riskUsd, protected: x.protected, liqDistancePct: x.liqDistancePct, stopDistancePct: x.stopLoss ? Math.abs(x.mark - x.stopLoss) / x.mark * 100 : null })),
      flags, marginMode: acc.marginMode, stats: acc.stats };
  }

  flags() {
    const st = this._status();
    return { isLive: config.isLive, authorised: !!st.authorised, authText: st.authText || require('./authStatus').liveAuthStatus(config).text, paused: !!this.journal.getState('live_paused'), emergency: this.journal.getState('emergency_stop') === true,
      blocked: (this.journal.getState('live_entries_blocked') || {}).reason || null, robotLastCycle: st.ts || null, robotError: st.error || null,
      runMode: config.runMode, testnet: !!config.bybit.testnet, keysPresent: this.hasKeys(), baseUrl: config.bybit.baseUrl,
      connectivity: (() => { try { return config.exchange === 'bybit' ? require('../exchanges/bybit').connectivity() : null; } catch (_) { return null; } })() };
  }

  async health() {
    const out = { exchange: config.exchange, mode: config.mode, isLive: config.isLive, testnet: !!(config.bybit && config.bybit.testnet && config.exchange === 'bybit'), keysPresent: this.hasKeys(),
      telegramConfigured: !!(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID), flags: this.flags(), checks: [] };
    const add = (name, ok, detail) => out.checks.push({ name, ok, detail });
    if (!this.supported()) { add('exchange', false, `EXCHANGE=${config.exchange} cannot trade live`); return out; }
    const ping = await this._guard('ping', () => this.exchange.ping());
    add('exchange reachable', ping.ok, ping.ok ? `${ping.data.latencyMs} ms round trip` : ping.error);
    if (ping.ok) add('clock drift', ping.data.driftMs < 3000, `${ping.data.driftMs} ms (limit 3000)`);
    add('API keys present', out.keysPresent, out.keysPresent ? 'set (values never shown)' : 'missing in .env');
    if (out.keysPresent) {
      const snap = await this.snapshot();
      add('account readable', !!(snap.account && snap.account.ok), snap.account && snap.account.ok ? `equity read at ${new Date(snap.ts).toLocaleTimeString()}${snap.stale ? ' (STALE)' : ''}` : (snap.account && snap.account.error) || snap.reason);
      const mm = snap.marginMode && snap.marginMode.ok ? snap.marginMode.data : null;
      add('isolated margin', mm === 'ISOLATED_MARGIN', mm || (snap.marginMode && snap.marginMode.error) || 'unknown');
      out.snapshotAgeMs = this.now() - snap.ts;
    }
    const f = out.flags; const age = f.robotLastCycle ? this.now() - f.robotLastCycle : null;
    add('robot loop running', age != null && age < 15 * 60 * 1000, age == null ? 'no live cycle recorded yet (start the robot in LIVE mode)' : `last live cycle ${Math.round(age / 1000)}s ago`);
    add('robot loop healthy', !f.robotError, f.robotError || 'no errors');
    add('Telegram configured', out.telegramConfigured, out.telegramConfigured ? 'yes' : 'optional: TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID');
    add('emergency stop', !f.emergency, f.emergency ? 'ACTIVE' : 'clear');
    return out;
  }

  journalView(limit = 200) {
    const closed = (this.journal.getClosedLiveTrades(limit) || []);
    const open = (this.journal.getLiveTrades(100) || []).filter(t => t.close_time == null);
    const byStrat = {}; const daily = {}; let cum = 0; const curve = [];
    for (const t of [...closed].sort((a, b) => a.close_time - b.close_time)) {
      const s = t.strategy_name || 'unknown'; byStrat[s] = byStrat[s] || { trades: 0, wins: 0, pnl: 0, gw: 0, gl: 0 };
      const b = byStrat[s]; b.trades++; b.pnl += t.pnl || 0; if (t.pnl > 0) { b.wins++; b.gw += t.pnl; } else b.gl += Math.abs(t.pnl || 0);
      const day = new Date(t.close_time).toISOString().slice(0, 10); daily[day] = (daily[day] || 0) + (t.pnl || 0);
      cum += t.pnl || 0; curve.push({ t: t.close_time, pnl: cum });
    }
    const stats = scaling.statsFromClosed(closed.map(t => ({ pnl: t.pnl || 0 })));
    return { ok: true, stats: { ...stats, totalPnl: cum, fees: closed.reduce((a, t) => a + (t.fee || 0), 0) }, open, closed: closed.slice(0, 100),
      strategies: Object.entries(byStrat).map(([name, b]) => ({ name, trades: b.trades, winRate: b.wins / b.trades, pnl: b.pnl, profitFactor: b.gl > 0 ? b.gw / b.gl : (b.gw > 0 ? 99 : 0) })).sort((a, b) => b.pnl - a.pnl),
      daily: Object.entries(daily).sort().map(([d, pnl]) => ({ d, pnl })).slice(-30), curve };
  }

  async preview(input) {
    const acc = await this.account(); if (!acc.ok) return { ok: false, reason: acc.reason };
    const snap = await this.snapshot(); const pos = this._positions(snap);
    try { await instrumentRules.refresh(); } catch (_) { /* rules cache may already be warm */ }
    const sym = String(input.symbol || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const rules = instrumentRules.getRules(sym);
    const limit = this.journal.getState('live_status')?.dailyLossLimit || config.liveMaxDailyLoss;
    const f = this.flags();
    const r = previewOrder({ input, account: acc, profile: acc.profile, positions: pos, rules, takerFee: rules && rules.takerFeeRate, flags: f,
      riskState: acc.startEquity ? { dayPnl: acc.dayPnl, dailyLimitUsd: acc.startEquity * limit } : {} });
    return { ok: true, ...r, note: 'Preview only: nothing is sent to the exchange.' };
  }
}

module.exports = LiveReadModel;
module.exports.WRITE_METHODS = WRITE_METHODS;
