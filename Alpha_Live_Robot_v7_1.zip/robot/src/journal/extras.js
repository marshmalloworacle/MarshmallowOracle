'use strict';
/**
 * Extended journal fields. Additive side table (`trade_extras`): existing tables, exports and history are untouched.
 * One JSON row per trade id (paper trade id, or `live_<symbol>_<openedAt>` for exchange positions).
 */
const journal = require('./store');
let ready = false;
function db() {
  const d = journal.getDb();
  if (!ready) { d.exec('CREATE TABLE IF NOT EXISTS trade_extras (id TEXT PRIMARY KEY, data TEXT, updated_at INTEGER)'); ready = true; }
  return d;
}
function get(id) { try { const r = db().prepare('SELECT data FROM trade_extras WHERE id=?').get(id); return r ? JSON.parse(r.data) : null; } catch (_) { return null; } }
/** merge `patch` into the stored row; never throws (journal extras must not break trading) */
function merge(id, patch) {
  try {
    const cur = get(id) || {};
    db().prepare('INSERT OR REPLACE INTO trade_extras (id, data, updated_at) VALUES (?,?,?)').run(id, JSON.stringify({ ...cur, ...patch }), Date.now());
    return true;
  } catch (_) { return false; }
}
function all(limit = 2000) { try { return db().prepare('SELECT id, data FROM trade_extras ORDER BY updated_at DESC LIMIT ?').all(limit).map(r => ({ id: r.id, ...JSON.parse(r.data) })); } catch (_) { return []; } }
module.exports = { get, merge, all };
