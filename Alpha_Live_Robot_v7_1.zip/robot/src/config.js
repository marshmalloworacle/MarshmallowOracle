'use strict';

const fs = require('fs');
const path = require('path');

// Minimal zero-dependency .env loader
const SHELL_ENV = new Set(Object.keys(process.env).filter(k => /^(EXCHANGE|TRADING_MODE|LIVE_TRADING_ENABLED|BITGET_[A-Z_]+|BYBIT_API_(KEY|SECRET)|MEXC_API_(KEY|SECRET))$/.test(k) && process.env[k] !== ''));
function loadEnv() {
  if (process.env.ROBOT_SKIP_DOTENV === '1') return;   // test isolation: ignore the real .env (never set this when running the robot)
  // Repo-root .env first (works from any start folder), then the current folder as fallback
  const repoEnv = path.resolve(__dirname, '..', '.env');
  const envPath = fs.existsSync(repoEnv) ? repoEnv : path.join(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, 'utf8');
    content.split(/\r?\n/).forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        let val = trimmed.slice(eqIdx + 1).trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        } else {
          val = val.replace(/\s+#.*$/, '').trim();   // strip inline comments: "MAX_OPEN_POSITIONS=0   # unlimited"
        }
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    });
  }
}

loadEnv();

// SCALING_TIERS="minEquity:slots:leverage,..." e.g. "0:5:10,15:6:10,40:8:10". Invalid input falls back to the built-in table.
function parseTiers(raw) {
  if (!raw) return undefined;
  const rows = raw.split(',').map(x => x.trim().split(':').map(Number));
  const ok = rows.length > 0 && rows.every(r => r.length === 3 && r.every(Number.isFinite) && r[1] >= 1 && r[2] >= 1) && rows.every((r, i) => i === 0 || r[0] > rows[i - 1][0]);
  return ok ? rows.map((r, i) => ({ name: `T${i} custom`, minEquity: r[0], slots: Math.floor(r[1]), leverage: Math.floor(r[2]) })) : undefined;
}

const config = {
  // Trading mode
  // TRADING_MODE: SIM (default; paper trading, no orders ever sent) | LIVE (real money, triple-gated).
  // v5.2: Testnet removed. Legacy TESTNET / PAPER values (and LIVE + BYBIT_TESTNET=true) all resolve to SIM - never to real money.
  mode: (process.env.TRADING_MODE || 'SIM').toUpperCase(),
  liveEnabled: process.env.LIVE_TRADING_ENABLED === 'true',

  // Bybit
  bybit: {
    apiKey: process.env.BYBIT_API_KEY || '',
    apiSecret: process.env.BYBIT_API_SECRET || '',
    testnet: process.env.BYBIT_TESTNET === 'true',   // derived from TRADING_MODE below
    baseUrl: 'https://api.bybit.com',                // derived below; override with BYBIT_BASE_URL
  },

  // MEXC USDT-M futures (official contract API: https://mexcdevelop.github.io/apidocs/contract_v1_en/)
  // NOTE: MEXC enables futures order placement via API only for some accounts. Run `npm run mexc:verify` first.
  // Bitget USDT-M futures (official v2 API: https://www.bitget.com/api-doc/contract/intro). Needs key + secret + PASSPHRASE.
  // Run `npm run bitget:verify` first (read-only). Orders are LIVE-mode only and stay behind every live gate.
  bitget: {
    apiKey: process.env.BITGET_API_KEY || '',
    apiSecret: process.env.BITGET_API_SECRET || '',
    passphrase: process.env.BITGET_PASSPHRASE || '',
    accountType: (process.env.BITGET_ACCOUNT_TYPE || 'auto').toLowerCase(),   // auto | classic (v2) | uta (v3 Unified Trading Account)
    baseUrl: process.env.BITGET_BASE_URL || 'https://api.bitget.com',
    wsUrl: process.env.BITGET_WS_URL || 'wss://ws.bitget.com/v2/ws/public',
  },
  mexc: {
    apiKey: process.env.MEXC_API_KEY || '',
    apiSecret: process.env.MEXC_API_SECRET || '',
    baseUrl: process.env.MEXC_BASE_URL || 'https://contract.mexc.com',
    wsUrl: process.env.MEXC_WS_URL || 'wss://contract.mexc.com/edge',
  },

  // Market — CRYPTO ONLY (Bybit USDT perpetuals)
  scanIntervalSeconds: parseInt(process.env.SCAN_INTERVAL_SECONDS || '60', 10),
  scanConcurrency: Math.max(1, parseInt(process.env.SCAN_CONCURRENCY || '8', 10)),
  scanMaxMarkets: parseInt(process.env.SCAN_MAX_MARKETS || '0', 10), // 0 = unlimited
  minQuoteVolume: parseFloat(process.env.MIN_QUOTE_VOLUME || '1000000'),
  excludedSymbols: (process.env.EXCLUDED_SYMBOLS || 'BTCUSDT,ETHUSDT')
    .split(',').map(s => s.trim().toUpperCase()).filter(Boolean),

  // Alpha (must remain off)
  alphaEnabled: false,

  // Strategy defaults
  gpsStrategyName: process.env.GPS_STRATEGY_NAME || 'GPS',
  minScore: parseFloat(process.env.MIN_SCORE || '85'),
  minRR: parseFloat(process.env.MIN_RR || '2.0'),
  minVolumeMultiplier: parseFloat(process.env.MIN_VOLUME_MULTIPLIER || '1.2'),
  regimeFilterEnabled: process.env.REGIME_FILTER_ENABLED !== 'false', // default true

  // Risk engine — $100 small account default
  accountBalance: parseFloat(process.env.ACCOUNT_BALANCE || '100'),
  riskPerTrade: parseFloat(process.env.RISK_PER_TRADE || '0.015'), // 1.5% default (minimum per user spec; raise freely)
  maxDailyLoss: parseFloat(process.env.MAX_DAILY_LOSS || '0'),   // 0 = no daily-loss stop (paper: reset balance instead)
  // Manual-trading tickets: size is computed for YOUR real Bybit account, not the paper balance
  ticketBalance: parseFloat(process.env.TICKET_BALANCE || process.env.ACCOUNT_BALANCE || '100'),
  ticketRiskPct: parseFloat(process.env.TICKET_RISK_PCT || process.env.RISK_PER_TRADE || '0.015'),
  // Signal freshness (see src/signals/expiry.js)
  signalExpiry: {
    entryToleranceR: parseFloat(process.env.SIGNAL_ENTRY_TOLERANCE_R || '0.25'), // price ran this far (in R) past entry => expired
    adverseExpireR: parseFloat(process.env.SIGNAL_ADVERSE_EXPIRE_R || '0.6'),    // pulled back this far toward SL => expired
    maxAgeMin: parseFloat(process.env.SIGNAL_MAX_AGE_MIN || '240'),              // older than this => expired
  },
  telegramMinScore: parseFloat(process.env.TELEGRAM_MIN_SCORE || '90'),          // only signals above this score are sent
  defaultLeverage: parseInt(process.env.DEFAULT_LEVERAGE || '10', 10),
  maxOpenPositions: parseInt(process.env.MAX_OPEN_POSITIONS || '0', 10),   // 0 = unlimited
  targetOpenPositions: parseInt(process.env.TARGET_OPEN_POSITIONS || '10', 10), // robot tries to keep >= this many open
  // Exposure is measured as MARGIN (notional / leverage) by default. The old notional basis capped a $100
  // account at ~1 position when risking 1.5% per trade, making 10+ positions mathematically impossible.
  exposureBasis: (process.env.EXPOSURE_BASIS || 'margin').toLowerCase(),   // 'margin' | 'notional'
  maxPortfolioExposure: parseFloat(process.env.MAX_PORTFOLIO_EXPOSURE || '0'),   // 0 = unlimited
  maxCorrelatedExposure: parseFloat(process.env.MAX_CORRELATED_EXPOSURE || '0'),  // 0 = off
  maxConsecutiveLosses: parseInt(process.env.MAX_CONSECUTIVE_LOSSES || '0', 10), // 0 = off

  // Multi-strategy behaviour
  strategyMode: (process.env.STRATEGY_MODE || 'ALL').toUpperCase(),        // ALL = every enabled strategy runs on every market; ROUTED = regime router picks
  onePositionPerSymbol: process.env.ONE_POSITION_PER_SYMBOL !== 'false',    // best signal per symbol (avoids stacking 9 strategies on one coin)
  fillToTarget: process.env.FILL_TO_TARGET === 'true',                      // OFF: only setups >= MIN_SCORE (85) trade
  fillMinScore: parseFloat(process.env.FILL_MIN_SCORE || '75'),
  maxNewPerScan: parseInt(process.env.MAX_NEW_PER_SCAN || '10', 10),        // 0 = unlimited; staggers entries across scans
  sizeOnEquity: process.env.SIZE_ON_EQUITY !== 'false',                     // risk % is applied to CURRENT balance (compounds, shrinks after losses)
  enforceFreeMargin: process.env.ENFORCE_FREE_MARGIN === 'true',            // paper default OFF (any number of positions); always ON in LIVE
  liqSafety: parseFloat(process.env.LIQ_SAFETY || '0.8'),                   // SL must sit inside 80% of the distance to liquidation
  maintenanceMarginRate: parseFloat(process.env.MAINTENANCE_MARGIN_RATE || '0.005'),

  // Exchange + data feed
  exchange: (process.env.EXCHANGE || 'bybit').toLowerCase(),               // bybit | bitget | mexc | sim
  wsEnabled: process.env.WS_ENABLED !== 'false',
  wsStaleMs: parseInt(process.env.WS_STALE_MS || '30000', 10),
  wsBookSymbols: parseInt(process.env.WS_BOOK_SYMBOLS || '25', 10),        // order books streamed for open positions + top candidates
  microChecks: process.env.MICRO_CHECKS !== 'false',
  maxSpreadBps: parseFloat(process.env.MAX_SPREAD_BPS || '15'),
  maxSlipBps: parseFloat(process.env.MAX_SLIP_BPS || '30'),
  minDepthMultiple: parseFloat(process.env.MIN_DEPTH_MULTIPLE || '3'),    // book depth within 1% must be >= 3x the order notional
  fundingVeto: process.env.FUNDING_VETO === 'true',
  evidenceGating: process.env.EVIDENCE_GATING === 'true',                  // mute strategy x regime pairs with negative validated expectancy
  // Scanner VISIBILITY only (does not change how many trades open): 0 = show every qualified signal.
  scannerDisplayLimit: parseInt(process.env.SCANNER_DISPLAY_LIMIT || '0', 10),
  signalRetention: parseInt(process.env.SIGNAL_RETENTION || '6000', 10),

  // Small-account scaling (see src/risk/scaling.js). Slots, leverage and risk follow equity; drawdown scales down.
  scaling: {
    enabled: process.env.SCALING_ENABLED !== 'false',
    baseLeverage: parseInt(process.env.SCALING_BASE_LEVERAGE || process.env.DEFAULT_LEVERAGE || '10', 10),
    minLeverage: parseInt(process.env.SCALING_MIN_LEVERAGE || '5', 10),
    maxLeverage: parseInt(process.env.SCALING_MAX_LEVERAGE || '20', 10),
    baseRisk: parseFloat(process.env.SCALING_BASE_RISK || process.env.RISK_PER_TRADE || '0.015'),
    maxRisk: parseFloat(process.env.SCALING_MAX_RISK || '0.02'),
    maxOpenRisk: parseFloat(process.env.SCALING_MAX_OPEN_RISK || '0.08'),
    sizing: (process.env.SCALING_SIZING || 'margin').toLowerCase() === 'risk' ? 'risk' : 'margin',
    marginPct: parseFloat(process.env.SCALING_MARGIN_PCT || '0.05'),
    minSizeRiskCap: parseFloat(process.env.SCALING_MIN_SIZE_RISK_CAP || '0.03'),
    maxMarginPct: parseFloat(process.env.SCALING_MAX_MARGIN_PCT || '0.6'),
    ddReduce: parseFloat(process.env.SCALING_DD_REDUCE || '0.05'),
    ddDefend: parseFloat(process.env.SCALING_DD_DEFEND || '0.10'),
    ddFreezeUp: parseFloat(process.env.SCALING_DD_FREEZE_UP || '0.08'),
    startSlots: parseInt(process.env.SCALING_START_SLOTS || '3', 10),
    rampEvery: parseInt(process.env.SCALING_RAMP_EVERY || '10', 10),
    rampMinPF: parseFloat(process.env.SCALING_RAMP_MIN_PF || '1.2'),
    tiers: parseTiers(process.env.SCALING_TIERS),
    slotsOverride: parseInt(process.env.SCALING_SLOTS || '0', 10),
    maxSlots: parseInt(process.env.SCALING_MAX_SLOTS || '0', 10),
    perfMinTrades: parseInt(process.env.SCALING_PERF_MIN_TRADES || '20', 10),
    perfMinPF: parseFloat(process.env.SCALING_PERF_MIN_PF || '1.2'),
  },
  // Live alerts (dashboard feed + Telegram)
  liveAlertEvents: (process.env.LIVE_ALERT_EVENTS || 'slots,orders,safety,heartbeat').split(',').map(x => x.trim().toLowerCase()).filter(Boolean),
  liveHeartbeatMin: parseInt(process.env.LIVE_HEARTBEAT_MIN || '60', 10),
  // Live order handling
  liveOrderType: (process.env.LIVE_ORDER_TYPE || 'Limit').replace(/^./, c => c.toUpperCase()).toLowerCase() === 'market' ? 'Market' : 'Limit',
  liveEntryOffsetBps: parseFloat(process.env.LIVE_ENTRY_OFFSET_BPS || '5'),   // limit entries cross the spread by this much so they fill as taker-limit
  liveEntryTtlSec: parseInt(process.env.LIVE_ENTRY_TTL_SEC || '120', 10),     // unfilled entries are cancelled after this
  // v6.7: entry block auto-clear (seconds; 0 = never) + force mode; manual "Take" from the scanner
  entryBlockAutoClearSec: parseInt(process.env.ENTRY_BLOCK_AUTOCLEAR_SEC || '15', 10),
  entryBlockForceClear: String(process.env.ENTRY_BLOCK_FORCE_CLEAR || 'false').toLowerCase() === 'true',
  manualTakeEnabled: String(process.env.MANUAL_TAKE_ENABLED || 'true').toLowerCase() !== 'false',
  manualTakeMaxDriftPct: parseFloat(process.env.MANUAL_TAKE_MAX_DRIFT_PCT || '0.5'),   // refuse if price moved > this % from the fresh entry
  manualTakeHardCapLive: parseInt(process.env.MANUAL_TAKE_HARD_CAP_LIVE || '0', 10),    // v7.0: 0 = no fixed cap (you are asked to confirm when you go over your position limit); set a number to restore a hard cap
  manualTakeHardCapPaper: parseInt(process.env.MANUAL_TAKE_HARD_CAP_PAPER || '0', 10),
  manualTakeRiskConfirmPct: parseFloat(process.env.MANUAL_TAKE_RISK_CONFIRM_PCT || '15'),   // v7.0: 2nd confirmation when open stop-risk after the trade would exceed this % of equity
  paperLabEnabled: String(process.env.PAPER_LAB_ENABLED || 'true').toLowerCase() !== 'false',   // v7.0: LIVE mode only - scanned setups also run on a separate paper account
  liveUnprotectedPolicy: (process.env.LIVE_UNPROTECTED_POLICY || 'alert').toLowerCase(), // alert | close
  // v5.2.4 controls
  takeLiveOnStart: process.env.TAKE_LIVE_TRADES_ON_START === 'true',   // default OFF: every start the robot waits for the Take Live Trades switch
  drawdownMode: (process.env.DRAWDOWN_MODE || 'warn').toLowerCase(),   // off | warn | enforce (LIVE only). warn = banner + log, never blocks entries
  leverageFixed: parseInt(process.env.LEVERAGE_FIXED || '0', 10),      // legacy: 0 = automatic scaling (paper / manual sizing OFF); >0 = fixed leverage
  // v5.2.4 LIVE trade sizing: every NEW live trade uses margin x leverage = notional. Dashboard values (saved in the DB) win over these .env defaults.
  manualTradeSizing: process.env.MANUAL_TRADE_SIZING_ENABLED !== 'false',
  manualDefaultMargin: parseFloat(process.env.MANUAL_DEFAULT_MARGIN || '1'),         // USDT margin per trade
  manualDefaultLeverage: parseInt(process.env.MANUAL_DEFAULT_LEVERAGE || '10', 10),
  manualMarginStep: (() => { const v = parseFloat(process.env.MANUAL_MARGIN_STEP || '0.5'); return v > 0 && v <= 1000 ? v : 0.5; })(),   // v7.1: size of one - / + click on the dashboard (USDT)
  manualMarginMin: (() => { const v = parseFloat(process.env.MANUAL_MARGIN_MIN || '0.1'); return v > 0 ? v : 0.1; })(),               // smallest margin you can choose (USDT)
  manualCustomMargin: process.env.MANUAL_CUSTOM_MARGIN_ENABLED !== 'false',          // false = only the preset margins can be chosen
  manualCustomLeverage: process.env.MANUAL_CUSTOM_LEVERAGE_ENABLED !== 'false',
  leverageOverMax: (process.env.LEVERAGE_OVER_MAX || 'skip').toLowerCase() === 'cap' ? 'cap' : 'skip',   // contract max below your leverage: skip (default, do not trade it) | cap (use contract max)
  protectManualTrades: process.env.PROTECT_MANUAL_TRADES !== 'false',  // trades opened in the exchange app are guarded (stop only ever tightens)
  manualTradeExits: process.env.MANUAL_TRADE_EXITS === 'true',         // default false: robot never auto-closes trades it did not open
  // LIVE-only hard limit: applies even if MAX_DAILY_LOSS=0 (paper stays unlimited)
  liveMaxDailyLoss: parseFloat(process.env.LIVE_MAX_DAILY_LOSS || '0.05'),

  // Trailing stop management
  trailingStop: {
    enabled: process.env.TRAILING_STOP_ENABLED !== 'false',
    activationRR: parseFloat(process.env.TRAILING_ACTIVATION_RR || '1.0'), // activate when trade reaches 1R
    distancePct: parseFloat(process.env.TRAILING_DISTANCE_PCT || '0.015'),  // 1.5% trailing distance
  },

  // Execution & Reconciliation
  reconciliationIntervalSeconds: parseInt(process.env.RECONCILIATION_INTERVAL_SECONDS || '300', 10),
  watchdogHeartbeatSeconds: parseInt(process.env.WATCHDOG_HEARTBEAT_SECONDS || '30', 10),
  dataQualityEnforce: process.env.DATA_QUALITY_ENFORCE !== 'false', // default true

  // Notifications (Telegram, Email, WhatsApp)
  notifications: {
    telegram: {
      enabled: process.env.TELEGRAM_ENABLED === 'true',
      botToken: process.env.TELEGRAM_BOT_TOKEN || '',
      chatId: process.env.TELEGRAM_CHAT_ID || '',
    },
    email: {
      enabled: process.env.EMAIL_ENABLED === 'true',
      webhookUrl: process.env.EMAIL_WEBHOOK_URL || '',
      recipient: process.env.EMAIL_RECIPIENT || '',
    },
    whatsapp: {
      enabled: process.env.WHATSAPP_ENABLED === 'true',
      webhookUrl: process.env.WHATSAPP_WEBHOOK_URL || '',
      phoneNumber: process.env.WHATSAPP_PHONE_NUMBER || '',
    },
  },
  telegram: {
    enabled: process.env.TELEGRAM_ENABLED === 'true',
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    chatId: process.env.TELEGRAM_CHAT_ID || '',
  },

  // Dashboard
  dashboardPort: parseInt(process.env.DASHBOARD_PORT || process.env.PORT || '3000', 10),

  // Logging
  logLevel: (process.env.LOG_LEVEL || 'INFO').toUpperCase(),
};

// ── Run mode resolution ───────────────────────────────────────────────────────────────────────
// runMode is what the operator sees: TESTNET | LIVE | SIM. Internally TESTNET reuses the full live order path
// (mode='LIVE', isLive=true) pointed at api-testnet.bybit.com, so it exercises exactly what mainnet will do.
let runMode = config.mode === 'LIVE' ? 'LIVE' : 'SIM';                                       // SIM = paper. Anything unknown (incl. legacy TESTNET) fails SAFE to SIM
config.legacyModeNote = (config.mode === 'TESTNET' || (config.mode === 'LIVE' && process.env.BYBIT_TESTNET === 'true')) ? 'Testnet was removed in v5.2: running in SIM (paper) mode.' : null;
if (config.mode === 'LIVE' && process.env.BYBIT_TESTNET === 'true') runMode = 'SIM';
if (config.exchange === 'sim') runMode = 'SIM';                                             // offline exchange cannot place orders
config.runMode = runMode;
config.envFromShell = [...SHELL_ENV];   // set by the shell / Codespaces secrets BEFORE .env was read: these win over .env (the dashboard Exchange tab warns about it)
// Exchange-neutral naming + paper/backtest taker fee (standard public tier per exchange; override with TAKER_FEE_RATE).
const NAMES = { bybit: 'Bybit', bitget: 'Bitget', mexc: 'MEXC', sim: 'Simulator' };
const DEFAULT_TAKER = { bybit: 0.00055, bitget: 0.0006, mexc: 0.0002, sim: 0.00055 };
config.exchangeLabel = NAMES[config.exchange] || config.exchange;
config.takerFeeRate = process.env.TAKER_FEE_RATE ? parseFloat(process.env.TAKER_FEE_RATE) : (DEFAULT_TAKER[config.exchange] ?? 0.00055);
config.bybit.testnet = false;
const customBase = (process.env.BYBIT_BASE_URL || '').replace(/\/+$/, '');
// Safety: in TESTNET mode a custom host is only accepted if it is a testnet host, so a stray mainnet URL can never receive test orders.
config.bybit.baseUrl = (customBase && (!config.bybit.testnet || /testnet/i.test(customBase))) ? customBase : (config.bybit.testnet ? 'https://api-testnet.bybit.com' : 'https://api.bybit.com');
if (runMode === 'TESTNET') { config.mode = 'LIVE'; config.liveEnabled = true; }           // testnet money is fake: no extra unlock needed
else if (runMode === 'SIM') { config.mode = 'PAPER'; config.liveEnabled = false; }
else { config.mode = 'LIVE'; }                                                              // mainnet still needs LIVE_TRADING_ENABLED=true + dashboard phrase

config.liveAuthorize = String(process.env.LIVE_AUTHORIZE || 'false').toLowerCase() === 'true';   // v6.5: the ONLY way live trading is authorised
config.isLive = config.mode === 'LIVE' && config.liveEnabled;
config.isPaper = !config.isLive;

// ── Open-position limits per mode (all overridable in .env / Codespaces) ──────────────────────
// Paper/SIM: MAX_OPEN_POSITIONS_PAPER (default 50; legacy MAX_OPEN_POSITIONS still honoured if set; 0 = unlimited).
// Live/Testnet: MAX_OPEN_POSITIONS_LIVE (default 12) caps the small-account slot table. Explicit SCALING_MAX_SLOTS wins.
// Aggregate open-risk cap (SCALING_MAX_OPEN_RISK, default 8%) applies to the live slot profile only; paper has no aggregate cap.
const envInt = (k) => (process.env[k] !== undefined && process.env[k] !== '' ? parseInt(process.env[k], 10) : undefined);
const paperMax = envInt('MAX_OPEN_POSITIONS_PAPER') ?? envInt('MAX_OPEN_POSITIONS') ?? 50;
const liveMax = envInt('MAX_OPEN_POSITIONS_LIVE') ?? 12;
config.maxOpenPositionsPaper = paperMax;
config.maxOpenPositionsLive = liveMax;
config.slotRamp = String(process.env.SLOT_RAMP || 'false').toLowerCase() === 'true';   // v6.0.2: ramp OFF by default; change on the Modules page
config.maxOpenPositions = config.isLive ? liveMax : paperMax;
if (envInt('MAX_NEW_PER_SCAN') === undefined) config.maxNewPerScan = config.isLive ? 10 : 20;   // paper fills 50 slots faster; live stays gentle
if (envInt('SCALING_MAX_SLOTS') === undefined) config.scaling.maxSlots = liveMax;
// Sizing sanity: what one position will use at the configured start balance (shown at startup and on the dashboard).
config.sizingPreview = {
  startBalance: config.accountBalance,
  marginPerTrade: parseFloat((config.accountBalance * config.scaling.marginPct).toFixed(2)),
  notionalPerTrade: parseFloat((config.accountBalance * config.scaling.marginPct * config.defaultLeverage).toFixed(2)),
};

module.exports = config;
