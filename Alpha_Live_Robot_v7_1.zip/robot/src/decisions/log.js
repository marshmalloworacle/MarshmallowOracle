'use strict';
/**
 * Decision log (v5.2.4): one place where the robot records WHY something happened - entry blocked, trade opened,
 * position modified/closed, warning raised. Every record is written from the real code path that made the decision
 * (gate / risk engine / live execution / protection loop / exchange close detection), never inferred by the dashboard.
 * Stored in the shared DB (robot_state key `decision_log`, newest first, ring of MAX). Identical unresolved events are
 * merged (count + lastTs) inside `cooldownMs` so banners never repeat.
 * Recording can never throw into trading code.
 */
const journal = require('../journal/store');

const KEY = 'decision_log', MAX = 300;
const TYPES = ['TRADE_CANDIDATE', 'TRADE_APPROVED', 'TRADE_REJECTED', 'TRADE_OPENED', 'TRADE_MODIFIED', 'TRADE_PROTECTED', 'TRADE_WARNING',
  'TRADE_CLOSED', 'ORDER_FAILED', 'RISK_BLOCKED', 'MODULE_BLOCKED', 'EMERGENCY_ACTION', 'SYSTEM'];
const SEVERITY = { CRITICAL: 3, WARNING: 2, INFO: 1 };
let seq = 0, lastWrite = [];                       // lastWrite: timestamps for a global flood cap

function load() { try { const v = journal.getState(KEY); return Array.isArray(v) ? v : []; } catch (_) { return []; } }

function snap() {
  try { const rt = require('../control/runtime'); return { modules: require('../features/flags').all(), drawdownMode: rt.drawdownMode(), leverage: rt.leverageChoice() || 'auto' }; } catch (_) { return null; }
}

/** e: { type, severity, symbol, direction, strategy, module, reason, measured, action, result, outcome, recommend, key, cooldownMs, mode, snapshot } */
function record(e) {
  try {
    if (!e || !e.reason) return null;
    const now = Date.now();
    lastWrite = lastWrite.filter(t => now - t < 60000);
    const sev = SEVERITY[e.severity] ? e.severity : 'INFO';
    if (lastWrite.length >= 80 && sev !== 'CRITICAL') return null;       // flood cap (critical events always get through)
    const list = load();
    const key = e.key || [e.type, e.symbol || '', e.module || '', String(e.reason).slice(0, 60)].join('|');
    const cool = e.cooldownMs == null ? 10 * 60 * 1000 : e.cooldownMs;
    const dup = cool > 0 ? list.find(x => x.key === key && now - x.lastTs < cool) : null;
    if (dup) { dup.count = (dup.count || 1) + 1; dup.lastTs = now; if (e.measured) dup.measured = e.measured; journal.setState(KEY, list); return dup; }
    const rec = { id: `${now.toString(36)}${(seq++ % 1296).toString(36)}`, key, ts: now, lastTs: now, count: 1,
      type: TYPES.includes(e.type) ? e.type : 'SYSTEM', severity: sev, symbol: e.symbol || null, direction: e.direction || null, strategy: e.strategy || null,
      module: e.module || null, reason: String(e.reason).slice(0, 400), measured: e.measured || null, action: e.action || null, result: e.result || null,
      outcome: e.outcome || null, recommend: e.recommend || null, mode: e.mode || (require('../config').isLive ? 'live' : 'paper'),
      snapshot: e.snapshot || snap() };      // snapshot = module/flag state AT THE TIME (history never changes when settings change later)
    list.unshift(rec); lastWrite.push(now);
    journal.setState(KEY, list.slice(0, MAX));
    return rec;
  } catch (_) { return null; }
}

/** filters: { limit, type, severity, symbol, q, sinceTs } */
function list(f = {}) {
  let out = load();
  if (f.type) out = out.filter(x => x.type === f.type);
  if (f.severity) out = out.filter(x => x.severity === f.severity);
  if (f.symbol) out = out.filter(x => x.symbol === String(f.symbol).toUpperCase());
  if (f.sinceTs) out = out.filter(x => x.lastTs >= f.sinceTs);
  if (f.q) { const q = String(f.q).toLowerCase(); out = out.filter(x => JSON.stringify(x).toLowerCase().includes(q)); }
  return out.slice(0, Math.min(300, Number(f.limit) || 100));
}
/** top banners: recent CRITICAL/WARNING events only (what the user needs to see right now) */
function banners(windowMs = 45 * 60 * 1000) {
  const since = Date.now() - windowMs;
  return load().filter(x => x.lastTs >= since && x.severity !== 'INFO').slice(0, 8);
}
/** map a gate/engine rejection string to the module that produced it */
function moduleOf(reason) {
  const r = String(reason || ''); const head = r.split(/[:(]/)[0].trim().toUpperCase();
  const map = { GOVERNOR: 'lossGovernor', REGIME: 'regimeFilter', ADAPTIVE: 'adaptiveDirection', ADAPTIVE_STRATEGY: 'adaptiveStrategy', CORRELATION: 'correlationBlock', AGGREGATE: 'correlationBlock', DIRECTION: 'directionControl',
    STALE: 'staleDataBlock', STALE_DATA: 'staleDataBlock', MICRO: 'microstructure', LIVE: 'liveExecution', RISK: 'riskEngine', PAUSED: 'takeLiveTrades', LIVE_STATE_UNVERIFIED: 'liveCycle',
    MAX_POSITIONS_REACHED: 'riskEngine', SPREAD_FILTER: 'spreadFilter', VOLUME_CONFIRMATION: 'volumeConfirm', HTF_TREND: 'htfTrend', VOLATILITY_FILTER: 'volatilityFilter', RISK_BUDGET: 'riskTaper', PORTFOLIO: 'riskTaper', KILL_SWITCH_ACTIVE: 'killSwitch' };
  return map[head] || (/^[A-Z_]+$/.test(head) ? head.toLowerCase() : 'engine');
}
module.exports = { record, list, banners, moduleOf, TYPES, KEY };
