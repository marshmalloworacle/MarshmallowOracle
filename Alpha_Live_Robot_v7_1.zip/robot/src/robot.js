'use strict';

const config = require('./config');
const logger = require('./utils/logger');
const { discoverMarkets, getReferenceMarkets } = require('./market/universe');
const dataFeed = require('./market/dataFeed');
const { createDefaultRegistry } = require('./strategy/registry');
const { scoreSignal } = require('./scoring/engine');
const RiskEngine = require('./risk/engine');
const PaperEngine = require('./paper/engine');
const LiveExecution = require('./execution/live');
const ReconciliationEngine = require('./execution/reconciliation');
const decisions = require('./decisions/log');
const Watchdog = require('./monitoring/watchdog');
const { defaultNotifier } = require('./notifications/index');
const journal = require('./journal/store');
const bybit = require('./exchanges');
const gate = require('./risk/gate');
const adaptive = require('./intelligence/adaptive');
const adi = require('./intelligence/adi');
const adiConfig = require('./control/adiConfig');
const directionControl = require('./control/direction');
const intel = require('./market/intel');
const governor = require('./risk/governor');
const flags = require('./features/flags');
const pcfg = require('./protection/config');
const protLive = require('./protection/live');
const { eventBus } = require('./events/bus');
const liveFeed = require('./market/liveFeed');
const micro = require('./market/microstructure');
const instrumentRules = require('./exchanges/rules');
const AlertCenter = require('./notifications/liveAlerts');

const MONITOR_INTERVAL_MS = parseInt(process.env.MONITOR_INTERVAL_SECONDS || '5', 10) * 1000;
const COMMAND_INTERVAL_MS = 1000;
const PERSISTED_EVENTS = [
  'position.opened', 'position.closed', 'position.trailing_updated',
  'emergency.triggered', 'risk.breach', 'scanner.error',
];

/**
 * GPS Trading Robot — Production Main Process
 *
 * Runs autonomously as a headless daemon.
 * PAPER mode by default. LIVE mode triple-gated and locked.
 */
class TradingRobot {
  constructor() {
    this.running = false;
    this.scanCount = 0;
    this.lastSignals = [];
    this.markets = [];

    this.strategyRegistry = createDefaultRegistry();
    this.riskEngine = new RiskEngine();
    // v7.0: in LIVE mode this engine is the separate PAPER LAB account (own balance, own risk engine, rows tagged LAB, no exchange access)
    this.paperEngine = new PaperEngine({}, config.isLive ? { ...this.riskEngine.cfg, maxOpenPositions: config.maxOpenPositionsPaper, accountBalance: config.accountBalance } : this.riskEngine.cfg);
    this.strategyRegistry = this.paperEngine.registry; // one registry: toggles/status reflect what actually trades

    this.reconciliation = new ReconciliationEngine({ riskEngine: this.riskEngine });
    this.watchdog = new Watchdog({ riskEngine: this.riskEngine });
    this.liveExecution = new LiveExecution({
      riskEngine: this.riskEngine,
      reconciliationEngine: this.reconciliation,
    });
    this.notifier = defaultNotifier;
    this.alerts = new AlertCenter({ notifier: defaultNotifier });
    this.liveExecution.orders.onEvent = (e) => { this.alerts.emit(e).catch(() => {}); };

    // Concurrency
    this.concurrency = config.scanConcurrency || 8;

    // Timers
    this._scanTimer = null;
    this._monitorTimer = null;
    this._commandTimer = null;
    this._monitoring = false;
    this._startTime = null;
    this._tickerCache = { at: 0, map: {} };
    this._tickerStale = false;
    this._protTick = {}; this._protBusy = false;
    this.paused = false;            // true = no NEW entries (open positions still managed)
    if (config.isLive) {   // v5.2.4 Take Live Trades: OFF at every start unless TAKE_LIVE_TRADES_ON_START=true (flip it any time from the dashboard)
      this.paused = !config.takeLiveOnStart;
      try { journal.setState('live_paused', this.paused); } catch (_) { /* ignore */ }
    }
    this._eventListener = null;
    this._micro = new Map();      // symbol -> latest microstructure snapshot (for the dashboard)
    this._lastTick = {};
  }

  async start() {
    if (this.running) {
      logger.warn('Robot already running');
      return;
    }

    this._startTime = Date.now();
    this.running = true;

    // v6.5: live authorisation comes ONLY from .env (LIVE_AUTHORIZE=true with TRADING_MODE=LIVE and LIVE_TRADING_ENABLED=true). No dashboard path.
    try {
      journal.setState('golive_pending', null);
      const au = require('./live/authStatus').liveAuthStatus(config);
      if (config.isLive) {
        if (au.ok) { this.liveExecution.confirmLiveMode(); logger.warn('LIVE authorised from .env (LIVE_AUTHORIZE=true). Take Live Trades is still OFF until you press it.'); }
        else logger.warn(`LIVE not authorised: ${au.missing.join('; ')}`);
      }
    } catch (e) { logger.warn(`Live authorisation check failed: ${e.message}`); }

    logger.info('════════════════════════════════════════════════════');
    logger.info('  GPS TRADING ROBOT — PRODUCTION DAEMON STARTING   ');
    logger.info(`  RUN MODE: ${config.runMode}${config.runMode === 'LIVE' ? ' (MAINNET, REAL MONEY)' : ' (offline simulator)'}`);
    logger.info(`  LIVE TRADING ENABLED: ${config.liveEnabled ? 'YES' : 'NO (LOCKED)'}`);
    logger.info(`  SCAN CONCURRENCY: ${this.concurrency}`);
    logger.info(`  STRATEGIES: ${this.strategyRegistry.getEnabled().map(s => `${s.name} v${s.version}`).join(', ')}`);
    logger.info('════════════════════════════════════════════════════');

    logger.info(`  DATABASE: ${journal.getDbPath()}  (PID ${process.pid})`);
    logger.info(`  START BALANCE: $${config.sizingPreview.startBalance} | MARGIN/TRADE: ~$${config.sizingPreview.marginPerTrade} (${(config.scaling.marginPct*100).toFixed(1)}%) | POSITION ~$${config.sizingPreview.notionalPerTrade} @ ${config.defaultLeverage}x | LIMITS paper ${config.maxOpenPositionsPaper} / live ${config.maxOpenPositionsLive}`);
    logger.info(`  RISK/TRADE: ${(config.riskPerTrade * 100).toFixed(2)}% | MAX OPEN: ${config.maxOpenPositions} | TARGET OPEN: ${config.targetOpenPositions}+ | STRATEGY MODE: ${config.strategyMode}`);
    if (config.riskPerTrade < 0.015 || (config.maxOpenPositions > 0 && config.maxOpenPositions < 10 && !config.isLive)) {
      logger.warn('  ⚠ Your .env overrides the v4.2 defaults (risk < 1.5% or a MAX_OPEN_POSITIONS cap). Update .env from .env.example.');
    }

    adiConfig.validateOrThrow(logger);   // v7.1: every ADI .env value is validated BEFORE trading starts; invalid values stop the robot with a clear message
    logger.info(`  ADI: ${adiConfig.cfg().ADI_ENABLED ? 'ON' : 'OFF'} | direction mode: ${directionControl.get().mode} (effective ${directionControl.effective().effective})`);
    try { require('./control/selfHeal').startup(logger); } catch (e) { logger.warn(`self-heal skipped: ${e.message}`); }   // v7.1: clear unmanageable/test rows + old scan sessions first
    // Re-attach open positions from the journal so SL/TP/trailing keep being managed after a restart
    this.paperEngine.restoreFromJournal();
    this._applyConfigOverrides(journal.getState('config_overrides') || {});
    for (const [id, on] of Object.entries(journal.getState('strategy_overrides') || {})) {
      try { this.strategyRegistry.setEnabled(id, !!on); } catch (_) { /* strategy removed */ }
    }
    if (journal.getState('emergency_stop') === true) {
      this._setEmergency(true, 'restored from previous session');
    }

    // Restore or initialize persistent state
    journal.setState('robot_running', true);
    journal.setState('robot_mode', config.mode);
    journal.setState('robot_start', this._startTime);

    // Initial Watchdog Health Check
    await this.watchdog.checkHealth();

    // Initial Market Discovery
    await this._refreshMarkets();

    // Live WebSocket feed (falls back to REST automatically); SL/TP then react to every ticker update
    dataFeed.attachLive(liveFeed);
    if (liveFeed.start(this.markets)) liveFeed.on('ticker', (t) => this._onLiveTicker(t));
    logger.info(`  DATA FEED: exchange=${config.exchange} | websocket=${liveFeed.enabled() ? 'ON (REST fallback armed)' : 'OFF (REST polling)'}`);

    // Schedule scan loop
    this._scheduleScan();

    // Fast loops: position monitor (SL/TP + heartbeat) and dashboard command queue
    this._attachEventPersistence();
    this._writeHeartbeat();
    this._monitorTimer = setInterval(() => this._monitorTick(), MONITOR_INTERVAL_MS);
    this._commandTimer = setInterval(() => this._commandTick(), COMMAND_INTERVAL_MS);
    this._blockTimer = setInterval(() => this._entryBlockTick(), 3000);   // v6.7: entry-block auto-clear + status for the dashboard

    // Process termination signals
    process.on('SIGINT',  () => this.stop('SIGINT'));
    process.on('SIGTERM', () => this.stop('SIGTERM'));
  }

  /**
   * v6.7 MANUAL TAKE. Re-validates a saved scanner setup against the market RIGHT NOW (fresh multi-timeframe analysis, live price,
   * portfolio gates). A stale or drifted setup is refused. Overrides ONLY the slot limit / scan budget / signal-repeat guard;
   * hard position cap, stop-loss, daily-loss, aggregate-risk, kill switch, pause, balance and exchange-min-qty checks all still apply.
   */
  async _prepareTake(p) {
    if (!config.manualTakeEnabled) throw new Error('Manual take is disabled (MANUAL_TAKE_ENABLED=false)');
    const symbol = String(p.symbol || '').toUpperCase(); const direction = String(p.direction || '').toUpperCase();
    if (!symbol || !['LONG', 'SHORT'].includes(direction)) throw new Error('symbol and direction (LONG/SHORT) are required');
    if (journal.getState('emergency_stop') === true) throw new Error('EMERGENCY STOP is active - reset it first');
    if (this.paused) throw new Error(config.isLive ? 'Take Live Trades is OFF - turn it ON before taking a trade' : 'Robot is paused - resume it before taking a trade');
    const a = await this.paperEngine.analyzeMarket(symbol);
    if (a.error) throw new Error(`Fresh analysis failed for ${symbol}: ${a.error}`);
    const sig = a.signals.find(x => x.tier === 'QUALIFIED' && x.direction === direction && (!p.strategyId || x.strategyId === p.strategyId));
    if (!sig) {
      const near = a.signals.find(x => x.direction === direction && (!p.strategyId || x.strategyId === p.strategyId));
      throw new Error(`NO_LONGER_QUALIFIED: ${symbol} ${direction} does not pass all quality checks now${near ? ` (score ${near.score}${near.rejectionReason ? ', ' + near.rejectionReason : ''})` : ' (no signal)'}`);
    }
    const dc = directionControl.manualConflict(direction);   // v7.1: hard permission = refuse; direction MODE = ask for confirmation (Manual Take overrides it)
    if (dc.permissionBlocked) throw new Error(dc.reason);
    const tk = await this._getTickerMap(1500);
    const px = tk[symbol]?.lastPrice || tk[symbol]?.markPrice;
    if (!(px > 0)) throw new Error(`No live price for ${symbol}`);
    const driftPct = Math.abs(px - sig.entry) / sig.entry * 100;
    if (driftPct > config.manualTakeMaxDriftPct) throw new Error(`PRICE_DRIFTED: ${symbol} is ${driftPct.toFixed(2)}% from the setup entry ${sig.entry} (max ${config.manualTakeMaxDriftPct}%) - wait for the next scan`);
    const long = direction === 'LONG';
    if (long ? px <= sig.stopLoss : px >= sig.stopLoss) throw new Error(`SETUP_INVALIDATED: price ${px} already beyond the stop-loss ${sig.stopLoss}`);
    if (long ? px >= sig.takeProfit : px <= sig.takeProfit) throw new Error(`SETUP_PLAYED_OUT: price ${px} already reached the take-profit ${sig.takeProfit}`);
    const livePos = config.isLive ? (this._livePositions || []) : [];
    if (config.isLive ? (livePos.some(x => x.symbol === symbol) || this.liveExecution.orders.list(true).some(r => r.symbol === symbol)) : this.paperEngine.getOpenTrades().some(t => t.symbol === symbol)) throw new Error(`SYMBOL_ALREADY_OPEN: ${symbol} already has a position or pending order`);
    await intel.refresh({ bybit, dataFeed }).catch(() => {});
    const gateCtx = await gate.prepare({ mode: config.isLive ? 'live' : 'paper', positions: this._normPositions(), equity: this._equityNow(), minScore: config.minScore, riskPerTrade: this.riskEngine.cfg.riskPerTrade,
      loader: async (sym) => (await dataFeed.getCandles(sym, '1h', 60)).map(c => c.close), runMode: config.runMode, sizing: config.isLive ? require('./control/runtime').sizing() : null });
    gateCtx.overrideAggregate = !!p.confirmRisk;
    let g = await gate.check(sig, gateCtx), riskBlocked = null;
    if (!g.allowed && !p.confirmRisk && g.reasons.every(r => /^(RISK_BUDGET|PORTFOLIO)/i.test(r))) { riskBlocked = g.reasons; gateCtx.overrideAggregate = true; g = await gate.check(sig, gateCtx); }
    if (!g.allowed) { gate.record(sig, g.reasons.join(' | ')); throw new Error(`GATE: ${g.reasons[0]}`); }
    sig._sizeFactor = g.sizeFactor == null ? 1 : g.sizeFactor; sig._taper = g.taper; sig._measured = g.measured;
    this.paperEngine.entryContext = { sentiment: gateCtx.intel && gateCtx.intel.sentiment.score, regimeState: gateCtx.intel && gateCtx.intel.regime.state, aggRiskPct: gateCtx.snap.aggRiskPct, govLevel: gateCtx.gov && gateCtx.gov.level };
    if (config.microChecks) {
      const eq = Math.max(0, config.isLive ? this._equityNow() : this.paperEngine.balance);
      const notional = (eq * this.riskEngine.cfg.riskPerTrade) / (Math.abs(sig.entry - sig.stopLoss) || 1) * sig.entry;
      const mi = await micro.evaluate(symbol, direction, notional).catch(() => null);
      if (mi && !mi.ok) throw new Error(`MICRO: ${mi.vetoes.join('; ')}`);
    }
    const openCount = config.isLive ? livePos.length : this.paperEngine.openTrades.size;
    const slotLimit = this.riskEngine.cfg.maxOpenPositions;
    const eqNow = Math.max(0, config.isLive ? this._equityNow() : this.paperEngine.balance), szc = gateCtx.sizing && gateCtx.sizing.enabled ? gateCtx.sizing : null, dist0 = Math.abs(sig.entry - sig.stopLoss) || 0;
    const newRisk = (szc ? szc.margin * szc.leverage * dist0 / (sig.entry || 1) : eqNow * this.riskEngine.cfg.riskPerTrade) * (sig._sizeFactor == null ? 1 : sig._sizeFactor);
    const openRisk = (gateCtx.snap && gateCtx.snap.aggRisk) || 0, openRiskPctAfter = eqNow > 0 ? (openRisk + newRisk) / eqNow * 100 : 0;
    return { directionConflict: dc.conflict ? dc : null, sig, symbol, direction, px, driftPct, openCount, slotLimit, hardCap: config.isLive ? config.manualTakeHardCapLive : config.manualTakeHardCapPaper,
      overridesSlots: slotLimit > 0 && openCount >= slotLimit, gateCtx, riskBlocked, openRiskPct: eqNow > 0 ? openRisk / eqNow * 100 : 0, openRiskPctAfter,
      needsRiskConfirm: !!riskBlocked || openRiskPctAfter > config.manualTakeRiskConfirmPct };
  }

  async _takeSetup(p) {
    const key = `${String(p.symbol || '').toUpperCase()}`;
    this._manualTaking = this._manualTaking || new Map();
    const last = this._manualTaking.get(key);
    if (last && Date.now() - last < 30000) throw new Error(`${key} was just submitted - wait 30s (duplicate-click protection)`);
    this._manualTaking.set(key, Date.now());
    let ok = false;
    try {
      const t = await this._prepareTake(p);
      const { sig, gateCtx } = t;
      if (t.hardCap > 0 && t.openCount >= t.hardCap) throw new Error(`HARD_CAP_REACHED (${t.openCount}/${t.hardCap}) - manual take cannot exceed the hard position cap`);
      if (p.marginUsdt != null && p.marginUsdt !== '') {         // v7.1: validate the per-trade size BEFORE anything is sent
        if (!config.isLive) throw new Error('Per-trade size applies to LIVE trades. Paper trades use equity-based sizing (SCALING_MARGIN_PCT).');
        const rt0 = require('./control/runtime'), s0 = rt0.sizing();
        if (!s0.enabled) throw new Error('Per-trade size needs manual sizing: set MANUAL_TRADE_SIZING_ENABLED=true in .env');
        rt0.resolveMargin(s0.margin, p.marginUsdt);
      }
      if (t.directionConflict && !p.confirmDirection) throw new Error(`CONFIRM_DIRECTION_REQUIRED: ${t.directionConflict.reason}. Your explicit Take overrides the direction mode - confirm to proceed`);
      if (t.overridesSlots && !p.confirmOver) throw new Error(`CONFIRM_REQUIRED: ${t.openCount} of ${t.slotLimit} allowed positions are open - confirm to go over your limit`);
      if (t.needsRiskConfirm && !p.confirmRisk) throw new Error(`CONFIRM_RISK_REQUIRED: open stop-risk would be ${t.openRiskPctAfter.toFixed(1)}% of equity (confirmation level ${config.manualTakeRiskConfirmPct}%) - confirm to proceed`);
      let mode;
      if (config.isLive) {
        mode = 'live';
        const lr = await this._openLive(sig, { manual: true, marginOverride: p.marginUsdt });
        if (!lr.ok) throw new Error(`LIVE: ${lr.reason}`);
        gate.noteOpened(gateCtx, sig, sig._sizeFactor || 1);
        await this._noteOutcomeOpen(sig, gateCtx, 'live');
        try { await this.notifier.notifySignal(sig, 'LIVE'); } catch (_) { /* notify only */ }
      } else {
        mode = 'paper';
        const r = this.paperEngine.openFromSignal(sig, { manual: true });
        if (r.action !== 'OPENED') throw new Error(`RISK: ${r.reason}`);
        gate.noteOpened(gateCtx, sig);
        await this._noteOutcomeOpen(sig, gateCtx, 'paper');
        sig.openedTradeId = r.trade.id;
        this.paperEngine.flushOutbox();
        try { await this.notifier.notifySignal(r.signal, config.mode); } catch (_) { /* notify only */ }
      }
      ok = true;
      const taken = journal.getState('manual_taken') || {}; const now = Date.now();
      for (const k of Object.keys(taken)) if (now - taken[k] > 6 * 3600 * 1000) delete taken[k];
      taken[`${sig.symbol}|${sig.direction}`] = now; journal.setState('manual_taken', taken);
      decisions.record({ type: 'TRADE_OPENED', severity: 'INFO', symbol: sig.symbol, direction: sig.direction, strategy: sig.strategyName || sig.strategyId, module: 'manualTake',
        reason: `MANUAL TAKE from scanner${p.marginUsdt != null && p.marginUsdt !== '' ? ` (size ${p.marginUsdt} USDT margin chosen for this trade)` : ''}: score ${sig.score}, entry ${sig.entry}, SL ${sig.stopLoss}, TP ${sig.takeProfit}${t.overridesSlots ? ` (slot limit ${t.slotLimit} overridden by you, ${t.openCount} open before)` : ''}${p.confirmRisk && t.needsRiskConfirm ? ` (aggregate risk caps overridden by you: open risk ${t.openRiskPctAfter.toFixed(1)}% of equity)` : ''}`,
        measured: { score: sig.score, entry: sig.entry, stopLoss: sig.stopLoss, takeProfit: sig.takeProfit, driftPct: Number(t.driftPct.toFixed(3)) }, action: `${mode} order placed after fresh re-validation`, mode, cooldownMs: 0 });
      this._updateState(); this._writeHeartbeat();
      return { symbol: sig.symbol, direction: sig.direction, mode, entry: sig.entry, stopLoss: sig.stopLoss, takeProfit: sig.takeProfit, score: sig.score, slotOverridden: t.overridesSlots };
    } finally { if (!ok) this._manualTaking.delete(key); }
  }

  /** v7.0 PAPER LAB (LIVE mode only): every qualified scanner setup also runs on a separate paper account so you can see which coins perform. Never touches live orders, live risk state or live limits. */
  async _labScan(qualified) {
    const lab = require('./intelligence/paperLab');
    if (!lab.enabled() || !this.running) return 0;
    const cap = this.riskEngine.cfg.maxOpenPositions; let budget = Math.max(config.maxNewPerScan || 10, 10), opened = 0;
    for (const sig of qualified) {
      if (budget <= 0 || !this.running) break;
      const before = this.paperEngine.openTrades.size;
      const r = this.paperEngine.openFromSignal({ ...sig, _adaptive: undefined }, { lab: true });
      if (r.action !== 'OPENED') continue;
      budget--; opened++; lab.markOpened(r.trade, { openBefore: before, liveCap: cap });
    }
    this.paperEngine.flushOutbox(); this._writePaperView(true);
    return opened;
  }

  /** v6.7: every 3s - auto-clear the live entry block after ENTRY_BLOCK_AUTOCLEAR_SEC and publish the real status. */
  async _entryBlockTick() {
    try { adaptive.heartbeat(); } catch (_) { /* confirms the saved adaptive mode to the dashboard within seconds */ }
    if (!config.isLive || this._blockBusy) return;
    this._blockBusy = true;
    try {
      const om = this.liveExecution.orders;
      await om.autoClear();
      journal.setState('entry_block_status', { ...om.blockStatus(), ts: Date.now() });
      // keep the Live view's gate cell truthful between scans (live_status is otherwise only rewritten once per scan)
      const lst = journal.getState('live_status'); const cur = om.blocked() || null;
      if (lst && JSON.stringify(lst.blocked || null) !== JSON.stringify(cur)) journal.setState('live_status', { ...lst, blocked: cur });
    } catch (e) { logger.warn(`entry-block tick: ${e.message}`); }
    finally { this._blockBusy = false; }
  }

  async stop(reason = 'MANUAL') {
    if (!this.running) return;
    this.running = false;

    if (this._scanTimer) clearTimeout(this._scanTimer);
    if (this._monitorTimer) clearInterval(this._monitorTimer);
    if (this._commandTimer) clearInterval(this._commandTimer);
    if (this._blockTimer) clearInterval(this._blockTimer);
    if (this._eventListener) eventBus.removeListener('*', this._eventListener);

    logger.info(`Robot stopping: ${reason}`);
    try { liveFeed.stop(); } catch (_) { /* ignore */ }
    journal.setState('robot_running', false);
    this._writeHeartbeat(false);

    await this.notifier.dispatch({
      type: 'INFO',
      severity: 'WARNING',
      title: 'ROBOT STOPPED',
      message: `Daemon stopped. Reason: ${reason}`,
    }).catch(() => {});
  }

  async emergencyStop(reason = 'Manual Trigger') {
    this.riskEngine.emergencyStop();
    journal.setState('emergency_stop', true);
    logger.risk(`⛔ EMERGENCY STOP ACTIVATED: ${reason}`);
    await this.notifier.notifyEmergencyStop(reason).catch(() => {});
  }

  _scheduleScan() {
    if (!this.running) return;
    const interval = config.scanIntervalSeconds * 1000;
    this._scanTimer = setTimeout(async () => {
      await this._runScan();
      this._scheduleScan();
    }, interval);
  }

  async _runScan() {
    if (!this.running) return;
    this.scanCount++;

    logger.scan(`Scan #${this.scanCount} starting — ${this.markets.length} markets (concurrency: ${this.concurrency})`);

    // Periodic tasks:
    if (!config.isLive) { try { const lv = require('./control/runtime').leverageChoice(); if (lv) this.paperEngine.riskEngine.cfg.leverage = lv; } catch (_) { /* ignore */ } }
    // 1. Refresh market list every 15 scans
    if (this.scanCount % 15 === 0) {
      await this._refreshMarkets();
    }

    // 2. Run Watchdog Health Check every 5 scans
    if (this.scanCount % 5 === 0) {
      const health = await this.watchdog.checkHealth();
      if (health.status !== 'HEALTHY') {
        logger.warn(`Watchdog report: ${health.status} issues: ${health.issues.join(', ')}`);
      }
    }

    // 3. Run Reconciliation if in LIVE mode
    if (config.isLive) {
      await this._liveCycle();
    }

    const scanStart = Date.now();
    const analyses = [];
    let errors = 0;

    // Phase 1 — analyse every market with every active strategy (no trades yet). SL/TP is handled by the monitor loop / live ticker stream
    // (market.lastPrice here can be 15 scans old, so it must never be used to close trades)
    for (let i = 0; i < this.markets.length; i += this.concurrency) {
      if (!this.running) break;
      const batch = this.markets.slice(i, i + this.concurrency);
      await Promise.all(batch.map(async (market) => {
        try {
          const a = await this.paperEngine.analyzeMarket(market.symbol);
          if (a.error) errors++;
          analyses.push({ market, ...a });
        } catch (err) {
          errors++;
          logger.error(`Error scanning ${market.symbol}: ${err.message}`);
        }
      }));
    }

    // Phase 2 — rank the whole universe, then fill slots best-first
    const all = analyses.flatMap(a => a.signals);
    const bySymbolBest = new Map();
    for (const sig of all) {
      const cur = bySymbolBest.get(sig.symbol);
      if (!cur || (sig.score || 0) > (cur.score || 0)) bySymbolBest.set(sig.symbol, sig);
    }
    const qualified = all.filter(s => s.tier === 'QUALIFIED').sort((a, b) => b.score - a.score);
    const fills = all.filter(s => s.tier === 'FILL').sort((a, b) => b.score - a.score);

    const opened = [];
    let blocked = 0;
    // v5 gate context: market intelligence (<=1/min), portfolio snapshot, governor level - built even while paused so the dashboard stays live
    let gateCtx = null;
    try {
      await intel.refresh({ bybit, dataFeed }).catch((e) => logger.warn(`market intel unavailable: ${e.message}`));
      const mode = config.isLive ? 'live' : 'paper';
      gateCtx = await gate.prepare({ mode, positions: this._normPositions(), equity: this._equityNow(), minScore: config.minScore, riskPerTrade: this.riskEngine.cfg.riskPerTrade,
        loader: async (sym) => (await dataFeed.getCandles(sym, '1h', 60)).map(c => c.close), runMode: config.runMode, sizing: config.isLive ? require('./control/runtime').sizing() : null });
      await this._governorActions(gateCtx.gov, mode);
    } catch (e) { logger.warn(`gate prepare failed (entries continue under v4.5 rules only): ${e.message}`); gateCtx = null; }
    this._writePaperView(true);
    if (this.paused && config.isLive && qualified.length) {
      decisions.record({ type: 'MODULE_BLOCKED', severity: 'WARNING', module: 'takeLiveTrades', reason: `Take Live Trades is OFF - ${qualified.length} qualified setup(s) waiting (best: ${qualified[0].symbol} ${qualified[0].direction}, score ${qualified[0].score})`,
        action: 'No order sent. Turn ON Take Live Trades to let the robot open them.', key: 'take_off_waiting', cooldownMs: 20 * 60 * 1000, recommend: 'Press Take Live Trades on the dashboard when you want the robot to start opening trades.' });
    }
    if (config.isLive) { try { await this._labScan(qualified); } catch (e) { logger.warn(`paper lab skipped (live trading unaffected): ${e.message}`); } }
    if (!this.paused) {
      let queue = [...qualified];
      if (config.fillToTarget) queue.push(...fills);
      // v6.8 Adaptive Winning Strategy Engine: re-orders (never adds, never changes score/sizing/risk). OFF = original order. Any error -> original order.
      try {
        adaptive.refresh({ signals: all, scanCount: this.scanCount });
        const ad = adaptive.order(qualified, config.fillToTarget ? fills : [], { signals: all, persist: true });
        queue = ad.queue;
        try { queue = adi.applyBias(queue, config.isLive); } catch (e) { logger.warn(`ADI bias skipped (order unchanged): ${e.message}`); }   // v7.1: ordering only, never adds/removes setups
        for (const s of ad.skipped) { s.rejectionReason = `ADAPTIVE_STRATEGY: ${s._adaptive.skip}`; blocked++; decisions.record({ type: 'TRADE_REJECTED', severity: 'INFO', symbol: s.symbol, direction: s.direction, strategy: s.strategyName || s.strategyId, module: 'adaptiveStrategy', reason: s._adaptive.skip, action: 'Skipped by STRONG adaptive mode', key: `adp_skip_${s.symbol}_${s.strategyId}`, cooldownMs: 30 * 60 * 1000 }); }
      } catch (e) { logger.warn(`adaptive engine skipped (original order used): ${e.message}`); queue = [...qualified]; if (config.fillToTarget) queue.push(...fills); }
      let budget = config.maxNewPerScan;
      if (gateCtx && gateCtx.f.lossGovernor && gateCtx.gov && gateCtx.gov.maxNewPerScan != null) budget = Math.min(budget, gateCtx.gov.maxNewPerScan);
      for (const sig of queue) {
        if (budget <= 0 || !this.running) break;
        if (gateCtx) {
          const g = await gate.check(sig, gateCtx);
          if (!g.allowed) { sig.rejectionReason = g.reasons[0]; gate.record(sig, g.reasons.join(' | ')); blocked++; continue; }
          sig._sizeFactor = g.sizeFactor == null ? 1 : g.sizeFactor; sig._taper = g.taper; sig._measured = g.measured;
          this.paperEngine.entryContext = { sentiment: gateCtx.intel && gateCtx.intel.sentiment.score, regimeState: gateCtx.intel && gateCtx.intel.regime.state, aggRiskPct: gateCtx.snap.aggRiskPct, govLevel: gateCtx.gov && gateCtx.gov.level };
        }
        const openCount = this.paperEngine.openTrades.size;
        if (sig.tier === 'FILL' && openCount >= config.targetOpenPositions) continue; // fills only top up to target
        if (config.microChecks) {
          const eq = Math.max(0, this.paperEngine.balance);
          const dist = Math.abs(sig.entry - sig.stopLoss) || 1;
          const notional = (eq * this.paperEngine.riskEngine.cfg.riskPerTrade) / dist * sig.entry;
          const mi = await micro.evaluate(sig.symbol, sig.direction, notional).catch(() => null);
          if (mi) {
            this._micro.set(sig.symbol, this._slimMicro(mi, notional));
            if (!mi.ok) { sig.rejectionReason = `MICRO: ${mi.vetoes.join('; ')}`; blocked++; continue; }
          }
        }
        if (config.isLive) {
          const lr = await this._openLive(sig);
          if (!lr.ok) { sig.rejectionReason = `LIVE: ${lr.reason}`; gate.record(sig, lr.reason, 'engine'); blocked++; if (lr.stop) break; continue; }
          budget--; opened.push(sig); if (gateCtx) gate.noteOpened(gateCtx, sig, sig._sizeFactor || 1);
          adaptive.noteSelected(sig, { tradeId: lr.tradeId || lr.id || lr.orderId || null, runMode: 'live' });
          await this._noteOutcomeOpen(sig, gateCtx, 'live');
          decisions.record({ type: 'TRADE_OPENED', severity: 'INFO', symbol: sig.symbol, direction: sig.direction, strategy: sig.strategyName || sig.strategyId, module: 'liveExecution', reason: `Live entry sent: score ${sig.score}, SL ${sig.stopLoss}, TP ${sig.takeProfit}`,
            measured: { score: sig.score, entry: sig.entry, stopLoss: sig.stopLoss, takeProfit: sig.takeProfit, riskReward: sig.riskReward }, action: 'Order submitted with exchange-side stop-loss', mode: 'live', cooldownMs: 0 });
          try { await this.notifier.notifySignal(sig, 'LIVE'); } catch (err) { logger.warn(`Notify failed: ${err.message}`); }
          continue;
        }
        const r = this.paperEngine.openFromSignal(sig);
        if (r.action !== 'OPENED') {
          if (!['DUPLICATE_SIGNAL', 'ALREADY_IN_TRADE', 'SYMBOL_ALREADY_OPEN'].includes(r.reason)) { sig.rejectionReason = `RISK: ${r.reason}`; gate.record(sig, r.reason, 'engine'); blocked++; }
          continue;
        }
        budget--;
        opened.push(r.signal);
        if (gateCtx) gate.noteOpened(gateCtx, sig);
        await this._noteOutcomeOpen(sig, gateCtx, 'paper');
        sig.openedTradeId = r.trade.id;
        adaptive.noteSelected(sig, { tradeId: r.trade.id, runMode: 'paper' });
        decisions.record({ type: 'TRADE_OPENED', severity: 'INFO', symbol: sig.symbol, direction: sig.direction, strategy: sig.strategyName || sig.strategyId, module: 'paperEngine', reason: `Paper entry: score ${sig.score}, SL ${sig.stopLoss}, TP ${sig.takeProfit}`,
          measured: { score: sig.score, entry: sig.entry, stopLoss: sig.stopLoss, takeProfit: sig.takeProfit }, action: 'Paper trade opened', mode: 'paper', cooldownMs: 0 });
        this.paperEngine.flushOutbox();
        try {
          await this.notifier.notifySignal(r.signal, config.mode);
        } catch (err) { logger.warn(`Notify failed: ${err.message}`); }
      }
    }

    this._writePaperView(true);
    // Phase 3 — persist so the dashboard is never blank: best signal per market + every qualified/fill setup
    const scanTs = Date.now();
    const toSave = new Map();
    for (const sig of bySymbolBest.values()) toSave.set(`${sig.symbol}|${sig.strategyId}`, sig);
    for (const sig of [...qualified, ...fills]) toSave.set(`${sig.symbol}|${sig.strategyId}`, sig);
    for (const sig of toSave.values()) {
      try {
        journal.saveSignal({ ...sig, timestamp: scanTs, mode: config.mode, decision: sig.decision || 'NO_TRADE' });
      } catch (err) { logger.warn(`Signal save failed for ${sig.symbol}: ${err.message}`); }
    }
    if (this.scanCount % 10 === 0) { try { journal.pruneSignals(config.signalRetention); } catch (_) { /* ignore */ } }

    const slim = (s) => ({
      symbol: s.symbol, strategyName: s.strategyName, strategyId: s.strategyId, direction: s.direction,
      score: s.score, tier: s.tier, entry: s.entry, stopLoss: s.stopLoss, takeProfit: s.takeProfit,
      riskReward: s.riskReward, opened: !!s.openedTradeId,
    });
    journal.setState('last_scan_summary', {
      scanId: this.scanCount, ts: scanTs, durationMs: scanTs - scanStart,
      markets: this.markets.length, analyzed: analyses.length, errors,
      qualified: qualified.length, fill: fills.length, opened: opened.length, blocked,
      openPositions: this.paperEngine.openTrades.size, target: config.targetOpenPositions,
      strategyMode: config.strategyMode, strategies: this.strategyRegistry.getEnabled().length,
      top: (config.scannerDisplayLimit > 0 ? [...qualified, ...fills].slice(0, config.scannerDisplayLimit) : [...qualified, ...fills]).map(slim),
    });

    // Stream order books + klines for open positions and the best candidates; refresh their microstructure view
    const watch = [...new Set([...this.paperEngine.getOpenTrades().map(t => t.symbol), ...qualified.slice(0, 15).map(q => q.symbol)])];
    if (liveFeed.started) liveFeed.setWatch(watch);
    for (const t of this.paperEngine.getOpenTrades().slice(0, 40)) {
      const notional = (t.positionSize || 0) * (t.entry || 0);
      const mi = await micro.evaluate(t.symbol, t.direction, notional, { allowRest: false }).catch(() => null);
      if (mi) this._micro.set(t.symbol, this._slimMicro(mi, notional));
    }
    for (const q of qualified.slice(0, 12)) {
      if (this._micro.has(q.symbol) && Date.now() - this._micro.get(q.symbol).ts < 60000) continue;
      const mi = await micro.evaluate(q.symbol, q.direction, 100).catch(() => null);
      if (mi) this._micro.set(q.symbol, this._slimMicro(mi, 100));
    }
    journal.setState('micro', Object.fromEntries([...this._micro.entries()].slice(-80)));
    if (this._micro.size > 200) for (const k of [...this._micro.keys()].slice(0, 100)) this._micro.delete(k);

    this.lastSignals = opened;
    this._updateState();
    logger.scan(`Scan #${this.scanCount} done in ${((scanTs - scanStart) / 1000).toFixed(1)}s — qualified ${qualified.length}, fill ${fills.length}, opened ${opened.length}, open positions ${this.paperEngine.openTrades.size}/${config.targetOpenPositions}+`);
  }

  _slimMicro(mi, notional) {
    const b = mi.book, f = mi.funding, o = mi.oi;
    return { ts: mi.ts, direction: mi.direction, notional: +notional.toFixed(2), ok: mi.ok, vetoes: mi.vetoes,
      spreadBps: b ? +b.spreadBps.toFixed(2) : null, depthUsd: b ? Math.round(b.depthUsd) : null, slipBps: b ? +Math.min(b.slipBps, 999).toFixed(2) : null,
      imbalance: b ? +b.imbalance.toFixed(2) : null, fundingRate: f ? f.rate : null, fundingTrend: f ? f.trend : null, crowded: f ? f.crowded : null,
      oiDeltaPct: o ? +o.deltaPct.toFixed(2) : null, oiTrend: o ? o.trend : null };
  }

  // ── Dashboard sync: heartbeat, position monitor, commands, events ───────

  _writeHeartbeat(alive = true) {
    try {
      journal.setState('robot_heartbeat', {
        ts: Date.now(),
        alive,
        pid: process.pid,
        dbPath: journal.getDbPath(),
        mode: config.mode,
        paused: this.paused,
        openTrades: config.isLive ? 0 : this.paperEngine.openTrades.size,   // v7.0: in LIVE mode the paper engine is the separate Paper Lab
        labOpen: config.isLive ? this.paperEngine.openTrades.size : 0,
        pendingWrites: this.paperEngine.getPendingWrites(),
        tickersStale: this._tickerStale,
        scanCount: this.scanCount,
      });
      journal.setState('feed_status', { ts: Date.now(), ...liveFeed.status(), exchangeInfo: require('./exchanges').info(), strategyMode: config.strategyMode });
    } catch (err) {
      logger.warn(`Heartbeat write failed: ${err.message}`);
    }
  }

  /** WebSocket tick: evaluate SL/TP/trailing immediately for symbols we hold (throttled per symbol) */
  _onLiveTicker(t) {
    if (!this.running || !(t.lastPrice > 0)) return;
    const now = Date.now();
    if (this.paperEngine.hasOpen(t.symbol)) {
      if (now - (this._lastTick[t.symbol] || 0) < 300) return;
      this._lastTick[t.symbol] = now;
      try {
        const closed = this.paperEngine.updateTrades(t.symbol, t.lastPrice);
        if (!config.isLive) for (const c of closed) this.notifier.notifyTradeClosed(c).catch(() => {});
        this._writePaperView();
      } catch (err) { logger.warn(`Live tick handling failed for ${t.symbol}: ${err.message}`); }
      return;
    }
    // EVERY-TICK protection for real exchange positions (throttled per symbol, single-flight, independent of pause/direction/governor)
    if (config.isLive && this._livePositions && this._livePositions.some(p => p.symbol === t.symbol)) {
      if (this._protBusy || now - (this._protTick[t.symbol] || 0) < 1000) return;
      this._protTick[t.symbol] = now; this._protBusy = true;
      const pos = this._livePositions.filter(p => p.symbol === t.symbol);
      protLive.run({ exchange: bybit, orders: this.liveExecution.orders, positions: pos, tickers: { [t.symbol]: { markPrice: t.markPrice || t.lastPrice, lastPrice: t.lastPrice } },
        alert: (a) => this.alerts.emit(a).catch(() => {}), prune: false })
        .catch((e) => logger.warn(`tick protection failed for ${t.symbol}: ${e.message}`)).finally(() => { this._protBusy = false; });
    }
  }

  /** Normalised positions for portfolio risk (exchange truth in live, paper book otherwise) */
  _normPositions() {
    if (config.isLive) return (this._livePositions || []).map(p => ({ symbol: p.symbol, side: p.side, qty: p.qty, entry: p.entry, stop: p.stopLoss, mark: p.markPrice || p.entry, leverage: p.leverage, margin: p.margin, liq: p.liquidationPrice }));
    return this.paperEngine.getOpenTrades().map(t => ({ symbol: t.symbol, side: t.direction, qty: t.positionSize, entry: t.entry, stop: t.stopLoss, mark: this.paperEngine._lastPrice.get(t.symbol) || t.entry, leverage: t.leverage || this.riskEngine.cfg.leverage || 1, margin: t.margin }));   // margin from the trade itself so 'Margin used' is not overstated by the leverage fallback
  }
  _equityNow() {
    if (config.isLive) return this._liveEquity || 0;
    let eq = this.paperEngine.balance;
    for (const t of this.paperEngine.getOpenTrades()) { const px = this.paperEngine._lastPrice.get(t.symbol); if (px > 0) eq += (t.direction === 'LONG' ? px - t.entry : t.entry - px) * t.positionSize; }
    return eq;
  }
  /** protection table rows for paper positions (live rows are written by protection/live.js) */
  _writePaperView(force = false) {
    const now = Date.now(); if (!force && now - (this._pvAt || 0) < 2000) return; this._pvAt = now;
    try {
      const { progress } = require('./protection/stops');
      const rows = this.paperEngine.getOpenTrades().map(t => {
        const mark = this.paperEngine._lastPrice.get(t.symbol) || t.entry, long = t.direction === 'LONG', pr = t.prot || {};
        const peak = progress({ side: t.direction, entry: t.entry, initialStop: t.initialStopLoss, target: t.takeProfit }, 'TP', pr.peakPrice || t.entry), cur = progress({ side: t.direction, entry: t.entry, initialStop: t.initialStopLoss, target: t.takeProfit }, 'TP', mark);
        return { mode: 'paper', id: t.id, moves: t.stopMoves || [], symbol: t.symbol, side: t.direction, entry: t.entry, mark, qty: t.positionSize, initialStop: t.initialStopLoss, tp: t.takeProfit, stop: t.stopLoss, stopReason: t.stopReason || null, stage: t.stage || null,
          peakProgress: Number(peak.toFixed(1)), progress: Number(cur.toFixed(1)), givebackPct: peak > 0 ? Number(Math.max(0, (peak - cur) / peak * 100).toFixed(1)) : 0,
          distToStopPct: Number(((long ? mark - t.stopLoss : t.stopLoss - mark) / mark * 100).toFixed(2)), liqDistPct: null, upnl: Number(((long ? mark - t.entry : t.entry - mark) * t.positionSize).toFixed(4)),
          protectedStop: true, hoursOpen: Number(((now - t.openTime) / 3600e3).toFixed(1)), atr: t.atr || null, atrSource: t.atrSource || null };
      });
      journal.setState('protection_view_paper', rows);
      this._writeAdvisor('paper', rows);
    } catch (e) { logger.warn(`paper protection view failed: ${e.message}`); }
  }

  /** v6.0: remember which modules were ON and what the market looked like at entry (for the performance tracker / what-if) */
  async _noteOutcomeOpen(sig, gateCtx, mode) {
    try {
      const filt = require('./risk/filters'); let m = sig._measured;
      if (!m || !Object.keys(m).length) { try { m = await filt.measure(sig, ['spread', 'volume', 'htf', 'vol'], 0); } catch (_) { m = {}; } }   // shadow measurement even when the filters are OFF
      require('./intelligence/outcomes').noteOpen({ symbol: sig.symbol, direction: sig.direction, mode, measured: m || {}, regime: gateCtx && gateCtx.intel ? gateCtx.intel.regime.state : null, aggRiskPct: gateCtx && gateCtx.snap ? gateCtx.snap.aggRiskPct : null });
    } catch (_) { /* never affects trading */ }
  }

  /** v5.2.4: per-position integrity + advisor snapshot for the dashboard (throttled, never affects trading) */
  _writeAdvisor(mode, rows) {
    const now = Date.now(); this._advAt = this._advAt || {};
    if (now - (this._advAt[mode] || 0) < 5000) return; this._advAt[mode] = now;
    try {
      const out = require('./intelligence/integrity').annotate(mode, rows, { intel: journal.getState('market_intel') || null });
      journal.setState('advisor_' + mode, { ts: now, rows: out });
    } catch (e) { logger.warn(`advisor snapshot failed: ${e.message}`); }
  }

  /** Governor EMERGENCY: alert once, optionally flatten (config), verify against exchange state. Never removes stops while only halting. */
  async _governorActions(gov, mode) {
    if (!gov || !flags.isOn('lossGovernor') || gov.level !== 'EMERGENCY' || !gov.emergency) return;
    const em = gov.emergency;
    if (!em.alerted) { governor.markEmergency(mode, { alerted: true }); this.alerts.emit({ category: 'safety', severity: 'CRITICAL', title: 'GOVERNOR EMERGENCY', message: `${em.reason}. New entries are halted. Action: ${pcfg.get().govEmergencyAction}. Acknowledge on the dashboard once resolved.` }).catch(() => {}); }
    if (pcfg.get().govEmergencyAction !== 'FLATTEN') return;
    if (gov.warnOnly) { decisions.record({ type: 'TRADE_WARNING', severity: 'CRITICAL', module: 'lossGovernor', reason: `Governor EMERGENCY level reached (${em.reason}) but DRAWDOWN_MODE=${require('./control/runtime').drawdownMode()}: nothing was closed and trading continues.`, action: 'Warning only', key: 'gov_emerg_warn', cooldownMs: 30 * 60 * 1000 }); return; }
    const open = config.isLive ? (this._livePositions || []).length : this.paperEngine.getOpenTrades().length;
    if (open === 0) { if (em.acted && !em.verified) governor.markEmergency(mode, { verified: true, verifiedAt: Date.now() }); return; }
    if (em.lastAttempt && Date.now() - em.lastAttempt < 60e3) return;
    governor.markEmergency(mode, { acted: true, lastAttempt: Date.now() });
    try {
      if (config.isLive) { await this.liveExecution.orders.cancelAllEntries(); await this.liveExecution.orders.flatten('GOVERNOR EMERGENCY'); }
      else { const tk = await this._getTickerMap(1500); this.paperEngine.closeAllTrades('GOVERNOR_EMERGENCY', (sym) => tk[sym]?.lastPrice || null, { strict: false }); }
    } catch (e) { this.alerts.emit({ category: 'safety', severity: 'CRITICAL', title: 'Emergency flatten FAILED', message: `${e.message} - will retry (stops remain in place)` }).catch(() => {}); }
  }

  async _getTickerMap(maxAgeMs = 3000) {
    const liveMap = liveFeed.getTickerMap(30000);
    if (Object.keys(liveMap).length) { this._tickerStale = false; return liveMap; }
    const now = Date.now();
    if (now - this._tickerCache.at < maxAgeMs && Object.keys(this._tickerCache.map).length) {
      return this._tickerCache.map;
    }
    try {
      const list = await bybit.getTickers();
      const map = {};
      for (const t of list) {
        map[t.symbol] = {
          lastPrice: parseFloat(t.lastPrice || 0),
          markPrice: parseFloat(t.markPrice || t.lastPrice || 0),
        };
      }
      this._tickerCache = { at: now, map };
      this._tickerStale = false;
    } catch (err) {
      this._tickerStale = true;
      logger.warn(`Ticker fetch failed in monitor: ${err.message}`);
    }
    return this._tickerCache.map;
  }

  /**
   * Fast position monitor. Previously SL/TP were only checked when a symbol was reached inside a
   * full market scan, so exits could lag by a whole scan cycle (minutes).
   */
  /**
   * LIVE housekeeping, once per scan: real equity -> scaling profile -> risk limits, persistent daily-loss anchor,
   * order reconciliation (fills, stale entries, stop-loss verification). Fails closed: if the account cannot be read,
   * entries are paused for this scan.
   */
  async _liveCycle() {
    this._liveOk = false;
    try {
      const bal = await bybit.getAccountBalance();
      const positions = await bybit.getPositions();
      if (!(bal.equity > 0)) throw new Error('equity is zero or unreadable');
      const mm = await bybit.getMarginMode();
      if (mm !== 'ISOLATED_MARGIN') throw new Error(`account margin mode is ${mm}; ALPHA LIVE ROBOT only trades ISOLATED margin. Switch the exchange account to isolated margin`);
      const today = new Date().toISOString().slice(0, 10);
      let day = journal.getState('live_day');
      if (!day || day.date !== today) { day = { date: today, startEquity: bal.equity }; journal.setState('live_day', day); }   // persistent daily anchor
      const peak = Math.max(journal.getState('live_peak_equity') || 0, bal.equity);
      journal.setState('live_peak_equity', peak);

      const re = this.riskEngine;
      re.cfg.accountBalance = bal.equity;
      re.state.dailyLossDate = new Date().toDateString();
      re.state.dailyPnL = bal.equity - day.startEquity;          // includes unrealised: conservative
      re.state.openPositions = positions.length;
      re.state.totalExposure = positions.reduce((a, p) => a + (p.margin || (p.qty * p.entry) / Math.max(1, re.cfg.leverage)), 0);
      const prevPositions = this._prevPositionCount ?? positions.length;
      if (this.scanCount % 5 === 1 || !journal.getState('live_stats') || positions.length < prevPositions) {   // refresh realised-PnL stats (and detect closes)
        try {
          const closed = await bybit.getClosedTrades(100);
          journal.setState('live_stats', { ...require('./risk/scaling').statsFromClosed(closed), ts: Date.now() });
          const seen = journal.getState('live_closed_seen');
          const newest = closed.reduce((m, t) => Math.max(m, t.closedAt || 0), 0);
          this._journalClosedLive(closed);
          if (seen != null) {
            for (const t of closed.filter(t => (t.closedAt || 0) > seen).sort((a, b) => a.closedAt - b.closedAt)) {
              try { require('./intelligence/outcomes').noteClose({ symbol: t.symbol, mode: 'live', pnl: t.pnl }); } catch (_) { /* tracker only */ }
              decisions.record({ type: 'TRADE_CLOSED', severity: t.pnl >= 0 ? 'INFO' : 'WARNING', symbol: t.symbol, module: 'exchange', reason: 'Position closed on the exchange (stop-loss, take-profit, trailing stop, manual close in the app, or liquidation). The exchange does not tell the robot which one; realised PnL is as reported.',
                measured: { pnl: t.pnl }, action: 'Closed by exchange', outcome: t.pnl >= 0 ? 'WIN' : 'LOSS', mode: 'live', cooldownMs: 0 });
              this.alerts.emit({ category: 'orders', severity: 'INFO', title: `${t.pnl >= 0 ? '✅ Win' : '❌ Loss'}: ${t.symbol} ${t.pnl >= 0 ? '+' : ''}${t.pnl.toFixed(4)} USDT`, message: 'realised PnL reported by the exchange' }).catch(() => {});
            }
          }
          if (seen == null || newest > seen) journal.setState('live_closed_seen', newest);
        } catch (e) { logger.warn(`live stats unavailable (${e.message}); leverage stays at base`); }
      }
      this._prevPositionCount = positions.length;
      const profile = re.refreshProfile({ equity: bal.equity, peakEquity: peak, stats: journal.getState('live_stats') || null });

      this._liveEquity = bal.equity;
      // v6.0.1: an exchange can report equity but 0/blank "available" (e.g. Bybit UTA). Use equity minus margin in use instead of treating it as 0,
      // so the robot trades when it sees equity. The exchange still rejects any order it cannot fund, and real zero (all margin used) stays zero.
      { const est = Math.max(0, (bal.equity || 0) - (bal.margin || 0)); const rep = Number.isFinite(bal.available) ? bal.available : null;
        bal.availableReported = rep; if ((rep == null || rep <= 0) && est > 0) { bal.available = est; bal.availableEstimated = true; }
        this._liveAvail = Number.isFinite(bal.available) ? bal.available : null; }
      this._recordEquity(bal.equity);
      this._alertProfile(profile);
      if (profile && profile.drawdownWarning) decisions.record({ type: 'TRADE_WARNING', severity: 'WARNING', module: 'drawdownGuard', reason: `Account is ${(profile.drawdown * 100).toFixed(1)}% below its peak: robot would be ${profile.drawdownWarning} (smaller size, fewer slots).`,
        measured: { drawdownPct: Number((profile.drawdown * 100).toFixed(2)), peak }, action: 'Warning only - slots, leverage and entries unchanged', key: 'dd_profile', cooldownMs: 60 * 60 * 1000, recommend: 'If results are poor, consider a lower leverage (5x) or switching DRAWDOWN_MODE to enforce.' });
      this._alertDaily(bal.equity, day, re);
      const rec = await this.liveExecution.orders.reconcile();
      this._journalOpenLive();
      journal.setState('live_status', { ts: Date.now(), exchange: config.exchange, equity: bal.equity, available: bal.available, startEquity: day.startEquity,
        peakEquity: peak, positions: positions.length, profile, stats: journal.getState('live_stats'), reconcile: rec, blocked: this.liveExecution.orders.blocked(),
        dailyLossLimit: re.cfg.maxDailyLoss, paused: this.paused, authorised: this.liveExecution.getOperationalState() === 'LIVE_AUTHORIZED', authText: require('./live/authStatus').liveAuthStatus(config).text });
      this._liveOk = true;
      this._livePositions = positions;
      try {   // v5.2.4 advisor rows: EVERY exchange position, including ones opened in the exchange app
        const { progress } = require('./protection/stops'); const tk0 = await this._getTickerMap(3000).catch(() => ({})); const pst = journal.getState('protection_state') || {}; const recs = this.liveExecution.orders.list(true);
        this._writeAdvisor('live', positions.map(p => {
          const mark = p.markPrice || tk0[p.symbol]?.markPrice || tk0[p.symbol]?.lastPrice || p.entry; const st = pst[`${p.symbol}:${p.side}`] || {}; const init = st.initialStop || p.stopLoss || 0;
          const tp = p.takeProfit || 0, tgt = tp || (init ? p.entry + (p.side === 'LONG' ? 1 : -1) * Math.abs(p.entry - init) * 2 : 0);
          const pr = (tgt && init) ? { side: p.side, entry: p.entry, initialStop: init, target: tgt } : null;
          const cur = pr ? progress(pr, 'TP', mark) : null, peak = pr ? progress(pr, 'TP', st.peakPrice || mark) : null;
          return { mode: 'live', stopReason: st.lastReason || null, moves: st.moves || [], symbol: p.symbol, side: p.side, entry: p.entry, mark, qty: p.qty, stop: p.stopLoss || null, tp: tp || null, initialStop: init || null, leverage: p.leverage || null,
            liqDistPct: p.liquidationPrice ? Number((Math.abs(mark - p.liquidationPrice) / mark * 100).toFixed(2)) : null, upnl: p.upnl ?? null, progress: cur == null ? null : Number(cur.toFixed(1)),
            peakProgress: peak == null ? null : Number(peak.toFixed(1)), stage: st.stage || null, hoursOpen: Number((((Date.now() - (st.openedAt || p.createdTime || Date.now())) / 3600e3)).toFixed(1)),
            protectedStop: !!p.stopLoss, manual: !recs.some(r => r.symbol === p.symbol && r.direction === p.side) };
        }));
      } catch (e) { logger.warn(`advisor rows failed: ${e.message}`); }
      try {   // v4.6 position protection (switchable; independent of the signal scanner and of direction/pause controls)
        const tk = await this._getTickerMap(1500).catch(() => ({}));
        await require('./protection/live').run({ exchange: bybit, orders: this.liveExecution.orders, positions, tickers: tk, alert: (a) => this.alerts.emit(a).catch(() => {}) });
      } catch (e) { logger.warn(`protection cycle failed: ${e.message}`); }
      this._heartbeat(bal, positions, profile, day);
    } catch (err) {
      logger.error(`LIVE cycle failed - new entries paused this scan: ${err.message}`);
      this.alerts.emit({ category: 'safety', severity: 'WARNING', title: 'Live cycle failed - entries paused', message: err.message, key: 'cycle_fail', cooldownMs: 15 * 60 * 1000 }).catch(() => {});
      journal.setState('live_status', { ts: Date.now(), error: err.message, blocked: { reason: 'live cycle failed' } });
    }
  }

  _recordEquity(equity) {
    const series = journal.getState('live_equity_series') || [];
    if (!series.length || Date.now() - series[series.length - 1].t >= 4 * 60 * 1000) { series.push({ t: Date.now(), e: Number(equity.toFixed(4)) }); journal.setState('live_equity_series', series.slice(-400)); }
  }

  /** Real trades -> live_trades journal (open row when filled, completed row when the exchange reports the close). */
  _journalOpenLive() {
    try {
      for (const r of this.liveExecution.orders.list(true)) {
        if ((r.state === 'FILLED' || r.state === 'PARTIAL') && !r.journaledOpen) {
          journal.saveLiveTrade({ id: r.id, orderId: r.orderId, strategyName: r.strategy || 'unknown', symbol: r.symbol, direction: r.direction, entry: r.avgPrice || r.entry,
            stopLoss: r.stopLoss, takeProfit: r.takeProfit, positionSize: r.filledQty || r.qty, riskReward: r.riskReward || null, openTime: r.createdAt, closeTime: null, outcome: null });
          r.journaledOpen = true; this.liveExecution.orders._save(r);
        }
      }
    } catch (e) { logger.warn(`live journal (open) failed: ${e.message}`); }
  }
  _journalClosedLive(closed) {
    try {
      const seen = new Set((journal.getClosedLiveTrades(500) || []).map(t => `${t.symbol}|${t.close_time}`));
      const om = this.liveExecution.orders;
      for (const t of closed) {
        if (seen.has(`${t.symbol}|${t.closedAt}`)) continue;
        const rec = om.list().filter(r => r.symbol === t.symbol && !r.journaledClose && ['FILLED', 'PARTIAL', 'CLOSED'].includes(r.state)).sort((a, b) => b.createdAt - a.createdAt)[0];
        const near = (a, b) => a && b && Math.abs(a - b) / b < 0.003;
        const reason = rec && near(t.exit, rec.stopLoss) ? 'STOP_LOSS_HIT' : rec && near(t.exit, rec.takeProfit) ? 'TAKE_PROFIT_HIT' : 'CLOSED';
        journal.saveLiveTrade({ id: rec ? rec.id : `ex_${t.symbol}_${t.closedAt}`, orderId: t.orderId, strategyName: rec ? (rec.strategy || 'unknown') : 'manual/unknown', symbol: t.symbol,
          direction: t.direction || (rec && rec.direction), entry: t.entry || (rec && rec.avgPrice) || (rec && rec.entry), stopLoss: rec && rec.stopLoss, takeProfit: rec && rec.takeProfit,
          exitPrice: t.exit, positionSize: t.qty, pnl: t.pnl, fee: t.fee, outcome: t.pnl > 0 ? 'WIN' : t.pnl < 0 ? 'LOSS' : 'BREAKEVEN', exitReason: reason,
          openTime: (rec && rec.createdAt) || t.openedAt, closeTime: t.closedAt });
        if (rec) { rec.journaledClose = true; om._save(rec); }
      }
    } catch (e) { logger.warn(`live journal (close) failed: ${e.message}`); }
  }

  /** One grouped alert when slots / leverage / tier / drawdown state change. */
  _alertProfile(p) {
    if (!p) return;
    const cur = { slots: p.slots, leverage: p.leverage, tier: p.tier, state: p.state };
    const prev = journal.getState('live_profile_prev');
    journal.setState('live_profile_prev', cur);
    if (!prev) return;
    const ch = [];
    if (prev.slots !== cur.slots) ch.push(`Slots ${prev.slots} → ${cur.slots}${p.slotsCap > cur.slots ? ` (cap ${p.slotsCap})` : ''}`);
    if (prev.leverage !== cur.leverage) ch.push(`Leverage ${prev.leverage}x → ${cur.leverage}x`);
    if (prev.tier !== cur.tier) ch.push(`Tier ${prev.tier} → ${cur.tier}`);
    if (prev.state !== cur.state) ch.push(`Mode ${prev.state} → ${cur.state}`);
    if (!ch.length) return;
    const worse = cur.state === 'REDUCED' || cur.state === 'DEFENSIVE' || cur.slots < prev.slots || cur.leverage < prev.leverage;
    this.alerts.emit({ category: 'slots', severity: worse ? 'WARNING' : 'INFO', title: worse ? 'Scaling DOWN' : 'Scaling UP', message: `${ch.join('\n')}\n${(p.reasons || []).join(' · ')}` }).catch(() => {});
  }

  _alertDaily(equity, day, re) {
    const limit = re.cfg.maxDailyLoss;
    if (!(limit > 0) || !day) return;
    if (equity - day.startEquity <= -limit * day.startEquity && this._dailyAlertDate !== day.date) {
      this._dailyAlertDate = day.date;
      this.alerts.emit({ category: 'safety', severity: 'CRITICAL', title: 'DAILY LOSS STOP HIT', message: `Day P&L ${(equity - day.startEquity).toFixed(2)} USDT (limit -${(limit * 100).toFixed(0)}% of $${day.startEquity.toFixed(2)}). No new entries until tomorrow (UTC). Open positions keep their stops.` }).catch(() => {});
    }
  }

  _heartbeat(bal, positions, p, day) {
    const every = (config.liveHeartbeatMin || 60) * 60 * 1000;
    const first = !this._hbStarted; const now = Date.now();
    if (!first && now - (this._lastHb || 0) < every) return;
    this._hbStarted = true; this._lastHb = now;
    this.alerts.emit({ category: 'heartbeat', severity: 'INFO', title: first ? 'ALPHA LIVE ROBOT started' : 'ALPHA LIVE ROBOT heartbeat',
      message: `Equity $${bal.equity.toFixed(2)} · day ${(bal.equity - day.startEquity >= 0 ? '+' : '')}${(bal.equity - day.startEquity).toFixed(2)}\nOpen ${positions.length}/${p ? p.slots : '-'} slots · ${p ? p.tier : ''} · ${p ? p.leverage + 'x' : ''} · ${p ? p.state : ''}\n${this.paused ? 'PAUSED (no new entries)' : 'Scanning'}` }).catch(() => {});
  }

  /** Real-order entry: risk check (with exchange rules) -> gates -> OrderManager. Returns { ok, reason, stop }. */
  async _openLive(sig, opts = {}) {
    if (!this._liveOk) return { ok: false, reason: 'LIVE_STATE_UNVERIFIED', stop: true };
    if (this.paused) return { ok: false, reason: 'PAUSED', stop: true };
    if (this.liveExecution.getOperationalState() !== 'LIVE_AUTHORIZED') return { ok: false, reason: 'LIVE_NOT_AUTHORIZED (confirm from the dashboard)', stop: true };
    await instrumentRules.refresh();
    const rules = instrumentRules.getRules(sig.symbol);
    if (!rules) return { ok: false, reason: `NO_EXCHANGE_RULES for ${sig.symbol}` };
    const open = (this._livePositions || []).map(p => ({ symbol: p.symbol, positionSize: p.qty, entry: p.entry }));
    const rt = require('./control/runtime'), sz0 = rt.sizing();   // read fresh for EVERY new trade: dashboard changes apply to the next trade, never to open ones
    let sz = sz0;
    if (opts.marginOverride != null && sz0.enabled) {            // v7.1: size for THIS manual trade only (saved default unchanged)
      const rm = rt.resolveMargin(sz0.margin, opts.marginOverride);
      sz = { ...sz0, margin: rm.margin, notional: Number((rm.margin * sz0.leverage).toFixed(4)) };
    }
    const fac = sig._sizeFactor == null ? 1 : sig._sizeFactor;
    const verdict = this.riskEngine.check(sig, open, { ...(opts.manual ? { ignoreSlots: true, hardCap: config.manualTakeHardCapLive } : {}), rules, fixedSizing: sz.enabled ? { ...sz, margin: sz.margin * fac, baseMargin: sz.margin } : null });
    if (!verdict.approved) return { ok: false, reason: verdict.reason };
    const lev = verdict.leverage || this.riskEngine.cfg.leverage;
    if (sz.enabled && verdict.marginUsd != null && this._liveAvail != null && verdict.marginUsd > this._liveAvail + 1e-9) return { ok: false, reason: `INSUFFICIENT_BALANCE: needs ${verdict.marginUsd} USDT margin, available ${this._liveAvail.toFixed(4)} USDT` };
    const res = await this.liveExecution.submitOrder(sig, verdict.positionSize, { approved: true, leverage: lev });
    if (!res.success) return { ok: false, reason: res.reason, stop: /ENTRIES_BLOCKED|EMERGENCY|AMBIGUOUS/.test(res.reason || '') };
    // reflect the new position immediately so the next signal in this scan sees the slot as used
    (this._livePositions = this._livePositions || []).push({ symbol: sig.symbol, qty: verdict.positionSize, entry: sig.entry });
    this.riskEngine.state.totalExposure += (verdict.positionSize * sig.entry) / Math.max(1, lev);
    if (this._liveAvail != null && verdict.marginUsd != null) this._liveAvail -= verdict.marginUsd;
    decisions.record({ type: 'TRADE_APPROVED', severity: 'INFO', symbol: sig.symbol, direction: sig.direction, module: 'tradeSizing', reason: `${sig._taper && sig._taper.factor < 1 ? `Soft risk budget: open risk ${sig._taper.openRiskPct}% of equity (cap ${sig._taper.capPct}%), new trade sized at ${Math.round(sig._taper.factor * 100)}%. ` : ''}Sized ${verdict.marginUsd != null ? verdict.marginUsd + ' USDT margin x ' + lev + 'x = ' + (verdict.marginUsd * lev).toFixed(2) + ' USDT position' : 'by risk'}${verdict.sizeNote && /capped/.test(verdict.sizeNote) ? ' (' + verdict.sizeNote.split('; ')[1] + ')' : ''}`,
      measured: { qty: verdict.positionSize, leverage: lev, marginUsd: verdict.marginUsd }, action: 'Order sent', mode: 'live', cooldownMs: 0 });
    return { ok: true };
  }

  async _monitorTick() {
    if (!this.running || this._monitoring) return;
    this._monitoring = true;
    try {
      const open = this.paperEngine.getOpenTrades();
      if (open.length) {
        const tickers = await this._getTickerMap();
        const symbols = [...new Set(open.map(t => t.symbol))];
        for (const sym of symbols) {
          const px = tickers[sym]?.lastPrice || tickers[sym]?.markPrice;
          if (!px) continue;
          const closed = this.paperEngine.updateTrades(sym, px);
          for (const t of closed) {
            try { require('./intelligence/outcomes').noteClose({ symbol: t.symbol, mode: 'paper', pnl: t.pnl }); } catch (_) { /* tracker only */ }
            decisions.record({ type: 'TRADE_CLOSED', severity: 'INFO', symbol: t.symbol, direction: t.direction, strategy: t.strategyName || t.strategy, module: /TRAIL/.test(t.exitReason || '') ? 'smartTrailing' : 'stopLoss', reason: `Paper trade closed: ${t.exitReason || 'exit'} at ${t.exitPrice}`,
              measured: { pnl: t.pnl, exitPrice: t.exitPrice }, action: 'Position closed', outcome: t.pnl >= 0 ? 'WIN' : 'LOSS', mode: 'paper', cooldownMs: 0 });
            if (!config.isLive) await this.notifier.notifyTradeClosed(t).catch(() => {});
          }
        }
      }
      this.paperEngine.flushOutbox();
      this._reconcileEngineWithJournal();
    } catch (err) {
      logger.warn(`Monitor tick failed: ${err.message}`);
    } finally {
      this._monitoring = false;
      this._writeHeartbeat();
    }
  }

  /** Self-heal: any open trade in memory that is missing from the DB is re-saved */
  _reconcileEngineWithJournal() {
    const dbOpen = new Set(journal.getOpenPaperTrades(config.isLive ? 'lab' : undefined).map(r => r.id));
    for (const t of this.paperEngine.getOpenTrades()) {
      if (!dbOpen.has(t.id)) {
        logger.warn(`Reconcile: open trade ${t.symbol} (${t.id}) missing from journal — re-saving`);
        this.paperEngine._persist(t);
      }
    }
  }

  _attachEventPersistence() {
    this._eventListener = (name, payload) => {
      if (!PERSISTED_EVENTS.includes(name)) return;
      try {
        const slim = { ...payload };
        if (slim.trade) {
          const t = slim.trade;
          slim.trade = {
            id: t.id, symbol: t.symbol, direction: t.direction, strategyName: t.strategyName,
            entry: t.entry, stopLoss: t.stopLoss, takeProfit: t.takeProfit,
            exitPrice: t.exitPrice, pnl: t.pnl, outcome: t.outcome, exitReason: t.exitReason,
            openTime: t.openTime, closeTime: t.closeTime,
          };
        }
        delete slim.signal;
        journal.appendEvent(name, slim);
        if (Math.random() < 0.02) journal.pruneEvents(2000);
      } catch (err) {
        logger.warn(`Event persistence failed (${name}): ${err.message}`);
      }
    };
    eventBus.on('*', this._eventListener);
  }

  _setEmergency(on, why = 'command') {
    if (on) {
      this.riskEngine.emergencyStop();
      this.paperEngine.riskEngine.emergencyStop();
      this.paused = true;
      journal.setState('emergency_stop', true);
    } else {
      this.riskEngine.resetKillSwitch();
      this.paperEngine.riskEngine.resetKillSwitch();
      this.paperEngine.riskEngine.enableTrading();
      journal.setState('emergency_stop', false);
    }
    logger.risk(`Emergency ${on ? 'ACTIVATED' : 'RESET'} (${why})`);
  }

  _applyConfigOverrides(o = {}) {
    const cfg = this.paperEngine.riskEngine.cfg;
    if (o.accountBalance > 0) {
      this.paperEngine.balance = o.accountBalance;
      this.paperEngine.startBalance = o.accountBalance;
      cfg.accountBalance = o.accountBalance;
    }
    if (o.riskPerTrade > 0 && o.riskPerTrade <= 0.5) cfg.riskPerTrade = o.riskPerTrade;
    if (o.maxOpenPositions >= 0 && o.maxOpenPositions <= 1000) cfg.maxOpenPositions = o.maxOpenPositions;
    if (o.maxDailyLoss >= 0 && o.maxDailyLoss <= 1) cfg.maxDailyLoss = o.maxDailyLoss;
    if (o.leverage >= 1 && o.leverage <= 100) cfg.leverage = o.leverage;
  }

  async _commandTick() {
    if (!this.running || this._commandBusy) return;
    this._commandBusy = true;
    try {
      journal.expireStaleCommands(60000);
      const pending = journal.claimPendingCommands(20);
      for (const cmd of pending) {
        try {
          const result = await this._executeCommand(cmd);
          journal.completeCommand(cmd.id, 'DONE', result);
        } catch (err) {
          logger.warn(`Command #${cmd.id} ${cmd.type} failed: ${err.message}`);
          journal.completeCommand(cmd.id, 'FAILED', { error: err.message });
        }
      }
      // Reflect the new state (paused / open count) on the dashboard immediately, not on the next 5s tick
      if (pending.length) this._writeHeartbeat();
    } catch (err) {
      logger.warn(`Command poller error: ${err.message}`);
    } finally {
      this._commandBusy = false;
    }
  }

  async _executeCommand(cmd) {
    const p = cmd.payload || {};
    switch (cmd.type) {
      case 'CLOSE_POSITION': {
        const id = p.id;
        if (!id) throw new Error('Position id required');
        let trade = this.paperEngine.getOpenTrades().find(t => t.id === id || t.symbol === id);
        if (!trade) {
          const live = journal.getOpenLiveTrades().find(t => t.id === id || t.symbol === id);
          if (live) throw new Error('Live positions must be closed on the exchange — dashboard close is paper-only');
          // Open in the journal but missing from memory (restart/desync) — re-attach it, then close normally
          const row = journal.getOpenPaperTrades().find(r => r.id === id || r.symbol === id);
          if (row) {
            trade = this.paperEngine.adoptOpenRow(row) || this.paperEngine.getOpenTrades().find(t => t.id === row.id);
            logger.warn(`Close: re-attached orphaned open position ${row.symbol} (${row.id}) from journal`);
          }
          // v7.1: a row the robot is not allowed to manage (e.g. a plain-paper/test row while LIVE) can never be closed normally. It never traded: remove it.
          if (row && !trade) {
            require('./control/selfHeal').removeOrphanRow(row.id);
            logger.warn(`Close: removed unmanageable ghost row ${row.symbol} (${row.id})`);
            return { closed: { id: row.id, symbol: row.symbol, exitPrice: null, pnl: 0, outcome: 'REMOVED_GHOST' } };
          }
        }
        if (!trade) throw new Error(`Position ${id} is not open (it may already have been closed by SL/TP) — refresh the dashboard`);
        const tickers = await this._getTickerMap(1500);
        const px = tickers[trade.symbol]?.lastPrice || tickers[trade.symbol]?.markPrice;
        if (!(px > 0)) throw new Error(`No live market price for ${trade.symbol} — not closed`);
        const closed = this.paperEngine.closeTrade(trade.id, p.reason || 'MANUAL_DASHBOARD_CLOSE', px);
        await this.notifier.notifyTradeClosed(closed).catch(() => {});
        return { closed: { id: closed.id, symbol: closed.symbol, exitPrice: closed.exitPrice, pnl: closed.pnl, outcome: closed.outcome } };
      }
      case 'CLOSE_ALL': {
        if (config.isLive) throw new Error('CLOSE_ALL is paper-only: close real positions on the exchange');
        const tickers = await this._getTickerMap(1500);
        const priceFor = (sym) => tickers[sym]?.lastPrice || tickers[sym]?.markPrice || null;
        const closed = this.paperEngine.closeAllTrades(p.reason || 'MANUAL_DASHBOARD_CLOSE_ALL', priceFor, { strict: true });
        for (const t of closed) await this.notifier.notifyTradeClosed(t).catch(() => {});
        return {
          count: closed.length,
          closed: closed.map(t => ({ id: t.id, symbol: t.symbol, exitPrice: t.exitPrice, pnl: t.pnl })),
          failed: closed.failed || [],
        };
      }
      case 'CLOSE_LIVE_POSITION': {
        if (!config.isLive) throw new Error('Not in LIVE mode');
        if (!p.symbol) throw new Error('symbol required');
        const r = await this.liveExecution.orders.closePosition(String(p.symbol), p.reason || 'manual close from dashboard');
        if (!r.ok) throw new Error(`${p.symbol}: ${r.reason}`);
        return r;
      }
      case 'FLATTEN_LIVE': {
        if (!config.isLive) throw new Error('Not in LIVE mode');
        const om = this.liveExecution.orders;
        const c = await om.cancelAllEntries();
        const f = await om.flatten(p.reason || 'FLATTEN ALL from dashboard');
        this.paused = true; journal.setState('live_paused', true);        // flattening always pauses new entries
        this.alerts.emit({ category: 'safety', severity: 'CRITICAL', title: 'FLATTEN ALL executed', message: `closed ${f.closed.length}, failed ${f.failed.length}, entries cancelled ${c.cancelled.length}. Entries are PAUSED.` }).catch(() => {});
        if (f.failed.length) throw new Error(`Some positions did not close: ${f.failed.map(x => `${x.symbol} ${x.reason}`).join('; ')}`);
        return { closed: f.closed.map(x => x.symbol), cancelledEntries: c.cancelled.length, remaining: f.remaining };
      }
      case 'KILL_LIVE': {
        if (!config.isLive) throw new Error('Not in LIVE mode');
        this._setEmergency(true, 'live kill switch');
        this.paused = true; journal.setState('live_paused', true);
        const c = await this.liveExecution.orders.cancelAllEntries();
        this.alerts.emit({ category: 'safety', severity: 'CRITICAL', title: 'KILL SWITCH activated', message: `No new trades. ${c.cancelled.length} resting entries cancelled. Open positions KEEP their exchange stop-loss.` }).catch(() => {});
        return { emergency: true, cancelledEntries: c.cancelled.length };
      }
      case 'TAKE_PREVIEW': {
        const t = await this._prepareTake(p);
        const eq = config.isLive ? this._equityNow() : this.paperEngine.balance;
        const riskUsd = eq * this.riskEngine.cfg.riskPerTrade * (t.sig._sizeFactor == null ? 1 : t.sig._sizeFactor);
        return { symbol: t.symbol, direction: t.direction, strategy: t.sig.strategyName || t.sig.strategyId, score: t.sig.score, entry: t.sig.entry, stopLoss: t.sig.stopLoss, takeProfit: t.sig.takeProfit, riskReward: t.sig.riskReward,
          livePrice: t.px, driftPct: Number(t.driftPct.toFixed(3)), maxDriftPct: config.manualTakeMaxDriftPct, riskUsd: Number(riskUsd.toFixed(2)), openCount: t.openCount, slotLimit: t.slotLimit, hardCap: t.hardCap, overridesSlots: t.overridesSlots, needsRiskConfirm: t.needsRiskConfirm, openRiskPct: Number(t.openRiskPct.toFixed(2)), openRiskPctAfter: Number(t.openRiskPctAfter.toFixed(2)), riskConfirmPct: config.manualTakeRiskConfirmPct, riskBlocked: t.riskBlocked, directionConflict: t.directionConflict, mode: config.isLive ? 'LIVE' : 'PAPER',
          sizing: config.isLive ? (() => { const rt = require('./control/runtime'); return { ...rt.sizing(), presets: rt.MARGINS, step: config.manualMarginStep, min: config.manualMarginMin, custom: config.manualCustomMargin }; })() : null };
      }
      case 'TAKE_SETUP': return this._takeSetup(p);
      case 'SET_ENTRY_BLOCK_FORCE': {
        const on = this.liveExecution.orders.setForceClear(!!p.enabled);
        journal.setState('entry_block_status', { ...this.liveExecution.orders.blockStatus(), ts: Date.now() });
        return { forceClear: on };
      }
      case 'CLEAR_ENTRY_BLOCK_NOW': {      // unconditional - operator override, same effect as force mode but immediate
        const om = this.liveExecution.orders; const b = om.blocked();
        if (!b) return { cleared: false, note: 'no entry block active' };
        (om._forced = om._forced || new Map()).set(b.reason, Date.now());
        om.unblock(); om._cleared(b, 'forced', 'operator forced clear now');
        journal.setState('entry_block_status', { ...om.blockStatus(), ts: Date.now() });
        return { cleared: true };
      }
      case 'UNBLOCK_ENTRIES': {
        const open = this.liveExecution.orders.list(true).filter(r => r.state === 'UNKNOWN' || r.protected === false);
        if (open.length) throw new Error(`Resolve first: ${open.map(r => `${r.symbol} ${r.state}${r.protected === false ? ' UNPROTECTED' : ''}`).join(', ')}`);
        this.liveExecution.orders.unblock();
        return { unblocked: true };
      }
      case 'RESET_ACCOUNT': {
        if (config.isLive) throw new Error('RESET_ACCOUNT is paper-only: in LIVE mode the balance is your real exchange equity');
        const bal = parseFloat(p.balance);
        if (!(bal > 0)) throw new Error('A positive balance is required');
        const tickers = await this._getTickerMap(1500);
        const closed = this.paperEngine.resetAccount(bal, (sym) => tickers[sym]?.lastPrice || tickers[sym]?.markPrice || null);
        for (const t of closed) await this.notifier.notifyTradeClosed(t).catch(() => {});
        journal.setState('account_epoch', { ts: Date.now(), balance: bal });
        const ov = journal.getState('config_overrides') || {};
        ov.accountBalance = bal;
        journal.setState('config_overrides', ov);
        this._applyConfigOverrides(ov);
        this._updateState();
        this._writeHeartbeat();
        return { balance: bal, closed: closed.length };
      }
      case 'STRATEGY_TOGGLE': {
        this.strategyRegistry.setEnabled(p.id, !!p.enabled);
        const st = journal.getState('strategy_overrides') || {};
        st[p.id] = !!p.enabled;
        journal.setState('strategy_overrides', st);
        return { id: p.id, enabled: !!p.enabled };
      }
      case 'CONFIG_UPDATE':
        this._applyConfigOverrides(p);
        return { applied: true };
      case 'CLOSE_BY_PNL': {   // v5.2.4: close ALL losing (or ALL winning) positions; entries are NOT paused, the other side keeps running
        const which = p.which === 'winning' ? 'winning' : p.which === 'losing' ? 'losing' : null;
        if (!which) throw new Error('which must be "losing" or "winning"');
        const closed = [], failed = []; let skipped = 0;
        if (config.isLive) {
          const om = this.liveExecution.orders;
          const positions = await om.exchange.getPositions();
          for (const pos of positions) {
            const pnl = Number(pos.upnl);
            if (!isFinite(pnl) || (which === 'losing' ? !(pnl < 0) : !(pnl > 0))) { skipped++; continue; }
            const r = await om.closePosition(pos.symbol, `manual: close all ${which.toUpperCase()}`);
            if (r.ok) { closed.push({ symbol: pos.symbol, pnl }); decisions.record({ type: 'TRADE_CLOSED', severity: 'INFO', symbol: pos.symbol, direction: pos.side, module: 'manualClose', reason: `You pressed Close all ${which.toUpperCase()} (floating PnL ${pnl.toFixed(4)} USDT at that moment)`, measured: { upnl: pnl }, action: 'Reduce-only market close sent', mode: 'live', cooldownMs: 0 }); }
            else failed.push({ symbol: pos.symbol, reason: r.reason });
          }
        } else {
          const tickers = await this._getTickerMap(1500);
          for (const t of this.paperEngine.getOpenTrades()) {
            const px = tickers[t.symbol]?.lastPrice || tickers[t.symbol]?.markPrice;
            if (!(px > 0)) { failed.push({ symbol: t.symbol, reason: 'no live price' }); continue; }
            const pnl = (t.direction === 'LONG' ? px - t.entry : t.entry - px) * t.positionSize;
            if (which === 'losing' ? !(pnl < 0) : !(pnl > 0)) { skipped++; continue; }
            const c = this.paperEngine.closeTrade(t.id, `MANUAL_CLOSE_ALL_${which.toUpperCase()}`, px);
            if (c) { closed.push({ symbol: c.symbol, pnl: c.pnl }); decisions.record({ type: 'TRADE_CLOSED', severity: 'INFO', symbol: c.symbol, direction: c.direction, module: 'manualClose', reason: `You pressed Close all ${which.toUpperCase()}`, measured: { pnl: c.pnl }, action: 'Paper position closed', mode: 'paper', cooldownMs: 0 }); await this.notifier.notifyTradeClosed(c).catch(() => {}); }
          }
        }
        this.alerts.emit({ category: 'orders', severity: 'WARNING', title: `Close all ${which.toUpperCase()}`, message: `closed ${closed.length}, failed ${failed.length}, left running ${skipped}` }).catch(() => {});
        if (failed.length && !closed.length) throw new Error(`Nothing closed: ${failed.map(x => `${x.symbol} ${x.reason}`).join('; ')}`);
        return { which, closed, failed, leftRunning: skipped, message: `Closed ${closed.length} ${which} position(s); ${skipped} left running${failed.length ? `; ${failed.length} failed` : ''}.` };
      }
      case 'PAUSE':
        decisions.record({ type: 'SYSTEM', severity: 'INFO', module: 'takeLiveTrades', reason: 'Take Live Trades switched OFF by you - no new entries. Open trades keep their stops.', key: 'take_off', cooldownMs: 0 });
        this.paused = true;
        if (config.isLive) { journal.setState('live_paused', true); this.alerts.emit({ category: 'safety', severity: 'WARNING', title: 'Live entries PAUSED', message: 'No new trades. Open positions keep their exchange stop-loss. /resume to continue.' }).catch(() => {}); }
        return { paused: true };
      case 'RESUME':
        decisions.record({ type: 'SYSTEM', severity: 'INFO', module: 'takeLiveTrades', reason: 'Take Live Trades switched ON by you - the robot may open new trades.', key: 'take_on', cooldownMs: 0 });
        if (config.isLive) { journal.setState('live_paused', false); this.alerts.emit({ category: 'safety', severity: 'INFO', title: 'Live entries RESUMED', message: 'New trades allowed again.' }).catch(() => {}); }
        if (this.paperEngine.riskEngine.state.killSwitch) throw new Error('Emergency stop active — reset it first');
        this.paused = false;
        return { paused: false };
      case 'EMERGENCY_STOP':
        this._setEmergency(true, 'dashboard');
        return { emergency: true };
      case 'EMERGENCY_RESET':
        this._setEmergency(false, 'dashboard');
        return { emergency: false };
      default:
        throw new Error(`Unknown command type: ${cmd.type}`);
    }
  }

  async _refreshMarkets() {
    try {
      this.markets = await discoverMarkets(true);
      journal.setState('market_count', this.markets.length);
      if (liveFeed.started) liveFeed.setUniverse(this.markets);
      logger.info(`Markets refreshed: ${this.markets.length} eligible crypto markets`);
    } catch (err) {
      logger.error(`Market discovery failed: ${err.message}`);
    }
  }

  _updateState() {
    const perf = this.paperEngine.getPerformance();
    journal.setState('performance', perf);
    journal.setState('scan_count', this.scanCount);
    journal.setState('last_scan', Date.now());
  }

  getStatus() {
    const perf = this.paperEngine.getPerformance();
    const watchdogStatus = this.watchdog.getStatus();
    const reconStatus = this.reconciliation.getStatus();
    const opState = this.liveExecution.getOperationalState();

    return {
      running: this.running,
      mode: config.mode,
      operationalState: opState,
      scanCount: this.scanCount,
      marketCount: this.markets.length,
      uptime: this._startTime ? Math.floor((Date.now() - this._startTime) / 1000) : 0,
      strategies: this.strategyRegistry.status(),
      riskStatus: this.riskEngine.getStatus(),
      watchdog: watchdogStatus,
      reconciliation: reconStatus,
      performance: perf,
      lastSignals: config.scannerDisplayLimit > 0 ? this.lastSignals.slice(0, config.scannerDisplayLimit) : this.lastSignals,
      live: config.isLive ? journal.getState('live_status') : null,
    };
  }
}

// ── Entry Point ────────────────────────────────────────────────────────────

if (require.main === module) {
  const robot = new TradingRobot();

  const args = process.argv.slice(2);
  const modeArg = args.find(a => a.startsWith('--mode='));
  if (modeArg) {
    const m = modeArg.split('=')[1].toUpperCase();
    process.env.TRADING_MODE = m;
  }

  robot.start().catch(err => {
    logger.error(`Robot startup failed: ${err.message}`);
    process.exit(1);
  });
}

module.exports = TradingRobot;
