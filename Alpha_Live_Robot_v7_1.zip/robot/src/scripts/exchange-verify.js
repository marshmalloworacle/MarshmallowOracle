'use strict';
/**
 * Read-only exchange check: node src/scripts/exchange-verify.js [mexc|bitget|bybit]
 * Verifies reachability, clock drift, contracts, credentials and account read. NEVER places an order.
 */
const arg = (process.argv[2] || process.env.EXCHANGE || 'mexc').toLowerCase();
if (!['mexc', 'bitget', 'bybit'].includes(arg)) { console.error('usage: exchange-verify [mexc|bitget|bybit]'); process.exit(2); }
process.env.EXCHANGE = arg;
const config = require('../config');
config.exchange = arg;
const ex = require(`../exchanges/${arg}`);
(async () => {
  console.log(`\nRead-only verification: ${arg.toUpperCase()}${arg === 'bybit' && config.bybit.testnet ? ' (TESTNET)' : ''}  - no orders are sent\n`);
  const r = await ex.verify();
  let failed = 0;
  for (const c of r.checks) {
    const mark = c.ok === true ? 'PASS' : c.ok === false ? 'FAIL' : 'INFO';
    if (c.ok === false) failed++;
    console.log(`  [${mark}] ${c.name}: ${c.detail}`);
  }
  if (arg === 'mexc' && r.apiAllowedCount === 0) console.log('\n  WARNING: MEXC reports apiAllowed=false on every contract: API order placement is not enabled. Ask MEXC support for futures API trading access, or use EXCHANGE=bybit.');
  console.log(failed ? `\n${failed} check(s) failed.` : '\nAll read-only checks passed. (Order permission is only proven by a real order; see LIVE_MEXC.md.)');
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('verify crashed:', e.message); process.exit(1); });
