'use strict';
/**
 * npm run env:upgrade - append-only: copies variables that exist in .env.example but are MISSING from .env (with their comments).
 * Never edits, reorders or deletes an existing line, never touches API keys or any value you set. A backup is written first.
 * `--check` only reports. If .env does not exist it is created from .env.example (no keys inside).
 */
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..', '..');
const ex = path.join(root, '.env.example'), env = path.join(root, '.env');
const check = process.argv.includes('--check');
const keyOf = (l) => { const m = /^\s*([A-Z][A-Z0-9_]*)\s*=/.exec(l); return m ? m[1] : null; };
if (!fs.existsSync(ex)) { console.error('.env.example not found'); process.exit(1); }
if (!fs.existsSync(env)) { if (check) { console.log('.env does not exist yet (npm run env:upgrade creates it from .env.example)'); process.exit(0); } fs.copyFileSync(ex, env); try { fs.chmodSync(env, 0o600); } catch (_) {} console.log('Created .env from .env.example'); process.exit(0); }
const have = new Set(fs.readFileSync(env, 'utf8').split(/\r?\n/).map(keyOf).filter(Boolean));
const lines = fs.readFileSync(ex, 'utf8').split(/\r?\n/), add = [], missing = [];
let pendingComments = [];
for (const l of lines) {
  const k = keyOf(l);
  if (!k) { pendingComments.push(l); if (pendingComments.length > 12) pendingComments.shift(); continue; }
  if (!have.has(k)) { add.push(...pendingComments.filter(c => c.trim().startsWith('#') && !/^#\s*[═─-]{4,}/.test(c.trim())).slice(-1), l); missing.push(k); }
  pendingComments = [];
}
if (!missing.length) { console.log('.env already has every variable from .env.example. Nothing to do.'); process.exit(0); }
if (check) { console.log(`${missing.length} variable(s) missing from .env (defaults are used): ${missing.join(', ')}`); process.exit(0); }
const bak = `${env}.bak-${new Date().toISOString().replace(/[:.]/g, '-')}`;
fs.copyFileSync(env, bak);
const cur = fs.readFileSync(env, 'utf8');
fs.writeFileSync(env, cur.replace(/\s*$/, '\n') + `\n# ── added by npm run env:upgrade (${new Date().toISOString().slice(0, 10)}) - your existing lines were not changed ──\n` + add.join('\n') + '\n', { mode: 0o600 });
console.log(`Added ${missing.length} missing variable(s) to .env (backup: ${path.basename(bak)}):\n  ${missing.join('\n  ')}`);
