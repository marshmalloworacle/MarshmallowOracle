'use strict';
/**
 * npm run bitget:stops  : READ-ONLY. Checks that the robot can READ BACK the exchange-side stop-loss / take-profit
 * of your open Bitget positions (Classic or Unified). The robot treats a position whose stop it cannot read as UNPROTECTED.
 * How to run the check without the robot: open the smallest possible position by hand in the Bitget app,
 * set a stop-loss and take-profit on it there, then run this command. It never places, changes or cancels anything.
 */
const config = require('../config');
const bitget = require('../exchanges/bitget');
(async () => {
  console.log('Bitget stop-loss / take-profit read-back check (read-only)\n');
  if (!config.bitget.apiKey || !config.bitget.apiSecret || !config.bitget.passphrase) { console.log('  [FAIL] BITGET_API_KEY / BITGET_API_SECRET / BITGET_PASSPHRASE are not set (save them in the dashboard Exchange tab or .env).'); process.exit(1); }
  const type = await bitget.accountType(); console.log(`  account type: ${type.toUpperCase()} (BITGET_ACCOUNT_TYPE=${config.bitget.accountType})`);
  const pos = await bitget.getPositions();
  console.log(`  open positions: ${pos.length}`);
  if (!pos.length) {
    console.log('\n  Nothing to check yet. Open the smallest position by hand in the Bitget app (USDT futures), set a stop-loss and take-profit on it, then run this again.');
    try { const raw = await bitget.rawStops(); console.log(`  (strategy/plan orders visible right now: ${raw.length})`); } catch (e) { console.log(`  [FAIL] cannot query TP/SL orders: ${e.message}`); process.exit(1); }
    process.exit(0);
  }
  let bad = 0;
  for (const p of pos) {
    let stops = [], raw = [];
    try { stops = await bitget.getStopOrders(p.symbol); raw = await bitget.rawStops(p.symbol); } catch (e) { console.log(`\n  ${p.symbol} ${p.side}: [FAIL] could not read TP/SL orders: ${e.message}`); bad++; continue; }
    const mine = stops.find(s => s.long === (p.side === 'LONG'));
    console.log(`\n  ${p.symbol} ${p.side} qty ${p.qty} entry ${p.entry}${p.sideUnknown ? '  (WARNING: side inferred, not reported by Bitget)' : ''}`);
    console.log(`    stop-loss read back : ${mine && mine.stopLoss ? mine.stopLoss : 'NONE'}`);
    console.log(`    take-profit read back: ${mine && mine.takeProfit ? mine.takeProfit : 'NONE'}`);
    if (!(mine && mine.stopLoss)) { bad++; console.log(`    [FAIL] the robot could NOT read a stop-loss for this position. Raw TP/SL orders returned: ${raw.length}`); if (raw[0]) console.log(`    field names Bitget returned (send these to fix the parser): ${Object.keys(raw[0]).join(', ')}`); }
    else console.log('    [PASS] stop-loss is readable: the robot can verify protection and move it when trailing.');
  }
  console.log(bad ? `\n${bad} position(s) failed. Do NOT trade live on this exchange until this passes.` : '\nAll open positions show a readable stop-loss.');
  console.log('Note: this proves READING. Moving the stop (trailing) is only proven by a real small trade; the robot reads the stop back after every move and alerts if it did not take.');
  process.exit(bad ? 1 : 0);
})().catch(e => { console.error('check crashed:', e.message); process.exit(1); });
