'use strict';
/**
 * Safe .env read/write for the dashboard Exchange tab.
 * - Only WHITELISTED keys can be written (exchange selection, API keys, trading mode). Nothing else in .env is touched.
 * - Values are validated (no newlines/control characters, max 256 chars) and quoted when needed, so a value can never inject another setting.
 * - Writes are atomic (temp file + rename) and the file is chmod 600. .env is gitignored.
 * - Secrets are NEVER returned to the browser: use mask()/status() only.
 */
const fs = require('fs');
const path = require('path');

const ENV_PATH = path.resolve(__dirname, '..', '..', '.env');
const SECRET_KEYS = ['BYBIT_API_SECRET', 'MEXC_API_SECRET', 'BITGET_API_SECRET', 'BITGET_PASSPHRASE'];
const ALLOWED = new Set(['EXCHANGE', 'TRADING_MODE', 'LIVE_TRADING_ENABLED', 'BITGET_ACCOUNT_TYPE',
  'BYBIT_API_KEY', 'BYBIT_API_SECRET', 'MEXC_API_KEY', 'MEXC_API_SECRET', 'BITGET_API_KEY', 'BITGET_API_SECRET', 'BITGET_PASSPHRASE']);
/** Keys the dashboard 'Save' button may write. TRADING_MODE / LIVE_TRADING_ENABLED are NOT here: only you, in .env, change them (v6.5: no dashboard switch). */
const CREDENTIAL_KEYS = new Set(['BYBIT_API_KEY', 'BYBIT_API_SECRET', 'MEXC_API_KEY', 'MEXC_API_SECRET', 'BITGET_API_KEY', 'BITGET_API_SECRET', 'BITGET_PASSPHRASE']);
const CLEAR = '__CLEAR__';

function parse(text) {
  const out = {};
  for (const line of String(text || '').split(/\r?\n/)) {
    const t = line.trim(); if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('='); if (i < 0) continue;
    let v = t.slice(i + 1).trim();
    const q = v[0] === '"' || v[0] === "'" ? v[0] : null;
    if (q && v.indexOf(q, 1) > 0) v = v.slice(1, v.indexOf(q, 1)); else v = v.replace(/\s+#.*$/, '').trim();
    out[t.slice(0, i).trim()] = v;
  }
  return out;
}
function readFile(p = ENV_PATH) { try { return fs.readFileSync(p, 'utf8'); } catch (_) { return ''; } }
function readAll(p = ENV_PATH) { return parse(readFile(p)); }
const quote = (v) => (/[\s#"']/.test(v) ? `"${v.replace(/"/g, '')}"` : v);

function validate(key, value) {
  if (!ALLOWED.has(key)) throw new Error(`setting ${key} cannot be changed from the dashboard`);
  const v = String(value);
  if (/[\r\n\0]/.test(v)) throw new Error(`${key}: invalid characters`);
  if (v.length > 256) throw new Error(`${key}: too long`);
  if (key === 'EXCHANGE' && !['bybit', 'bitget', 'mexc', 'sim'].includes(v)) throw new Error('EXCHANGE must be bybit, bitget, mexc or sim');
  if (key === 'TRADING_MODE' && !['SIM', 'LIVE'].includes(v)) throw new Error('TRADING_MODE must be SIM or LIVE');
  if (key === 'LIVE_TRADING_ENABLED' && !['true', 'false'].includes(v)) throw new Error('LIVE_TRADING_ENABLED must be true or false');
  if (key === 'BITGET_ACCOUNT_TYPE' && !['auto', 'classic', 'uta'].includes(v)) throw new Error('BITGET_ACCOUNT_TYPE must be auto, classic or uta');
  return v;
}

/** updates: { KEY: 'value' | '' (leave unchanged) | '__CLEAR__' (remove value) }. Returns the list of keys actually written. */
function set(updates, p = ENV_PATH) {
  const changes = {};
  for (const [k, raw] of Object.entries(updates || {})) {
    if (raw === undefined || raw === null || raw === '') continue;            // blank = keep what is already saved
    changes[k] = raw === CLEAR ? '' : validate(k, raw);
    if (raw === CLEAR && !ALLOWED.has(k)) throw new Error(`setting ${k} cannot be changed from the dashboard`);
  }
  const keys = Object.keys(changes); if (!keys.length) return [];
  const lines = readFile(p).split(/\r?\n/); const done = new Set();
  const next = lines.map((line) => {
    const t = line.trim(); if (!t || t.startsWith('#')) return line;
    const i = t.indexOf('='); if (i < 0) return line;
    const k = t.slice(0, i).trim();
    if (k in changes && !done.has(k)) { done.add(k); return `${k}=${quote(changes[k])}`; }
    return line;
  });
  while (next.length && next[next.length - 1] === '') next.pop();
  for (const k of keys) if (!done.has(k)) next.push(`${k}=${quote(changes[k])}`);
  const tmp = `${p}.tmp-${process.pid}`;
  fs.writeFileSync(tmp, next.join('\n') + '\n', { mode: 0o600 });
  fs.renameSync(tmp, p); try { fs.chmodSync(p, 0o600); } catch (_) { /* best effort */ }
  return keys;
}

const mask = (v) => (!v ? null : v.length > 8 ? `••••${v.slice(-4)}` : '••••');
/** What the browser may see: whether each credential is saved plus a masked tail; never a full secret. */
function keyStatus(p = ENV_PATH) {
  const e = readAll(p); const row = (names) => Object.fromEntries(names.map(n => [n, { saved: !!e[n], masked: SECRET_KEYS.includes(n) ? (e[n] ? '••••••••' : null) : mask(e[n]) }]));
  return {
    bybit: row(['BYBIT_API_KEY', 'BYBIT_API_SECRET']), mexc: row(['MEXC_API_KEY', 'MEXC_API_SECRET']), bitget: row(['BITGET_API_KEY', 'BITGET_API_SECRET', 'BITGET_PASSPHRASE']),
    selected: { EXCHANGE: e.EXCHANGE || null, TRADING_MODE: e.TRADING_MODE || null, LIVE_TRADING_ENABLED: e.LIVE_TRADING_ENABLED || null, BITGET_ACCOUNT_TYPE: e.BITGET_ACCOUNT_TYPE || null },
  };
}
module.exports = { ENV_PATH, ALLOWED, CREDENTIAL_KEYS, SECRET_KEYS, CLEAR, parse, readAll, set, mask, keyStatus, validate };
