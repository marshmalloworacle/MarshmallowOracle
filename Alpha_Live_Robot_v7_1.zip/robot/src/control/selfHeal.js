'use strict';
/**
 * v7.1 STALE-DATA SELF-HEAL
 *
 * Fixes "BTCUSDT values were already there on first start and would not go away":
 *  1. Open paper rows that the robot cannot manage (test leftovers `TEST_...`, or PLAIN-paper rows while LIVE, where only Paper Lab
 *     rows are adopted) can never be closed, because the dashboard lists them straight from the database. They never traded, so
 *     they are DELETED (not recorded as fake closed trades, which would pollute win-rate / expectancy / adaptive learning).
 *  2. A scanner session left RUNNING/PAUSED from an earlier run (older than SCAN_SESSION_MAX_AGE_HOURS) is marked STOPPED so a
 *     fresh start never shows old "scanned" symbols or old qualified setups.
 * Runs at start of BOTH the robot and the dashboard (idempotent), and on demand from the dashboard "Clear stale rows" button.
 */
const config = require('../config');
const journal = require('../journal/store');

const DEFAULT_MAX_AGE_H = 6;
function maxAgeHours() {
  const v = Number(process.env.SCAN_SESSION_MAX_AGE_HOURS);
  return Number.isFinite(v) && v >= 0 ? v : DEFAULT_MAX_AGE_H;
}
function enabled() { return String(process.env.STARTUP_SELF_HEAL || 'true').toLowerCase() !== 'false'; }

/** Delete one open paper row the robot cannot manage. Used by the close command as a last resort. */
function removeOrphanRow(id) {
  const r = journal.getDb().prepare("DELETE FROM paper_trades WHERE id = ? AND close_time IS NULL AND outcome IS NULL").run(id);
  return Number(r.changes) || 0;
}

/**
 * @param {{force?:boolean, isLive?:boolean, now?:number}} o  force = ignore age and clear every unfinished scan session too
 * @returns {{removedTestRows:number, removedOrphans:number, stoppedScanSessions:number}}
 */
function run({ force = false, isLive = config.isLive, now = Date.now() } = {}) {
  const out = { removedTestRows: 0, removedOrphans: 0, stoppedScanSessions: 0 };
  const db = journal.getDb();
  try {
    out.removedTestRows = Number(db.prepare("DELETE FROM paper_trades WHERE close_time IS NULL AND outcome IS NULL AND id LIKE 'TEST\\_%' ESCAPE '\\'").run().changes) || 0;
    if (isLive) out.removedOrphans = Number(db.prepare("DELETE FROM paper_trades WHERE close_time IS NULL AND outcome IS NULL AND (mode IS NULL OR mode != 'LAB')").run().changes) || 0;
  } catch (e) { out.error = `trade cleanup: ${e.message}`; }
  try {
    const cutoff = force ? now + 1 : now - maxAgeHours() * 3600e3;
    out.stoppedScanSessions = Number(db.prepare("UPDATE scan_sessions SET status = 'STOPPED', updated_at = ? WHERE status IN ('RUNNING','PAUSED','IDLE') AND COALESCE(updated_at, started_at, 0) < ?").run(now, cutoff).changes) || 0;
  } catch (e) { out.error = `${out.error ? out.error + '; ' : ''}scan cleanup: ${e.message}`; }
  return out;
}

/** Startup entry point: honours STARTUP_SELF_HEAL=false and logs what it did. */
function startup(log = console) {
  if (!enabled()) return null;
  const r = run();
  const n = r.removedTestRows + r.removedOrphans + r.stoppedScanSessions;
  if (n) log.warn ? log.warn(`[self-heal] cleared stale data: ${r.removedTestRows} test row(s), ${r.removedOrphans} unmanageable open paper row(s), ${r.stoppedScanSessions} old scan session(s)`) : log.log(`[self-heal] ${JSON.stringify(r)}`);
  return r;
}

module.exports = { run, startup, removeOrphanRow, maxAgeHours };
