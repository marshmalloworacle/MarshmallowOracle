'use strict';
/**
 * Directional entry control. Governs NEW ENTRIES only - never closes, reverses, cancels or edits existing positions
 * (DIRECTION_CHANGE_* in .env are locked to exactly that; set() below never touches a position).
 *
 * Modes: ADAPTIVE | AUTO | BOTH | LONG_ONLY | SHORT_ONLY | PAUSE   (v7.1 adds ADAPTIVE and AUTO; ADI = Adaptive Directional Intelligence)
 *   ADAPTIVE   both directions allowed; ADI only nudges the ORDER of setups toward the stronger direction (never blocks)
 *   AUTO       ADI may restrict new entries to the stronger direction when evidence + confidence are high enough and
 *              the approval rules allow it (paper: ADI_PAPER_AUTO_ADAPT; live: your approval)
 *   BOTH / LONG_ONLY / SHORT_ONLY / PAUSE   fixed manual modes, exactly as before
 * A timed override reverts to the previous mode on expiry (evaluated lazily on every check, so it is correct after a restart).
 * Initial mode comes from .env (TRADING_DIRECTION_MODE / ADI_DIRECTION_MODE). The dashboard choice is persisted in the DB and wins
 * until you EDIT the mode in .env (a changed .env value is applied once, then the dashboard wins again).
 *
 * Hard permissions ALLOW_LONG_TRADES / ALLOW_SHORT_TRADES apply to everything, including Manual Take.
 * Manual Take overrides the direction MODE (with your confirmation) but not those permissions.
 */
const journal = require('../journal/store');
const flags = require('../features/flags');
const adiCfg = require('./adiConfig');

const KEY = 'direction_control';
const MODES = adiCfg.DIR_MODES.slice();
const PRESET_H = [1, 3, 6, 12, 24];
const isLiveRun = () => { try { return !!require('../config').isLive; } catch (_) { return false; } };

function envMode() { try { return adiCfg.cfg().EFFECTIVE_DIRECTION_MODE || 'BOTH'; } catch (_) { return 'BOTH'; } }

function _load() {
  let s = null;
  try { s = journal.getState(KEY); } catch (_) { /* ignore */ }
  const em = envMode();
  if (!s) return { mode: em, defaultMode: em, source: '.env', startedAt: null, expiresAt: null, blocked: 0, reasons: {}, envSeen: em };
  if (!MODES.includes(s.mode)) s = { ...s, mode: em, defaultMode: em };
  if (s.envSeen === undefined) { s = { ...s, envSeen: em }; try { journal.setState(KEY, s); } catch (_) { /* ignore */ } }   // first run of v7.1 on an old DB: keep the saved mode
  else if (s.envSeen !== em && !s.expiresAt) {                                                                             // .env was edited since: that edit wins once
    s = { ...s, mode: em, defaultMode: em, previousMode: s.mode, source: '.env (changed)', startedAt: null, expiresAt: null, envSeen: em };
    try { journal.setState(KEY, s); } catch (_) { /* ignore */ }
  }
  return s;
}
function _save(s) { journal.setState(KEY, { ...s, envSeen: s.envSeen === undefined ? envMode() : s.envSeen }); return s; }

/** Current state with expiry applied. */
function get(now = Date.now()) {
  let s = _load();
  if (s.expiresAt && now >= s.expiresAt) {
    s = { ...s, mode: s.defaultMode || 'BOTH', previousMode: s.mode, source: 'expired', startedAt: null, expiresAt: null };
    _save(s);
  }
  return { ...s, remainingMs: s.expiresAt ? Math.max(0, s.expiresAt - now) : null };
}

/** hours: number | null (null = until changed). Custom duration = any positive number of hours. Changes NEW-ENTRY rules only. */
function set(mode, { hours = null, source = 'dashboard', now = Date.now() } = {}) {
  mode = adiCfg.normMode(mode);
  if (!MODES.includes(mode)) throw new Error(`mode must be one of ${MODES.join(', ')}`);
  if (hours != null && !(hours > 0 && hours <= 24 * 30)) throw new Error('duration must be between 0 and 720 hours');
  const a = adiCfg.cfg();
  if (mode === 'LONG_ONLY' && !a.ALLOW_LONG_TRADES) throw new Error('LONG_ONLY conflicts with ALLOW_LONG_TRADES=false');
  if (mode === 'SHORT_ONLY' && !a.ALLOW_SHORT_TRADES) throw new Error('SHORT_ONLY conflicts with ALLOW_SHORT_TRADES=false');
  const cur = get(now);
  // Timed override remembers what to restore: the mode in force before it (or the existing default if already timed).
  const defaultMode = hours ? (cur.expiresAt ? cur.defaultMode : cur.mode) : mode;
  const s = {
    mode, defaultMode, previousMode: cur.mode, source, startedAt: now, expiresAt: hours ? now + hours * 3600e3 : null,
    blocked: cur.blocked || 0, reasons: cur.reasons || {}, envSeen: cur.envSeen === undefined ? envMode() : cur.envSeen,
  };
  return _save(s);
}

/** What actually restricts NEW entries right now: { mode, effective: BOTH|LONG_ONLY|SHORT_ONLY|PAUSE, via } */
function effective(now = Date.now(), isLive = isLiveRun()) {
  const s = get(now), a = adiCfg.cfg();
  if (s.mode === 'ADAPTIVE' || s.mode === 'AUTO') {
    if (!a.ADI_ENABLED) return { mode: s.mode, effective: 'BOTH', via: 'ADI is OFF - behaves like BOTH' };
    if (s.mode === 'ADAPTIVE') return { mode: s.mode, effective: 'BOTH', via: 'ADAPTIVE: both directions open, ADI only re-orders setups' };
    let r = null; try { r = require('../intelligence/adi').autoRestriction(isLive, now); } catch (_) { /* ADI failure must never block trading */ }
    return r ? { mode: s.mode, effective: r, via: `AUTO: ADI restricts new entries to ${r.replace('_', ' ')}` } : { mode: s.mode, effective: 'BOTH', via: 'AUTO: no approved restriction - both directions open' };
  }
  return { mode: s.mode, effective: s.mode, via: 'fixed mode' };
}

/**
 * Entry gate. Returns { allowed, reason }. opts: { manual, dryRun } (a number is accepted as `now` for older callers).
 * Order: ALLOW_* permissions (always) -> flag off = allowed (v4.5 behaviour) -> manual take skips the MODE -> mode/ADI restriction.
 */
function check(direction, opts = {}) {
  const o = typeof opts === 'number' ? { now: opts } : (opts || {}), now = o.now || Date.now();
  const a = adiCfg.cfg();
  let reason = null;
  if (direction === 'LONG' && !a.ALLOW_LONG_TRADES) reason = 'PERMISSION: LONG trades are not allowed (ALLOW_LONG_TRADES=false)';
  else if (direction === 'SHORT' && !a.ALLOW_SHORT_TRADES) reason = 'PERMISSION: SHORT trades are not allowed (ALLOW_SHORT_TRADES=false)';
  if (!reason) {
    if (!flags.isOn('directionControl') || o.manual) return { allowed: true };
    const e = effective(now, o.isLive);
    if (e.effective === 'PAUSE') reason = 'DIRECTION: new trades paused';
    else if (e.effective === 'LONG_ONLY' && direction === 'SHORT') reason = `DIRECTION: LONG ONLY mode blocks SHORT entries${e.mode === 'AUTO' ? ' (ADI AUTO)' : ''}`;
    else if (e.effective === 'SHORT_ONLY' && direction === 'LONG') reason = `DIRECTION: SHORT ONLY mode blocks LONG entries${e.mode === 'AUTO' ? ' (ADI AUTO)' : ''}`;
  }
  if (!reason) return { allowed: true };
  if (!o.dryRun) {
    try {
      const cur = _load(); cur.blocked = (cur.blocked || 0) + 1; cur.reasons = cur.reasons || {};
      cur.reasons[reason] = (cur.reasons[reason] || 0) + 1; _save(cur);
    } catch (_) { /* counters are best effort; the block itself is not */ }
  }
  return { allowed: false, reason };
}

/**
 * Manual Take helper: does the direction MODE (not the hard permission) conflict with this take?
 * Returns { permissionBlocked, reason } (hard stop) or { conflict, reason } (needs confirmation) or {}.
 */
function manualConflict(direction, now = Date.now()) {
  const a = adiCfg.cfg();
  const hard = check(direction, { manual: true, dryRun: true, now });
  if (!hard.allowed) return { permissionBlocked: true, reason: hard.reason };
  if (!flags.isOn('directionControl')) return {};
  const auto = check(direction, { dryRun: true, now });
  return auto.allowed ? {} : { conflict: true, reason: auto.reason, mode: get(now).mode, effective: effective(now).effective, adi: a.ADI_ENABLED };
}

module.exports = { MODES, PRESET_H, get, set, check, effective, manualConflict, envMode };
