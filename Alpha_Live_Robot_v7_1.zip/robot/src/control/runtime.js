'use strict';
/**
 * v5.2.4 runtime controls shared by the robot and the dashboard (both read/write the same DB state).
 *  - drawdownMode : off | warn | enforce  (LIVE only; default warn = drawdown limits warn, never block)
 *  - leverageChoice: 5 | 10 | 20 or 0 (= automatic scaling). Dashboard value wins over .env LEVERAGE_FIXED.
 * Paper mode keeps the original (enforced) limits so paper results stay comparable.
 */
const config = require('../config');
const journal = require('../journal/store');

const MODES = ['off', 'warn', 'enforce'];
// v7.1: presets come from .env (MANUAL_MARGIN_PRESETS / MANUAL_LEVERAGE_PRESETS, comma separated). Bad entries are ignored; an empty/invalid list falls back to the defaults.
function parseList(raw, def, { int = false, max = 100000 } = {}) {
  if (raw === undefined || String(raw).trim() === '') return def.slice();
  const out = [...new Set(String(raw).split(/[,\s;]+/).map(Number).filter(n => Number.isFinite(n) && n > 0 && n <= max && (!int || Number.isInteger(n))))].sort((a, b) => a - b);
  return out.length ? out : def.slice();
}
const LEVERAGES = parseList(process.env.MANUAL_LEVERAGE_PRESETS, [5, 10, 12, 20, 50], { int: true, max: 125 });   // custom values 1-125 allowed unless MANUAL_CUSTOM_LEVERAGE_ENABLED=false
const MARGINS = parseList(process.env.MANUAL_MARGIN_PRESETS, [1, 1.5, 2, 3, 5, 8, 10, 20]);                       // USDT; custom allowed unless MANUAL_CUSTOM_MARGIN_ENABLED=false
const r4 = (v) => Number(Number(v).toFixed(4));

function drawdownMode() {
  let s = null; try { s = journal.getState('drawdown_mode'); } catch (_) { /* DB not ready */ }
  return MODES.includes(s) ? s : (MODES.includes(config.drawdownMode) ? config.drawdownMode : 'warn');
}
/** effective mode for a given run: paper is always enforce (unchanged behaviour) */
function effectiveDrawdownMode(live = config.isLive) { return live ? drawdownMode() : 'enforce'; }
function setDrawdownMode(m) { if (!MODES.includes(m)) throw new Error(`mode must be one of ${MODES.join(', ')}`); journal.setState('drawdown_mode', m); return m; }

function leverageChoice() {
  let s = null; try { s = journal.getState('leverage_choice'); } catch (_) { /* ignore */ }
  const v = Number(s !== null && s !== undefined ? s : config.leverageFixed);
  return v >= 1 && v <= 125 ? v : 0;     // legacy value: 0 = automatic scaling
}
function setLeverageChoice(v) {
  const n = Number(v);
  if (n === 0) { journal.setState('leverage_choice', 0); return 0; }
  if (!Number.isInteger(n) || n < 1 || n > 125) throw new Error('leverage must be a whole number from 1 to 125 (the exchange contract limit is checked per coin when a trade is placed)');
  if (!config.manualCustomLeverage && !LEVERAGES.includes(n)) throw new Error(`custom leverage is disabled (MANUAL_CUSTOM_LEVERAGE_ENABLED=false); choose one of ${LEVERAGES.join(', ')}`);
  journal.setState('leverage_choice', n); return n;
}
function marginChoice() {
  let s = null; try { s = journal.getState('margin_choice'); } catch (_) { /* ignore */ }
  const v = Number(s !== null && s !== undefined ? s : config.manualDefaultMargin);
  return v > 0 && v <= 100000 ? v : 1;
}
function setMarginChoice(v) {
  const n = r4(v);
  if (!(n > 0) || n > 100000) throw new Error('margin must be a positive USDT amount');
  if (n < config.manualMarginMin) throw new Error(`margin must be at least ${config.manualMarginMin} USDT (MANUAL_MARGIN_MIN)`);
  if (!config.manualCustomMargin && !MARGINS.includes(n)) throw new Error(`custom margin is disabled (MANUAL_CUSTOM_MARGIN_ENABLED=false); choose one of ${MARGINS.join(', ')}`);
  journal.setState('margin_choice', n); return n;
}
/** v7.1 one - / + click: moves by MANUAL_MARGIN_STEP (or to the next/previous preset when custom amounts are disabled). Applies to NEW trades only. */
function adjustMargin(direction) {
  const cur = marginChoice(), dir = Number(direction) >= 0 ? 1 : -1;
  if (!config.manualCustomMargin) {
    const next = dir > 0 ? MARGINS.find(m => m > cur + 1e-9) : [...MARGINS].reverse().find(m => m < cur - 1e-9);
    if (next === undefined) throw new Error(`already at the ${dir > 0 ? 'largest' : 'smallest'} preset (${cur} USDT)`);
    return setMarginChoice(next);
  }
  return setMarginChoice(Math.max(config.manualMarginMin, r4(cur + dir * config.manualMarginStep)));
}
/** v7.1 per-trade size for ONE manual Take: validated here, then used instead of the saved margin for that single order (the saved default is not changed). */
function resolveMargin(base, override) {
  if (override === undefined || override === null || override === '') return { margin: base, overridden: false };
  const n = r4(override);
  if (!Number.isFinite(n) || !(n > 0) || n > 100000) throw new Error('trade size must be a positive USDT amount');
  if (n < config.manualMarginMin) throw new Error(`trade size must be at least ${config.manualMarginMin} USDT (MANUAL_MARGIN_MIN)`);
  if (!config.manualCustomMargin && !MARGINS.includes(n)) throw new Error(`custom trade size is disabled (MANUAL_CUSTOM_MARGIN_ENABLED=false); choose one of ${MARGINS.join(', ')}`);
  return { margin: n, overridden: n !== base };
}
/** LIVE sizing for the NEXT new trade (read fresh for every trade). null = use the old equity-scaling sizing. */
function sizing() {
  if (!config.manualTradeSizing) return { enabled: false, margin: null, leverage: null, notional: null };
  const margin = marginChoice(); const lc = leverageChoice(); const leverage = lc || config.manualDefaultLeverage || 10;
  return { enabled: true, margin, leverage, notional: Number((margin * leverage).toFixed(4)) };
}
/** v6.0.2 position slots: no equity tier. Ramp ON = start at `start`, +1 per `every` closed live trades while PF >= minPF. Ramp OFF = `max` slots straight away. max 0 = unlimited (treated as 100). */
function slotConfig() {
  let s = null; try { s = journal.getState('slot_cfg'); } catch (_) { /* ignore */ }
  const d = { ramp: config.slotRamp, start: config.scaling.startSlots > 0 ? config.scaling.startSlots : 3, every: config.scaling.rampEvery, minPF: config.scaling.rampMinPF, max: config.maxOpenPositionsLive };
  return { ...d, ...(s || {}) };
}
function setSlotConfig(p = {}) {
  const cur = slotConfig(), out = { ...cur };
  if (p.ramp !== undefined) out.ramp = !!p.ramp;
  const num = (k, lo, hi, int) => { if (p[k] === undefined || p[k] === '') return; const n = Number(p[k]); if (!Number.isFinite(n) || n < lo || n > hi || (int && !Number.isInteger(n))) throw new Error(`${k} must be ${int ? 'a whole number' : 'a number'} from ${lo} to ${hi}`); out[k] = n; };
  num('start', 1, 200, true); num('every', 1, 500, true); num('minPF', 0, 20, false); num('max', 0, 200, true);
  journal.setState('slot_cfg', out); return out;
}
module.exports = { slotConfig, setSlotConfig, drawdownMode, effectiveDrawdownMode, setDrawdownMode, leverageChoice, setLeverageChoice, marginChoice, setMarginChoice, adjustMargin, resolveMargin, parseList, sizing, MODES, LEVERAGES, MARGINS };
