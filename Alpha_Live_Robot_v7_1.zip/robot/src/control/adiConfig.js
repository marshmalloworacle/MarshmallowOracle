'use strict';
/**
 * ADAPTIVE DIRECTIONAL INTELLIGENCE (ADI) - the ONE authoritative configuration service (v7.1).
 *
 * Priority (deterministic, shown per setting as `source`):
 *   1. dashboard override  - only for the RUNTIME_KEYS whitelist, persisted in the DB (robot_state `adi_cfg`), survives restarts
 *   2. .env                - initial defaults / everything else (changing .env needs a restart, except where noted)
 *   3. built-in safe default
 * Extra rule for the direction MODE: a CHANGED .env value is a new instruction and wins once (the mode seen last time is stored),
 * after that dashboard changes win again - so a dashboard refresh can never silently reset your choice, and editing .env always works.
 *
 * Safety-critical keys (live approval, live auto-apply, DIRECTION_CHANGE_*) are .env-only: the dashboard can never change them.
 * Never returns secrets (it only knows ADI keys).
 */
require('../config');                       // loads .env into process.env BEFORE any ADI value is read
const journal = require('../journal/store');

const KEY = 'adi_cfg';
const DIR_MODES = ['ADAPTIVE', 'AUTO', 'BOTH', 'LONG_ONLY', 'SHORT_ONLY', 'PAUSE'];
const bool = (d) => ({ type: 'bool', def: d });
const int = (d, lo, hi) => ({ type: 'int', def: d, lo, hi });
const flt = (d, lo, hi) => ({ type: 'float', def: d, lo, hi });
const enm = (d, vals) => ({ type: 'enum', def: d, vals });
const locked = (d) => ({ type: 'bool', def: d, locked: true });

/** key -> { type, def, ..., runtime (dashboard-changeable live), live (explains .env-only safety keys) } */
const SCHEMA = {
  // A. master
  ADI_ENABLED: { ...bool(true), runtime: true, group: 'ADI master controls', desc: 'Master switch. OFF = ADAPTIVE/AUTO behave like BOTH, no bias, no recommendations. Explicit LONG_ONLY/SHORT_ONLY/PAUSE and ALLOW_* still work.' },
  ADI_DIRECTION_MODE: { ...enm('ADAPTIVE', DIR_MODES), group: 'ADI master controls', desc: 'Initial direction mode (same as TRADING_DIRECTION_MODE; if both are set and differ, TRADING_DIRECTION_MODE wins).' },
  ADI_AUTO_LEARNING: { ...bool(true), runtime: true, group: 'ADI master controls', desc: 'Recompute recommendations automatically every ADI_RECOMMENDATION_REFRESH_MINUTES. OFF = only when you press Refresh.' },
  ADI_PAPER_LEARNING: { ...bool(true), group: 'ADI master controls', desc: 'Learn from paper (and Paper Lab) trades.' },
  ADI_LIVE_LEARNING: { ...bool(true), group: 'ADI master controls', desc: 'Learn from live trades.' },
  ADI_LIVE_AUTO_APPLY: { ...bool(false), group: 'ADI master controls', envOnly: true, desc: 'LIVE: let ADI apply its direction bias without approval. Ignored while ADI_REQUIRE_LIVE_APPROVAL=true.' },
  // B. directional trading
  TRADING_DIRECTION_MODE: { ...enm('ADAPTIVE', DIR_MODES), group: 'Directional trading', desc: 'Initial direction mode: ADAPTIVE | AUTO | BOTH | LONG_ONLY | SHORT_ONLY | PAUSE. Dashboard changes persist and override this until you edit it here.' },
  ALLOW_LONG_TRADES: { ...bool(true), runtime: true, group: 'Directional trading', desc: 'Hard permission for LONG entries (applies to automatic AND manual takes).' },
  ALLOW_SHORT_TRADES: { ...bool(true), runtime: true, group: 'Directional trading', desc: 'Hard permission for SHORT entries (applies to automatic AND manual takes).' },
  ADI_DIRECTIONAL_BIAS_ENABLED: { ...bool(true), runtime: true, group: 'Directional trading', desc: 'Let ADI nudge the ORDER of qualified setups toward the stronger direction (never changes score, size or risk).' },
  ADI_DIRECTION_SWITCH_APPROVAL_REQUIRED: { ...bool(true), group: 'Directional trading', envOnly: true, desc: 'ADI-initiated direction restrictions need your approval (except paper with ADI_PAPER_AUTO_ADAPT=true).' },
  // C. learning
  ADI_PERFORMANCE_WINDOW_MODE: { ...enm('COMBINED', ['RECENT', 'LONG_TERM', 'COMBINED']), runtime: true, group: 'Adaptive learning', desc: 'Which trade window is scored.' },
  ADI_RECENT_WINDOW_TRADES: { ...int(50, 5, 1000), group: 'Adaptive learning', desc: 'Trades in the recent window (per direction and source).' },
  ADI_LONG_TERM_WINDOW_TRADES: { ...int(200, 10, 10000), group: 'Adaptive learning', desc: 'Trades in the long-term window (must be >= recent).' },
  ADI_MIN_COMPLETED_TRADES: { ...int(20, 1, 1000), group: 'Adaptive learning', desc: 'Completed trades a direction+source needs before it counts.' },
  ADI_PAPER_WEIGHT: { ...flt(0.40, 0, 1), group: 'Adaptive learning', desc: 'Default paper weight. Normalised against live; if one source has too little data the other gets the full weight; poor live results are never hidden by good paper results.' },
  ADI_LIVE_WEIGHT: { ...flt(0.60, 0, 1), group: 'Adaptive learning', desc: 'Default live weight.' },
  ADI_RISK_ADJUSTED_SCORING: { ...bool(true), group: 'Adaptive learning', desc: 'Score by expectancy per unit of average loss, reduced by drawdown. OFF = plain expectancy.' },
  ADI_INCLUDE_FEES: { ...bool(true), group: 'Adaptive learning', desc: 'Net-of-fees results (recorded P&L is already net). OFF = fees added back (gross).' },
  ADI_INCLUDE_FUNDING: { ...bool(true), group: 'Adaptive learning', desc: 'Include funding. The journal does not record funding per trade yet, so this has no effect until it does (shown in status).' },
  ADI_PERFORMANCE_DECAY_ENABLED: { ...bool(true), group: 'Adaptive learning', desc: 'Older trades count less (half-life set by ADI_PERFORMANCE_DECAY_SENSITIVITY).' },
  ADI_RECOMMENDATION_REFRESH_MINUTES: { ...int(30, 1, 1440), group: 'Adaptive learning', desc: 'How often recommendations are recomputed.' },
  // D. strategy intelligence (mapped onto the existing Adaptive Winning Strategy Engine)
  ADI_STRATEGY_LEARNING_ENABLED: { ...bool(true), group: 'Strategy intelligence', desc: 'Gate for the Adaptive Winning Strategy Engine (it still needs ADAPTIVE_STRATEGY_ENABLED=true or its dashboard switch).' },
  ADI_STRATEGY_DIRECTION_ANALYSIS: { ...bool(true), group: 'Strategy intelligence', desc: 'Strategy ranking considers LONG vs SHORT results.' },
  ADI_STRATEGY_AUTO_PRIORITY: { ...bool(true), group: 'Strategy intelligence', desc: 'Gate: let the strategy engine re-order setups automatically.' },
  ADI_MARKET_REGIME_ANALYSIS: { ...bool(true), group: 'Strategy intelligence', desc: 'Strategy ranking considers the market regime.' },
  ADI_ADAPTIVE_CONFIDENCE_THRESHOLD: { ...int(70, 0, 100), runtime: true, group: 'Strategy intelligence', desc: 'Confidence (0-100) needed before ADI recommends restricting to one direction.' },
  ADI_PERFORMANCE_DECAY_SENSITIVITY: { ...enm('MEDIUM', ['LOW', 'MEDIUM', 'HIGH']), group: 'Strategy intelligence', desc: 'Decay half-life: LOW 60 / MEDIUM 30 / HIGH 15 trades.' },
  // E. open position protection (locked: the robot never does these on a direction change)
  DIRECTION_CHANGE_CLOSE_EXISTING_POSITIONS: { ...locked(false), group: 'Open position protection', desc: 'LOCKED false. A direction change never closes or reverses open positions.' },
  DIRECTION_CHANGE_CANCEL_PROTECTIVE_ORDERS: { ...locked(false), group: 'Open position protection', desc: 'LOCKED false. A direction change never cancels stop-loss/take-profit orders.' },
  DIRECTION_CHANGE_MODIFY_EXISTING_POSITIONS: { ...locked(false), group: 'Open position protection', desc: 'LOCKED false. A direction change never edits open trades.' },
  DIRECTION_CHANGE_APPLIES_TO_NEW_ENTRIES_ONLY: { ...locked(true), group: 'Open position protection', desc: 'LOCKED true. Direction rules govern NEW entries only.' },
  // F. recommendations and approval
  ADI_GENERATE_RECOMMENDATIONS: { ...bool(true), runtime: true, group: 'Recommendations and approval', desc: 'Generate direction recommendations.' },
  ADI_REQUIRE_LIVE_APPROVAL: { ...bool(true), group: 'Recommendations and approval', envOnly: true, desc: 'LIVE: ADI changes nothing without your approval. Always wins over the live auto settings.' },
  ADI_PAPER_AUTO_ADAPT: { ...bool(true), runtime: true, group: 'Recommendations and approval', desc: 'PAPER: AUTO mode may apply its direction recommendation without approval.' },
  ADI_LIVE_AUTO_DIRECTION_SWITCH: { ...bool(false), group: 'Recommendations and approval', envOnly: true, desc: 'LIVE: AUTO may switch direction without approval. Ignored while ADI_REQUIRE_LIVE_APPROVAL=true.' },
  ADI_SAVE_RECOMMENDATION_HISTORY: { ...bool(true), group: 'Recommendations and approval', desc: 'Keep a history of recommendations (last 200).' },
};
const KEYS = Object.keys(SCHEMA);
const RUNTIME_KEYS = KEYS.filter(k => SCHEMA[k].runtime);

const TRUE = new Set(['true', '1', 'yes', 'on']), FALSE = new Set(['false', '0', 'no', 'off']);
const normMode = (v) => String(v).trim().toUpperCase().replace(/[\s-]+/g, '_');

/** Parse one raw value against its schema entry. Returns { ok, value } or { ok:false, error }. Empty/undefined => not set. */
function parseValue(key, raw) {
  const s = SCHEMA[key];
  if (!s) return { ok: false, error: `${key} is not an ADI setting` };
  if (raw === undefined || raw === null || String(raw).trim() === '') return { ok: true, unset: true };
  const t = String(raw).trim();
  if (s.type === 'bool') {
    const l = t.toLowerCase();
    if (TRUE.has(l)) return { ok: true, value: true };
    if (FALSE.has(l)) return { ok: true, value: false };
    return { ok: false, error: `${key}="${t}" is not a valid true/false value` };
  }
  if (s.type === 'int' || s.type === 'float') {
    const n = Number(t);
    if (!Number.isFinite(n) || (s.type === 'int' && !Number.isInteger(n))) return { ok: false, error: `${key}="${t}" must be ${s.type === 'int' ? 'a whole number' : 'a number'} between ${s.lo} and ${s.hi}` };
    if (n < s.lo || n > s.hi) return { ok: false, error: `${key}=${t} is out of range (${s.lo} to ${s.hi})` };
    return { ok: true, value: n };
  }
  const u = s.vals === DIR_MODES ? normMode(t) : t.toUpperCase();
  if (!s.vals.includes(u)) return { ok: false, error: `${key}="${t}" must be one of ${s.vals.join(', ')}` };
  return { ok: true, value: u };
}

/** Read + validate .env (process.env). Pure: returns { values, errors, warnings, explicit } and never throws. */
function fromEnv(env = process.env) {
  const values = {}, errors = [], warnings = [], explicit = {};
  for (const k of KEYS) {
    const r = parseValue(k, env[k]);
    if (!r.ok) { errors.push(r.error); values[k] = SCHEMA[k].def; continue; }
    explicit[k] = !r.unset;
    values[k] = r.unset ? SCHEMA[k].def : r.value;
    if (SCHEMA[k].locked && !r.unset && r.value !== SCHEMA[k].def) {
      errors.push(`${k}=${r.value} is not allowed: ${SCHEMA[k].desc.replace(/^LOCKED (true|false)\. /, '')} The only supported value is ${SCHEMA[k].def}.`);
      values[k] = SCHEMA[k].def;
    }
  }
  // conflicts
  if (values.ADI_LONG_TERM_WINDOW_TRADES < values.ADI_RECENT_WINDOW_TRADES) errors.push(`ADI_LONG_TERM_WINDOW_TRADES (${values.ADI_LONG_TERM_WINDOW_TRADES}) must be >= ADI_RECENT_WINDOW_TRADES (${values.ADI_RECENT_WINDOW_TRADES})`);
  if (values.ADI_PAPER_WEIGHT + values.ADI_LIVE_WEIGHT <= 0) errors.push('ADI_PAPER_WEIGHT and ADI_LIVE_WEIGHT cannot both be 0');
  if (!values.ALLOW_LONG_TRADES && !values.ALLOW_SHORT_TRADES) errors.push('ALLOW_LONG_TRADES=false and ALLOW_SHORT_TRADES=false together forbid every trade - use TRADING_DIRECTION_MODE=PAUSE (or the Take Live Trades switch) to stop trading instead');
  // direction mode: TRADING_DIRECTION_MODE wins when both are explicitly set and differ
  let mode = values.TRADING_DIRECTION_MODE;
  if (explicit.TRADING_DIRECTION_MODE && explicit.ADI_DIRECTION_MODE && values.ADI_DIRECTION_MODE !== values.TRADING_DIRECTION_MODE) {
    warnings.push(`ADI_DIRECTION_MODE=${values.ADI_DIRECTION_MODE} and TRADING_DIRECTION_MODE=${values.TRADING_DIRECTION_MODE} differ - using TRADING_DIRECTION_MODE`);
  } else if (!explicit.TRADING_DIRECTION_MODE && explicit.ADI_DIRECTION_MODE) mode = values.ADI_DIRECTION_MODE;
  values.EFFECTIVE_DIRECTION_MODE = mode;
  if (mode === 'LONG_ONLY' && !values.ALLOW_LONG_TRADES) errors.push('Direction mode LONG_ONLY conflicts with ALLOW_LONG_TRADES=false');
  if (mode === 'SHORT_ONLY' && !values.ALLOW_SHORT_TRADES) errors.push('Direction mode SHORT_ONLY conflicts with ALLOW_SHORT_TRADES=false');
  if (values.ADI_REQUIRE_LIVE_APPROVAL && (values.ADI_LIVE_AUTO_APPLY || values.ADI_LIVE_AUTO_DIRECTION_SWITCH)) warnings.push('ADI_REQUIRE_LIVE_APPROVAL=true wins: ADI_LIVE_AUTO_APPLY / ADI_LIVE_AUTO_DIRECTION_SWITCH are ignored in LIVE until you set ADI_REQUIRE_LIVE_APPROVAL=false');
  if (values.ADI_AUTO_LEARNING && !values.ADI_PAPER_LEARNING && !values.ADI_LIVE_LEARNING) warnings.push('ADI_PAPER_LEARNING and ADI_LIVE_LEARNING are both false: ADI has no data to learn from');
  return { values, errors, warnings, explicit };
}

function _saved() { try { return journal.getState(KEY) || {}; } catch (_) { return {}; } }

/** Effective values + where each came from. */
function effective(env = process.env) {
  const e = fromEnv(env), saved = _saved(), out = {}, source = {};
  for (const k of KEYS) {
    out[k] = e.values[k]; source[k] = e.explicit[k] ? '.env' : 'default';
    if (SCHEMA[k].runtime && Object.prototype.hasOwnProperty.call(saved, k)) { const r = parseValue(k, saved[k]); if (r.ok && !r.unset) { out[k] = r.value; source[k] = 'dashboard'; } }
  }
  out.EFFECTIVE_DIRECTION_MODE = e.values.EFFECTIVE_DIRECTION_MODE;
  // locked / safety rules
  out.liveNeedsApproval = out.ADI_REQUIRE_LIVE_APPROVAL || out.ADI_DIRECTION_SWITCH_APPROVAL_REQUIRED || !(out.ADI_LIVE_AUTO_APPLY || out.ADI_LIVE_AUTO_DIRECTION_SWITCH);
  return { values: out, source, errors: e.errors, warnings: e.warnings };
}

/** Fast accessor used by the trading path: cfg().ADI_ENABLED etc. Never throws (falls back to .env/default). */
function cfg() { try { return effective().values; } catch (_) { return fromEnv().values; } }

/** Validate and persist dashboard changes for RUNTIME_KEYS only. Throws a readable Error. */
function setRuntime(patch = {}) {
  const saved = { ..._saved() }, changed = [];
  for (const [k, v] of Object.entries(patch)) {
    if (!SCHEMA[k]) throw new Error(`${k} is not an ADI setting`);
    if (!SCHEMA[k].runtime) throw new Error(`${k} cannot be changed from the dashboard - edit it in .env (Codespaces) and restart the robot${SCHEMA[k].envOnly || SCHEMA[k].locked ? ' (safety setting: .env only by design)' : ''}`);
    const r = parseValue(k, v);
    if (!r.ok) throw new Error(r.error);
    if (r.unset) { delete saved[k]; changed.push(k); continue; }
    saved[k] = r.value; changed.push(k);
  }
  // re-check conflicts on the would-be effective values
  const env = { ...process.env }; for (const [k, v] of Object.entries(saved)) env[k] = String(v);
  const chk = fromEnv(env);
  const bad = chk.errors.filter(m => /ALLOW_|conflicts/.test(m));
  if (bad.length) throw new Error(bad[0]);
  journal.setState(KEY, saved);
  return changed;
}
function resetRuntime(keys) { const s = _saved(); for (const k of keys || Object.keys(s)) delete s[k]; journal.setState(KEY, s); }

/** Dashboard/API description: never contains secrets (ADI keys only). */
function describe() {
  const e = effective();
  return {
    settings: KEYS.map(k => ({ key: k, group: SCHEMA[k].group, type: SCHEMA[k].type, value: e.values[k], default: SCHEMA[k].def, source: e.source[k],
      runtimeEditable: !!SCHEMA[k].runtime, needsRestart: !SCHEMA[k].runtime, locked: !!SCHEMA[k].locked, envOnly: !!(SCHEMA[k].envOnly || SCHEMA[k].locked), desc: SCHEMA[k].desc,
      choices: SCHEMA[k].vals || null, min: SCHEMA[k].lo ?? null, max: SCHEMA[k].hi ?? null })),
    effectiveDirectionMode: e.values.EFFECTIVE_DIRECTION_MODE, errors: e.errors, warnings: e.warnings,
    howTo: 'To change a setting permanently, edit that line in .env (Codespaces file explorer > robot/.env) and restart the robot; settings marked "live" can also be changed on the dashboard and are saved across restarts.',
  };
}

/** Startup gate: throws one Error listing every invalid .env value. Warnings are logged. */
function validateOrThrow(log = console) {
  const e = fromEnv();
  for (const w of e.warnings) (log.warn || log.log).call(log, `[ADI config] ${w}`);
  if (e.errors.length) throw new Error(`Invalid ADI configuration in .env:\n  - ${e.errors.join('\n  - ')}\nFix these lines in .env (see .env.example) and start again.`);
  return e;
}
/** Safe one-line-per-setting summary (no secrets). */
function summary() { const d = describe(); return d.settings.map(s => `${s.key}=${s.value}  [${s.source}${s.runtimeEditable ? ', live' : ', restart'}]`).join('\n'); }

module.exports = { SCHEMA, KEYS, RUNTIME_KEYS, DIR_MODES, parseValue, fromEnv, effective, cfg, setRuntime, resetRuntime, describe, validateOrThrow, summary, normMode };
