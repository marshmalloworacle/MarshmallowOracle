'use strict';
/**
 * Feature switches. Every v4.6 enhancement can be turned on/off at any time (dashboard or API).
 * State lives in the DB (robot_state key `feature_flags`) so it survives restarts and is shared by the
 * robot and dashboard processes. Defaults: safe features ON, risk-changing features OFF (user decision).
 * OFF always means "behave exactly like v4.5".
 */
const journal = require('../journal/store');

const KEY = 'feature_flags';
const FEATURES = {
  directionControl: { on: true,  label: 'Directional control', desc: 'LONG ONLY / SHORT ONLY / BOTH / PAUSE with timers (backend-enforced on every entry path)' },
  healthStrip:      { on: true,  label: 'System health strip', desc: 'Scanner, market data, exchange, position manager, DB, last reconciliation' },
  journalExtras:    { on: true,  label: 'Extended journal',    desc: 'Peak profit, giveback, stage and exit-reason fields' },
  closeButtons:     { on: true,  label: 'Individual close buttons', desc: 'Per-position close with instant UI update (paper + live/testnet)' },
  smartTrailing:    { on: true,  label: 'Smart trailing stop', desc: 'Break-even + ATR/profit-stage ratchet (never loosens a stop)' },
  profitGiveback:   { on: true,  label: 'Profit giveback guard', desc: 'Tighten stop after a set giveback from peak profit' },
  partialExits:     { on: false, label: 'Partial profit-taking', desc: 'Close a fraction at profit milestones, let the rest run (stop stays on the remainder)' },
  timeExit:         { on: false, label: 'Time exits',          desc: 'Close losing / going-nowhere trades after the stale-hours limit; close profitable ones at max hold' },
  correlationBlock: { on: false, label: 'Correlation / exposure block', desc: 'Block new entries when portfolio risk caps are exceeded' },
  lossGovernor:     { on: false, label: 'Daily/weekly loss governor', desc: 'CAUTION / DEFENSIVE / ENTRY HALT states from drawdown' },
  staleDataBlock:   { on: true,  label: 'Stale-data entry block', desc: 'Block new entries when market data is older than the limit (never blocks stops/exits)' },
  adaptiveDirection:{ on: false, label: 'Adaptive direction (auto bias)', desc: 'Block entries against a confirmed strong market bias (manual direction control always wins)' },
  riskTaper:        { on: true,  label: 'Soft risk budget (taper)', desc: 'New trades shrink smoothly as open risk nears the cap and winners go to break-even, instead of a hard stop of new trades' },
  spreadFilter:     { on: false, label: 'Spread & liquidity filter', desc: 'Skips coins with a wide bid/ask spread or a thin order book' },
  volumeConfirm:    { on: false, label: 'Volume confirmation', desc: 'Needs the last hour volume to be at least a set share of its 20-hour average' },
  htfTrend:         { on: false, label: 'Higher-timeframe trend filter', desc: 'Blocks entries against the coin 4h trend (EMA20 vs EMA50)' },
  volatilityFilter: { on: false, label: 'Volatility filter', desc: 'Blocks entries when the coin volatility is extreme versus its normal level' },
  regimeFilter:     { on: false, label: 'Market regime filter', desc: 'Restrict entries by regime (shock / high volatility)' },
};

function all() {
  let saved = {};
  try { saved = journal.getState(KEY) || {}; } catch (_) { /* DB not ready: defaults */ }
  const out = {};
  const allOff = process.env.MODULES_DEFAULT_OFF === 'true';   // v5.2.4: set true to start with every optional module OFF
  for (const [k, d] of Object.entries(FEATURES)) out[k] = typeof saved[k] === 'boolean' ? saved[k] : (allOff ? false : d.on);
  return out;
}
function isOn(name) { return all()[name] === true; }
function set(name, value) {
  if (!FEATURES[name]) throw new Error(`Unknown feature "${name}"`);
  let saved = {};
  try { saved = journal.getState(KEY) || {}; } catch (_) { /* ignore */ }
  const before = all()[name];
  saved[name] = !!value;
  journal.setState(KEY, saved);
  if (before !== !!value) { try { require('../decisions/log').record({ type: 'SYSTEM', severity: 'INFO', module: name, reason: `Module "${FEATURES[name].label}" switched ${value ? 'ON' : 'OFF'} (you, from the dashboard/API)`, key: `mod_${name}_${Date.now()}`, cooldownMs: 0 }); } catch (_) { /* audit is best effort */ } }
  return all();
}
function describe() { const cur = all(); return Object.entries(FEATURES).map(([key, d]) => ({ key, label: d.label, desc: d.desc, default: d.on, enabled: cur[key] })); }

module.exports = { FEATURES, all, isOn, set, describe };
