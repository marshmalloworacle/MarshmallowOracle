'use strict';
/**
 * v6.0 entry-quality filters (all OFF by default, each its own module switch):
 *   spreadFilter, volumeConfirm, htfTrend, volatilityFilter.
 * measure() reads real market data (cached candles / order book). A filter FAILS OPEN: if its data is unavailable it does not block a trade,
 * it reports "unknown" (so a data hiccup never silently stops trading). Only NEW entries are affected; stops and exits are never touched.
 */
const dataFeed = require('../market/dataFeed');
const ind = require('../indicators');
const micro = require('../market/microstructure');

const lastOf = (a) => { for (let i = a.length - 1; i >= 0; i--) if (Number.isFinite(a[i])) return a[i]; return null; };
const mean = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : null);

/** need: subset of ['spread','volume','htf','vol'] */
async function measure(sig, need = ['spread', 'volume', 'htf', 'vol'], notionalUsd = 0, deps = {}) {
  const m = {}; const feed = deps.dataFeed || dataFeed, mi = deps.micro || micro;
  const sym = sig.symbol;
  if (need.includes('spread')) {
    try { const r = await mi.evaluate(sym, sig.direction, notionalUsd || 0); if (r && r.book) { m.spreadBps = Number(r.book.spreadBps.toFixed(2)); m.depthUsd = Math.round(r.book.depthUsd); m.slipBps = Number(Math.min(r.book.slipBps, 999).toFixed(2)); } } catch (_) { /* unknown */ }
  }
  if (need.includes('volume') || need.includes('vol')) {
    try {
      const c = await feed.getCandles(sym, '1h', 80); const closed = c.slice(0, -1);   // the forming candle is excluded
      if (need.includes('volume') && closed.length >= 22) { const v = closed.map(x => x.volume), base = mean(v.slice(-21, -1)); if (base > 0) m.volRatio = Number((v[v.length - 1] / base).toFixed(2)); }
      if (need.includes('vol') && closed.length >= 64) { const a = ind.atr(closed, 14), cur = lastOf(a), base = mean(a.slice(-50).filter(Number.isFinite)); if (cur > 0 && base > 0) m.atrRatio = Number((cur / base).toFixed(2)); }
    } catch (_) { /* unknown */ }
  }
  if (need.includes('htf')) {
    try {
      const c = await feed.getCandles(sym, '4h', 90); const cl = c.slice(0, -1).map(x => x.close);
      if (cl.length >= 55) { const e20 = lastOf(ind.ema(cl, 20)), e50 = lastOf(ind.ema(cl, 50)), px = cl[cl.length - 1];
        m.htfTrend = e20 > e50 && px > e50 ? 'UP' : e20 < e50 && px < e50 ? 'DOWN' : 'FLAT'; }
    } catch (_) { /* unknown */ }
  }
  return m;
}

/** which measurements the switched-on filters need */
function needed(f) { const n = []; if (f.spreadFilter) n.push('spread'); if (f.volumeConfirm) n.push('volume'); if (f.htfTrend) n.push('htf'); if (f.volatilityFilter) n.push('vol'); return n; }

function reasons(sig, m, f, caps, notionalUsd = 0) {
  const out = [];
  if (f.spreadFilter && m.spreadBps != null) {
    if (m.spreadBps > caps.spreadMaxBps) out.push(`SPREAD_FILTER: spread ${m.spreadBps} bps > max ${caps.spreadMaxBps} bps`);
    else if (notionalUsd > 0 && m.depthUsd != null && m.depthUsd < notionalUsd * 10) out.push(`SPREAD_FILTER: thin order book (depth $${m.depthUsd} < 10x the order)`);
  }
  if (f.volumeConfirm && m.volRatio != null && m.volRatio < caps.volumeMinRatio) out.push(`VOLUME_CONFIRMATION: last hour volume is ${m.volRatio}x its 20-hour average (needs >= ${caps.volumeMinRatio}x)`);
  if (f.htfTrend && m.htfTrend && ((m.htfTrend === 'DOWN' && sig.direction === 'LONG') || (m.htfTrend === 'UP' && sig.direction === 'SHORT'))) out.push(`HTF_TREND: the 4h trend is ${m.htfTrend}, which is against this ${sig.direction}`);
  if (f.volatilityFilter && m.atrRatio != null && m.atrRatio > caps.volatilityMaxRatio) out.push(`VOLATILITY_FILTER: volatility is ${m.atrRatio}x its normal level (max ${caps.volatilityMaxRatio}x)`);
  return out;
}
module.exports = { measure, needed, reasons };
