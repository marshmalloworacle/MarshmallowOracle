'use strict';
/**
 * One backend entry gate for every automated entry (paper + live/testnet), after strategy qualification and BEFORE order creation.
 * Each check is behind its own feature switch. It only ever blocks NEW entries - it never touches stops, exits or reconciliation.
 * Direction control is enforced one layer deeper (paper engine / order manager) so no route can skip it.
 */
const journal = require('../journal/store');
const flags = require('../features/flags');
const pcfg = require('../protection/config');
const portfolio = require('./portfolio');
const governor = require('./governor');

const RING = 'no_trade_reasons';
function record(sig, reason, source = 'gate') {
  try {
    const ring = journal.getState(RING) || [];
    ring.unshift({ ts: Date.now(), symbol: sig.symbol, direction: sig.direction, strategy: sig.strategyName || sig.strategyId || null, score: sig.score ?? null, reason, source });
    journal.setState(RING, ring.slice(0, 40));
    const counts = journal.getState('no_trade_counts') || {}; const day = new Date().toISOString().slice(0, 10);
    if (counts.day !== day) { counts.day = day; counts.by = {}; }
    const key = String(reason).split(':')[0]; counts.by[key] = (counts.by[key] || 0) + 1; journal.setState('no_trade_counts', counts);
  } catch (_) { /* never let bookkeeping break trading */ }
  try {   // v5.2.4 decision log: same real rejection, with the responsible module and a plain explanation
    const dl = require('../decisions/log'); const mod = dl.moduleOf(reason);
    const hard = /^(RISK|LIVE|MAX_|KILL|PAUSED)/i.test(String(reason));
    dl.record({ type: hard ? 'RISK_BLOCKED' : 'MODULE_BLOCKED', severity: 'WARNING', symbol: sig.symbol, direction: sig.direction, strategy: sig.strategyName || sig.strategyId || null, module: mod,
      reason: String(reason) === 'PAUSED' ? 'Take Live Trades is OFF - the robot is not allowed to open trades yet' : String(reason).slice(0, 300), measured: sig.score != null ? { score: sig.score } : null, action: 'Entry blocked - no order sent', key: `rej|${sig.symbol}|${mod}|${String(reason).slice(0, 50)}`, cooldownMs: 15 * 60 * 1000 });
  } catch (_) { /* ignore */ }
}

/** Once per scan. positions: normalised (see portfolio.js). loader: async (symbol)=>1h closes */
async function prepare({ mode, positions, equity, minScore, riskPerTrade, loader, runMode, sizing = null, now = Date.now() }) {
  const f = flags.all(), caps = pcfg.get();
  const intel = journal.getState('market_intel') || null;
  const gov = f.lossGovernor ? governor.update(mode, equity, now) : (governor.update(mode, equity, now), null);   // always tracked, only enforced when switched on
  let returns = {}, snap = portfolio.snapshot(positions, equity, {}, caps.corrThreshold);
  if (f.correlationBlock && loader && positions.length) { returns = await portfolio.loadReturns(positions.map(p => p.symbol), loader); snap = portfolio.snapshot(positions, equity, returns, caps.corrThreshold); }
  journal.setState('portfolio_risk', { ts: now, mode, ...snap, groups: snap.groups, enforced: f.correlationBlock, caps: { aggRiskPct: caps.aggRiskPct, corrRiskPct: caps.corrRiskPct, dirNotionalPct: caps.dirNotionalPct, corrThreshold: caps.corrThreshold } });
  const bias = journal.getState('bias_track') || {};
  return { f, caps, intel, gov, snap, returns, loader, minScore, riskPerTrade, equity, runMode, now, bias, positions, sizing };
}

/** returns { allowed, reasons[] } */
async function check(sig, ctx) {
  const reasons = []; const { f, caps, intel, gov } = ctx;
  if (f.staleDataBlock && ctx.runMode !== 'SIM') {
    const age = intel ? (ctx.now - intel.ts) / 1000 : null;
    if (age == null || age > caps.staleDataSec) reasons.push(`STALE_DATA: market intelligence ${age == null ? 'unavailable' : Math.round(age) + 's old'} (limit ${caps.staleDataSec}s)`);
  }
  if (f.lossGovernor && gov) {
    if (gov.block) reasons.push(`GOVERNOR: ${gov.level} - ${(gov.reasons || []).join('; ') || 'entries halted'}`);
    else if (gov.minScoreAdd && (sig.score || 0) < ctx.minScore + gov.minScoreAdd) reasons.push(`GOVERNOR: ${gov.level} requires score >= ${ctx.minScore + gov.minScoreAdd} (got ${sig.score})`);
  }
  if (f.regimeFilter && intel) {
    const st = intel.regime.state;
    if (st === 'MARKET_SHOCK') reasons.push(`REGIME: MARKET_SHOCK (BTC 1h ${intel.shock.btc1hPct?.toFixed(1)}%) - entries blocked`);
    else if (st === 'HIGH_VOLATILITY' && (sig.score || 0) < ctx.minScore + 5) reasons.push(`REGIME: HIGH_VOLATILITY requires score >= ${ctx.minScore + 5}`);
  }
  if (f.adaptiveDirection && intel) {
    const rec = intel.bias.recommendation, held = ctx.now - (ctx.bias.since || ctx.now);
    if ((intel.bias.confidence || 0) >= 70 && held >= 30 * 60e3 && ((rec === 'LONG_BIAS' && sig.direction === 'SHORT') || (rec === 'SHORT_BIAS' && sig.direction === 'LONG')))
      reasons.push(`ADAPTIVE (auto): ${rec} (confidence ${intel.bias.confidence}%) blocks ${sig.direction}`);
  }
  const dist0 = Math.abs(sig.entry - sig.stopLoss) || 0;
  const sz = ctx.sizing && ctx.sizing.enabled ? ctx.sizing : null;                       // live margin x leverage sizing
  const plannedNotional = sz ? sz.margin * sz.leverage : (dist0 > 0 ? ctx.equity * ctx.riskPerTrade / dist0 * sig.entry : 0);
  const filt = require('./filters'); const need = filt.needed(f); let measured = null;
  if (need.length && ctx.runMode !== 'SIM') {   // v6.0 entry-quality filters (fail open when data is missing)
    measured = await filt.measure(sig, need, plannedNotional).catch(() => ({}));
    reasons.push(...filt.reasons(sig, measured, f, caps, plannedNotional));
  }
  // v6.0 soft risk budget: shrink the NEW trade smoothly as open stop-risk approaches the cap; refuse only above the hard ceiling
  let sizeFactor = 1, taper = null;
  if (f.riskTaper && sz && ctx.equity > 0 && dist0 > 0) {
    const fullRisk = plannedNotional * dist0 / sig.entry, cap = caps.aggRiskPct / 100 * ctx.equity, ceil = cap * caps.ceilingPct / 100, open = ctx.snap.aggRisk || 0;
    const used = cap > 0 ? open / cap : 0, start = caps.taperStartPct / 100, minF = caps.taperMinPct / 100;
    let factor = used <= start ? 1 : used >= 1 ? minF : 1 - (1 - minF) * (used - start) / (1 - start);
    if (open + fullRisk * factor > ceil) factor = Math.min(factor, fullRisk > 0 ? Math.max(0, (ceil - open) / fullRisk) : 0);
    taper = { usedPct: Number((used * 100).toFixed(1)), openRiskPct: Number((open / ctx.equity * 100).toFixed(2)), capPct: caps.aggRiskPct, ceilingPct: caps.ceilingPct, factor: Number(factor.toFixed(2)) };
    if (factor < minF * 0.5) reasons.push(`RISK_BUDGET: open stop-risk is ${taper.openRiskPct}% of equity; even a minimum-size trade would pass the hard ceiling (${(caps.aggRiskPct * caps.ceilingPct / 100).toFixed(1)}%). Trades resume as stops tighten or positions close.`);
    else sizeFactor = factor;
  }
  if (f.correlationBlock && ctx.equity > 0) {
    const dist = dist0;
    const riskUsd = sz ? plannedNotional * dist0 / sig.entry * sizeFactor : ctx.equity * ctx.riskPerTrade;
    const capsEff = f.riskTaper && sz ? { ...caps, aggRiskPct: caps.aggRiskPct * caps.ceilingPct / 100 } : caps;   // with the soft budget ON the aggregate check uses the ceiling
    let ret = ctx.returns;
    if (ctx.loader && !ret[sig.symbol]) { try { ret = { ...ret, ...(await portfolio.loadReturns([sig.symbol], ctx.loader)) }; } catch (_) { /* unknown correlation is reported, not assumed */ } }
    const v = portfolio.checkEntry({ symbol: sig.symbol, direction: sig.direction, entry: sig.entry, stopLoss: sig.stopLoss, riskUsd, notional: dist > 0 ? riskUsd / dist * sig.entry : 0 }, ctx.snap, capsEff, ret);
    reasons.push(...v.reasons);
  }
  // v7.0: a manual Take the user explicitly confirmed may pass the AGGREGATE open-risk caps only (never governor, kill switch, correlation, direction, stale data)
  const overridden = [];
  if (ctx.overrideAggregate) { for (let i = reasons.length - 1; i >= 0; i--) if (/^(RISK_BUDGET|PORTFOLIO)/i.test(reasons[i])) overridden.push(...reasons.splice(i, 1)); }
  return { allowed: reasons.length === 0, reasons, sizeFactor, taper, measured, overridden };
}
/** keep the snapshot honest as the scan opens trades */
function noteOpened(ctx, sig, sizeFactor = 1) {
  const sz = ctx.sizing && ctx.sizing.enabled ? ctx.sizing : null;
  const dist = Math.abs(sig.entry - sig.stopLoss) || 0, riskUsd = sz && sig.entry > 0 ? sz.margin * sz.leverage * sizeFactor * dist / sig.entry : ctx.equity * ctx.riskPerTrade;
  ctx.positions = [...ctx.positions, { symbol: sig.symbol, side: sig.direction, qty: dist > 0 ? riskUsd / dist : 0, entry: sig.entry, stop: sig.stopLoss, mark: sig.entry, leverage: 1 }];
  ctx.snap = portfolio.snapshot(ctx.positions, ctx.equity, ctx.returns, ctx.caps.corrThreshold);
  try { journal.setState('portfolio_risk', { ts: Date.now(), mode: ctx.mode || null, ...ctx.snap, enforced: ctx.f.correlationBlock, caps: { aggRiskPct: ctx.caps.aggRiskPct, corrRiskPct: ctx.caps.corrRiskPct, dirNotionalPct: ctx.caps.dirNotionalPct, corrThreshold: ctx.caps.corrThreshold } }); } catch (_) { /* display only */ }
}
module.exports = { prepare, check, record, noteOpened };
