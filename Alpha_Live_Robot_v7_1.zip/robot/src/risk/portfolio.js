'use strict';
/**
 * Portfolio risk + correlation. Pure maths on normalised positions; the only I/O is the optional returns loader.
 * position: { symbol, side:'LONG'|'SHORT', qty, entry, stop, mark, leverage, margin, liq }
 * Risk-to-stop = |entry - stop| x qty; once a stop is beyond entry in profit the remaining risk is 0 (locked profit).
 * Correlation is NEVER treated as proof of identical risk: only SAME-direction pairs above the threshold are grouped
 * (opposite-direction positively-correlated pairs act as a hedge and are not added together).
 */
const sign = (side) => (side === 'LONG' ? 1 : -1);
const riskToStop = (p) => { if (!(p.stop > 0)) return null; const m = (p.entry - p.stop) * sign(p.side); return Math.max(0, m) * p.qty; };

function corr(a, b) {
  const n = Math.min(a.length, b.length); if (n < 12) return null;
  const x = a.slice(-n), y = b.slice(-n); const mx = x.reduce((s, v) => s + v, 0) / n, my = y.reduce((s, v) => s + v, 0) / n;
  let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) ** 2; syy += (y[i] - my) ** 2; }
  return sxx > 0 && syy > 0 ? sxy / Math.sqrt(sxx * syy) : null;
}
function returnsFromCloses(closes) { const r = []; for (let i = 1; i < closes.length; i++) if (closes[i - 1] > 0 && closes[i] > 0) r.push(Math.log(closes[i] / closes[i - 1])); return r; }

/** returns: { SYMBOL: number[] } ; threshold: correlation that counts as "same bet" */
function snapshot(positions, equity, returns = {}, threshold = 0.75) {
  const rows = positions.map(p => ({ ...p, notional: p.qty * (p.mark || p.entry), risk: riskToStop(p) }));
  const unknownStops = rows.filter(r => r.risk === null).map(r => r.symbol);
  const aggRisk = rows.reduce((s, r) => s + (r.risk || 0), 0);
  const longN = rows.filter(r => r.side === 'LONG').reduce((s, r) => s + r.notional, 0);
  const shortN = rows.filter(r => r.side === 'SHORT').reduce((s, r) => s + r.notional, 0);
  const totalN = longN + shortN;
  const margin = rows.reduce((s, r) => s + (r.margin || r.notional / Math.max(1, r.leverage || 1)), 0);
  // same-direction correlation groups (connected components)
  const groups = []; const seen = new Set(); const pairs = [];
  for (let i = 0; i < rows.length; i++) for (let j = i + 1; j < rows.length; j++) {
    const c = corr(returns[rows[i].symbol] || [], returns[rows[j].symbol] || []);
    if (c != null) pairs.push({ a: rows[i].symbol, b: rows[j].symbol, corr: Number(c.toFixed(2)), sameDir: rows[i].side === rows[j].side });
  }
  const linked = (x, y) => x.side === y.side && pairs.some(p => p.sameDir && p.corr >= threshold && ((p.a === x.symbol && p.b === y.symbol) || (p.a === y.symbol && p.b === x.symbol)));
  for (const r of rows) {
    if (seen.has(r.symbol)) continue;
    const g = [r]; seen.add(r.symbol);
    for (let k = 0; k < g.length; k++) for (const o of rows) if (!seen.has(o.symbol) && linked(g[k], o)) { g.push(o); seen.add(o.symbol); }
    groups.push({ side: r.side, symbols: g.map(x => x.symbol), risk: g.reduce((s, x) => s + (x.risk || 0), 0) });
  }
  const topGroup = groups.reduce((m, g) => (g.risk > (m?.risk || -1) ? g : m), null);
  const pct = (v) => (equity > 0 ? v / equity * 100 : null);
  return { n: rows.length, equity, aggRisk, aggRiskPct: pct(aggRisk), notional: totalN, longNotional: longN, shortNotional: shortN, netNotional: longN - shortN,
    dominantSidePct: totalN > 0 ? Math.max(longN, shortN) / totalN * 100 : null, marginUsed: margin, marginUsedPct: pct(margin), freeMarginPct: equity > 0 ? Math.max(0, equity - margin) / equity * 100 : null,
    largestAssetPct: totalN > 0 ? Math.max(0, ...rows.map(r => r.notional)) / totalN * 100 : null, unknownStops, groups, topGroup, topGroupRiskPct: topGroup ? pct(topGroup.risk) : 0,
    corrPairs: pairs.filter(p => p.corr >= threshold).sort((x, y) => y.corr - x.corr).slice(0, 6), hasCorrData: pairs.length > 0,
    minLiqDistPct: Math.min(Infinity, ...rows.filter(r => r.liq > 0 && r.mark > 0).map(r => Math.abs(r.mark - r.liq) / r.mark * 100)) };
}

/**
 * Would adding `cand` ({symbol, direction, entry, stopLoss, riskUsd}) break a cap? Returns { allowed, reasons[] }.
 * caps: { aggRiskPct, corrRiskPct, dirNotionalPct, corrThreshold }
 */
function checkEntry(cand, snap, caps, returns = {}) {
  const reasons = []; const eq = snap.equity;
  if (!(eq > 0)) return { allowed: false, reasons: ['PORTFOLIO: equity unknown'] };
  const add = cand.riskUsd || 0;
  const aggAfter = (snap.aggRisk + add) / eq * 100;
  if (aggAfter > caps.aggRiskPct + 1e-9) reasons.push(`PORTFOLIO: aggregate stop-risk ${aggAfter.toFixed(1)}% > cap ${caps.aggRiskPct}%`);
  let corrAfter = add; let corrWith = [];
  for (const g of snap.groups.filter(x => x.side === cand.direction)) {
    const linked = g.symbols.some(s => { const c = corr(returns[cand.symbol] || [], returns[s] || []); return c != null && c >= caps.corrThreshold; });
    if (linked) { corrAfter += g.risk; corrWith.push(...g.symbols); }
  }
  if (corrWith.length && corrAfter / eq * 100 > caps.corrRiskPct + 1e-9) reasons.push(`CORRELATION: ${cand.symbol} ${cand.direction} joins correlated group (${[...new Set(corrWith)].join(', ')}) -> ${(corrAfter / eq * 100).toFixed(1)}% > cap ${caps.corrRiskPct}%`);
  if (snap.n >= 3 && snap.notional > 0) {
    const same = cand.direction === 'LONG' ? snap.longNotional : snap.shortNotional;
    const after = (same + (cand.notional || 0)) / (snap.notional + (cand.notional || 0)) * 100;
    if (after > caps.dirNotionalPct + 1e-9) reasons.push(`DIRECTION EXPOSURE: ${after.toFixed(0)}% of notional would be ${cand.direction} > cap ${caps.dirNotionalPct}%`);
  }
  return { allowed: reasons.length === 0, reasons, aggAfterPct: aggAfter };
}

/** loader: async (symbol) => closes[]  (1h closes) ; cached by caller */
async function loadReturns(symbols, loader) {
  const out = {};
  await Promise.all([...new Set(symbols)].map(async (s) => { try { out[s] = returnsFromCloses(await loader(s)); } catch (_) { /* no data for this symbol: correlation unknown, never assumed */ } }));
  return out;
}
module.exports = { snapshot, checkEntry, corr, returnsFromCloses, riskToStop, loadReturns };
