'use strict';

/**
 * Small-account scaling profile.
 *
 * Pure functions (no I/O) so they are easy to test. Given current equity, the equity high-water mark and
 * recent closed-trade stats, computeProfile() returns what the account may do RIGHT NOW:
 *   slots      - how many positions may be open at once
 *   leverage   - leverage used for sizing / liquidation checks
 *   riskPerTrade - fraction of equity risked per trade (distance entry -> stop-loss)
 *   marginPerSlot - max margin ($) one position may use (equity * maxMarginPct / slots)
 *
 * Rules (all configurable through .env, see .env.example):
 *  1. Tier by equity: a $20 account gets 5 slots @ base leverage; slots/leverage grow as equity grows.
 *     Per-trade risk shrinks as slots grow so ALL slots stopped out together cost <= maxOpenRisk (default 8%).
 *  2. Leverage ABOVE the base only unlocks once the strategy has proven itself on closed trades
 *     (>= perfMinTrades with profit factor >= perfMinPF and positive expectancy). Slots still grow with equity.
 *  3. Drawdown from the equity peak scales everything DOWN, hard:
 *       >= ddReduce  -> leverage x0.75, one slot fewer
 *       >= ddDefend  -> leverage floor, 1 slot, half risk
 *     Nothing scales UP while drawdown >= ddFreezeUp.
 *  4. Hard ceilings (maxLeverage, maxRisk) can never be exceeded, whatever the tiers say.
 */

const DEFAULT_TIERS = [
  // minEquity: tier starts at this equity (USDT). Many small isolated-margin slots: one losing trade never blocks the rest.
  { name: 'T0 Seed',    minEquity: 0,    slots: 5,  leverage: 10 },
  { name: 'T1 Starter', minEquity: 15,   slots: 6,  leverage: 10 },   // the $20-$40 start: 6 slots
  { name: 'T2 Builder', minEquity: 40,   slots: 8,  leverage: 10 },
  { name: 'T3 Growth',  minEquity: 80,   slots: 10, leverage: 12 },
  { name: 'T4 Scale',   minEquity: 150,  slots: 12, leverage: 15 },
  { name: 'T5 Pro',     minEquity: 400,  slots: 14, leverage: 15 },
  { name: 'T6 Elite',   minEquity: 1000, slots: 16, leverage: 20 },
];

const DEFAULTS = {
  enabled: true,
  baseLeverage: 10,       // leverage with no proven edge
  minLeverage: 5,         // floor while defending drawdown
  maxLeverage: 20,        // hard ceiling
  baseRisk: 0.015,        // 1.5% of equity per trade
  maxRisk: 0.02,          // hard ceiling
  maxOpenRisk: 0.08,      // all slots stopped out together may cost at most 8% -> per-trade risk = min(baseRisk, maxOpenRisk / slots)
  sizing: 'margin',       // 'margin' = each trade uses marginPct of equity as isolated margin (e.g. ~$1 on $20); 'risk' = size purely from stop distance
  marginPct: 0.05,        // margin per trade as a fraction of equity (grows automatically as equity grows)
  minSizeRiskCap: 0.03,   // tiny accounts: allow the exchange-minimum size if its stop-loss risk is <= 3% of equity
  maxMarginPct: 0.6,      // all open margin together stays below 60% of equity (rest = buffer)
  ddReduce: 0.05,
  ddDefend: 0.10,
  ddFreezeUp: 0.08,
  startSlots: 3,          // slots at the beginning; earned upward automatically (0 = skip the ramp and use the equity tier directly)
  rampEvery: 10,          // +1 slot for every N closed live trades while the edge holds (PF >= rampMinPF and expectancy > 0)
  rampMinPF: 1.2,
  slotsOverride: 0,       // 0 = automatic by equity tier; N = always N slots (drawdown rules can still reduce it)
  maxSlots: 0,            // 0 = no cap; N = never more than N slots
  perfMinTrades: 20,
  perfMinPF: 1.2,
  tiers: DEFAULT_TIERS,
};

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

function pickTier(equity, tiers) {
  let t = tiers[0];
  for (const x of tiers) if (equity >= x.minEquity) t = x;
  return t;
}

/** stats: { trades, profitFactor, expectancy } from closed LIVE trades (journal). */
function edgeProven(stats, cfg) {
  if (!stats) return false;
  return (stats.trades || 0) >= cfg.perfMinTrades &&
    (stats.profitFactor || 0) >= cfg.perfMinPF &&
    (stats.expectancy || 0) > 0;
}

/** closed = [{ pnl }]; returns { trades, profitFactor, expectancy, winRate } (exchange realised PnL, net of fees). */
function statsFromClosed(closed = []) {
  const n = closed.length; if (!n) return { trades: 0, profitFactor: 0, expectancy: 0, winRate: 0 };
  const win = closed.filter(t => t.pnl > 0), loss = closed.filter(t => t.pnl < 0);
  const gw = win.reduce((a, t) => a + t.pnl, 0), gl = Math.abs(loss.reduce((a, t) => a + t.pnl, 0));
  return { trades: n, profitFactor: gl > 0 ? gw / gl : (gw > 0 ? 99 : 0), expectancy: closed.reduce((a, t) => a + t.pnl, 0) / n, winRate: win.length / n };
}

function computeProfile({ equity, peakEquity, stats = null, config = {} } = {}) {
  const defined = Object.fromEntries(Object.entries(config || {}).filter(([, v]) => v !== undefined && v !== null && !(typeof v === 'number' && Number.isNaN(v))));
  const cfg = { ...DEFAULTS, ...defined };
  if (!Array.isArray(cfg.tiers) || !cfg.tiers.length) cfg.tiers = DEFAULT_TIERS;
  const eq = Math.max(0, Number(equity) || 0);
  const peak = Math.max(eq, Number(peakEquity) || eq);
  const dd = peak > 0 ? (peak - eq) / peak : 0;
  const reasons = [];

  if (!cfg.enabled) {
    return { tier: 'FIXED', tierIndex: -1, slots: 0, leverage: cfg.baseLeverage, riskPerTrade: cfg.baseRisk,
      marginPerSlot: 0, drawdown: dd, edgeProven: false, state: 'DISABLED', reasons: ['scaling disabled (fixed settings)'] };
  }

  const tier = pickTier(eq, cfg.tiers);
  const tierIndex = cfg.tiers.indexOf(tier);
  let slots = tier.slots;
  if (cfg.userSlots) slots = cfg.maxSlots > 0 ? Math.floor(cfg.maxSlots) : 100;   // v6.0.2: equity tier does NOT limit slots (0 = unlimited, counted as 100)
  const slotsCap = slots;
  if (cfg.slotsOverride > 0 && !cfg.userSlots) { slots = Math.floor(cfg.slotsOverride); reasons.push(`slots fixed at ${slots} by SCALING_SLOTS`); }
  else if (cfg.startSlots > 0 && (!cfg.userSlots || cfg.slotRamp)) {
    // Automatic ramp: start small, earn one more slot per rampEvery closed trades while the strategy proves itself.
    const t = (stats && stats.trades) || 0;
    const edgeOk = t >= cfg.rampEvery && (stats.profitFactor || 0) >= cfg.rampMinPF && (stats.expectancy || 0) > 0;
    const earned = cfg.startSlots + (edgeOk ? Math.floor(t / cfg.rampEvery) : 0);
    slots = Math.min(slots, earned);
    reasons.push(edgeOk ? `slot ramp: ${t} closed trades, PF ${(stats.profitFactor || 0).toFixed(2)} -> ${earned} slots earned (tier allows ${slotsCap})`
                        : `slot ramp: starting at ${cfg.startSlots} until ${cfg.rampEvery}+ closed trades show PF>=${cfg.rampMinPF}`);
  }
  if (cfg.maxSlots > 0) slots = Math.min(slots, Math.floor(cfg.maxSlots));
  if (cfg.userSlots && !cfg.slotRamp) reasons.push(`slots: ${slots} (your setting, ramp off, equity tier not used)`);
  let leverage = tier.leverage;
  let risk = cfg.baseRisk;
  let state = 'NORMAL';

  // 2. leverage above base needs a proven edge
  const proven = edgeProven(stats, cfg);
  if (leverage > cfg.baseLeverage && !proven) {
    leverage = cfg.baseLeverage;
    reasons.push(`leverage held at ${cfg.baseLeverage}x until ${cfg.perfMinTrades}+ closed trades show PF>=${cfg.perfMinPF}`);
  }

  // 3. drawdown scaling (down hard, up never)
  const ddMode = cfg.drawdownMode || 'enforce';   // v5.2.4: 'warn' | 'off' = never cut slots/leverage/risk
  let drawdownWarning = null;
  if (ddMode !== 'enforce') {
    if (dd >= cfg.ddDefend) drawdownWarning = 'DEFENSIVE'; else if (dd >= cfg.ddReduce) drawdownWarning = 'REDUCED';
    if (drawdownWarning && ddMode === 'warn') reasons.push(`WARNING only: drawdown ${(dd * 100).toFixed(1)}% from peak would be ${drawdownWarning} (slots/leverage NOT reduced: DRAWDOWN_MODE=warn)`);
    if (ddMode === 'off') drawdownWarning = null;
  } else if (dd >= cfg.ddDefend) {
    leverage = cfg.minLeverage; slots = 1; risk = cfg.baseRisk * 0.5; state = 'DEFENSIVE';
    reasons.push(`drawdown ${(dd * 100).toFixed(1)}% >= ${cfg.ddDefend * 100}%: ${cfg.minLeverage}x, 1 slot, half risk`);
  } else if (dd >= cfg.ddReduce) {
    leverage = Math.max(cfg.minLeverage, Math.floor(leverage * 0.75)); slots = Math.max(1, slots - 1); state = 'REDUCED';
    reasons.push(`drawdown ${(dd * 100).toFixed(1)}% >= ${cfg.ddReduce * 100}%: leverage x0.75, one slot fewer`);
  }
  if (dd >= cfg.ddFreezeUp && state === 'NORMAL') state = 'FROZEN';

  // 4. hard ceilings
  leverage = clamp(Math.round(leverage), cfg.minLeverage, cfg.maxLeverage);
  if (slots > 0) risk = Math.min(risk, cfg.maxOpenRisk / Math.min(slots, 20));   // aggregate open-risk budget
  risk = clamp(risk, 0, cfg.maxRisk);

  const marginPerSlot = slots > 0 ? (eq * cfg.maxMarginPct) / Math.min(slots, 20) : 0;
  if (!reasons.length) reasons.push(`${tier.name}: equity $${eq.toFixed(2)}`);

  return { tier: tier.name, tierIndex, slots, slotsCap: Math.min(slotsCap, cfg.maxSlots > 0 ? cfg.maxSlots : slotsCap), leverage, riskPerTrade: risk, marginPerSlot,
    maxTotalMargin: eq * cfg.maxMarginPct, drawdown: dd, edgeProven: proven, state, reasons, drawdownWarning };
}

/**
 * Fit a position to the exchange rules and the slot's margin budget.
 * Returns { ok, qty, notional, margin, riskUsd, shrunk, reason }.
 *  - qty is floored to qtyStep (never exceeds the risk budget)
 *  - shrunk to the slot margin if needed, then re-checked against min qty / min notional
 *  - SKIPPED (ok:false) when the exchange minimum cannot be met inside the risk budget (never rounds UP)
 */
function fitPosition({ entry, stopLoss, equity, riskPerTrade, leverage, marginPerSlot, rules = {}, minRiskOverrun = 1.0, minSizeRiskCap = 0, sizing = 'risk', marginPct = 0 }) {
  const dist = Math.abs(entry - stopLoss);
  if (!(entry > 0) || !(dist > 0) || !(equity > 0)) return { ok: false, reason: 'INVALID_INPUT' };
  const step = rules.qtyStep || 0;
  const floorStep = (q) => (step ? Math.floor(q / step + 1e-9) * step : q);
  const dec = step ? (String(step).split('.')[1] || '').length : 8;
  const fixq = (q) => Number(q.toFixed(dec));

  const riskBudget = equity * riskPerTrade;
  let qty = riskBudget / dist;
  let shrunk = false;
  if (sizing === 'margin' && marginPct > 0) {
    // Margin sizing: the trade uses ~marginPct of equity as isolated margin (notional = margin x leverage), but is
    // still cut back so a stop-out never costs more than the per-trade risk budget.
    let target = equity * marginPct;
    if (marginPerSlot > 0) target = Math.min(target, marginPerSlot);
    const byMargin = (target * leverage) / entry;
    if (byMargin < qty) { qty = byMargin; shrunk = true; }
  } else if (marginPerSlot > 0) {
    const maxQtyByMargin = (marginPerSlot * leverage) / entry;
    if (qty > maxQtyByMargin) { qty = maxQtyByMargin; shrunk = true; }
  }
  qty = fixq(floorStep(qty));

  const minQty = rules.minQty || 0;
  const minNotional = rules.minNotional || 0;
  if (rules.maxQty && qty > rules.maxQty) qty = fixq(floorStep(rules.maxQty));
  let bumped = false;
  if (qty <= 0 || qty < minQty || qty * entry < minNotional) {
    // Tiny account: the risk-based size is below the exchange minimum. Use the smallest legal size ONLY if its
    // stop-loss risk and margin stay inside the caps; otherwise skip (never silently take a bigger risk).
    const ceilStep = (q) => (step ? Math.ceil(q / step - 1e-9) * step : q);
    const need = Math.max(minQty, minNotional > 0 ? minNotional / entry : 0, step || 0);
    const q = fixq(ceilStep(need));
    const okRisk = minSizeRiskCap > 0 && q * dist <= equity * minSizeRiskCap + 1e-9;
    const okMargin = !(marginPerSlot > 0) || (q * entry) / leverage <= marginPerSlot + 1e-9;
    if (!okRisk || !okMargin) {
      if (qty <= 0 || qty < minQty) return { ok: false, reason: `BELOW_MIN_QTY (${minQty}); minimum size would risk $${(q * dist).toFixed(2)}`, qty };
      return { ok: false, reason: `BELOW_MIN_NOTIONAL ($${minNotional})`, qty };
    }
    qty = q; bumped = true;
  }

  const riskUsd = qty * dist;
  if (!bumped && riskUsd > riskBudget * (1 + 1e-9) * minRiskOverrun) return { ok: false, reason: 'RISK_OVER_BUDGET', qty };
  const notional = qty * entry;
  return { ok: true, qty, notional, margin: notional / leverage, riskUsd, shrunk, bumped };
}

module.exports = { computeProfile, statsFromClosed, fitPosition, edgeProven, DEFAULT_TIERS, DEFAULTS };
