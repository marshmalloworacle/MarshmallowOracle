'use strict';
/**
 * Loss governor: NORMAL -> CAUTION -> DEFENSIVE -> ENTRY_HALT -> EMERGENCY, from DAILY drawdown (UTC day, includes unrealised),
 * WEEKLY drawdown (UTC Monday), and ACCOUNT drawdown from the equity high-water mark. Baselines persist in the DB.
 * EMERGENCY latches until acknowledged on the dashboard - a daily reset never clears it. Governs NEW entries only.
 */
const journal = require('../journal/store');
const pcfg = require('../protection/config');
const runtime = require('../control/runtime');
const KEY = 'governor_state';
const LEVELS = ['NORMAL', 'CAUTION', 'DEFENSIVE', 'ENTRY_HALT', 'EMERGENCY'];

const utcDay = (t) => new Date(t).toISOString().slice(0, 10);
function utcWeek(t) { const d = new Date(t); const dow = (d.getUTCDay() + 6) % 7; return utcDay(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - dow)); }

function load() { try { return journal.getState(KEY) || {}; } catch (_) { return {}; } }
/** mode: 'paper' | 'live' - separate books so paper resets never affect live baselines */
function update(mode, equity, now = Date.now()) {
  const all = load(); const s = all[mode] || {};
  const c = pcfg.get();
  if (!(equity > 0)) return { level: s.level || 'NORMAL', unknown: true, reason: 'equity unknown', ...s };
  if (s.day !== utcDay(now)) { s.day = utcDay(now); s.dayStart = equity; }
  if (s.week !== utcWeek(now)) { s.week = utcWeek(now); s.weekStart = equity; }
  s.hwm = Math.max(s.hwm || 0, equity);
  const dd = (a, b) => (a > 0 ? Math.max(0, (a - b) / a * 100) : 0);
  const daily = dd(s.dayStart, equity), weekly = dd(s.weekStart, equity), account = dd(s.hwm, equity);
  let level = 'NORMAL'; const why = [];
  const bump = (l, r) => { if (LEVELS.indexOf(l) > LEVELS.indexOf(level)) level = l; why.push(r); };
  if (daily >= c.govCautionPct) bump('CAUTION', `daily DD ${daily.toFixed(1)}% >= ${c.govCautionPct}%`);
  if (daily >= c.govDefensivePct) bump('DEFENSIVE', `daily DD ${daily.toFixed(1)}% >= ${c.govDefensivePct}%`);
  if (daily >= c.govHaltPct) bump('ENTRY_HALT', `daily DD ${daily.toFixed(1)}% >= ${c.govHaltPct}%`);
  if (weekly >= c.govWeeklyHaltPct) bump('ENTRY_HALT', `weekly DD ${weekly.toFixed(1)}% >= ${c.govWeeklyHaltPct}%`);
  if (account >= c.govAccountDdPct) bump('ENTRY_HALT', `account DD ${account.toFixed(1)}% from peak >= ${c.govAccountDdPct}%`);
  if (daily >= c.govEmergencyPct) bump('EMERGENCY', `daily DD ${daily.toFixed(1)}% >= ${c.govEmergencyPct}%`);
  if (level === 'EMERGENCY' && !s.emergency) s.emergency = { since: now, reason: why[why.length - 1], acted: false, verified: false };
  if (s.emergency && !s.emergency.acknowledged) { level = 'EMERGENCY'; why.push('EMERGENCY latched until acknowledged'); }
  s.level = level; s.reasons = why; s.daily = daily; s.weekly = weekly; s.account = account; s.equity = equity; s.ts = now;
  all[mode] = s; journal.setState(KEY, all);
  const warnOnly = runtime.effectiveDrawdownMode(mode === 'live') !== 'enforce';   // v5.2.4: live drawdown levels warn, never block
  return { ...s, ...(warnOnly ? { minScoreAdd: 0, maxNewPerScan: null, block: false, warnOnly: true } : restrictions(level)) };
}
/** what each level does to NEW entries */
function restrictions(level) {
  return { NORMAL: { minScoreAdd: 0, maxNewPerScan: null, block: false }, CAUTION: { minScoreAdd: 5, maxNewPerScan: 2, block: false },
    DEFENSIVE: { minScoreAdd: 10, maxNewPerScan: 1, block: false }, ENTRY_HALT: { minScoreAdd: 0, maxNewPerScan: 0, block: true }, EMERGENCY: { minScoreAdd: 0, maxNewPerScan: 0, block: true } }[level];
}
function markEmergency(mode, patch) { const all = load(); if (all[mode] && all[mode].emergency) { Object.assign(all[mode].emergency, patch); journal.setState(KEY, all); } }
function acknowledge(mode) { const all = load(); if (all[mode] && all[mode].emergency) { all[mode].emergency.acknowledged = true; all[mode].emergency.ackAt = Date.now(); delete all[mode].emergency; all[mode].level = 'ENTRY_HALT'; journal.setState(KEY, all); return true; } return false; }
function get(mode) { const s = load()[mode]; if (!s) return null; const warnOnly = runtime.effectiveDrawdownMode(mode === 'live') !== 'enforce'; return { ...s, ...(warnOnly ? { minScoreAdd: 0, maxNewPerScan: null, block: false, warnOnly: true } : restrictions(s.level || 'NORMAL')) }; }
module.exports = { update, get, acknowledge, markEmergency, restrictions, LEVELS, utcDay, utcWeek };
