'use strict';

const config = require('../config');
const { eventBus } = require('../events/bus');
const logger = require('../utils/logger');
const scaling = require('./scaling');

// Asset Clusters for Correlation Risk Management
const ASSET_CLUSTERS = {
  LAYER_1: new Set([
    'BTC', 'ETH', 'SOL', 'SUI', 'AVAX', 'NEAR', 'ADA', 'DOT', 'BNB', 'TRX',
    'APT', 'SEI', 'TON', 'FTM', 'S', 'ALGO', 'ATOM', 'XRP', 'LTC', 'BCH',
  ]),
  MEME: new Set([
    'DOGE', '1000PEPE', 'PEPE', 'SHIB', '1000BONK', 'BONK', 'FLOKI', 'WIF',
    'PUMPFUN', 'MOODENG', 'POPCAT', 'BRETT', 'TURBO', 'MEW', 'NEIRO', '1000NEIROCTO',
  ]),
  DEFI: new Set([
    'UNI', 'AAVE', 'LINK', 'MKR', 'LDO', 'CRV', 'SNX', 'DYDX', 'PENDLE',
    'JUP', 'RAY', 'SUSHI', 'COMP', '1INCH', 'ENA', 'CAKE', 'RUNE',
  ]),
  AI_DEPIN: new Set([
    'TAO', 'RENDER', 'FET', 'WLD', 'AKT', 'GRASS', 'IO', 'KAS', 'JASMY',
    'AR', 'HIVE', 'ROBO',
  ]),
  INFRA_L2: new Set([
    'ARB', 'OP', 'STRK', 'ZK', 'TIA', 'MANTA', 'CELO', 'METIS', 'ZRO', 'POL',
  ]),
};

/**
 * Identify asset cluster for correlation management
 */
function getAssetCluster(symbol) {
  const clean = (symbol || '').toUpperCase().replace(/USDT$/, '');
  for (const [cluster, tokens] of Object.entries(ASSET_CLUSTERS)) {
    if (tokens.has(clean)) return cluster;
  }
  return 'ALT_GENERAL';
}

/**
 * Centralized Correlation-Aware Risk Engine
 * ALL trades must pass before execution.
 * Strategy cannot bypass risk engine.
 */
class RiskEngine {
  constructor(riskConfig = {}) {
    this.cfg = {
      riskPerTrade:          riskConfig.riskPerTrade          ?? config.riskPerTrade,
      maxOpenPositions:      riskConfig.maxOpenPositions      ?? config.maxOpenPositions,
      maxDailyLoss:          riskConfig.maxDailyLoss          ?? config.maxDailyLoss,
      maxPortfolioExposure:  riskConfig.maxPortfolioExposure  ?? config.maxPortfolioExposure,
      maxCorrelatedExposure: riskConfig.maxCorrelatedExposure ?? config.maxCorrelatedExposure ?? 0.20,
      maxConsecutiveLosses:  riskConfig.maxConsecutiveLosses  ?? config.maxConsecutiveLosses,
      accountBalance:        riskConfig.accountBalance        ?? config.accountBalance,
      minRR:                 riskConfig.minRR                 ?? config.minRR,
      regimeFilterEnabled:   riskConfig.regimeFilterEnabled   ?? config.regimeFilterEnabled !== false,
      exposureBasis:         riskConfig.exposureBasis         ?? config.exposureBasis ?? 'margin',
      leverage:              riskConfig.leverage              ?? config.defaultLeverage ?? 10,
      liqSafety:             riskConfig.liqSafety             ?? config.liqSafety ?? 0.8,
      mmr:                   riskConfig.mmr                   ?? config.maintenanceMarginRate ?? 0.005,
      enforceFreeMargin:     riskConfig.enforceFreeMargin     ?? (config.enforceFreeMargin || config.isLive),
    };

    // LIVE mode must never run without a daily-loss stop, even if the env left it at 0 (= off, paper behaviour)
    if (config.isLive && !(this.cfg.maxDailyLoss > 0)) this.cfg.maxDailyLoss = config.liveMaxDailyLoss || 0.05;
    this.cfg.scalingEnabled = riskConfig.scaling ?? (config.isLive && config.scaling.enabled);
    this.cfg.marginPerSlot = 0;
    this.profile = null;

    // Runtime state
    this.state = {
      openPositions:    0,
      dailyPnL:         0,
      consecutiveLosses: 0,
      totalExposure:    0,
      clusterExposures: {},
      tradingEnabled:   true,
      killSwitch:       false,
      dailyLossDate:    null,
    };
  }

  /** warn-only drawdown notice -> decision log (deduplicated there) */
  _ddWarn(code, message, signal) {
    try { require('../decisions/log').record({ type: 'TRADE_WARNING', severity: 'WARNING', module: 'drawdownGuard', symbol: signal && signal.symbol, direction: signal && signal.direction,
      reason: message, action: 'Warning only - trade allowed', key: `dd_${code}`, cooldownMs: 30 * 60 * 1000, recommend: 'Review position size / leverage, or set DRAWDOWN_MODE=enforce if you want the limit to block entries.' }); } catch (_) { /* never break risk checks */ }
  }

  /**
   * Recompute slots / leverage / risk from equity (see scaling.js). Called by the live loop before each scan.
   * No-op unless scaling is enabled (LIVE default); paper keeps its fixed settings.
   */
  refreshProfile({ equity, peakEquity, stats } = {}) {
    if (!this.cfg.scalingEnabled) return null;
    const runtime = require('../control/runtime');
    const sc = runtime.slotConfig();   // v6.0.2: your slot settings replace the equity tier and the fixed ramp
    const p = scaling.computeProfile({ equity, peakEquity, stats, config: { ...config.scaling, drawdownMode: runtime.effectiveDrawdownMode(), userSlots: true, slotRamp: sc.ramp, startSlots: sc.start, rampEvery: sc.every, rampMinPF: sc.minPF, maxSlots: sc.max } });
    const sz = runtime.sizing(); const fixed = sz.enabled ? sz.leverage : runtime.leverageChoice();   // your leverage (dashboard / .env); contract max is checked per coin at order time
    if (fixed) { p.leverage = fixed; p.reasons.push(`leverage fixed at ${fixed}x by your selection`); }
    this.profile = p;
    this.cfg.leverage = p.leverage;
    this.cfg.riskPerTrade = p.riskPerTrade;
    this.cfg.maxOpenPositions = p.slots;
    this.cfg.marginPerSlot = p.marginPerSlot;
    this.cfg.maxPortfolioExposure = Math.max(this.cfg.maxPortfolioExposure || 0, 0) || config.scaling.maxMarginPct;
    return p;
  }

  /**
   * Main risk & correlation check — returns { approved, reason, positionSize, riskAmount }
   */
  check(signal, openPositions = [], opts = {}) {
    // 1. Kill switch
    if (this.state.killSwitch) {
      return this._reject('KILL_SWITCH_ACTIVE');
    }

    // 2. Trading disabled
    if (!this.state.tradingEnabled) {
      return this._reject('TRADING_DISABLED');
    }

    // 3. Reset daily PnL if new day
    this._checkDayReset();

    // 4. Max open positions
    const openCount = openPositions.length;
    if (this.cfg.accountBalance <= 0) return this._reject('ACCOUNT_DEPLETED — reset the paper balance');
    // v6.7: a MANUAL take (opts.ignoreSlots) skips the slot limit but can never pass opts.hardCap (live 5 / paper 50 by default)
    if (opts.ignoreSlots) {
      if (opts.hardCap > 0 && openCount >= opts.hardCap) return this._reject(`HARD_CAP_REACHED (${openCount}/${opts.hardCap}) - manual take cannot exceed the hard position cap`);
    } else if (this.cfg.maxOpenPositions > 0 && openCount >= this.cfg.maxOpenPositions) {
      return this._reject(`MAX_POSITIONS_REACHED (${openCount}/${this.cfg.maxOpenPositions})`);
    }

    // 5. Max daily loss
    const dailyLossPct = Math.abs(Math.min(0, this.state.dailyPnL)) / this.cfg.accountBalance;
    const ddMode = require('../control/runtime').effectiveDrawdownMode();
    if (this.cfg.maxDailyLoss > 0 && dailyLossPct >= this.cfg.maxDailyLoss) {
      if (ddMode === 'enforce') return this._reject(`MAX_DAILY_LOSS_REACHED (${(dailyLossPct * 100).toFixed(2)}%)`);
      this._ddWarn('DAILY_LOSS_LIMIT', `Daily loss ${(dailyLossPct * 100).toFixed(2)}% is past the ${(this.cfg.maxDailyLoss * 100).toFixed(1)}% limit. Trading continues (DRAWDOWN_MODE=${ddMode}).`, signal);
    }

    // 6. Max consecutive losses
    if (this.cfg.maxConsecutiveLosses > 0 && this.state.consecutiveLosses >= this.cfg.maxConsecutiveLosses) {
      if (ddMode === 'enforce') return this._reject(`MAX_CONSECUTIVE_LOSSES (${this.state.consecutiveLosses})`);
      this._ddWarn('LOSS_STREAK', `${this.state.consecutiveLosses} losses in a row (limit ${this.cfg.maxConsecutiveLosses}). Trading continues (DRAWDOWN_MODE=${ddMode}).`, signal);
    }

    // 7. Minimum R:R
    if (signal.riskReward < this.cfg.minRR) {
      return this._reject(`R:R ${signal.riskReward} < ${this.cfg.minRR}`);
    }

    // 8. Valid entry/SL/TP
    if (!signal.entry || !signal.stopLoss || !signal.takeProfit) {
      return this._reject('INVALID_LEVELS');
    }

    // 9. Regime Conflict Gate (optional/configurable)
    if (this.cfg.regimeFilterEnabled && signal.regime) {
      const { regime, confidence = 0 } = signal.regime;
      if (confidence >= 75) {
        if (signal.direction === 'LONG' && regime === 'TRENDING_DOWN') {
          return this._reject(`REGIME_CONFLICT: Cannot LONG in ${regime}`);
        }
        if (signal.direction === 'SHORT' && regime === 'TRENDING_UP') {
          return this._reject(`REGIME_CONFLICT: Cannot SHORT in ${regime}`);
        }
      }
    }

    // 9b. Liquidation awareness: the stop must trigger well before the exchange would liquidate the position
    const fx = opts.fixedSizing || null;                 // v5.2.4 live margin x leverage sizing
    let effLev = this.cfg.leverage, levNote = null;
    if (fx) {
      effLev = fx.leverage; const cm = opts.rules && opts.rules.maxLeverage;
      if (cm && effLev > cm) {
        if (config.leverageOverMax === 'skip') return this._reject(`LEVERAGE_ABOVE_CONTRACT_MAX: ${signal.symbol} allows ${cm}x, you chose ${effLev}x (LEVERAGE_OVER_MAX=skip)`);
        levNote = `leverage capped ${effLev}x -> ${cm}x (contract max for ${signal.symbol})`; effLev = cm;
      }
    }
    const liq = liquidationPrice(signal.direction, signal.entry, effLev, this.cfg.mmr);
    if (liq && Math.abs(signal.entry - signal.stopLoss) > Math.abs(signal.entry - liq) * this.cfg.liqSafety) {
      return this._reject(`SL_TOO_CLOSE_TO_LIQUIDATION (liq ${liq.toFixed(4)} at ${effLev}x; the stop must trigger before liquidation - try a lower leverage)`);
    }

    // 10. Position sizing
    let positionSize = this.calcPositionSize(signal, this.cfg.accountBalance);
    let sizeNote = null;
    if (fx) {   // notional = margin x leverage, floored to the contract step; never rounded UP past your margin
      const rl = opts.rules || {}, step = rl.qtyStep || 0, dec = step ? (String(step).split('.')[1] || '').length : 8;
      let q = (fx.margin * effLev) / signal.entry; if (step) q = Math.floor(q / step + 1e-9) * step; q = Number(q.toFixed(dec));
      if (rl.maxQty && q > rl.maxQty) q = rl.maxQty;
      if ((!(q > 0) || q < (rl.minQty || 0) || q * signal.entry < (rl.minNotional || 0)) && fx.baseMargin > fx.margin) {   // taper shrank it below the contract minimum: use the minimum size if it stays within your normal margin
        let qm = Math.max(rl.minQty || 0, (rl.minNotional || 0) / signal.entry, step || 0); if (step) qm = Math.ceil(qm / step - 1e-9) * step; qm = Number(qm.toFixed(dec));
        if (qm * signal.entry / effLev <= fx.baseMargin + 1e-9) q = qm;
      }
      if (!(q > 0) || q < (rl.minQty || 0) || q * signal.entry < (rl.minNotional || 0)) {
        return this._reject(`SIZE_SKIPPED: ${fx.margin} USDT x ${effLev}x = ${(fx.margin * effLev).toFixed(2)} USDT is below the contract minimum (min qty ${rl.minQty || '-'}, min notional ${rl.minNotional || '-'} USDT) for ${signal.symbol}. Raise the margin or leverage.`);
      }
      positionSize = q; sizeNote = levNote ? `FIXED_MARGIN; ${levNote}` : 'FIXED_MARGIN';
    } else if (this.cfg.scalingEnabled || opts.rules) {
      // Fit to the slot's margin budget and the exchange minimums; never rounds UP past the risk budget
      const fit = scaling.fitPosition({ entry: signal.entry, stopLoss: signal.stopLoss, equity: this.cfg.accountBalance,
        riskPerTrade: this.cfg.riskPerTrade, leverage: this.cfg.leverage, marginPerSlot: this.cfg.marginPerSlot, rules: opts.rules || {}, minSizeRiskCap: this.cfg.scalingEnabled ? config.scaling.minSizeRiskCap : 0,
        sizing: this.cfg.scalingEnabled ? config.scaling.sizing : 'risk', marginPct: config.scaling.marginPct });
      if (!fit.ok) return this._reject(`SIZE_SKIPPED: ${fit.reason}`);
      positionSize = fit.qty;
      sizeNote = fit.bumped ? 'MIN_EXCHANGE_SIZE' : fit.shrunk ? 'SHRUNK_TO_SLOT' : null;
    }
    const posValue = positionSize * signal.entry;

    // 11. Max overall portfolio exposure
    const newExposure = (this.state.totalExposure + this._expo(posValue)) / this.cfg.accountBalance;
    if (this.cfg.enforceFreeMargin && this.state.totalExposure + this._expo(posValue) > this.cfg.accountBalance + 1e-9) {
      return this._reject(`INSUFFICIENT_FREE_MARGIN (needs $${this._expo(posValue).toFixed(2)}, free $${Math.max(0, this.cfg.accountBalance - this.state.totalExposure).toFixed(2)})`);
    }
    if (this.cfg.maxPortfolioExposure > 0 && newExposure > this.cfg.maxPortfolioExposure + 1e-9) {
      return this._reject(`MAX_EXPOSURE (${(newExposure * 100).toFixed(1)}% > ${(this.cfg.maxPortfolioExposure * 100)}%)`);
    }

    // 12. Correlation / Cluster Exposure Gate
    const cluster = getAssetCluster(signal.symbol);
    const existingClusterVal = openPositions
      .filter(p => getAssetCluster(p.symbol) === cluster)
      .reduce((sum, p) => sum + this._expo((p.positionSize || 0) * (p.entry || 0)), 0);

    const newClusterExposure = (existingClusterVal + this._expo(posValue)) / this.cfg.accountBalance;
    // ALT_GENERAL is a catch-all bucket (not a genuinely correlated cluster) — it is governed by the portfolio cap only,
    // otherwise most altcoins share one cap and 10+ concurrent positions become impossible.
    if (this.cfg.maxCorrelatedExposure > 0 && cluster !== 'ALT_GENERAL' && newClusterExposure > this.cfg.maxCorrelatedExposure + 1e-9) {
      return this._reject(`MAX_CORRELATED_EXPOSURE: ${cluster} (${(newClusterExposure * 100).toFixed(1)}% > ${(this.cfg.maxCorrelatedExposure * 100)}%)`);
    }

    logger.risk(`APPROVED: ${signal.symbol} ${signal.direction} [${cluster}] | Size: ${positionSize.toFixed(4)} | R:R: ${signal.riskReward}`);

    return {
      approved: true,
      reason: 'APPROVED',
      positionSize,
      riskAmount: positionSize * Math.abs(signal.entry - signal.stopLoss),
      cluster,
      sizeNote,
      leverage: effLev,
      marginUsd: fx ? Number(((positionSize * signal.entry) / effLev).toFixed(6)) : undefined,
    };
  }

  /**
   * Calculate position size from risk per trade
   * positionSize = (accountBalance × riskPerTrade) / |entry - stopLoss|
   */
  calcPositionSize(signal, balance = null) {
    const bal = balance ?? this.cfg.accountBalance;
    const riskAmount = bal * this.cfg.riskPerTrade;
    const riskPerUnit = Math.abs(signal.entry - signal.stopLoss);
    if (riskPerUnit === 0) return 0;
    return parseFloat((riskAmount / riskPerUnit).toFixed(4));
  }

  onTradeClosed(pnl) {
    this.state.dailyPnL += pnl;
    if (pnl < 0) {
      this.state.consecutiveLosses++;
    } else {
      this.state.consecutiveLosses = 0;
    }
  }

  onPositionOpened(value, symbol = null) {
    value = this._expo(value);
    this.state.openPositions++;
    this.state.totalExposure += value;
    if (symbol) {
      const c = getAssetCluster(symbol);
      this.state.clusterExposures[c] = (this.state.clusterExposures[c] || 0) + value;
    }
  }

  onPositionClosed(value, symbol = null) {
    value = this._expo(value);
    this.state.openPositions = Math.max(0, this.state.openPositions - 1);
    this.state.totalExposure = Math.max(0, this.state.totalExposure - value);
    if (symbol) {
      const c = getAssetCluster(symbol);
      this.state.clusterExposures[c] = Math.max(0, (this.state.clusterExposures[c] || 0) - value);
    }
  }

  emergencyStop() {
    this.state.killSwitch = true;
    this.state.tradingEnabled = false;
    eventBus.emitEvent('emergency.triggered', { timestamp: Date.now() });
    logger.risk('⛔ EMERGENCY STOP ACTIVATED — all trading blocked');
  }

  disableTrading() {
    this.state.tradingEnabled = false;
    logger.risk('Trading DISABLED');
  }

  enableTrading() {
    if (this.state.killSwitch) {
      logger.risk('Cannot enable trading — kill switch active');
      return false;
    }
    this.state.tradingEnabled = true;
    logger.risk('Trading ENABLED');
    return true;
  }

  resetKillSwitch() {
    this.state.killSwitch = false;
    logger.risk('Kill switch reset');
  }

  getStatus() {
    return {
      tradingEnabled: this.state.tradingEnabled,
      killSwitch: this.state.killSwitch,
      openPositions: this.state.openPositions,
      consecutiveLosses: this.state.consecutiveLosses,
      dailyPnL: this.state.dailyPnL,
      totalExposure: this.state.totalExposure,
      exposurePct: parseFloat(((this.state.totalExposure / this.cfg.accountBalance) * 100).toFixed(1)),
      clusterExposures: { ...this.state.clusterExposures },
      maxCorrelatedExposure: this.cfg.maxCorrelatedExposure,
      mode: config.mode,
    };
  }

  /** Convert a notional value into the configured exposure basis (margin = notional / leverage) */
  _expo(notional) {
    return this.cfg.exposureBasis === 'margin' ? notional / Math.max(1, this.cfg.leverage) : notional;
  }

  _reject(reason) {
    logger.risk(`REJECTED: ${reason}`);
    eventBus.emitEvent('risk.breach', { reason, timestamp: Date.now() });
    return { approved: false, reason, positionSize: 0 };
  }

  _checkDayReset() {
    const today = new Date().toDateString();
    if (this.state.dailyLossDate !== today) {
      this.state.dailyPnL = 0;
      this.state.dailyLossDate = today;
    }
  }
}

/** Isolated-margin liquidation estimate: LONG entry*(1-1/L+mmr), SHORT entry*(1+1/L-mmr) */
function liquidationPrice(direction, entry, leverage = 10, mmr = 0.005) {
  if (!entry || !leverage) return null;
  return direction === 'SHORT' ? entry * (1 + 1 / leverage - mmr) : entry * (1 - 1 / leverage + mmr);
}

module.exports = RiskEngine;
module.exports.liquidationPrice = liquidationPrice;
module.exports.getAssetCluster = getAssetCluster;
module.exports.ASSET_CLUSTERS = ASSET_CLUSTERS;
