# v6.3 (includes 6.0 and 6.0.1)
- Position slots card (Modules): Ramp ON/OFF, Max slots (0 = no limit), ramp start, +1 slot per N closed trades, minimum profit factor. No equity tier. Applies to the next trade, no restart. Ramp default OFF (env SLOT_RAMP=true to default ON).
- Every notification and pop-up is tagged LIVE (red-orange) or PAPER (blue).
- Open trades tab (Insights): per-trade panel with chart (entry, stop-loss, trailing stop, take-profit, stop-move markers), protection status in plain words (Trailing ACTIVE / waiting / OFF / no stop), and a Close button (live and paper) with confirm. Close button on every row.
- Stop moves are now recorded per trade (last 25) so trailing is provable.
- Ultra-dark glass theme, airier spacing, grouped controls; status tiles with dots.
