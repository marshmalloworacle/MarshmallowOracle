# v6.5.1
- Fix: "ENTRIES BLOCKED: <coin> filled without a verified stop-loss" appeared falsely once trailing / break-even had moved the stop, because the safety check compared the exchange stop with the ORIGINAL stop. A stop that is the same or TIGHTER than the original now counts as verified. A missing stop, or one looser than the original, still blocks entries and alerts (position left open, policy unchanged).
- If entries are still showing blocked after installing, press Unblock entries once (Live Accounts).
