# v5.2: exchange-neutral robot, Exchange tab, GO LIVE, Bitget UTA, early trailing

## Modes
- **Testnet removed.** Modes are SIM (paper, default) and LIVE. Legacy `TRADING_MODE=TESTNET` / `PAPER` / `LIVE`+`BYBIT_TESTNET=true` all resolve to SIM (never to real money). Testnet Lab tab, routes, command and `testLab.js` deleted.

## Exchange-neutral
- Labels, logs, intel scope text, Telegram banner and the connection ping follow the ACTIVE exchange. Paper/backtest taker fee follows the exchange (`TAKER_FEE_RATE` overrides).
- New dashboard **Exchange** tab: pick Bybit / Bitget / MEXC / Simulator, enter API keys (write-only; masked status only; saved to the local `.env`, mode 600, gitignored), Bitget account type (Auto / Classic / Unified), read-only **Test connection**, **Save**.
- Changes apply through a **safe restart** (`start-all` supervisor restarts robot + dashboard on the same port; exit code 75). Without the supervisor the tab says to restart manually. Switching exchange is refused while live positions are open. No dashboard login (by choice); writes need the dashboard header + same-origin, secrets are never returned, mode changes only through typed confirmations.

## GO LIVE / Stop live
- **GO LIVE** (Live Accounts bar and Exchange tab): type `GO LIVE`; a read-only connection test must pass; then `.env` is set to LIVE and the robot restarts, applying the one-time runtime authorisation. All other live gates, stop-loss placement and risk limits unchanged. **Back to paper** (type `PAPER`) refuses while live positions are open.
- **Stop live (no new trades)** = the existing pause: stops NEW entries, open trades keep their stops and trailing; **Resume live** re-allows. Closing trades remains Emergency Stop / Flatten.

## Bitget Unified Trading Account (UTA)
- `src/exchanges/bitgetUta.js` (v3: account assets/settings, positions, orders, TP/SL, leverage, one-way + isolated) beside the Classic (v2) layer; `BITGET_ACCOUNT_TYPE=auto|classic|uta`, auto asks Bitget. Hedge / unreadable position mode refuses to trade. Response parsing is defensive; **not verified against a live UTA account**: run `npm run bitget:verify` and start with the smallest size.

## Trailing stop
- Smart trailing and profit-giveback tighten are now **ON by default**, armed from the open (ATR trail follows the peak before any stage), ladder starts at 15% of the way to TP: stages `15,30,50,60,70,80` / locks `0,0.1,0.2,0.35,0.5,0.65` (`PROT_STAGES`, `PROT_LOCKS`, `PROT_ARM_AT_OPEN`). Stops only ever tighten. Note: a flag saved earlier in the dashboard (Modules) overrides the new default.

## Tests: 350 passing (modes, env store, route safety, Bitget Classic + UTA, streams, trailing ladder).

## 5.2.1
- Added `npm run paper` and `npm run all` (both start robot + dashboard; mode and exchange come from `.env` / the dashboard). Removed the obsolete `npm run testnet`.
- A dashboard-requested restart now drops dashboard-managed settings inherited from the launching shell (e.g. `TRADING_MODE`), so GO LIVE / Back to paper / exchange changes are never silently overridden by an old shell variable.
