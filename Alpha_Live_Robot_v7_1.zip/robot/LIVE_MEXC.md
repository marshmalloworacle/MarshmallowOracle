# Going live: small account ($10–$100), MEXC or Bybit

**Status (v4.4):** the live order path, order lifecycle, small-account scaling and the Live Account dashboard tab are built and tested **offline with mocks only**. Nothing has touched a real exchange yet, so the first contact happens on your machine. Follow the order below and do not skip steps.

## 0. Know the MEXC limitation first
MEXC enables futures **order placement via API for some accounts only** (the official contract docs mark order endpoints as restricted, and each contract carries an `apiAllowed` flag). This robot uses only the official signed endpoints. It never uses browser-session tokens or "bypass" libraries. If MEXC refuses your key, the robot stays safe and cannot trade there. Use `EXCHANGE=bybit`, or ask MEXC support for futures API trading permission.

## 1. Read-only verification (places no orders)
```bash
cd robot            # the project folder
cp .env.example .env
# edit .env: set MEXC_API_KEY / MEXC_API_SECRET (or BYBIT_*), EXCHANGE=mexc (or bybit)
npm run mexc:verify     # or: npm run bybit:verify
```
It checks reachability, clock drift, contracts (and how many are `apiAllowed`), credentials, and balance read. Fix every FAIL before continuing. The "order placement" line is deliberately **INFO**: permission is only proven by a real order.

API key rules: Futures **read + trade** only, **withdrawals OFF**, IP whitelist if you can. Never paste keys in chat. Codespaces: store them as Codespaces secrets or in `.env` (git-ignored).

### If private checks fail (HTTP 401, error 1005)
- **Never set `MEXC_BASE_URL=https://api.mexc.com`**: that is MEXC's spot host. The robot now refuses it. Remove the line; the default `https://contract.mexc.com` is the futures host.
- Error **1005 / 401 on contract.mexc.com** means MEXC rejected the key for futures. On MEXC → API Management: make sure the key has **Futures** read (and trade) ticked, futures trading is activated on the account, and test once with **no IP restriction** (Codespaces IPs change). Create a fresh key if unsure. Error 406 = IP whitelist, 602 = signature/secret mismatch, 701/703 = missing permission.
- The verify output now prints the exact MEXC code and a next step. Re-run `npm run mexc:verify` after each change.

## 2. Paper first, on live data
`TRADING_MODE=PAPER` with your chosen `EXCHANGE`. Let it run for days. Check signals, fees, and that the scanner finds enough setups at your account size.

## 3. Bybit testnet rehearsal (recommended)
`BYBIT_TESTNET=true`, testnet keys, `EXCHANGE=bybit`, `TRADING_MODE=LIVE`, `LIVE_TRADING_ENABLED=true`. This runs the full real-order code with fake money. Watch the **Live Account** tab: orders, "Stop verified", slots.

## 4. Real money
1. `.env`: `TRADING_MODE=LIVE`, `LIVE_TRADING_ENABLED=true`, real keys. Fund with what you can afford to lose (start small).
2. `npm run start:all`, open the dashboard (Codespaces: forward the port). The ribbon shows **LIVE MODE LOCKED**.
3. Live Account tab → type `I UNDERSTAND LIVE TRADING` → **Authorise**. The server checks the phrase. Restarting the robot locks it again.
4. Watch the first 20–30 trades by hand. Keep the exchange app open.

## What protects you
| Control | Behaviour |
|---|---|
| Gates | emergency stop, mode, live flag, credentials, runtime confirmation, reconciliation, signal integrity, risk approval, all must pass |
| Daily loss | **5%** of start-of-day equity (`LIVE_MAX_DAILY_LOSS`), applies even if `MAX_DAILY_LOSS=0`; persisted, survives restarts |
| Slots | many small isolated slots: $0–15 → 5, $15–40 → **6 (your start)**, $40–80 → 8, $80–150 → 10, $150–400 → 12, $400–1000 → 14, $1000+ → 16. Override with `SCALING_SLOTS`, cap with `SCALING_MAX_SLOTS` (example file sets 10). Risk per trade = min(1.5%, 8% ÷ slots) |
| Leverage | 10x base. Above that only after 20+ closed trades with profit factor ≥ 1.2. Hard ceiling 20x |
| Drawdown | ≥5% from peak: leverage ×0.75 and one slot fewer. ≥10%: 1 slot, 5x, half risk. No scale-up at ≥8% |
| Position size | **margin sizing**: each trade uses 5% of equity as isolated margin (≈$1 on $20, ≈$10 position at 10x; grows with equity), cut back so a stop-out never exceeds the per-trade risk budget; also shrunk to the slot's margin, floored to the exchange step. **Skipped** (never rounded up) if below the exchange minimum or over the risk budget |
| Orders | persisted before sending; deterministic client id (no duplicates after retries or restarts); timeouts are never blind-retried: the exchange is queried first, otherwise entries are blocked |
| Stop-loss | attached to the entry, then **read back from the exchange**. Unverified → entries blocked + alert (`LIVE_UNPROTECTED_POLICY=close` also closes the position) |
| Stale entries | unfilled limit entries are cancelled after 120 s |
| Margin mode | **Isolated only.** MEXC orders are sent isolated. On Bybit the robot reads the account margin mode and pauses entries unless it is ISOLATED_MARGIN |
| Reset button | disabled in LIVE mode, in the UI and in the server |
| Liquidation | stop-loss must sit inside 80% of the distance to liquidation |

## Profit targets on tiny positions
Targets come from the strategy's stop distance and R:R (min 2.0), sized so a loss is ~1.5% of equity. On $20 that is about $0.30 risk for roughly $0.60+ reward. Fees matter more at this size: exchange minimums and taker fees can eat a large share of a $0.35 win. Check the real fee rates your account pays (`getOrderHistory` / the exchange fee page); the robot does not assume a rate.

## Live Control Center (dashboard)
The header has a **PAPER | LIVE** switch. PAPER shows the simulated panels as before. LIVE swaps the whole page for the Control Center, which reads your **real exchange account directly** (read-only, cached 5 s, flagged STALE if the exchange stops answering). It works even when the robot process is stopped.
- **Emergency bar:** *Flatten all* (`F`; cancels resting entries, closes every position at market reduce-only, then pauses entries) · *Kill switch* (`K`; stops new trading and cancels resting entries, keeps positions and their exchange stops) · Pause/Resume · Clear entry block · Revoke live auth. Flatten and Kill need you to type `FLATTEN` / `KILL`; shortcuts only open the confirmation.
- **Tabs:** Account · Risk · Order Preview (sizes an idea exactly like the robot and runs every rule; sends nothing) · Positions & Orders (per-row Close) · Live Journal · Strategy · Charts · System Health (+ alert feed).
- **Live journal:** real fills and exchange-reported closes are written to the live trades table, separate from paper trades and charts.
- **Safety design:** the dashboard server has no code path that places or cancels orders. Close/flatten/kill are forwarded to the robot process, re-validated there, and refused outside LIVE mode. If the robot process is not running they return an error instead of acting; your positions keep their exchange stop-loss, and you can close them in the exchange app.
- Dashboard extras: monospace prices, compact/comfortable density, optional sound cues (soft click on fills, warning tone on blocks or unprotected stops), PAPER ribbon green and LIVE ribbon full crimson.

## Alerts and Telegram control
Alerts appear in the **Live Account** tab and are sent to Telegram (set `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `TELEGRAM_ADMIN_CHAT_ID` in `.env`):
- **slots:** one grouped message when slots, leverage, tier or drawdown mode change (up or down)
- **orders:** placed, filled, stop-loss confirmed, closed with realised PnL
- **safety:** entries blocked, unprotected position, unknown order, daily stop hit, failed live cycle, pause/resume
- **heartbeat:** a start message, then hourly. **No heartbeat for over an hour = the robot or Codespace stopped.** Positions keep their exchange stop-loss meanwhile.
Telegram commands (admin chat only): `/status` (equity, slots, day P&L, paused/blocked), `/pause` (no new entries; saved across restarts), `/resume`. Choose categories with `LIVE_ALERT_EVENTS`, heartbeat spacing with `LIVE_HEARTBEAT_MIN`.

## Settings reference (all in `.env`; every one is optional)
| Setting | Default | Meaning |
|---|---|---|
| `SCALING_START_SLOTS` | 3 | slots at the beginning (0 = skip the ramp, use the equity table) |
| `SCALING_RAMP_EVERY` / `SCALING_RAMP_MIN_PF` | 10 / 1.2 | +1 slot per 10 closed live trades while profit factor ≥ 1.2 and expectancy > 0; falls back automatically if the edge is lost |
| `SCALING_SLOTS` | 0 | fixed slot count (0 = automatic); wins over the ramp |
| `SCALING_MAX_SLOTS` | 10 (example file) | hard cap on open trades |
| `SCALING_TIERS` | built-in | custom table `minEquity:slots:leverage,...` e.g. `0:5:10,15:6:10,40:8:10` |
| `SCALING_SIZING` / `SCALING_MARGIN_PCT` | margin / 0.05 | each trade uses 5% of equity as isolated margin |
| `SCALING_BASE_RISK` / `SCALING_MAX_RISK` | 0.015 / 0.02 | per-trade risk to the stop-loss (hard ceiling) |
| `SCALING_MAX_OPEN_RISK` | 0.08 | all slots stopped out together cost ≤ 8% |
| `SCALING_BASE_LEVERAGE` / `MIN` / `MAX` | 10 / 5 / 20 | leverage start, drawdown floor, hard ceiling |
| `SCALING_PERF_MIN_TRADES` / `SCALING_PERF_MIN_PF` | 20 / 1.2 | evidence needed before leverage rises above base |
| `SCALING_DD_REDUCE` / `DEFEND` / `FREEZE_UP` | 0.05 / 0.10 / 0.08 | drawdown steps that cut leverage, slots and risk |
| `SCALING_MAX_MARGIN_PCT` | 0.6 | all open margin together stays under 60% of equity |
| `SCALING_MIN_SIZE_RISK_CAP` | 0.03 | allow exchange-minimum size if its stop risk ≤ 3% of equity |
| `LIVE_MAX_DAILY_LOSS` | 0.05 | daily loss stop |
| `LIVE_ORDER_TYPE` / `LIVE_ENTRY_OFFSET_BPS` / `LIVE_ENTRY_TTL_SEC` | Limit / 5 / 120 | entry order style |
| `LIVE_UNPROTECTED_POLICY` | alert | alert or close when a stop-loss can't be verified |
| `MAX_OPEN_POSITIONS`, `RISK_PER_TRADE`, `DEFAULT_LEVERAGE` | (paper) | paper-mode equivalents |

## Known limitations (be honest with yourself)
- Never tested against real MEXC or Bybit servers from the build environment; mocks follow the official docs.
- MEXC: REST only (no futures WebSocket yet; the feed polls), no open-interest history (endpoint doesn't exist), order permission is account-dependent.
- Leverage above 10x unlocks from exchange-reported closed-trade PnL (needs 20+ closed trades, PF ≥ 1.2). Until then it stays at 10x.
- Tiny accounts: if the risk-based size is under the exchange minimum, the minimum size is used only when its stop-loss risk ≤ 3% of equity and margin fits the slot; otherwise the signal is skipped.
- Dashboard shows live orders and equity from the exchange; the paper journal does not record real trades yet.
- Codespaces can suspend when idle. For 24/7 live trading use a VPS; Codespaces is fine for testing.
- Nothing here guarantees profit. A small account can lose its entire balance.
