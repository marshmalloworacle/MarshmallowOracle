# v6.3.1
- Fix: "Authorise live trading" did nothing. The Live page refreshed every 5 seconds and erased the phrase while you typed, so the button sent an empty phrase. Typing is now never wiped (refresh pauses while a box is focused and values are kept), and an empty box tells you what to type.
- Phrase check is now case/space tolerant (I UNDERSTAND LIVE TRADING) and the error says exactly what to type.
- Authorising still needs TRADING_MODE=LIVE and LIVE_TRADING_ENABLED=true in .env, and is separate from Take Live Trades.
