# Alpha Live Robot v7.1

## Fixes
- **Stale BTCUSDT rows on first start / "cannot close".** Cause: the v7.0 zip shipped a `data/robot.db` full of test leftovers (5 fake open `TEST_TRADE_` BTCUSDT paper rows, a paused scan session listing BTCUSDT as scanned, fake live stats), because `npm test` wrote into the real database. In LIVE mode the robot also refuses to manage plain-paper rows, so Close could never work on them.
  - The zip now ships with **no database**; `npm test` runs on a temporary database.
  - **Startup self-heal** (robot and dashboard): removes `TEST_` rows and unmanageable open paper rows, finishes scanner sessions older than `SCAN_SESSION_MAX_AGE_HOURS` (6). Closed history is never touched. Turn off with `STARTUP_SELF_HEAL=false`.
  - **Close** on a ghost row now removes it instead of failing; **Clear stale rows** button in the toolbar.
- **Home / Back** are now a normal toolbar row under the page header (no floating circles over the sidebar).

## Adaptive Directional Intelligence (extends the existing direction control and Adaptive engine)
- Direction modes: **ADAPTIVE** (both open, ADI only re-orders setups), **AUTO** (ADI may restrict new entries to the stronger direction with enough evidence and approval), plus BOTH / LONG ONLY / SHORT ONLY / PAUSE as before.
- Direction changes govern **new entries only**: open positions, stops and take-profits are never closed, reversed, cancelled or edited. `DIRECTION_CHANGE_*` are locked to those safe values.
- LIVE: nothing is applied without your approval (24h, tied to the recommended direction). Paper may auto-adapt (`ADI_PAPER_AUTO_ADAPT`).
- Paper and live results are weighted and normalised; paper can never hide poor live results; insufficient data = BOTH.
- **Manual Take overrides the direction MODE** (with a confirmation); `ALLOW_LONG_TRADES` / `ALLOW_SHORT_TRADES` stay hard permissions.
- One configuration service: `.env` initial values, dashboard overrides for live-editable keys (persisted), safety keys `.env`-only, effective value + source shown. An edited `.env` mode applies once, then the dashboard wins again.
- All 37 ADI variables are in `.env.example`, validated at startup (clear error, robot refuses to start on invalid values). `npm run adi:config` prints the safe summary. `npm run env:check` / `npm run env:upgrade` add missing variables to an existing `.env` without touching any existing line.
- Funding: not stored per trade yet, so `ADI_INCLUDE_FUNDING` has no effect until it is (shown on the dashboard).

## Trade size
- Presets from `.env`: `MANUAL_MARGIN_PRESETS` (default 1,1.5,2,3,5,8,10,20), `MANUAL_LEVERAGE_PRESETS`; `MANUAL_MARGIN_STEP` (0.5) and `MANUAL_MARGIN_MIN` (0.1).
- Dashboard top bar: **- / +** buttons, presets, custom box (decimals fine). Applies to NEW trades only.
- **Take window: size box for that one trade** (live), with -/+ and presets; your saved default is not changed.
- Paper trades keep equity-based sizing (`SCALING_MARGIN_PCT`).

## Tests
- 463 tests, 0 failing (new: `tests/v71_features.test.js`, 44 tests).
